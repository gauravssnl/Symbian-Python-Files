import urlaudiostream,e32,appuifw
import sys
sys.setdefaultencoding('utf-8')

Name=''
def fu(num,err,ls):
  global Name
  if len(ls)==1:
    if ls[0] != Name:
      Name=ls[0]
      appuifw.app.body.color=0
      print ls[0]
      appuifw.app.body.color=0x993333 
      print "*"*33 
  else:
    appuifw.app.body.color=err and 0xdd0000 or 0x5555aa
    print ['stop','connect','connected','read info','play'][num]
    if err > 0:
      print ['','not supported','error read'][err]
    else:
     if  len(ls):
       appuifw.app.body.clear()
       print 'Bitrate:',ls[0]
       print 'Channels:',ls[1]
       print 'Frequency:',ls[2]
       print 'Name:',ls[3]
       print 'Description:',ls[4]
       print 'Genre:',ls[5]
       print '*'*33

st=urlaudiostream.New(fu)

Volume=30

def mfunc(vol):
  global Volume
  if vol==1 or vol==3:
    Volume+= (vol==1 and Volume<100 and 10) or (vol==3 and Volume>0 and -10)
    st.volume(Volume)


keys=None
try:
  import mediakeys
  keys=mediakeys.New(mfunc)
except: pass

#appuifw.app.body.clear()
#appuifw.app.body.focus = False
appuifw.app.title=u'Web Radio'

stan={\
  u"enter url": u'',\
  u"GoHa.Ru": u"http://radio.goha.ru:8000/grind.fm",\
  u"Authors songs": u"http://music.myradio.com.ua:8000/bard128.mp3", \
  u"Sunradio.ru reggae": u"http://radio.sunradio.ru:80/reggae64",\
  u"Frontiers records": u"http://newsletter.frontiers.it:8000/live.mp3",\
  u"Electronic": u"http://205.188.215.228:8006/", \
  u"Electronic house deep": u"http://scfire-mtc-aa01.stream.aol.com:80/stream/1007", \
  u"Ocaml radio": u"http://listen.42fm.ru:8000/stealkill.m3u", \
  u"Neformatnoe radio": u"http://neformatnoe.ru:8777/live.m3u", \
  u"Radiocanal melodia 128": u"http://stream128.melodiafm.spb.ru:8000/melodia128",\
  u"Radiocanal melodia 64": u"http://stream64.melodiafm.spb.ru:8000/melodia64", \
  u"Disco 80": u"http://music.myradio.com.ua:8000/Disco128.mp3", \
  u"Hymorfm online": u"http://81.19.85.195/umor32.mp3",\
  u"Radiofantasyki": u"http://fantasyradioru.no-ip.biz:8008/" ,\
  u"Rockradio1.com": u"http://91.121.201.88:8000/",\
  unicode("Радио шторм"): u"http://radio-shtorm.ru:8000/112", \
  unicode("Кабриолет"): u"http://setmedia.ru:8000/high3",\
  u"Staroe radio": u"http://www.staroeradio.ru/ices128.asx",\
  u"Hitroe radio": u"http://www.hitroe.com:8000/stream_original",\
  unicode("Геройское радио"): u"http://radio.heroeswm.ru:8000/", \
  unicode("Radiofunny-виктор цой"): u"http://radiofunny.org:8020/", \
  u"ZaycevFM": u"http://www.zaycev.fm:9001/", \
  u"Redburda.ru": u"http://radio.redburda.ru:8000/radio.m3u",\
  u"Gold balads": u"http://listen.rockfunk.ru:8007/listen",\
  u"Russian town  radio": u"http://russiantown.serverroom.us:8480/" }

##################

def start():
#  st.stop()
  index=appuifw.popup_menu(stan.keys(),u"Select")
  if index==None: return
  url=stan.values()[index]
  if url == u'':
    url=appuifw.query(u'enter url','text',u'http://')
    if url==None or len(url)<12 or url[:7] !=u'http://': return
    st.play(url)
  else:
    st.play(stan.values()[index])  
  appuifw.app.body.clear()
  

start()

app_lock = e32.Ao_lock()
def quit():
  app_lock.signal()
appuifw.app.exit_key_handler = quit

appuifw.app.menu=[(u"Play",start),(u"Stop",st.stop),(u"Exit",quit)]

app_lock.wait()
st.stop()
del  st
if keys: del keys
