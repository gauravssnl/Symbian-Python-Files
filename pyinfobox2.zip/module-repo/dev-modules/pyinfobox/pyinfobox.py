import _pyinfobox
def dialog(header=u"", text = u""):
	res = _pyinfobox.dialog(header, text)
	return res != 0
