#ifndef GLOBALNOTEMYPY_H
#define GLOBALNOTEMYPY_H

#include <e32std.h>
#include <e32base.h>

#include <eikenv.h>
#include <aknglobalnote.h> 


//-------------------------------------------------------------------------

class CGlobalNoteHandler: public CActive
 {
   public: 
     static CGlobalNoteHandler* NewL();
     CGlobalNoteHandler();
     ~CGlobalNoteHandler();
     
   public:
     void ShowNoteL(TInt aResource, const TDesC& aText, TAknGlobalNoteType aType); 

    protected: 
        void RunL();
        void DoCancel();
        TInt RunError( TInt aError );

    public: 

        CAknGlobalNote *iGlobalNote;
        TInt iNoteId;
        TInt iNoteReturn;
        CActiveSchedulerWait iWait;
  };

#endif
