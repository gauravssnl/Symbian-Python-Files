#include<avkon.rsg>

#include "globalnot.h"
#include "Python.h"
#include "symbian_python_ext_util.h"
//--------------------------------------------------------------------------

class CGlobalNoteCont;
//---------------------------------------------------------------------------

CGlobalNoteHandler::CGlobalNoteHandler() : CActive( EPriorityNormal )
{
  CActiveScheduler::Add( this );
}
 
//--------------------------------------------------------------------------

CGlobalNoteHandler::~CGlobalNoteHandler()
{
  Cancel();
  if(iGlobalNote)
    delete iGlobalNote;
}

//--------------------------------------------------------------------------

CGlobalNoteHandler* CGlobalNoteHandler::NewL()
{
	 CGlobalNoteHandler* ctrl = new  CGlobalNoteHandler();
  //	ctrl->ConstructL();
	 return ctrl;
}

//--------------------------------------------------------------------------
void CGlobalNoteHandler::ShowNoteL(TInt aResource,const TDesC16& aText, TAknGlobalNoteType aType)
 {
    if( iGlobalNote )
        return; 

    iGlobalNote = CAknGlobalNote::NewL();
    iGlobalNote->SetSoftkeys( aResource );
    iNoteId = iGlobalNote->ShowNoteL( iStatus, aType, aText );   
    SetActive();

 }

//--------------------------------------------------------------------------


void CGlobalNoteHandler::RunL()
{
    iGlobalNote->CancelNoteL( iNoteId );
    delete iGlobalNote;

    iGlobalNote = NULL;
    iNoteId = 0;
  
    iNoteReturn=  iStatus.Int();
    iWait.AsyncStop();
}


//--------------------------------------------------------------------------
// error occurs in RunL()
TInt CGlobalNoteHandler::RunError( TInt aError )
{
    // cancel note operation
    TRAP_IGNORE( iGlobalNote->CancelNoteL( iNoteId ) );
    delete iGlobalNote;
    iGlobalNote = NULL;
    iNoteId = 0;

    return 0;//iNoteClient.NoteError( aError );  // all errors are passed to client

}
//--------------------------------------------------------------------------
// system cancelled the note
void CGlobalNoteHandler::DoCancel()
 {
    // cancel note operation
    TRAP_IGNORE( iGlobalNote->CancelNoteL( iNoteId ) );
    delete iGlobalNote;
    iGlobalNote = NULL;
    iNoteId = 0;

  }
//==========================================================================

static PyObject* Show(PyObject* , PyObject* args) 
{
 PyObject* text=NULL;
 char *_type = NULL;
 TInt i_type;
 
 if (!PyArg_ParseTuple(args, "Us#",&text, &_type, &i_type))
    return NULL;
  
 if ( !PyUnicode_Check(text) )
  {
   PyErr_SetString(PyExc_ValueError, "argument is not unicode");
   return NULL;
  }
  
  TPtrC8 type_note((TUint8*)_type, i_type);
  TAknGlobalNoteType type;
  if (!type_note.Compare(_L8("note")))
        type = EAknGlobalInformationNote;
  else if (!type_note.Compare(_L8("warning")))
        type = EAknGlobalWarningNote;
  else if (!type_note.Compare(_L8("confirm")))
        type = EAknGlobalConfirmationNote;
  else if (!type_note.Compare(_L8("error")))
        type = EAknGlobalErrorNote;
  else if (!type_note.Compare(_L8("charging")))
        type = EAknGlobalChargingNote;
  else if (!type_note.Compare(_L8("wait")))
        type = EAknGlobalWaitNote;
  else if (!type_note.Compare(_L8("permanent")))
        type = EAknGlobalPermanentNote;
  else if (!type_note.Compare(_L8("not_charging")))
        type = EAknGlobalNotChargingNote;
  else if (!type_note.Compare(_L8("battery_full")))
        type = EAknGlobalBatteryFullNote;
  else if (!type_note.Compare(_L8("battery_low")))
        type = EAknGlobalBatteryLowNote;
  else if (!type_note.Compare(_L8("recharge_battery")))
        type = EAknGlobalRechargeBatteryNote;
  else if (!type_note.Compare(_L8("text")))
        type = EAknGlobalTextNote;
  else {
        PyErr_SetString(PyExc_ValueError, "Invalid type");
        return 0;
    }
  
  
  
  CGlobalNoteHandler* note = CGlobalNoteHandler::NewL();
  note->ShowNoteL(type == EAknGlobalConfirmationNote? R_AVKON_SOFTKEYS_YES_NO: R_AVKON_SOFTKEYS_OK_EMPTY, 
                      TPtrC((TUint16*) PyUnicode_AsUnicode(text), 
                                    PyUnicode_GetSize(text)), type);
  
  Py_BEGIN_ALLOW_THREADS
  note->iWait.Start();
  Py_END_ALLOW_THREADS
   
  TInt ret = note->iNoteReturn;
  delete note;

  return Py_BuildValue("i", ret);
}


//========================================================================

static const PyMethodDef globconfirm_met[] = {
   {"show", (PyCFunction)Show, METH_VARARGS},
   {0, 0}
};

//----------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("globconfirm", globconfirm_met);
}

