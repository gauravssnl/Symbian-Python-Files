import pybtswitch
pybtswitch.set_power_state(1)
print "all done"

