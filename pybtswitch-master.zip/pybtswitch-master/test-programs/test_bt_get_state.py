import pybtswitch
print(repr(pybtswitch.get_power_state()))
print "all done"
