import pybtswitch
pybtswitch.set_power_state(0)
print "all done"

