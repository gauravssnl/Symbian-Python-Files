#
# martin.wibbels@novay.nl
#
import e32
import time
import imagedecoder
import thread
import graphics
import struct

def notifyLoad(result, args):
	global lock
	global bitmap
	print "notifyLoad", result
	if isinstance(result, int):
		print "error", args
	else:
		bitmap = result
	lock.signal();

def notifySave(result, args):
	global lock
	if isinstance(result, int):
		print "error", result
	else:
	    #print result
		#print "len: " + len(result)
		open(u'c:\\convertout.png','w').write(result)
	lock.signal()

lock = e32.Ao_lock()

print "Calling decoder"
converter = imagedecoder.ConvertFileImageMime(u'c:\\basti.png',"image/png", notifyLoad, 10, 44, 44)
print "Decoder called"

print "Starting wait"
lock.wait()
print "Decoder done"

del converter

print "Calling encoder"
converter = imagedecoder.ConvertBitmap(bitmap, "image/png", notifySave, 75, 'default', 8, 1)
print "Encoder called"

print "Starting wait"
lock.wait()
print "Encoder done"

del converter
del bitmap