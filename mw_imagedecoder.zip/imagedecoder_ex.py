import e32
import time
import imagedecoder
import thread
import graphics
import struct
import e32dbm
import graphics

def notifyLoad(args):
    global lock
    global bitmap
    if isinstance(args, int):
        print "error", args
    else:
        bitmap = args
    lock.signal()

def notifySave(args):
	global lock
	global converted
	if isinstance(args, int):
		print "error", args
	else:
		converted = args
	lock.signal()

lock = e32.Ao_lock()

converter = imagedecoder.ConvertFileImageMime(u'c:\\basti.png',"image/png", notifyLoad, 6, 44, 44)

lock.wait()

del converter

converter = imagedecoder.ConvertBitmap(bitmap, "image/png", notifySave, 50, 'best', 8, 1)

lock.wait()

del converter
del bitmap

file = u"c:\\covers"

db = e32dbm.open(file, "r")

start = time.time()
for i in range(10):
    fromDB = db["basti"]
    #print "len", len(fromDB)

    #print "Calling decoder"
    converter = imagedecoder.ConvertImageMime(fromDB,"image/png",notifyLoad,6,44,44)
    #print "Decoder called"

    #print "Starting wait"
    lock.wait()
    #print "Decoder done"

    del converter
    
    im = graphics.Image.new((44,44),'RGB12')
    img = graphics.Image.from_cfbsbitmap(bitmap)
    #print "New img"
    del bitmap
    #print img
    #print img.size #(without this print statement, or any others in this for loop, Python crashes)
    im.blit(img,target=(0,44 - img.size[1]))

print time.time() - start
db.close()


