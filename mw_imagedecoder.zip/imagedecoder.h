//
// martin.wibbels@novay.nl
//
#ifndef IMAGEDECODER_H
#define IMAGEDECODER_H

#include <ImageConversion.h>
#include <f32file.h>
#include <FBS.H>

class CActiveImageDecoder : public CActive {

    public:
        CActiveImageDecoder();

		void ConstructFileL(char* fileName, int fileNameLen, char* mime, int mimeLen, PyObject* callback, int displayMode, int width, int height);

		void ConstructBufferL(char* data, int dataLen, char* mime, int mimeLen, PyObject* callback, int displayMode, int width, int height);

		void ConstructBitmapL(CFbsBitmap* image, char* mime, int mimeLen, PyObject* callback, int aQuality, 
		  TPngEncodeData::TPngCompressLevel aCompressionLevel, int aBpp, int aColor);

        virtual ~CActiveImageDecoder();

        void RunL();
        
        TInt RunError(TInt error);

        void DoCancel();

    private:
        void InvokeImageCallback(PyObject *arg);
		void ConstructL(CImageDecoder* decoder, PyObject* callback, int displayMode, int width, int height);

        PyObject *iImageCallback;
        CFbsBitmap* iImage;
        CImageDecoder* iDecoder;
        RFs ifsSession;
        HBufC8* iCopyDesc;
        CImageEncoder* iEncoder;
        CFrameImageData* iFrameImageData;
        HBufC8* iImageBuff;
};
#endif 
// End of File
