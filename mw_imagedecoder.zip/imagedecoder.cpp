////////////////////////////////////////////////////////////////////////////////////////////
// ImageDecoder Python Extension for Symbian S60 3rd edition FP1 and higher
//
// Author: Martin Wibbels
// martin.wibbels@novay.nl
//
////////////////////////////////////////////////////////////////////////////////////////////
#include <e32std.h>
#include <e32base.h>
#include <EIKBTGPC.H>
#include <avkon.hrh>
#include <aknnavi.h>
#include <aknnavide.h>
#include <eikspane.h>
#include <aknappui.h>
#include <f32file.h>
#include <FBS.H>

#include <ImageConversion.h>
#include <exifmodify.h>
#include <exiftag.h>

#include "Python.h"
#include "symbian_python_ext_util.h"

#include "imagedecoder.h"
#include "logger.h"

// PYTHON STUFF
#define imagedecoder_type_string "imagedecoder.ImageDecoder"
#define exifmodify_type_string "imagedecoder.ExifModify"

#define type_ImageDecoder (*(PyTypeObject*)SPyGetGlobalString(imagedecoder_type_string))
#define type_ExifModify (*(PyTypeObject*)SPyGetGlobalString(exifmodify_type_string))

#define RETURN_PYNONE \
  Py_INCREF(Py_None);\
  return Py_None;

	_LIT8(KJPEG, "image/jpeg");
	_LIT8(KPNG, "image/png");

typedef struct
{
    PyObject_HEAD;
	CActiveImageDecoder* iImageDecoder;
} obj_ImageDecoder;

typedef struct
{
    PyObject_HEAD;
	CExifModify* iExifModify;
} obj_ExifModify;

/// Utility stuff ////////////////////////////////////////////////////////////////////////////////////////////////
static obj_ImageDecoder* createImageDecoder(CActiveImageDecoder* decoder)
{
    obj_ImageDecoder *imageDecoder = PyObject_New(obj_ImageDecoder, &type_ImageDecoder);

    if (imageDecoder)
    {
        imageDecoder->iImageDecoder = decoder;
    }

    return imageDecoder;
}

static obj_ExifModify* createExifModify(CExifModify* exif)
{
    obj_ExifModify *exifModify = PyObject_New(obj_ExifModify, &type_ExifModify);

    if (exifModify)
    {
        exifModify->iExifModify = exif;
    }

    return exifModify;
}

CActiveImageDecoder::CActiveImageDecoder():CActive(EPriorityStandard)
{
    CActiveScheduler::Add(this);
    iImageCallback = NULL;
    iImage = NULL;
    iDecoder = NULL;
    iCopyDesc = NULL;
    iEncoder = NULL;
    iImageBuff = NULL; 
    iFrameImageData = NULL;
}
  
void CActiveImageDecoder::ConstructFileL(char* data, int dataLen, char* mime, int mimeLen, PyObject* callback, int displayMode, int width, int height) {
	User::LeaveIfError(ifsSession.Connect());

    TPtrC fileNameDesc((unsigned short*)data, dataLen);

    CImageDecoder* decoder;
    if (mime == NULL) {
    	decoder = CImageDecoder::FileNewL(ifsSession, fileNameDesc, CImageDecoder::EOptionAlwaysThread);
	}
	else {
	    TPtrC8 mimeTypeDesc((TUint8*)mime, mimeLen);
    	decoder = CImageDecoder::FileNewL(ifsSession, fileNameDesc, mimeTypeDesc, CImageDecoder::EOptionAlwaysThread);
	}
    CleanupStack::PushL(decoder); 
    	
    ConstructL(decoder, callback, displayMode, width, height);

    CleanupStack::Pop(); // decoder
    	
    SetActive();
	LOG(_L("Convert active object scheduled"));
}

void CActiveImageDecoder::ConstructBufferL(char* data, int dataLen, char* mime, int mimeLen, PyObject* callback, int displayMode, int width, int height) {
	User::LeaveIfError(ifsSession.Connect());

    TPtrC8 dataDesc((TUint8*)data, dataLen);

	iCopyDesc = dataDesc.AllocL();
	
    CImageDecoder* decoder;
    if (mime == NULL) {
    	decoder = CImageDecoder::DataNewL(ifsSession, *iCopyDesc, CImageDecoder::EOptionAlwaysThread);
	}
	else {
	    TPtrC8 mimeTypeDesc((TUint8*)mime, mimeLen);
    	decoder = CImageDecoder::DataNewL(ifsSession, *iCopyDesc, mimeTypeDesc, CImageDecoder::EOptionAlwaysThread);
	}
    CleanupStack::PushL(decoder); 
    	
    ConstructL(decoder, callback, displayMode, width, height);

    CleanupStack::Pop(); // decoder
    	
    SetActive();
	LOG(_L("Convert active object scheduled"));
}

#define ERROR(msg) do { PyErr_SetString(PyExc_ValueError,"error: " msg); return NULL; } while(0)

void CActiveImageDecoder::ConstructBitmapL(CFbsBitmap* image, char* mime, int mimeLen, PyObject* callback, int aQuality, 
		  TPngEncodeData::TPngCompressLevel aCompressionLevel, int aBpp, int aColor) {

	iImage = image;
	
  	iImageBuff = NULL;
  	
    TPtrC8 mimeTypeDesc((TUint8*)mime, mimeLen);

  	if (mimeTypeDesc == KJPEG) {
      iEncoder = CImageEncoder::DataNewL(iImageBuff, CImageEncoder::EOptionNone, KImageTypeJPGUid);
      CleanupStack::PushL(iEncoder);
      iFrameImageData=CFrameImageData::NewL();
      CleanupStack::PushL(iFrameImageData);
      TJpegImageData *imageData=new (ELeave) TJpegImageData;
      CleanupStack::PushL(imageData);
      if (aColor == 0) {
      	imageData->iSampleScheme=TJpegImageData::EMonochrome;
      }
      else {
      	imageData->iSampleScheme=TJpegImageData::EColor444;
      }
      imageData->iQualityFactor=aQuality;
      iFrameImageData->AppendImageData(imageData); // assumes ownership of imageData
      CleanupStack::Pop(imageData);
    }
    else if (mimeTypeDesc == KPNG) {
      iEncoder = CImageEncoder::DataNewL(iImageBuff, CImageEncoder::EOptionNone, KImageTypePNGUid);
      CleanupStack::PushL(iEncoder);
      iFrameImageData=CFrameImageData::NewL();
      CleanupStack::PushL(iFrameImageData);
      TPngEncodeData *frameData=new (ELeave) TPngEncodeData;
      CleanupStack::PushL(frameData);
      frameData->iLevel=aCompressionLevel;
      frameData->iBitsPerPixel=aBpp;
      frameData->iColor=aColor;
      frameData->iPaletted=EFalse;
      iFrameImageData->AppendFrameData(frameData); // assumes ownership of frameData
      CleanupStack::Pop(frameData);
    }

    iEncoder->Convert(&iStatus, *iImage, iFrameImageData);

    iImageCallback = callback;
    Py_XINCREF(callback);

    CleanupStack::Pop(iFrameImageData);
    CleanupStack::Pop(iEncoder);

    SetActive();
}

void CActiveImageDecoder::ConstructL(CImageDecoder* decoder, PyObject* callback, int displayMode, int width, int height) {
	CFbsBitmap* image = new (ELeave)CFbsBitmap();
	CleanupStack::PushL(image);
	
	TFrameInfo frameInfo = decoder->FrameInfo();
	if (displayMode == -1) displayMode = frameInfo.iFrameDisplayMode;

	if ((width == 0) || (height == 0)) {
   		LOG(_L("No size found"));
		// regular size
		User::LeaveIfError(image->Create(frameInfo.iOverallSizeInPixels, (TDisplayMode)displayMode));
	}
	else if ((frameInfo.iFlags & TFrameInfo::EFullyScaleable) == 0) {
   		LOG(_L("Size found, but not fully scaleable"));
		// must check if size is factor 2, 4 or 8, ...
		TSize dim = frameInfo.iOverallSizeInPixels;
		
		int factor = 256;
		int mask = 255;
		while ((factor > 1) && ((dim.iWidth / factor < width) || (dim.iHeight / factor < height))) {
			factor = factor >> 1;
			mask = mask >> 1;
		}
		
		// NOTE that we're ignoring the aspact ratio of the desired width/height here, and keep the aspect ratio of the original image
		int imgWidth = dim.iWidth / factor;
		int imgHeight = dim.iHeight / factor;
		
		if ((dim.iWidth & mask) != 0) imgWidth++;
		if ((dim.iHeight & mask) != 0) imgHeight++;
			
		User::LeaveIfError(image->Create(TSize(imgWidth, imgHeight), (TDisplayMode)displayMode));
	}
	else {
   		LOG(_L("Size found, fully scaleable"));
		User::LeaveIfError(image->Create(TSize(width, height), (TDisplayMode)displayMode));
	}
	
	LOG(_L("Calling convert"));
    decoder->Convert(&iStatus, *image);
	LOG(_L("Convert called"));

    CleanupStack::Pop(); // image

   	iImage = image;
   	iDecoder = decoder;
   	
    iImageCallback = callback;
    Py_XINCREF(callback);
}

CActiveImageDecoder::~CActiveImageDecoder()
{
	Cancel();
    Py_XDECREF(iImageCallback); 
    iImageCallback = NULL;
    if (iDecoder) delete iDecoder;
    if (iEncoder) delete iEncoder;
    if (iCopyDesc) delete iCopyDesc;
    if (iImageBuff) delete iImageBuff;
    if (iImage) delete iImage;
    if (iFrameImageData) delete iFrameImageData;
    ifsSession.Close();
	LOG(_L("Destructor done"));
}    
  
void CActiveImageDecoder::RunL()
{
	LOG(_L("RunL called"));
    // if iStatus == KErrCancel then we may be in a different thread? Anyway, don't do anything in the cancel case
    if (iStatus == KErrNone) {
        PyEval_RestoreThread(PYTHON_TLS->thread_state);
	    PyObject *arg;
	    if (iImageBuff == NULL) {
	    	arg =Py_BuildValue("(O)", PyCObject_FromVoidPtr(iImage, NULL));
            iImage = NULL; // hand over ownership of image
	    }
	    else {
			arg = Py_BuildValue("(s#)", iImageBuff->Ptr(), iImageBuff->Length());
	    }
        InvokeImageCallback(arg);
        PyEval_SaveThread();
    }
    else {
        PyEval_RestoreThread(PYTHON_TLS->thread_state);
	    PyObject *arg=Py_BuildValue("(i)", iStatus.Int());
        InvokeImageCallback(arg);
        PyEval_SaveThread();
   	}
}

TInt CActiveImageDecoder::RunError(TInt error) {
	LOG(_L("RunError"));
    PyEval_RestoreThread(PYTHON_TLS->thread_state);
    PyObject *arg=Py_BuildValue("(i)", error);
    InvokeImageCallback(arg);
    PyEval_SaveThread();
	return KErrNone;
}
  
void CActiveImageDecoder::DoCancel()
{
    if (iDecoder) iDecoder->Cancel();
}

void CActiveImageDecoder::InvokeImageCallback(PyObject *arg)
{
	LOG(_L("InvokeImageCallback"));
    if (iImageCallback) {
    	LOG(_L("InvokeImageCallback, callback is defined"));
        PyObject* rval = PyEval_CallObject(iImageCallback, (PyObject*)arg);
        Py_XDECREF(rval);
    }
    Py_XDECREF(arg);
}

/// ImageDecoder //////////////////////////////////////////////////////////////////////////////

// ctor (factory-function)
static PyObject* imagedecoder_Create(PyObject* /*self*/, PyObject* args)
{
	char* data;
	int dataLen;
	PyObject *callback;
	int width = 0;
	int height = 0;
	int displayMode = -1;

	if (PyArg_ParseTuple(args, "s#O|iii:Convert", &data, &dataLen, &callback, &displayMode, &width, &height))
    {
       
        CActiveImageDecoder* iImageDecoder = NULL;
        
	    TRAPD(err,
	        iImageDecoder = new CActiveImageDecoder();
	    	CleanupStack::PushL(iImageDecoder);
    	    iImageDecoder->ConstructBufferL(data, dataLen, NULL, 0, callback, displayMode, width, height);
	        CleanupStack::Pop(); // iImageDecoder
	    );
	
	    if (err)
	    {
	        return SPyErr_SetFromSymbianOSErr(err);
	    }
	
	    return (PyObject*)createImageDecoder(iImageDecoder);
	}
	return 0;
}

// ctor (factory-function)
static PyObject* imagedecoder_CreateMime(PyObject* /*self*/, PyObject* args)
{
	char* data;
	int dataLen;
	char* mime;
	int mimeLen;
	PyObject *callback;
	int width = 0;
	int height = 0;
	int displayMode = -1;

	if (PyArg_ParseTuple(args, "s#s#O|iii:Convert", &data, &dataLen, &mime, &mimeLen, &callback, &displayMode, &width, &height))
    {
       
        CActiveImageDecoder* iImageDecoder = NULL;
        
	    TRAPD(err,
	        iImageDecoder = new CActiveImageDecoder();
	    	CleanupStack::PushL(iImageDecoder);
    	    iImageDecoder->ConstructBufferL(data, dataLen, mime, mimeLen, callback, displayMode, width, height);
	        CleanupStack::Pop(); // iImageDecoder
	    );
	
	    if (err)
	    {
	        return SPyErr_SetFromSymbianOSErr(err);
	    }
	
	    return (PyObject*)createImageDecoder(iImageDecoder);
	}
	return 0;
}

// ctor (factory-function)
static PyObject* imagedecoder_CreateFile(PyObject* /*self*/, PyObject* args)
{
	char* data;
	int dataLen;
	PyObject *callback;
	int width = 0;
	int height = 0;
	int displayMode = -1;

	if (PyArg_ParseTuple(args, "u#O|ii:Convert", &data, &dataLen, &callback, &displayMode, &width, &height))
    {
       
        CActiveImageDecoder* iImageDecoder = NULL;
        
	    TRAPD(err,
	        iImageDecoder = new CActiveImageDecoder();
	    	CleanupStack::PushL(iImageDecoder);
    	    iImageDecoder->ConstructFileL(data, dataLen, NULL, 0, callback, displayMode, width, height);
	        CleanupStack::Pop(); // iImageDecoder
	    );
	
	    if (err)
	    {
	        return SPyErr_SetFromSymbianOSErr(err);
	    }
	
	    return (PyObject*)createImageDecoder(iImageDecoder);
	}
	return 0;
}

// ctor (factory-function)
static PyObject* imagedecoder_CreateFileMime(PyObject* /*self*/, PyObject* args)
{
	char* data;
	int dataLen;
	char* mime;
	int mimeLen;
	PyObject *callback;
	int width = 0;
	int height = 0;
	int displayMode = -1;

	if (PyArg_ParseTuple(args, "u#s#O|iii:Convert", &data, &dataLen, &mime, &mimeLen, &callback, &displayMode, &width, &height))
    {
       
        CActiveImageDecoder* iImageDecoder = NULL;
        
	    TRAPD(err,
	        iImageDecoder = new CActiveImageDecoder();
	    	CleanupStack::PushL(iImageDecoder);
    	    iImageDecoder->ConstructFileL(data, dataLen, mime, mimeLen, callback, displayMode, width, height);
	        CleanupStack::Pop(); // iImageDecoder
	    );
	
	    if (err)
	    {
	        return SPyErr_SetFromSymbianOSErr(err);
	    }
	
	    return (PyObject*)createImageDecoder(iImageDecoder);
	}
	return 0;
}

// (bitmap, callback, mime-type, 
static PyObject* imagedecoder_CreateBitmap(PyObject* /*self*/, PyObject *args)
{
  	PyObject *bitmap_object=NULL;
  	PyObject *callback=NULL;
	char* mime;
	int mimeLen;
  	char *compressionstring;
  	int quality, bpp, color=0;;
    if (!PyArg_ParseTuple(args, "Os#Oisii", &bitmap_object, &mime, &mimeLen, &callback, &quality, &compressionstring, &bpp, &color)) 
    	return NULL;  

	TPngEncodeData::TPngCompressLevel compression=TPngEncodeData::EDefaultCompression;
	CFbsBitmap *bitmap=(CFbsBitmap *)PyCObject_AsVoidPtr(bitmap_object);

    TPtrC8 mimeTypeDesc((TUint8*)mime, mimeLen);

  	if (mimeTypeDesc == KJPEG) {
    	if (quality < 0 || quality > 100) 
      		ERROR("invalid quality");    
  	} 
  	else if (mimeTypeDesc == KPNG) {
    	if (!strcmp(compressionstring,"default")) {
      		compression=TPngEncodeData::EDefaultCompression;
    	} 
    	else if (!strcmp(compressionstring,"no")) {
      		compression=TPngEncodeData::ENoCompression;
    	} 
    	else if (!strcmp(compressionstring,"fast")) {
      		compression=TPngEncodeData::EBestSpeed;
    	} 
    	else if (!strcmp(compressionstring,"best")) {
      		compression=TPngEncodeData::EBestCompression;
    	} 
    	else {
      		ERROR("invalid compression level");
    	}
    	switch (bpp) {
	    	case 1:
	    	case 8:
	    	case 24:
	    		break;
	    	default:
	      		ERROR("invalid number of bits per pixel");
    	}
  	} 
  	else {
    	ERROR("invalid format");
  	}
  
    CActiveImageDecoder* iImageDecoder = NULL;
    
    TRAPD(err,
        iImageDecoder = new CActiveImageDecoder();
    	CleanupStack::PushL(iImageDecoder);
	    iImageDecoder->ConstructBitmapL(bitmap, mime, mimeLen, callback, quality, compression, bpp, color);
        CleanupStack::Pop(); // iImageDecoder
    );

    if (err)
    {
        return SPyErr_SetFromSymbianOSErr(err);
    }

    return (PyObject*)createImageDecoder(iImageDecoder);
}

static PyObject* imagedecoder_stop(obj_ImageDecoder* self, PyObject* /*args*/) {
	self->iImageDecoder->Cancel();
	RETURN_PYNONE
}

// dtor
static void dealloc_ImageDecoder(obj_ImageDecoder* decoder)
{
	if (decoder->iImageDecoder) delete decoder->iImageDecoder;
    PyObject_Del(decoder);
}

static const PyMethodDef ImageDecoder_methods[] =
{
    {"Stop", (PyCFunction)imagedecoder_stop, METH_NOARGS, "void Stop()" },
    {NULL, NULL} /* sentinel */
};

static PyObject *getattr_ImageDecoder(PyObject *self, char *name)
{
    return Py_FindMethod(const_cast<PyMethodDef*>(&ImageDecoder_methods[0]), self, name);
}

static const PyTypeObject type_template_ImageDecoder =
{
/*******************************************************/
    PyObject_HEAD_INIT(0)    /* initialize to 0 to ensure Win32 portability */
    0,                 /*ob_size*/
    "imagedecoder.ImageDecoder",            /*tp_name*/
    sizeof(obj_ImageDecoder), /*tp_basicsize*/
    0,                 /*tp_itemsize*/
    /* methods */
    (destructor)dealloc_ImageDecoder, /*tp_dealloc*/
	 0, /*tp_print*/
    (getattrfunc)getattr_ImageDecoder, /*tp_getattr*/

    /* implied by ISO C: all zeros thereafter */
};


/// ExifModify //////////////////////////////////////////////////////////////////////////////

// ctor (factory-function)
static PyObject* exifmodify_Create(PyObject* /*self*/, PyObject* args)
{
	char* data;
	int dataLen;

	if (PyArg_ParseTuple(args, "s#:CreateExifModify", &data, &dataLen))
    {
        TPtrC8 dataDesc((TUint8*)data, dataLen);
		CExifModify* exif = 0;

		TRAPD(err,	
			TRAPD(error, exif = CExifModify::NewL(dataDesc));
			if(error == KErrCorrupt)
			{
				// no exif yet, or invalid
				exif = CExifModify::NewL(dataDesc, CExifModify::ECreate);
			}	
		);
	    if (err)
	    {
	        return SPyErr_SetFromSymbianOSErr(err);
	    }
	
	    return (PyObject*)createExifModify(exif);
	}
	return 0;
}

// dtor
static void dealloc_ExifModify(obj_ExifModify* exif)
{
	if (exif->iExifModify) delete exif->iExifModify;
    PyObject_Del(exif);
}

static PyObject* exifmodify_release(obj_ExifModify* self, PyObject* /*args*/) {
	TRAPD(err,
		if (self->iExifModify) {
			delete self->iExifModify;
		}
		self->iExifModify = 0;
	);
    RETURN_ERROR_OR_PYNONE(err);
}

static PyObject* exifmodify_SetTag(obj_ExifModify* self, PyObject* args) {
	TExifIfdType ifdType;
	int id;
	CExifTag::TExifTagDataType type;
	int count;
	char* data;
	int dataLen;

	if (PyArg_ParseTuple(args, "iiiis#:SetTag", &ifdType, &id, &type, &count, &data, &dataLen))
    {
    	TExifTagInfo info(id, type, count);
        TPtrC8 dataDesc((TUint8*)data, dataLen);

		TRAPD(err,
    		self->iExifModify->SetTagL(ifdType, info, dataDesc);
		);
	    RETURN_ERROR_OR_PYNONE(err);
    }
    
    return 0;
}

static PyObject* exifmodify_WriteData(obj_ExifModify* self, PyObject* args) {
	char* data;
	int dataLen;

	if (PyArg_ParseTuple(args, "s#:WriteData", &data, &dataLen))
    {
        TPtrC8 dataDesc((TUint8*)data, dataLen);
        HBufC8* resultData = NULL;

		TRAPD(err,
    		resultData = self->iExifModify->WriteDataL(dataDesc);
		);
	    if (err)
	    {
	        return SPyErr_SetFromSymbianOSErr(err);
	    }
		PyObject* result =  Py_BuildValue("s#", resultData->Ptr(), resultData->Length());
		delete resultData;
		return result;
    }
    
    return 0;
}

static const PyMethodDef ExifModify_methods[] =
{
    {"Release", (PyCFunction)exifmodify_release, METH_NOARGS, "void Release()" },
    {"SetTag", (PyCFunction)exifmodify_SetTag, METH_VARARGS, "void SetTag(int ifdType, int id, int type, int count, string data)" },
    {"WriteData", (PyCFunction)exifmodify_WriteData, METH_VARARGS, "string WriteData(string originalData)" },
    {NULL, NULL} /* sentinel */
};

static PyObject *getattr_ExifModify(PyObject *self, char *name)
{
    return Py_FindMethod(const_cast<PyMethodDef*>(&ExifModify_methods[0]), self, name);
}

static const PyTypeObject type_template_ExifModify =
{
/*******************************************************/
    PyObject_HEAD_INIT(0)    /* initialize to 0 to ensure Win32 portability */
    0,                 /*ob_size*/
    "imagedecoder.ExifModify",            /*tp_name*/
    sizeof(obj_ExifModify), /*tp_basicsize*/
    0,                 /*tp_itemsize*/
    /* methods */
    (destructor)dealloc_ExifModify, /*tp_dealloc*/
	 0, /*tp_print*/
    (getattrfunc)getattr_ExifModify, /*tp_getattr*/

    /* implied by ISO C: all zeros thereafter */
};


/// DLL ///////////////////////////////////////////////////////////////////////////////////////////

static const PyMethodDef module_methods[] =
{
    {"ConvertImage", (PyCFunction)imagedecoder_Create, METH_VARARGS},
    {"ConvertImageMime", (PyCFunction)imagedecoder_CreateMime, METH_VARARGS},
    {"ConvertFileImage", (PyCFunction)imagedecoder_CreateFile, METH_VARARGS},
    {"ConvertFileImageMime", (PyCFunction)imagedecoder_CreateFileMime, METH_VARARGS},
    {"ConvertBitmap", (PyCFunction)imagedecoder_CreateBitmap, METH_VARARGS},
    {"CreateExifModify", (PyCFunction)exifmodify_Create, METH_VARARGS},
	{0, 0} /* sentinel */
};

static bool createType(PyTypeObject typeTemplate, char* type_string)
{
	// do type
	PyTypeObject *newTypeObject = PyObject_New(PyTypeObject, &PyType_Type);
	if (!newTypeObject)
	{
   		PyErr_SetString(PyExc_Exception, "Alloc error");
		return false;
	}

    *newTypeObject = typeTemplate;

	TInt err = SPyAddGlobalString(type_string, (PyObject*)newTypeObject);
    if (0 != err) // 0 is success
	{
        PyObject_Del(newTypeObject);
   		PyErr_SetString(PyExc_Exception, "SPyAddGlobalString failed");
        return false;
	}

    // set the type of the type object to .... type!
    newTypeObject->ob_type = &PyType_Type;

    return true;
}

DL_EXPORT(void) init_imagedecoder()
{
  	// 3rd edition, use _imagedecoder for separate python loader
	Py_InitModule("_imagedecoder", (PyMethodDef*) module_methods);

	// create/register types
	if (!createType(type_template_ImageDecoder, imagedecoder_type_string)) return;
	if (!createType(type_template_ExifModify, exifmodify_type_string)) return;
}
	
