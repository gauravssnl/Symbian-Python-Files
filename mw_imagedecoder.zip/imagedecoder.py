#
# martin.wibbels@novay.nl
#
import e32

if e32.s60_version_info>=(3,0):
    import imp
    _imagedecoder=imp.load_dynamic('_imagedecoder', 'c:\\sys\\bin\\_imagedecoder.pyd')
    del imp
else:
    import _imagedecoder

del e32 #remove unnecessary names from namespace
from _imagedecoder import *
del _imagedecoder

EDefault = -1;
ENone = 0;
EGray2 = 1;
EGray4 = 2;
EGray16 = 3;
EGray256 = 4;
EColor16 = 5;
EColor256 = 6;
EColor64K = 7;
EColor16M = 8;
ERgb = 9;
EColor4K = 10;
EColor16MU = 11;
EColor16MA = 12;
EColorLast = 13;

EIfd0 = 0;
EIfdExif = 1;
EIfd1 = 2;
EIfdGps = 3;
EIfdIntOp = 4;

ETagByte = 1;
ETagAscii = 2;
ETagShort = 3;
ETagLong = 4;
ETagRational = 5;
ETagUndefined = 7;
ETagSlong = 9;
ETagSrational = 10;

