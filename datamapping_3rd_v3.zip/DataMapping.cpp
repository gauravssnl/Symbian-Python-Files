#include <apgcli.h>	
#include <apmstd.h>	
#include "Python.h"
#include "symbian_python_ext_util.h"


//--------------------------------------------------------------------------

static void SetAndUnSet(const TUid aUid,const TDesC8& aDes,TBool aEnable)
{
  RApaLsSession rapala;
  rapala.Connect();
  CleanupClosePushL(rapala);

  TDataType datatype(aDes);   //_L8("text/plain")
  //rapala.DeleteDataMapping(datatype);
  if (aEnable)
  {
     User::LeaveIfError(rapala.InsertDataMapping(datatype,
     TDataTypePriority(KDataTypePriorityHigh+1),aUid));
  }
  else {
   User::LeaveIfError(rapala.DeleteDataMapping(datatype));
  }

  CleanupStack::PopAndDestroy(); // rapala
}
//--------------------------------------------------------------------------

static PyObject* UnSet(PyObject* /*self*/,PyObject* args)
{
  TInt len;
  char* b = NULL;

  if (!PyArg_ParseTuple(args, "s#", &b, &len))
    return NULL;
  
  const TUid uid={0};
  
  SetAndUnSet(uid,TPtrC8((TUint8 *)b,len),EFalse);
  
  Py_INCREF(Py_None);
  return Py_None;
}

//--------------------------------------------------------------------------

static PyObject* Set(PyObject* /*self*/,PyObject* args)
{
  TInt len;
  char* b = NULL;
  TUint _uid;
  
  if (!PyArg_ParseTuple(args, "s#i", &b, &len,&_uid))
    return NULL;

  const TUid uid={_uid};

  SetAndUnSet(uid,TPtrC8((TUint8 *)b,len),ETrue);
  
  Py_INCREF(Py_None);
  return Py_None;
}

//--------------------------------------------------------------------------

static PyObject* Get(PyObject* /*self*/,PyObject* args)
{
  PyObject* obj_text;

  if (!PyArg_ParseTuple(args, "U", &obj_text))
    return NULL;

  TPtrC filename((TUint16*) PyUnicode_AsUnicode(obj_text),
                           PyUnicode_GetSize(obj_text));

  RApaLsSession rapala;
  rapala.Connect();
  CleanupClosePushL(rapala);

  TDataType datatype;
  TUid uid;
  
  rapala.AppForDocument(filename, uid, datatype);
  CleanupStack::PopAndDestroy(); // rapala

  return Py_BuildValue("s#i",datatype.Des8().Ptr(), datatype.Des8().Length(),(TUint)uid.iUid);
}
//--------------------------------------------------------------------------

static PyObject* GetData(PyObject* /*self*/,PyObject* args)
{
  TInt len;
  char* b = NULL;

  if (!PyArg_ParseTuple(args, "s#", &b, &len))
    return NULL;


  RApaLsSession rapala;
  rapala.Connect();
  CleanupClosePushL(rapala);

  TDataType datatype(TPtrC8((TUint8 *)b,len));
  TUid uid;

  rapala.AppForDataType(datatype, uid);
  CleanupStack::PopAndDestroy(); // rapala

  return Py_BuildValue("i",(TUint)uid.iUid);
}
//--------------------------------------------------------------------------

static PyObject* List(PyObject* /*self*/,PyObject* /*args*/)
{
  RApaLsSession rapala;
  rapala.Connect();
  CleanupClosePushL(rapala);

  CDataTypeArray* array = new (ELeave) CDataTypeArray(2); ;
  rapala.GetSupportedDataTypesL(*array);
  
  CleanupStack::PopAndDestroy(); // rapala
  
  TInt count = array->Count();
  PyObject* pyarr = PyList_New(count);
  
  for(TInt i=0; i<count; i++)
  {
    PyList_SetItem( pyarr, i,
                    Py_BuildValue("s#",(*array)[i].Des8().Ptr(),
                                 (*array)[i].Des8().Length()) );
  }
  
  array->Reset();
  delete array;

  return pyarr;
}

//--------------------------------------------------------------------------

static PyObject* GetApp(PyObject* /*self*/,PyObject* args)
{

  TUint _uid;

  if (!PyArg_ParseTuple(args, "i",&_uid))
    return NULL;

  const TUid uid={_uid};
  TApaAppInfo info;
  
  RApaLsSession rapala;
  rapala.Connect();
  CleanupClosePushL(rapala);
  rapala.GetAppInfo(info, uid);
  CleanupStack::PopAndDestroy(); // rapala
  
  return Py_BuildValue("u#u#",info.iShortCaption.Ptr(), info.iShortCaption.Length(), info.iFullName.Ptr(), info.iFullName.Length());

}
//--------------------------------------------------------------------------

static const PyMethodDef datamapping_met[] = {
    {"set", (PyCFunction)Set, METH_VARARGS},
    {"unset", (PyCFunction)UnSet, METH_VARARGS},
    {"list", (PyCFunction) List, METH_NOARGS},
    {"get_for_doc", (PyCFunction) Get, METH_VARARGS},
    {"get_for_data", (PyCFunction) GetData, METH_VARARGS},
    {"get_appinfo", (PyCFunction) GetApp, METH_VARARGS},
    {0, 0}
};
//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
    Py_InitModule("datamapping", datamapping_met);
}

//--------------------------------------------------------------------------

#ifndef EKA2
GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
}
#endif
