from appuifw import *
import e32
import os
import miso
import key_codes
import key
from graphics import *
from sysinfo import *
from graphics import Image
from graphics import screenshot
import fgimage
from graphics import Image
from e32 import ao_sleep
from fgimage import FGImage
from sysinfo import display_pixels
from graphics import *
import topwindow
from akntextutils import *
from sysinfo import display_pixels as display_pixels
from TopWindow import TopWindow
w, h = display_pixels()
s_x = (w / 176.0)
s_y = (h / 208.0)
if os.path.exists('E:\\System\\Libs\\') : 
    Graph = 'E:\\System\\Libs\\'
elif os.path.exists('E:\\Python\\') : 
    Graph = 'E:\\Python\\'
else :
    appuifw.note(u"ERROR CONTACT AAN",'error')

im1=Image.open(Graph+'nb.tmb')
im2=Image.open(Graph+'nb.msk')
ly1, ly2 = display_pixels()
class AAN(object, ) :
    __module__ = __name__
    __module__ = __name__
    def __init__(s):
        s.Bg = Image.new((ly1, ly2))
        s.canvas = Canvas(event_callback = None, redraw_callback = s.Handle_redraw)
        s.f1 = (u'LatinPlain12', 12)
        s.f2 = (u'LatinBold19', 19)
        s.txt = s.Bg.text
        s.im = s.Bg.measure_text
        s.t1 = 'Modules For Note V1'
        s.t1a = '-== Aan Gabriel ==-'
        s.t2 = '** Note with window **'
        s.t2a = '** Mprogres bar **'
        s.t2b = '** Cleare Screen **'
        s.t3 = '** Note with Smoth **'
        s.t3a = '** Note with images **'
        s.t3b = 'http://fb.me/mobile.clubz'
        s.t4 = 'http://nircable.com'
        s.t4a = 'http://malware.us.to'
        s.t4b = 'http://zombie.heck.in'
        s.t5 = 'A A N  G A B R I E L'
        s.vh = [3, 200, 1]
        s.m, s.p, s.g = (13631488, 15658734, 53248)


    def Handle_redraw(s, rect):
        s.canvas.blit(s.Bg)


    def Screen(s):
        app.screen = 'full'
        app.body = s.canvas
        s.Bg(0)
        s.Handle_redraw(())


    def quit(s):
        s.Looping = False


    def joe(s, y, teks, wrn, font):
        s.bbox, s.advance, s.ichars = s.im(unicode(teks), font)
        s.lbr = s.bbox[2]
        s.x = (int((s.Bg.size[0] - s.lbr)) / 2)
        s.xy = (s.x, y)
        s.tl = (0, y)
        s.o = ((s.tl[0] - s.bbox[0]), s.tl[1])
        s.txt(s.xy, unicode(teks), wrn, font)


    def Main(s):
        s.Looping = True
        app.menu = []
        app.exit_key_handler = lambda  :  s.quit() 
        app.screen = 'full'
        app.body = s.canvas
        while s.Looping : 
            s.Bg.clear(0)
            s.joe((s.vh[1] - 3), s.t1, s.m, s.f2)
            s.joe((s.vh[1] + 30), s.t2, s.g, s.f1)
            s.joe((s.vh[1] + 45), s.t2a, s.p, s.f1)
            s.joe((s.vh[1] + 60), s.t2b, s.p, s.f1)
            s.joe((s.vh[1] + 90), s.t3, s.g, s.f1)
            s.joe((s.vh[1] + 105), s.t3a, s.p, s.f1)
            s.joe((s.vh[1] + 120), s.t3b, s.p, s.f1)
            s.joe((s.vh[1] + 150), s.t4, s.g, s.f1)
            s.joe((s.vh[1] + 165), s.t4a, s.p, s.f1)
            s.joe((s.vh[1] + 180), s.t4b, s.p, s.f1)
            s.joe((s.vh[1] + 210), s.t5, s.g, s.f1)
            s.Handle_redraw(())
            e32.ao_yield()
            if s.vh[1] > -208 : 
                s.vh[1] -= 1
            if s.vh[1] < -207 : 
                s.vh[1] = 211


class Device(object, ) :
    __module__ = __name__
    __module__ = __name__
    def __init__(s):
        s.Bg = Image.new((ly1, ly2))
        s.canvas = Canvas(event_callback = None, redraw_callback = s.Handle_redraw)
        s.m, s.p, s.g = (13631488, 15658734, 53248)
        s.f1 = (u'LatinPlain12', 12)
        s.f2 = (u'LatinBold13', 13)
        s.txt = s.Bg.text
        s.im = s.Bg.measure_text
        s.total_r = total_ram()
        s.free_r = free_ram()
        s.using_r = (s.total_r - s.free_r)
        s.profile = active_profile()
        s.dsizes = free_drivespace()
        s.version = sw_version()
        s.osversion = os_version()
        s.imei = imei()
        s.screen = str(display_pixels())
        s.cpuhead = miso.get_hal_attr(11)
        s.drivers = e32.drive_list()
        s.pyvers = e32.pys60_version
        s.syvinfo = e32.s60_version_info
        s.s_list = s.version.split(' ')
        s.s_vers = s.version.split(' ')[1]
        s.s_date = s.version.split(' ')[2]
        s.s_firm = s.version.split(' ')[3]
        s.mapping_firmware_model = {'RM-51' : '3230', 'RM-38' : '3250', 'NHM-10' : '3600', 'NHM-10X' : '3620', 'NHL-8' : '3650', 'RM-133' : 'N73-1 (SoftBank 705NK)', 'NHL-8X' : '3660', 'RM-25' : '6260', 'RM-29' : '6260b', 'NHL-10' : '6600', 'NHL-12' : '6620', 'NHL-12X' : '6620', 'RM-1' : '6630', 'RH-67' : '6670', 'RH-68' : '6670b', 'RM-36' : '6680', 'RM-57' : '6681', 'RM-58' : '6682', 'RH-51' : '7610', 'RH-52' : '7610b', 'NHL-2NA' : '7650', 'RM-49' : 'E60-1', 'RM-89' : 'E61-1', 'RM-10' : 'E70-1', 'RM-24' : 'E70-?', 'NEM-4' : 'N-Gage', 'RH-29' : 'N-Gage QD (asia/europe)', 'RH-47' : 'N-Gage QD (americas)', 'RM-84' : 'N70-1', 'RM-99' : 'N70-5', 'RM-67' : 'N71-1', 'RM-112' : 'N71-5', 'RM-91' : 'N80-3', 'RM-92' : 'N80-1', 'RM-42' : 'N90-1', 'RM-43' : 'N91-1', 'RM-158' : 'N91-5'}
        s.mapping_prefix_description = {'N' : 'Mobile Phone', 'R' : 'Computing Device', 'T' : 'Terminal'}
        s.mapping_suffix_description = {'B' : 'GSM 900/1900', 'C' : 'DAMPS 800', 'D' : 'CDMA/AMPS 800', 'E' : 'GSM 900/1800', 'F' : 'NMT-450', 'K' : 'GSM 1800', 'L' : 'GSM 900/1800/1900 or GSM 850/1800/1900', 'M' : 'EGSM 900/1800 (support WCDMA)', 'N' : 'IEEE 802.11b', 'P' : 'CDMA 800', 'W' : 'AMPS/TDMA 800/1900', 'X' : 'ETACS/TACS'}
        s.sdk_name = {(1, 2) : 'SDK S60 1st Edition', (2, 0) : 'SDK S60 2nd', (2, 6) : 'SDK S60 2nd Edition FP 2', (2, 8) : 'SDK S60 2nd Edition FP 3', (3, 0) : 'SDK S60 3rd Edition'}
        s.firmcode = s.s_firm.split('-')
        s.firmware_prefix = s.firmcode[0][0]
        s.firmware_suffix = s.firmcode[0][-1]
        s.firmware_date = s.s_date
        s.phone_name = s.mapping_firmware_model[s.s_firm]
        s.prefix_name = s.mapping_prefix_description[s.firmware_prefix]
        s.suffix_name = s.mapping_suffix_description[s.firmware_suffix]


    def Handle_redraw(s, rect):
        s.canvas.blit(s.Bg)


    def Screen(s):
        app.screen = 'full'
        app.body = s.canvas
        s.Bg.clear(2105376)
        s.Handle_redraw(())


    def quit(s):
        s.Looping = False


    def fo(s, type, value):
        if type == 'byte' : 
            return (('%.1f' % float(value)) + u' ' + type)
        elif type == 'kb' : 
            return (('%.1f' % (float(value) / 1024)) + u' ' + type)
        elif type == 'mb' : 
            return (('%.1f' % (float(value) / 1048576)) + u' ' + type)
        elif type == 'hz' : 
            return (('%.1f' % float(value)) + u' ' + type)
        elif type == 'mhz' : 
            return (('%.1f' % (float(value) / 1000)) + u' ' + type)
        else : 
            pass


    def Ram(s, type):
        if type == 'Free' : 
            return s.fo('mb', s.free_r)
        elif type == 'Total' : 
            return s.fo('mb', s.total_r)
        elif type == 'Used' : 
            return s.fo('mb', s.using_r)
        else : 
            pass


    def Info(s, type):
        profile_name = {'general' : u'General', 'silent' : u'Silent', 'meeting' : u'Meeting', 'outdoor' : u'Outdoor', 'pager' : u'Pager', 'offline' : u'Offline', 'drive' : u'Drive'}
        if type == 'Profil' : 
            return profile_name[s.profile]
        elif type == 'PyVersion' : 
            return s.pyvers
        elif type == 'S60Version' : 
            return s.sdk_name[s.syvinfo]
        elif type == 'CPUSpeed' : 
            return s.fo('mhz', s.cpuhead)
        elif type == 'ScrRes' : 
            cord = s.screen[1 : 9]
            cordinat = cord.split(',')
            return ((cordinat[0] + ' x') + cordinat[1])
        else : 
            pass


    def Tel(s, type):
        if type == 'Model' : 
            return s.phone_name
        elif type == 'Imei' : 
            return s.imei
        elif type == 'GSM' : 
            return s.suffix_name
        elif type == 'Prefix' : 
            return s.prefix_name
        elif type == 'Date' : 
            return s.firmware_date
        else : 
            pass


    def Main(s):
        s.Looping = True
        app.menu = []
        app.exit_key_handler = lambda  :  s.quit() 
        app.screen = 'full'
        app.body = s.canvas
        s.Bg.clear(2105376)
        while s.Looping : 
            s.txt((5, 13), u'Memori', s.m, s.f2)
            s.txt((5, 27), (u'RAM Free : ' + s.Ram('Free')), s.p, s.f1)
            s.txt((5, 39), (u'RAM Used : ' + s.Ram('Used')), s.p, s.f1)
            s.txt((5, 51), (u'RAM Total : ' + s.Ram('Total')), s.p, s.f1)
            s.txt((5, 72), u'Telephone', s.m, s.f2)
            s.txt((5, 87), u'Model : ', s.p, s.f1)
            s.txt((43, 87), (u'' + s.Tel('Model')), s.g, s.f1)
            s.txt((5, 99), u'IMEI : ', s.p, s.f1)
            s.txt((32, 99), (u'' + s.Tel('Imei')), s.g, s.f1)
            s.txt((5, 111), (u'' + s.Tel('GSM')), s.p, s.f1)
            s.txt((5, 123), (u'' + s.Tel('Prefix')), s.p, s.f1)
            s.txt((5, 135), u'Firmware Date :', s.p, s.f1)
            s.txt((87, 135), (u'' + s.Tel('Date')), s.p, s.f1)
            s.txt((5, 154), u'Device', s.m, s.f2)
            s.txt((5, 168), (u'Profil : ' + s.Info('Profil')), s.p, s.f1)
            s.txt((5, 180), (u'CPU Speed : ' + s.Info('CPUSpeed')), s.p, s.f1)
            s.txt((5, 192), (u'' + s.Info('S60Version')), s.p, s.f1)
            s.txt((5, 204), (u'Python Version : ' + s.Info('PyVersion')), s.p, s.f1)
            s.Handle_redraw(())
            e32.ao_yield()



def toMask(img):
 msk=Image.new(img.size,'L')
 msk.blit(img)
 return msk
class New:
 def __init__(s,pos=(30,20)):
  s.pos=pos
  s.fg=fgimage.FGImage()
 def Show(s,txt=u'',timeout=0):
  img=im1
  msk=toMask(im2)
  ss=screenshot()
  bg=Image.new(img.size)
  bg.blit(ss,target=(-s.pos[0],-s.pos[1]))
  bg.blit(img,mask=msk)
  bg.text((25,17),unicode(txt),(231,231,231))
  s.fg.set(s.pos[0],s.pos[1],bg._bitmapapi())
  if timeout:
   e32.ao_sleep(timeout,lambda:s.Hide())
 def Hide(s):
  s.fg.unset()

def ru(text):
    return text.decode('utf-8')

class Cleared:
    __module__ = __name__

    def __init__(s, color_background=0xffffff, color_text=0, text='GOODBYE', size_text=40):
        s.color_background = color_background
        s.color_text = color_text
        s.text = text
        s.size_text = size_text
        size_dislay = display_pixels()
        s.x = size_dislay[0]
        s.y = size_dislay[1]
        s.fg = FGImage()
        s.img = Image.new(size_dislay)
        s.quit()

    def quit(s):
        scr = screenshot()
        a = s.img.measure_text(ru(s.text), font = (None, s.size_text))
        for d in xrange(0, max(s.x, s.y) / 2 + 10, 5):
            s.img.clear(s.color_background)
            s.img.text(((s.x - a[0][2]) / 2, (s.y + s.size_text) / 2), ru(s.text), fill = s.color_text, font = (None, s.size_text))
            s.img.blit(scr, source = (0, 0, s.x / 2, s.y / 2), target = (-d, -d, s.x / 2 - d, s.y /2 - d))
            s.img.blit(scr, source = (0, s.y / 2, s.x / 2, s.y), target = (-d, s.y / 2 + d, s.x / 2 - d, s.y + d))
            s.img.blit(scr, source = (s.x / 2 , 0, s.x, s.y / 2), target = (s.x / 2 + d, -d, s.x + d, s.y / 2 - d))
            s.img.blit(scr, source = (s.x / 2, s.y / 2, s.x, s.y), target = (s.x / 2 + d, s.y / 2 + d, s.x + d, s.y + d))

            s.fg.set(0, 0, s.img._bitmapapi())
            ao_sleep(.01)
        ao_sleep(2)
        s.fg.unset()



class net(object, ) :
    __module__ = __name__
    __module__ = __name__
    __module__ = __name__
    __module__ = __name__
    __module__ = __name__
    def __init__(self, text, type = 'info'):
        self.width = 170
        if type == 'error' : 
            self.warna = 14291217
            self.warna2 = 16737894
            self.delay = 1
        elif type == 'conf' : 
            self.warna = 1169937
            self.warna2 = 6750054
            self.delay = 0.5
        else : 
            self.warna = 1118682
            self.warna2 = 6711039
            self.delay = 1.5
        self.line = wrap_text_to_array(text, 'legend', (self.width - 5))
        self.height = ((len(self.line) + 1) * 15)
        self.screen_pixel = display_pixels()
        self.left = ((self.screen_pixel[0] - self.width) / 2)
        self.top = ((self.screen_pixel[1] - self.height) / 2)
        self.right = (self.left + self.width)
        self.bottom = (self.top + self.height)
        self.color = 0
        self.textcoord = (5, 15)
        self.textfont = u'latinbold12'
        self.textcolor = 0
        self.window = topwindow.TopWindow()
        self.window.size = (self.width, self.height)
        self.window.position = (self.left, self.top)
        self.window._set_bg_color(0)
        self.window._set_shadow(2)
        self.window.corner_type = 'corner2'
        self.img = Image.new((self.width, self.height))
        self.window.add_image(self.img, (0, 0, self.width, self.height))
        self.tampil()
        e32.ao_sleep(self.delay)
        self.mislep()
        e32.ao_sleep(0.3)


    def showadd(self):
        self.window.show()


    def reset(self):
        self.img.rectangle((1, 1, (self.width - 1), (self.height - 1)), self.warna2, self.warna, width = 3)
        self.my = 5
        for i in self.line:
            self.img.text((6, (15 + self.my)), i, 0, 'legend')
            self.my += 15
        self.window.remove_image(self.window.images[0][0])
        self.window.add_image(self.img, (0, 0, self.width, self.height))


    def tampil(self):
        self.n = 0
        self.m = 0
        while self.m < ((len(self.line) + 2) * 15) : 
            self.reset()
            e32.ao_sleep(0.03)
            self.window.position = (self.left, (208 - self.m))
            self.showadd()
            self.n += 1
            self.m += 4


    def mislep(self):
        self.n = 0
        while self.m >= 0 : 
            self.reset()
            e32.ao_sleep(0.03)
            self.window.position = (self.left, (208 - self.m))
            self.showadd()
            self.n += 1
            self.m -= 4



class notif(object, ) :
    __module__ = __name__
    __module__ = __name__
    __module__ = __name__
    __module__ = __name__
    __module__ = __name__
    def __init__(self, teks, m = 'info'):
        if m == 'error' : 
            self.wrn = 14291217
            self.tit = 'Error'
            self.delay = 1.5
        elif m == 'conf' : 
            self.wrn = 1169937
            self.tit = 'Konfirmasi'
            self.delay = 1
        else : 
            self.wrn = 7051007
            self.tit = 'Info'
            self.delay = 2
        teks = wrap_text_to_array(teks, u'latinbold12', (166 * s_x))
        self.win = topwindow.TopWindow()
        self.win.position = ((12 * s_x), (70 * s_y))
        self.win._set_shadow(2)
        self.win.corner_type = 'square'
        f = Image.new(((150 * s_x), ((14 + (22 * len(teks))) * s_y)))
        f.rectangle((0, 0, (150 * s_x), ((14 + (22 * len(teks))) * s_y)), fill = 14737632)
        f.rectangle((s_x, s_y, (149 * s_x), (18 * s_y)), outline = 15658734, fill = self.wrn)
        f.text(((5 * s_x), (15 * s_y)), unicode(self.tit, 'utf-8'), 0, font = u'latinbold12')
        m = 0
        for x in teks:
            m += 1
            f.text(((5 * s_x), ((12 + (18 * m)) * s_y)), x, 0, font = u'latinplain12')
        e32.reset_inactivity()
        self.win.size = ((150 * s_x), ((14 + (22 * len(teks))) * s_y))
        self.win.add_image(f, (0, 0))
        self.tampil()
        e32.ao_sleep(self.delay)
        self.mislep()
        e32.ao_sleep(0.3)


    def showadd(self):
        self.win.show()


    def tampil(self):
        self.showadd()


    def mislep(self):
        self.showadd()


class MPB(object):
    def __init__(self,):
        self.coords = 36,102
        self.height,self.width = 16,106
        self.outline = 0x8c8a8c
        self.font = (u"LatinPlain12", 11)
        self.text = "Loading..."
        self.value = 0

    def start(self, r,per):
        self.per = per;del per
        self.range = r;del r
        self.window = TopWindow()
        self.window.corner_type = 'square'
        self.window.size = (self.width,self.height)
        self.window.position = (self.coords[0], self.coords[1])
        self.pbimg = Image.new((self.width,self.height))
        self.pbimg.rectangle((0, 0, self.width, self.height), outline=self.outline, fill=0x0)

    def close(self):
        del self.pbimg
        self.window.hide()
        del self.window
 
    def set_values(self, value, text):
        self.value = value*(self.width/float(self.range))
        self.text = text
        self.redraw()
 
    def redraw(self):
        for x in range(self.height-2):
           self.pbimg.line((1,x+1,self.width-1,x+1), self.color_combine("gray")[x])
           self.pbimg.line((1,x+1,self.value,x+1), self.color_combine("blue")[x])
        self.pbimg.text((35, 13),self.text.decode("u8"), fill = 0x0,font = self.font)
        if self.per : self.pbimg.text((3, 13),'%'+str(int((self.value/self.width)*100)).decode("u8"), fill = 0x222222,font = self.font)
        self.window.add_image(self.pbimg,(0,0))
        self.window.show()

    def color_combine(self,color):
        bluel = [(74, 117, 181),(99, 162, 247),(99, 162, 239),(107, 170, 239),(123, 178, 239),(132, 182, 247),(140, 186, 247),(140, 190, 247),(140, 190, 247),(140, 190, 247),(140, 190, 247),(132, 182, 247),(123, 178, 239),(115, 170, 239),(107, 166, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239),(107, 162, 239)]
        collist = [(156, 158, 156),(165, 166, 165),(181, 174, 181),(189, 186, 189),(198, 195, 198),(214, 207, 214),(214, 215, 214),(222, 219, 222),(222, 223, 222),(222, 223, 222),(222, 223, 222),(222, 223, 222),(222, 219, 222),(222, 219, 222),(214, 215, 214)]
        if color == "gray":return collist
        elif color == "blue": return bluel



# public API
__all__= ('net',
          'notif',
          'Show',
          'New',
          'AAN',
          'Cleared',
          'MPB')