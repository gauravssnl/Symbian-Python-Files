#include<avkon.rsg>
#include <aknglobalnote.h> //GlobalNote

#include "globalnot.h"
#include "Python.h"
#include "symbian_python_ext_util.h"
//--------------------------------------------------------------------------

class CGlobalNoteCont;
//---------------------------------------------------------------------------

CGlobalNoteHandler::CGlobalNoteHandler() : CActive( EPriorityNormal )
{
  CActiveScheduler::Add( this );
}
 
//--------------------------------------------------------------------------

CGlobalNoteHandler::~CGlobalNoteHandler()
{
  Cancel();
  if(iGlobalNote)
    delete iGlobalNote;
}

//--------------------------------------------------------------------------

CGlobalNoteHandler* CGlobalNoteHandler::NewL()
{
	CGlobalNoteHandler* ctrl = new  CGlobalNoteHandler();
 //	CleanupStack::PushL(ctrl);
 //	ctrl->ConstructL();
 //	CleanupStack::Pop(ctrl);
	return ctrl;
}

//--------------------------------------------------------------------------
// showing the note

void CGlobalNoteHandler::ShowNoteL(TInt aResource,const TDesC16& aText/*, MGlobalNoteClient*& aClient */)
 {
    if( iGlobalNote )
        return;  // do not do anything if a note is already shown

    iGlobalNote = CAknGlobalNote::NewL();
    iGlobalNote->SetSoftkeys( aResource );
    iNoteId = iGlobalNote->ShowNoteL( iStatus, EAknGlobalConfirmationNote, aText );//EAknGlobalConfirmationNote  EAknGlobalTextNote    
    SetActive();

 }

//--------------------------------------------------------------------------

void CGlobalNoteHandler::RunL()
 {
    iGlobalNote->CancelNoteL( iNoteId );
    delete iGlobalNote;
    iGlobalNote = NULL;
    iNoteId = 0;
    iNoteReturn=  iStatus.Int();
    iWait.AsyncStop();
 }


//--------------------------------------------------------------------------

TInt CGlobalNoteHandler::RunError( TInt aError )
{
    TRAP_IGNORE( iGlobalNote->CancelNoteL( iNoteId ) );
    delete iGlobalNote;
    iGlobalNote = NULL;
    iNoteId = 0;
    return 0;//iNoteClient.NoteError( aError );  
}

//--------------------------------------------------------------------------

void CGlobalNoteHandler::DoCancel()
 {
    TRAP_IGNORE( iGlobalNote->CancelNoteL( iNoteId ) );
    delete iGlobalNote;
    iGlobalNote = NULL;
    iNoteId = 0;
  }

//==========================================================================

static PyObject* Show(PyObject* , PyObject* args) 
{
  PyObject* text=NULL;

  if (!PyArg_ParseTuple(args, "O",&text))
    return NULL;
  
  if ( !PyUnicode_Check(text) )
  {
   PyErr_SetString(PyExc_ValueError, "argument is not unicode");
   return NULL;
  }
  
  CGlobalNoteHandler* note = CGlobalNoteHandler::NewL();
  note->ShowNoteL(R_AVKON_SOFTKEYS_OK_EMPTY, TPtrC((TUint16*) PyUnicode_AsUnicode(text),  PyUnicode_GetSize(text)));
  
  Py_BEGIN_ALLOW_THREADS
  note->iWait.Start();
  Py_END_ALLOW_THREADS
   
  TInt ret = note->iNoteReturn;
  delete note;

  return Py_BuildValue("i", ret);
}


//=======================================================================

static const PyMethodDef globconfirm_met[] = {
    {"show", (PyCFunction)Show, METH_VARARGS},
    {0, 0}
};

//----------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
    Py_InitModule("globconfirm", globconfirm_met);
}

//----------------------------------------------------------------------

GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone; 
}
