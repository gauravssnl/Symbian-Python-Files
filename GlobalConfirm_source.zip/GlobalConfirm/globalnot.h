#ifndef GLOBALNOTEMYPY_H
#define GLOBALNOTEMYPY_H
  
#include <e32std.h>
#include <e32base.h>
#include <eikenv.h>
#include <aknglobalnote.h> 


//-------------------------------------------------------------------------
/*
class MGlobalNoteClient
 {
    public:
        virtual void HandleCommandL( TInt aCommand ) = 0;
        virtual TInt NoteError( TInt aError ) = 0;
  };
*/
//-------------------------------------------------------------------------

class CGlobalNoteHandler: public CActive
 {
   public: 
     static CGlobalNoteHandler* NewL();
     CGlobalNoteHandler();
     ~CGlobalNoteHandler();
     
   public: 

     void ShowNoteL(
            TInt aResource, 
            const TDesC& aText); 
            //,MGlobalNoteClient*& aClient );

    protected:  // from CActive
    
        void RunL();
        void DoCancel();
        TInt RunError( TInt aError );


    public:  // data

        CAknGlobalNote *iGlobalNote;
        TInt iNoteId;
        TInt iNoteReturn;
        CActiveSchedulerWait iWait;
  };



#endif
