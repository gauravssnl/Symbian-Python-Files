#include <fbs.h> //CFbsBitmap
#include <aknsskininstance.h> //MAknsSkinInstance
#include <aknsutils.h> //AknsUtils
#include <f32file.h>
#include <apgcli.h>
  
#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Get(PyObject* /*self*/,PyObject* args)
{                       

  TUint width;
  TUint height;
  if (!PyArg_ParseTuple(args, "(ii)", &width, &height))
    return NULL;
    
  TSize size(width, height);
 
  RApaLsSession lsSession;
  User::LeaveIfError( lsSession.Connect() );
  CleanupClosePushL( lsSession );
  TInt count;
  lsSession.AppCount(count);
  PyObject* arr = PyList_New(count);
  TApaAppInfo appInfo;
  lsSession.GetAllApps();
  MAknsSkinInstance* skin = AknsUtils::SkinInstance();
  
  for(TInt i=0; i<count; i++)
  {
    CFbsBitmap*	img(NULL);
    CFbsBitmap*	img_mask(NULL);

    lsSession.GetNextApp(appInfo);
    
	   //TRAPD(err,  Since both the bitmaps are left in the cleanup stack, call to this method can not be enclosed in an immediate TRAP.  без TRAP вылет -46
	   TRAPD(err,
    AknsUtils::CreateAppIconLC(skin, appInfo.iUid, EAknsAppIconTypeContext, img, img_mask);
	   CleanupStack::Pop(2); );

    AknIconUtils::SetSize(img, size);
    AknIconUtils::SetSize(img_mask, size);
    
    PyList_SetItem( arr, i, img==NULL? Py_BuildValue("iu#u#ii",(TUint)appInfo.iUid.iUid, appInfo.iCaption.Ptr(), appInfo.iCaption.Length(),appInfo.iFullName.Ptr(), appInfo.iFullName.Length(), 0, 0 ) : Py_BuildValue("iu#u#OO",(TUint)appInfo.iUid.iUid, appInfo.iCaption.Ptr(), appInfo.iCaption.Length(),appInfo.iFullName.Ptr(), appInfo.iFullName.Length(), PyCObject_FromVoidPtr(img, NULL), PyCObject_FromVoidPtr(img_mask, NULL)) );
  }
  
  CleanupStack::PopAndDestroy(1);

  return arr;
}
 
//--------------------------------------------------------------------------

static const PyMethodDef applist2_met[] = {
    {"get", (PyCFunction)Get, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("applist2", applist2_met);
}

//--------------------------------------------------------------------------
