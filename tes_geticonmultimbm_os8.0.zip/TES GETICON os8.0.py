import e32,appuifw
from graphics import *
import geticon,multimbm

uid=0x20009591 #xplore
x,y=0,0
img=Image.new((x,y))
img_mask=Image.new((x,y),'L')

geticon.get(uid,img,img_mask)
multimbm.create(u'd:\\test.mbm',[img,img_mask])
icon1=appuifw.Icon(u'd:\\test.mbm',0,1)
entries=[(u'XPlore',unicode(hex(uid)),icon1)]

lb=appuifw.Listbox(entries,lambda:None)
app_lock = e32.Ao_lock() 

def exit():
  app_lock.signal()

appuifw.app.body=lb
appuifw.app.exit_key_handler = exit
app_lock = e32.Ao_lock() 
app_lock.wait()