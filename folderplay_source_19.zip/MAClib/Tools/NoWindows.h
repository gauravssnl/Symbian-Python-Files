#ifndef _MSC_VER

#ifndef APE_NOWINDOWS_H
#define APE_NOWINDOWS_H

#define FALSE    0
#define TRUE    1

#define NEAR
#define FAR

#define __stdcall
#define __cdecl
#define CALLBACK
#define __forceinline			inline


#ifdef __SYMBIAN32__

#include <e32std.h>
#include <e32const.h>


#ifndef __wchar_t_defined
#ifndef __GCCXML__
typedef unsigned short int wchar_t;
#endif
#endif

typedef TUint32							size_t;
typedef TUint32							uint32;
typedef TInt32							int32;
typedef TUint16							uint16;
typedef TInt16							int16;
typedef TUint8							uint8;
typedef TInt8								int8;
typedef char								str_ansi;
typedef TText8							str_utf8;
typedef wchar_t							str_utf16;

typedef TUint32							DWORD;
typedef	TBool								BOOL;
typedef TUint8							BYTE;
typedef TUint16				      WORD;
typedef TAny*								HANDLE;
typedef TUint32							UINT;
typedef TUint32							WPARAM;
typedef TInt32							LPARAM;
typedef const TInt8*				LPCSTR;
typedef TInt8*							LPSTR;
typedef const wchar_t*			LPCWSTR;
typedef TInt32							LRESULT;
typedef	TText8							UCHAR;

#define ZeroMemory(POINTER, BYTES)	Mem::FillZ(POINTER, BYTES)
#define memcpy(dest, src, count)		Mem::Copy(dest, src, count) 
#define memset(dest, c, count)			Mem::Fill(dest, count, c)
#define memmove(dest, src, count)		Mem::Move(dest, src, count)

template<class T> inline T max(T aLeft, T aRight) { return Max(aLeft, aRight); }
template<class T> inline T min(T aLeft, T aRight) { return Min(aLeft, aRight); }

inline TInt abs(int n) { return Abs(n); }
inline TInt32 labs(TInt32 n) { return Abs(n); }

inline TInt atoi(const char* str)
{ TInt aNum; TLex8((const TUint8*)str).Val(aNum); return aNum; }
inline TInt _wtoi(const wchar_t* str)
{ TInt aNum; TLex16((const TUint16*)str).Val(aNum); return aNum; }
inline char* _ultoa(TUint64 value, char* str, TInt radix)
{ TPtr8 aDst((TUint8*)str, 33); aDst.Num(value, (TRadix)radix); aDst.ZeroTerminate(); return str; }

inline TInt strncmp(const char* str1, const char* str2, TInt count)
{ return TPtrC8((const TUint8*)str1).Left(count).Compare(TPtrC8((const TUint8*)(const TUint8*)str2).Left(count)); }
inline TInt wcsncmp(const wchar_t* str1, const wchar_t* str2, TInt count)
{ return TPtrC16((const TUint16*)str1).Left(count).Compare(TPtrC16((const TUint16*)str2).Left(count)); }

inline TInt _strnicmp(const char* str1, const char* str2, TInt count)
{ return TPtrC8((const TUint8*)str1).Left(count).CompareF(TPtrC8((const TUint8*)str2).Left(count)); }
inline TInt _wcsnicmp(const wchar_t* str1, const wchar_t* str2, TInt count)
{ return TPtrC16((const TUint16*)str1).Left(count).CompareF(TPtrC16((const TUint16*)str2).Left(count)); }

inline TInt wcscmp(const wchar_t* str1, const wchar_t* str2)
{ return TPtrC16((const TUint16*)str1).Compare(TPtrC16((const TUint16*)str2)); }

inline TInt _stricmp(const char* str1, const char* str2)
{ return TPtrC8((const TUint8*)str1).CompareF(TPtrC8((const TUint8*)str2)); }
inline TInt _wcsicmp(const wchar_t* str1, const wchar_t* str2)
{ return TPtrC16((const TUint16*)str1).CompareF(TPtrC16((const TUint16*)str2)); }

inline TInt strlen(const char* str) { return TPtrC8((const TUint8*)str).Length(); }
inline TInt wcslen(const wchar_t* str) { return TPtrC16((const TUint16*)str).Length(); }  

inline const char* strstr(const char* str, const char* strSearch)
{ 
	TInt aIdx = TPtrC8((const TUint8*)str).Find(TPtrC8((const TUint8*)strSearch));
	return aIdx != KErrNotFound ? str + aIdx : NULL;
}

inline const wchar_t* wcsrchr(const wchar_t* str, wchar_t c)
{ TInt aIdx = TPtrC16((const TUint16*)str).LocateReverse(c); return aIdx != KErrNotFound ? str + aIdx : NULL; }

inline char* strcpy(char* strDestination, const char* strSource)
{	
	TPtrC8 aSrc((const TUint8*)strSource);
	TPtr8 aDst((TUint8*)strDestination, aSrc.Length() + 1);
	aDst.Copy(aSrc); aDst.ZeroTerminate(); return strDestination; 
}
inline wchar_t* wcscpy(wchar_t* strDestination, const wchar_t* strSource)
{	
	TPtrC16 aSrc((const TUint16*)strSource); TPtr16 aDst((TUint16*)strDestination, aSrc.Length() + 1);
	aDst.Copy(aSrc); aDst.ZeroTerminate(); return strDestination; 
}

inline char* strncpy(char* strDest, const char* strSource, TInt count)
{
	TPtr8((TUint8*)strDest, count).Justify(TPtrC8((const TUint8*)strSource), count, ELeft, 0); 
	return strDest;
}

// used for sorting
class TQuickSort : public TSwap, public TKey 
{
public:
	inline TQuickSort(TAny* ar, TUint width, TInt (*cmp)(const TAny*, const TAny*))
	{ _ar = ar; _width = width; _cmp = cmp; }
	
	virtual void Swap(TInt aLeft, TInt aRight) const
	{ Mem::Swap((char*)_ar + aLeft * _width, (char*)_ar + aRight * _width, _width); }
	virtual TInt Compare(TInt aLeft, TInt aRight) const
	{ return (*_cmp)((char*)_ar + aLeft * _width, (char*)_ar + aRight * _width); }

protected:
	TAny*		_ar;
	TUint		_width;
	TInt		(*_cmp)(const TAny*, const TAny*);
};

inline void qsort(TAny* base, TUint num, TUint width, TInt (*compare)(const TAny*, const TAny*))
{ TQuickSort qs(base, width, compare); User::QuickSort(num, qs, qs); }

#define free(memblock)							User::Free(memblock)
#define calloc(num, size)						User::AllocZ((TInt)((num) * (size)))

#define MAX_PATH										KMaxPath

#else // __SYMBIAN32__

typedef unsigned int        uint32;
typedef int                    int32;
typedef unsigned short        uint16;
typedef short                int16;
typedef unsigned char        uint8;
typedef char                int8;
typedef char                str_ansi;
typedef unsigned char        str_utf8;
typedef wchar_t                str_utf16;

typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef void *                HANDLE;
typedef unsigned int        UINT;
typedef unsigned int        WPARAM;
typedef long                LPARAM;
typedef const char *        LPCSTR;
typedef char *                LPSTR;
typedef long                LRESULT;

#define ZeroMemory(POINTER, BYTES) memset(POINTER, 0, BYTES);
#define max(a,b)    (((a) > (b)) ? (a) : (b))
#define min(a,b)    (((a) < (b)) ? (a) : (b))

#define _stricmp strcasecmp
#define _strnicmp strncasecmp

#define _FPOSOFF(fp) ((long)(fp).__pos)
#define MAX_PATH    260

#endif // __SYMBIAN32__


#ifndef _WAVEFORMATEX_
#define _WAVEFORMATEX_

typedef struct tWAVEFORMATEX
{
    WORD        wFormatTag;         /* format type */
    WORD        nChannels;          /* number of channels (i.e. mono, stereo...) */
    DWORD       nSamplesPerSec;     /* sample rate */
    DWORD       nAvgBytesPerSec;    /* for buffer estimation */
    WORD        nBlockAlign;        /* block size of data */
    WORD        wBitsPerSample;     /* number of bits per sample of mono data */
    WORD        cbSize;             /* the count in bytes of the size of */
                    /* extra information (after cbSize) */
} WAVEFORMATEX, *PWAVEFORMATEX, NEAR *NPWAVEFORMATEX, FAR *LPWAVEFORMATEX;
typedef const WAVEFORMATEX FAR *LPCWAVEFORMATEX;

#endif // _WAVEFORMATEX_

#define ERROR_INVALID_PARAMETER						87L

#endif // APE_NOWINDOWS_H

#endif // _MSC_VER
