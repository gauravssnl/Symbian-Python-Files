#ifndef APE_IO_H
#define APE_IO_H

// file and i/o errors (1000's)
#define ERROR_IO_READ                                   1000
#define ERROR_IO_WRITE                                  1001
#define ERROR_INVALID_INPUT_FILE                        1002
#define ERROR_INVALID_OUTPUT_FILE                       1003
#define ERROR_INPUT_FILE_TOO_LARGE                      1004
#define ERROR_INPUT_FILE_UNSUPPORTED_BIT_DEPTH          1005
#define ERROR_INPUT_FILE_UNSUPPORTED_SAMPLE_RATE        1006
#define ERROR_INPUT_FILE_UNSUPPORTED_CHANNEL_COUNT      1007
#define ERROR_INPUT_FILE_TOO_SMALL                      1008
#define ERROR_INVALID_CHECKSUM                          1009
#define ERROR_DECOMPRESSING_FRAME                       1010
#define ERROR_INITIALIZING_UNMAC                        1011
#define ERROR_INVALID_FUNCTION_PARAMETER                1012
#define ERROR_UNSUPPORTED_FILE_TYPE                     1013
#define ERROR_UPSUPPORTED_FILE_VERSION                  1014

#ifndef FILE_BEGIN
    #define FILE_BEGIN			0
#endif

#ifndef FILE_CURRENT
    #define FILE_CURRENT		1
#endif

#ifndef FILE_END
    #define FILE_END				2
#endif

class CIO
{
public:
    // read / write
    virtual int Read(void* pBuffer, unsigned int nBytesToRead, unsigned int* pBytesRead) = 0;
    virtual int Write(const void* pBuffer, unsigned int nBytesToWrite, unsigned int* pBytesWritten) = 0;
		virtual void Flush() = 0;
    
    // seek
    virtual int Seek(int nDistance, unsigned int nMoveMode) = 0;
    
    // attributes
    virtual int GetPosition() = 0;
    virtual int GetSize() = 0;
    
    // other functions
    virtual int SetEOF() = 0;
};

#endif // #ifndef APE_IO_H
