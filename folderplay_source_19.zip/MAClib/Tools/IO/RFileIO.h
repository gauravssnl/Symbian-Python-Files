/*
 * RFileIO.h
 *
 *  Created on: 27/05/2009
 *      Author: Alexander Demidov
 *      
 *  This public file can be used in the client code under Symbian OS
 *  it is not included anywhere here
 */

#ifndef APE_RFILEIO_H_
#define APE_RFILEIO_H_

#include <f32file.h>

#include "IO.h"

class CRFileIO : public CIO
{
public:
	inline explicit CRFileIO(RFile& anFile) : iFile(anFile) {}
	
	virtual int Read(void* pBuffer, unsigned int nBytesToRead, unsigned int* pBytesRead)
	{
		TPtr8 aBuffer((TUint8*)pBuffer, nBytesToRead);
		if(iFile.Read(aBuffer, nBytesToRead) != KErrNone) return ERROR_IO_READ;
		*pBytesRead = aBuffer.Length(); return 0;
	}
	
	virtual int Write(const void* pBuffer, unsigned int nBytesToWrite, unsigned int* pBytesWritten)
	{
		if(iFile.Write(TPtrC8((const TUint8*)pBuffer, nBytesToWrite)) != KErrNone) return ERROR_IO_WRITE;
		*pBytesWritten = nBytesToWrite; return 0;
	}

	virtual void Flush() { iFile.Flush(); }
	
	virtual int Seek(int nDistance, unsigned int nMoveMode)
	{
		return iFile.Seek(nMoveMode == FILE_BEGIN ? ESeekStart :
			(nMoveMode == FILE_END ? ESeekEnd : ESeekCurrent), nDistance) == KErrNone ? 0 : -1;
	}
	
	virtual int GetPosition()
	{ TInt aPos = 0; return iFile.Seek(ESeekCurrent, aPos) == KErrNone ? aPos : -1; }
	
	virtual int GetSize()
	{ TInt aSize; return iFile.Size(aSize) == KErrNone ? aSize : -1; }
	
	virtual int SetEOF()
	{ return iFile.SetSize(GetPosition()) == KErrNone ? 0 : -1; }

protected:
	RFile&		iFile;
};

#endif // APE_RFILEIO_H_
