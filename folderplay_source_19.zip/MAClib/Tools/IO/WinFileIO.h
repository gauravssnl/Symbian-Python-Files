/*
 * WinFileIO.h
 *
 *  Created on: 27/05/2009
 *      Author: Alexander Demidov
 *      
 *  This public file can be used in the client code under Windows
 *  it is not included anywhere here
 */

#ifndef _winfileio_h_
#define _winfileio_h_

#include <Windows.h>

#include "IO.h"

class CWinFileIO : public CIO
{
public:
	inline explicit CWinFileIO(HANDLE hFile) : m_hFile(hFile) {}
 
	virtual int Read(void* pBuffer, unsigned int nBytesToRead, unsigned int* pBytesRead)
	{ return ::ReadFile(m_hFile, pBuffer, nBytesToRead, (LPDWORD)pBytesRead, NULL) ? 0 : ERROR_IO_READ; }
  
	virtual int Write(const void* pBuffer, unsigned int nBytesToWrite, unsigned int* pBytesWritten)
	{ return ::WriteFile(m_hFile, pBuffer, nBytesToWrite, (LPDWORD)pBytesWritten, NULL) ? 0 : ERROR_IO_WRITE; }

	virtual void Flush() { ::FlushFileBuffers(m_hFile); }

	virtual int Seek(int nDistance, unsigned int nMoveMode)
  { ::SetFilePointer(m_hFile, nDistance, NULL, nMoveMode); return 0; }
    
	virtual int GetPosition() { return ::SetFilePointer(m_hFile, 0, NULL, FILE_CURRENT); }
	virtual int GetSize() { return ::GetFileSize(m_hFile, NULL); }
    
	virtual int SetEOF() { return ::SetEndOfFile(m_hFile) ? 0 : -1; }
   
protected:
	HANDLE		m_hFile;
};

#endif //_winfileio_h_
