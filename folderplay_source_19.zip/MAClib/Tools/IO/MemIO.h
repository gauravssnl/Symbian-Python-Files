/*
 * MemIO.h
 *
 *  Created on: 29/05/2009
 *      Author: Alexander Demidov
 *      
 *  This public file can be used in the client code under any platform
 *  it is not included anywhere here
 */

#ifndef _memio_h_
#define _memio_h_

#include "IO.h"

class CMemIO : public CIO
{
public:
	inline explicit CMemIO(char* mem, unsigned int size = 0) { _pos = _begin = mem; _end = mem + size; }
 
	virtual int Read(void* pBuffer, unsigned int nBytesToRead, unsigned int* pBytesRead)
	{
		*pBytesRead = nBytesToRead <= (unsigned int)(_end - _pos) ? nBytesToRead : (unsigned int)(_end - _pos);
		memcpy(pBuffer, _pos, *pBytesRead); _pos += *pBytesRead; return 0;
	}
  
	virtual int Write(const void* pBuffer, unsigned int nBytesToWrite, unsigned int* pBytesWritten)
	{ memcpy(_pos, pBuffer, nBytesToWrite); *pBytesWritten = nBytesToWrite; _pos += nBytesToWrite; if(_pos > _end) _end = _pos; return 0; }

	virtual void Flush() {}

	virtual int Seek(int nDistance, unsigned int nMoveMode)
  {
		_pos = (nMoveMode == FILE_BEGIN ? _begin : (nMoveMode == FILE_END ? _end : _pos)) + nDistance;
		if(_pos > _end) _pos = _end; else if(_pos < _begin) _pos = _begin;
		return 0;
	}
    
	virtual int GetPosition() { return _pos - _begin; }
	virtual int GetSize() { return _end - _begin; }
    
	virtual int SetEOF() { _end = _pos; return 0; }
   
protected:
	char*		_begin;
	char*		_end;
	char*		_pos;
};

#endif //_memio_h_
