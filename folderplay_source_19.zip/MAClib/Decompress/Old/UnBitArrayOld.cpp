#include "All.h"
#ifdef BACKWARDS_COMPATIBILITY

#include "APEInfo.h"
#include "UnBitarrayOld.h"
#include "BitArray.h"

const uint32 K_SUM_MIN_BOUNDARY_OLD[32] = {0UL,128UL,256UL,512UL,1024UL,2048UL,4096UL,8192UL,16384UL,32768UL,65536UL,131072UL,262144UL,524288UL,1048576UL,2097152UL,4194304UL,8388608UL,16777216UL,33554432UL,67108864UL,134217728UL,268435456UL,536870912UL,1073741824UL,2147483648UL,0UL,0UL,0UL,0UL,0UL,0UL};
const uint32 K_SUM_MAX_BOUNDARY_OLD[32] = {128UL,256UL,512UL,1024UL,2048UL,4096UL,8192UL,16384UL,32768UL,65536UL,131072UL,262144UL,524288UL,1048576UL,2097152UL,4194304UL,8388608UL,16777216UL,33554432UL,67108864UL,134217728UL,268435456UL,536870912UL,1073741824UL,2147483648UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
const uint32 Powers_of_Two[32] = {1UL,2UL,4UL,8UL,16UL,32UL,64UL,128UL,256UL,512UL,1024UL,2048UL,4096UL,8192UL,16384UL,32768UL,65536UL,131072UL,262144UL,524288UL,1048576UL,2097152UL,4194304UL,8388608UL,16777216UL,33554432UL,67108864UL,134217728UL,268435456UL,536870912UL,1073741824UL,2147483648UL};
const uint32 Powers_of_Two_Reversed[32] = {2147483648UL,1073741824UL,536870912UL,268435456UL,134217728UL,67108864UL,33554432UL,16777216UL,8388608UL,4194304UL,2097152UL,1048576UL,524288UL,262144UL,131072UL,65536UL,32768UL,16384UL,8192UL,4096UL,2048UL,1024UL,512UL,256UL,128UL,64UL,32UL,16UL,8UL,4UL,2UL,1UL};
const uint32 Powers_of_Two_Minus_One[33] = {0UL,1UL,3UL,7UL,15UL,31UL,63UL,127UL,255UL,511UL,1023UL,2047UL,4095UL,8191UL,16383UL,32767UL,65535UL,131071UL,262143UL,524287UL,1048575UL,2097151UL,4194303UL,8388607UL,16777215UL,33554431UL,67108863UL,134217727UL,268435455UL,536870911UL,1073741823UL,2147483647UL,4294967295UL};
const uint32 Powers_of_Two_Minus_One_Reversed[33] = {4294967295UL,2147483647UL,1073741823UL,536870911UL,268435455UL,134217727UL,67108863UL,33554431UL,16777215UL,8388607UL,4194303UL,2097151UL,1048575UL,524287UL,262143UL,131071UL,65535UL,32767UL,16383UL,8191UL,4095UL,2047UL,1023UL,511UL,255UL,127UL,63UL,31UL,15UL,7UL,3UL,1UL,0UL};

const uint32 K_SUM_MIN_BOUNDARY[32] = {0UL,32UL,64UL,128UL,256UL,512UL,1024UL,2048UL,4096UL,8192UL,16384UL,32768UL,65536UL,131072UL,262144UL,524288UL,1048576UL,2097152UL,4194304UL,8388608UL,16777216UL,33554432UL,67108864UL,134217728UL,268435456UL,536870912UL,1073741824UL,2147483648UL,0UL,0UL,0UL,0UL};
const uint32 K_SUM_MAX_BOUNDARY[32] = {32UL,64UL,128UL,256UL,512UL,1024UL,2048UL,4096UL,8192UL,16384UL,32768UL,65536UL,131072UL,262144UL,524288UL,1048576UL,2097152UL,4194304UL,8388608UL,16777216UL,33554432UL,67108864UL,134217728UL,268435456UL,536870912UL,1073741824UL,2147483648UL,0UL,0UL,0UL,0UL,0UL};

/***********************************************************************************
Construction
***********************************************************************************/
CUnBitArrayOld::CUnBitArrayOld(IAPEDecompress * pAPEDecompress, int nVersion, int nFurthestReadByte) :
	CUnBitArrayBase(nFurthestReadByte)
{
    int nBitArrayBytes = 262144;

    // calculate the bytes
    if (nVersion <= 3880)
    {
        int nMaxFrameBytes = (pAPEDecompress->GetInfo(APE_INFO_BLOCKS_PER_FRAME) * 50) / 8;
        nBitArrayBytes = 65536;
        while (nBitArrayBytes < nMaxFrameBytes)
        {
            nBitArrayBytes <<= 1;
        }
        
        nBitArrayBytes = max(nBitArrayBytes, 262144);
    }
    else if (nVersion <= 3890)
    {
        nBitArrayBytes = 65536;
    }
    else
    {
        // error
    }
    
    CreateHelper(GET_IO(pAPEDecompress), nBitArrayBytes, nVersion);

    // set the refill threshold
    if (m_nVersion <= 3880)
        m_nRefillBitThreshold = (m_nBits - (16384 * 8));
    else
        m_nRefillBitThreshold = (m_nBits - 512);
}

CUnBitArrayOld::~CUnBitArrayOld()
{
    SAFE_ARRAY_DELETE(m_pBitArray)
}

////////////////////////////////////////////////////////////////////////////////////
// Gets the number of m_nBits of data left in the m_nCurrentBitIndex array
////////////////////////////////////////////////////////////////////////////////////
uint32 CUnBitArrayOld::GetBitsRemaining()
{
    return (m_nElements * 32 - m_nCurrentBitIndex);
}

////////////////////////////////////////////////////////////////////////////////////
// Gets a rice value from the array
////////////////////////////////////////////////////////////////////////////////////
uint32 CUnBitArrayOld::DecodeValueRiceUnsigned(uint32 k) 
{
    // variable declares
    uint32 v;
    
    // plug through the string of 0's (the overflow)
    uint32 BitInitial = m_nCurrentBitIndex;
    while (!(m_pBitArray[m_nCurrentBitIndex >> 5] & Powers_of_Two_Reversed[m_nCurrentBitIndex++ & 31])) {}
    
    // if k = 0, your done
    if (k == 0)
        return (m_nCurrentBitIndex - BitInitial - 1);
    
    // put the overflow value into v
    v = (m_nCurrentBitIndex - BitInitial - 1) << k;
    
    return v | DecodeValueXBits(k);
}

////////////////////////////////////////////////////////////////////////////////////
// Get the optimal k for a given value
////////////////////////////////////////////////////////////////////////////////////
uint32 CUnBitArrayOld::Get_K(uint32 x) 
{
    if (x == 0)    return 0;

    uint32 k = 0;
    while (x >= Powers_of_Two[++k]) {}
    return k;    
}

unsigned int CUnBitArrayOld::DecodeValue(DECODE_VALUE_METHOD DecodeMethod, int nParam1, int /*nParam2*/)
{
    switch (DecodeMethod)
    {
    case DECODE_VALUE_METHOD_UNSIGNED_INT:
        return DecodeValueXBits(32);
    case DECODE_VALUE_METHOD_UNSIGNED_RICE:
        return DecodeValueRiceUnsigned(nParam1);
    case DECODE_VALUE_METHOD_X_BITS:
        return DecodeValueXBits(nParam1);
    }

    return 0;
}

////////////////////////////////////////////////////////////////////////////////////
// Generates an array from the m_nCurrentBitIndexarray
////////////////////////////////////////////////////////////////////////////////////
void CUnBitArrayOld::GenerateArrayOld(int* Output_Array, uint32 Number_of_Elements, int Minimum_nCurrentBitIndex_Array_Bytes) {

    //variable declarations
    uint32 K_Sum;
    uint32 q;
    uint32 kmin, kmax;
    uint32 k;
    uint32 Max;
    int *p1, *p2;

    // fill bit array if necessary
    // could use seek information to determine what the max was...
    uint32 Max_Bits_Needed = Number_of_Elements * 50;

    if (Minimum_nCurrentBitIndex_Array_Bytes > 0) 
    {
        // this is actually probably double what is really needed
        // we can only calculate the space needed for both arrays in multichannel
        Max_Bits_Needed = ((Minimum_nCurrentBitIndex_Array_Bytes + 4) * 8);
    }
    
    if (Max_Bits_Needed > GetBitsRemaining())
        FillBitArray();

    // decode the first 5 elements (all k = 10)
    Max = (Number_of_Elements < 5) ? Number_of_Elements : 5;
    for (q = 0; q < Max; q++) 
    {
        Output_Array[q] = DecodeValueRiceUnsigned(10);
    }
    
    // quit if that was all
    if (Number_of_Elements <= 5) 
    { 
        for (p2 = &Output_Array[0]; p2 < &Output_Array[Number_of_Elements]; p2++)
            *p2 = (*p2 & 1) ? (*p2 >> 1) + 1 : -(*p2 >> 1);
        return; 
    }

    // update k and K_Sum
    K_Sum = Output_Array[0] + Output_Array[1] + Output_Array[2] + Output_Array[3] + Output_Array[4];
    k = Get_K(K_Sum / 10);

    // work through the rest of the elements before the primary loop
    Max = (Number_of_Elements < 64) ? Number_of_Elements : 64;
    for (q = 5; q < Max; q++) 
    {
        Output_Array[q] = DecodeValueRiceUnsigned(k);
        K_Sum += Output_Array[q];
        k = Get_K(K_Sum / (q  + 1) / 2);
    }

    // quit if that was all
    if (Number_of_Elements <= 64) 
    { 
        for (p2 = &Output_Array[0]; p2 < &Output_Array[Number_of_Elements]; p2++)
            *p2 = (*p2 & 1) ? (*p2 >> 1) + 1 : -(*p2 >> 1);
        return; 
    }
        
    // set all of the variables up for the primary loop
    uint32 v, Bit_Array_Index;
    k = Get_K(K_Sum >> 7);
    kmin = K_SUM_MIN_BOUNDARY_OLD[k];
    kmax = K_SUM_MAX_BOUNDARY_OLD[k];
    p1 = &Output_Array[64]; p2 = &Output_Array[0];

    // the primary loop
    for (p1 = &Output_Array[64], p2 = &Output_Array[0]; p1 < &Output_Array[Number_of_Elements]; p1++, p2++) 
    {
        // plug through the string of 0's (the overflow)
        uint32 Bit_Initial = m_nCurrentBitIndex;
        while (!(m_pBitArray[m_nCurrentBitIndex >> 5] & Powers_of_Two_Reversed[m_nCurrentBitIndex++ & 31])) {}
    
        // if k = 0, your done
        if (k == 0) 
        {
            v = (m_nCurrentBitIndex - Bit_Initial - 1);
        }
        else 
        {
            // put the overflow value into v
            v = (m_nCurrentBitIndex - Bit_Initial - 1) << k;
    
            // store the bit information and incement the bit pointer by 'k'
            Bit_Array_Index = m_nCurrentBitIndex >> 5;
            unsigned int Bit_Index = m_nCurrentBitIndex & 31;
            m_nCurrentBitIndex += k;

            // figure the extra bits on the left and the left value
            int Left_Extra_Bits = (32 - k) - Bit_Index;
            unsigned int Left_Value = m_pBitArray[Bit_Array_Index] & Powers_of_Two_Minus_One_Reversed[Bit_Index];
            
            if (Left_Extra_Bits >= 0) 
                v |= (Left_Value >> Left_Extra_Bits);
            else 
                v |= (Left_Value << -Left_Extra_Bits) | (m_pBitArray[Bit_Array_Index + 1] >> (32 + Left_Extra_Bits));
        }    

        *p1 = v;
        K_Sum += *p1 - *p2;

        // convert *p2 to unsigned
        *p2 = (*p2 % 2) ? (*p2 >> 1) + 1 : -(*p2 >> 1);

        // adjust k if necessary
        if ((K_Sum < kmin) || (K_Sum >= kmax)) 
        {
            if (K_Sum < kmin) 
                while (K_Sum < K_SUM_MIN_BOUNDARY_OLD[--k]) {}
            else
                while (K_Sum >= K_SUM_MAX_BOUNDARY_OLD[++k]) {}

            kmax = K_SUM_MAX_BOUNDARY_OLD[k];
            kmin = K_SUM_MIN_BOUNDARY_OLD[k];
        }
    }

    for (; p2 < &Output_Array[Number_of_Elements]; p2++)
        *p2 = (*p2 & 1) ? (*p2 >> 1) + 1 : -(*p2 >> 1);
}

void CUnBitArrayOld::GenerateArray(int *pOutputArray, int nElements, int nBytesRequired) 
{
    if (m_nVersion < 3860)
    {
        GenerateArrayOld(pOutputArray, nElements, nBytesRequired);
    }
    else if (m_nVersion <= 3890)
    {
        GenerateArrayRice(pOutputArray, nElements, nBytesRequired);
    }
    else
    {    
        // error
    }
}

void CUnBitArrayOld::GenerateArrayRice(int* Output_Array, uint32 Number_of_Elements, int /*Minimum_nCurrentBitIndex_Array_Bytes*/) 
{
    /////////////////////////////////////////////////////////////////////////////
    // decode the bit array
    /////////////////////////////////////////////////////////////////////////////
    
    k = 10;
    K_Sum = 1024 * 16;

    if (m_nVersion <= 3880)
    {
        // the primary loop
        for (int *p1 = &Output_Array[0]; p1 < &Output_Array[Number_of_Elements]; p1++) 
        {
            *p1 = DecodeValueNew(FALSE);
        }
    }
    else
    {
        // the primary loop
        for (int *p1 = &Output_Array[0]; p1 < &Output_Array[Number_of_Elements]; p1++) 
        {
            *p1 = DecodeValueNew(TRUE);
        }
    }
}

__inline int CUnBitArrayOld::DecodeValueNew(BOOL bCapOverflow)
{
    // make sure there is room for the data
    // this is a little slower than ensuring a huge block to start with, but it's safer
    if (m_nCurrentBitIndex > m_nRefillBitThreshold)
    {
        FillBitArray();
    }
    
    unsigned int v;
    
    // plug through the string of 0's (the overflow)
    uint32 Bit_Initial = m_nCurrentBitIndex;
    while (!(m_pBitArray[m_nCurrentBitIndex >> 5] & Powers_of_Two_Reversed[m_nCurrentBitIndex++ & 31])) {}
    
    int nOverflow = (m_nCurrentBitIndex - Bit_Initial - 1);
    
    if (bCapOverflow)
    {
        while (nOverflow >= 16)
        {
            k += 4;
            nOverflow -= 16;
        }
    }
    
    // if k = 0, your done
    if (k != 0)
    {
        // put the overflow value into v
        v = nOverflow << k;
        
        // store the bit information and incement the bit pointer by 'k'
        unsigned int Bit_Array_Index = m_nCurrentBitIndex >> 5;
        unsigned int Bit_Index = m_nCurrentBitIndex & 31;
        m_nCurrentBitIndex += k;
        
        // figure the extra bits on the left and the left value
        int Left_Extra_Bits = (32 - k) - Bit_Index;
        unsigned int Left_Value = m_pBitArray[Bit_Array_Index] & Powers_of_Two_Minus_One_Reversed[Bit_Index];
        
        if (Left_Extra_Bits >= 0) 
        {
            v |= (Left_Value >> Left_Extra_Bits);
        }
        else 
        {
            v |= (Left_Value << -Left_Extra_Bits) | (m_pBitArray[Bit_Array_Index + 1] >> (32 + Left_Extra_Bits));
        }
    }    
    else
    {
        v = nOverflow;
    }
    
    // update K_Sum
    K_Sum += v - ((K_Sum + 8) >> 4);
    
    // update k
    if (K_Sum < K_SUM_MIN_BOUNDARY[k]) 
        k--;
    else if (K_Sum >= K_SUM_MAX_BOUNDARY[k]) 
        k++;
    
    // convert to unsigned and save
    return (v & 1) ? (v >> 1) + 1 : -(int(v >> 1));
}

#endif // #ifdef BACKWARDS_COMPATIBILITY
