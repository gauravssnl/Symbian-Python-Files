#include "All.h"
#include "APEInfo.h"
#include "UnBitArray.h"
#include "BitArray.h"

const uint32 POWERS_OF_TWO_MINUS_ONE_REVERSED[33] = {4294967295UL,2147483647UL,1073741823UL,536870911UL,268435455UL,134217727UL,67108863UL,33554431UL,16777215UL,8388607UL,4194303UL,2097151UL,1048575UL,524287UL,262143UL,131071UL,65535UL,32767UL,16383UL,8191UL,4095UL,2047UL,1023UL,511UL,255UL,127UL,63UL,31UL,15UL,7UL,3UL,1UL,0UL};

const uint32 K_SUM_MIN_BOUNDARY[32] = {0UL,32UL,64UL,128UL,256UL,512UL,1024UL,2048UL,4096UL,8192UL,16384UL,32768UL,65536UL,131072UL,262144UL,524288UL,1048576UL,2097152UL,4194304UL,8388608UL,16777216UL,33554432UL,67108864UL,134217728UL,268435456UL,536870912UL,1073741824UL,2147483648UL,0UL,0UL,0UL,0UL};

const uint32 RANGE_TOTAL_1[65] = {0UL,14824UL,28224UL,39348UL,47855UL,53994UL,58171UL,60926UL,62682UL,63786UL,64463UL,64878UL,65126UL,65276UL,65365UL,65419UL,65450UL,65469UL,65480UL,65487UL,65491UL,65493UL,65494UL,65495UL,65496UL,65497UL,65498UL,65499UL,65500UL,65501UL,65502UL,65503UL,65504UL,65505UL,65506UL,65507UL,65508UL,65509UL,65510UL,65511UL,65512UL,65513UL,65514UL,65515UL,65516UL,65517UL,65518UL,65519UL,65520UL,65521UL,65522UL,65523UL,65524UL,65525UL,65526UL,65527UL,65528UL,65529UL,65530UL,65531UL,65532UL,65533UL,65534UL,65535UL,65536UL};
const uint32 RANGE_WIDTH_1[64] = {14824UL,13400UL,11124UL,8507UL,6139UL,4177UL,2755UL,1756UL,1104UL,677UL,415UL,248UL,150UL,89UL,54UL,31UL,19UL,11UL,7UL,4UL,2UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};

const uint32 RANGE_TOTAL_2[65] = {0UL,19578UL,36160UL,48417UL,56323UL,60899UL,63265UL,64435UL,64971UL,65232UL,65351UL,65416UL,65447UL,65466UL,65476UL,65482UL,65485UL,65488UL,65490UL,65491UL,65492UL,65493UL,65494UL,65495UL,65496UL,65497UL,65498UL,65499UL,65500UL,65501UL,65502UL,65503UL,65504UL,65505UL,65506UL,65507UL,65508UL,65509UL,65510UL,65511UL,65512UL,65513UL,65514UL,65515UL,65516UL,65517UL,65518UL,65519UL,65520UL,65521UL,65522UL,65523UL,65524UL,65525UL,65526UL,65527UL,65528UL,65529UL,65530UL,65531UL,65532UL,65533UL,65534UL,65535UL,65536UL};
const uint32 RANGE_WIDTH_2[64] = {19578UL,16582UL,12257UL,7906UL,4576UL,2366UL,1170UL,536UL,261UL,119UL,65UL,31UL,19UL,10UL,6UL,3UL,3UL,2UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};

#define RANGE_OVERFLOW_TOTAL_WIDTH 65536
#define RANGE_OVERFLOW_SHIFT 16

#define CODE_BITS 32
#define TOP_VALUE ((unsigned int ) 1 << (CODE_BITS - 1))
#define SHIFT_BITS (CODE_BITS - 9)
#define EXTRA_BITS ((CODE_BITS - 2) % 8 + 1)
#define BOTTOM_VALUE (TOP_VALUE >> 8)

#define MODEL_ELEMENTS 64

/***********************************************************************************
Construction
***********************************************************************************/
CUnBitArray::CUnBitArray(CIO* pIO, int nVersion, int nFurthestReadByte) :
	CUnBitArrayBase(nFurthestReadByte)
{
    CreateHelper(pIO, 16384, nVersion);
    m_nFlushCounter = 0;
    m_nFinalizeCounter = 0;
    m_nRefillBitThreshold = (m_nBits - 512);
}

CUnBitArray::~CUnBitArray()
{
    SAFE_ARRAY_DELETE(m_pBitArray)
}

unsigned int CUnBitArray::DecodeValue(DECODE_VALUE_METHOD DecodeMethod, int /*nParam1*/, int /*nParam2*/)
{
    switch (DecodeMethod)
    {
    	case DECODE_VALUE_METHOD_UNSIGNED_INT:
        return DecodeValueXBits(32);
    	default: break;
    }
    
    return 0;
}

void CUnBitArray::GenerateArray(int * pOutputArray, int nElements, int /*nBytesRequired*/) 
{
    GenerateArrayRange(pOutputArray, nElements);
}

inline uint32 CUnBitArray::DecodeByte()
{
	// error check (only done in debug since we protect against overreads in other ways)
	#ifdef _DEBUG
		if ((m_nCurrentBitIndex / 8) >= m_nGoodBytes)
			ODS(_T("Overread error in CUnBitArray::DecodeByte(...)\n"));
	#endif

	// read byte
    uint32 nByte = ((m_pBitArray[m_nCurrentBitIndex >> 5] >> (24 - (m_nCurrentBitIndex & 31))) & 0xFF);
    m_nCurrentBitIndex += 8;
	return nByte;
}

inline unsigned int CUnBitArray::RangeDecodeFast(int nShift)
{
    while (m_RangeCoderInfo.range <= BOTTOM_VALUE)
    {   
        m_RangeCoderInfo.buffer = (m_RangeCoderInfo.buffer << 8) | DecodeByte();
        m_RangeCoderInfo.low = (m_RangeCoderInfo.low << 8) | ((m_RangeCoderInfo.buffer >> 1) & 0xFF);
        m_RangeCoderInfo.range <<= 8;
    }

    // decode
    m_RangeCoderInfo.range = m_RangeCoderInfo.range >> nShift;
    
    return m_RangeCoderInfo.low / m_RangeCoderInfo.range;
}

inline int CUnBitArray::RangeDecodeFastWithUpdate(int nShift)
{
    while (m_RangeCoderInfo.range <= BOTTOM_VALUE)
    {   
        m_RangeCoderInfo.buffer = (m_RangeCoderInfo.buffer << 8) | DecodeByte();
        m_RangeCoderInfo.low = (m_RangeCoderInfo.low << 8) | ((m_RangeCoderInfo.buffer >> 1) & 0xFF);
        m_RangeCoderInfo.range <<= 8;
    }

    // decode
    m_RangeCoderInfo.range = m_RangeCoderInfo.range >> nShift;
    int nRetVal = m_RangeCoderInfo.low / m_RangeCoderInfo.range;
    m_RangeCoderInfo.low -= m_RangeCoderInfo.range * nRetVal;
    return nRetVal;
}

int CUnBitArray::DecodeValueRange(UNBIT_ARRAY_STATE & BitArrayState)
{
    // make sure there is room for the data
    // this is a little slower than ensuring a huge block to start with, but it's safer
    if (m_nCurrentBitIndex > m_nRefillBitThreshold)
        FillBitArray();

    int nValue = 0;

    if (m_nVersion >= 3990)
    {
        // figure the pivot value
        int nPivotValue = max(BitArrayState.nKSum / 32, 1UL);
        
        // get the overflow
        int nOverflow = 0;
        {
            // decode
            unsigned int nRangeTotal = RangeDecodeFast(RANGE_OVERFLOW_SHIFT);
            
            // lookup the symbol (must be a faster way than this)
            while (nRangeTotal >= RANGE_TOTAL_2[nOverflow + 1]) { nOverflow++; }
            
            // update
            m_RangeCoderInfo.low -= m_RangeCoderInfo.range * RANGE_TOTAL_2[nOverflow];
            m_RangeCoderInfo.range = m_RangeCoderInfo.range * RANGE_WIDTH_2[nOverflow];
            
            // get the working k
            if (nOverflow == (MODEL_ELEMENTS - 1))
            {
                nOverflow = RangeDecodeFastWithUpdate(16);
                nOverflow <<= 16;
                nOverflow |= RangeDecodeFastWithUpdate(16);
            }
        }

        // get the value
        int nBase = 0;
        {
            //int nShift = 0;
            if (nPivotValue >= (1 << 16))
            {
                int nPivotValueBits = 0;
                while ((nPivotValue >> nPivotValueBits) > 0) { nPivotValueBits++; }
                int nSplitFactor = 1 << (nPivotValueBits - 16);

                int nPivotValueA = (nPivotValue / nSplitFactor) + 1;
                int nPivotValueB = nSplitFactor;

                while (m_RangeCoderInfo.range <= BOTTOM_VALUE)
                {   
                    m_RangeCoderInfo.buffer = (m_RangeCoderInfo.buffer << 8) | DecodeByte();
                    m_RangeCoderInfo.low = (m_RangeCoderInfo.low << 8) | ((m_RangeCoderInfo.buffer >> 1) & 0xFF);
                    m_RangeCoderInfo.range <<= 8;
                }
                m_RangeCoderInfo.range = m_RangeCoderInfo.range / nPivotValueA;
                int nBaseA = m_RangeCoderInfo.low / m_RangeCoderInfo.range;
                m_RangeCoderInfo.low -= m_RangeCoderInfo.range * nBaseA;

                while (m_RangeCoderInfo.range <= BOTTOM_VALUE)
                {   
                    m_RangeCoderInfo.buffer = (m_RangeCoderInfo.buffer << 8) | DecodeByte();
                    m_RangeCoderInfo.low = (m_RangeCoderInfo.low << 8) | ((m_RangeCoderInfo.buffer >> 1) & 0xFF);
                    m_RangeCoderInfo.range <<= 8;
                }
                m_RangeCoderInfo.range = m_RangeCoderInfo.range / nPivotValueB;
                int nBaseB = m_RangeCoderInfo.low / m_RangeCoderInfo.range;
                m_RangeCoderInfo.low -= m_RangeCoderInfo.range * nBaseB;

                nBase = nBaseA * nSplitFactor + nBaseB;
            }
            else
            {
                while (m_RangeCoderInfo.range <= BOTTOM_VALUE)
                {   
                    m_RangeCoderInfo.buffer = (m_RangeCoderInfo.buffer << 8) | DecodeByte();
                    m_RangeCoderInfo.low = (m_RangeCoderInfo.low << 8) | ((m_RangeCoderInfo.buffer >> 1) & 0xFF);
                    m_RangeCoderInfo.range <<= 8;
                }

                // decode
                m_RangeCoderInfo.range = m_RangeCoderInfo.range / nPivotValue;
                int nBaseLower = m_RangeCoderInfo.low / m_RangeCoderInfo.range;
                m_RangeCoderInfo.low -= m_RangeCoderInfo.range * nBaseLower;

                nBase = nBaseLower;
            }
        }

        // build the value
        nValue = nBase + (nOverflow * nPivotValue);
    }
    else
    {
        // decode
        unsigned int nRangeTotal = RangeDecodeFast(RANGE_OVERFLOW_SHIFT);
        
        // lookup the symbol (must be a faster way than this)
        int nOverflow = 0;
        while (nRangeTotal >= RANGE_TOTAL_1[nOverflow + 1]) { nOverflow++; }
        
        // update
        m_RangeCoderInfo.low -= m_RangeCoderInfo.range * RANGE_TOTAL_1[nOverflow];
        m_RangeCoderInfo.range = m_RangeCoderInfo.range * RANGE_WIDTH_1[nOverflow];
        
        // get the working k
        int nTempK;
        if (nOverflow == (MODEL_ELEMENTS - 1))
        {
            nTempK = RangeDecodeFastWithUpdate(5);
            nOverflow = 0;
        }
        else
        {
            nTempK = (BitArrayState.k < 1) ? 0 : BitArrayState.k - 1;
        }
        
        // figure the extra bits on the left and the left value
        if (nTempK <= 16 || m_nVersion < 3910)
        {
            nValue = RangeDecodeFastWithUpdate(nTempK);
        }                    
        else
        {    
            int nX1 = RangeDecodeFastWithUpdate(16);
            int nX2 = RangeDecodeFastWithUpdate(nTempK - 16);
            nValue = nX1 | (nX2 << 16);
        }
            
        // build the value and output it
        nValue += (nOverflow << nTempK);
    }

    // update nKSum
    BitArrayState.nKSum += ((nValue + 1) / 2) - ((BitArrayState.nKSum + 16) >> 5);
    
    // update k
    if (BitArrayState.nKSum < K_SUM_MIN_BOUNDARY[BitArrayState.k]) 
        BitArrayState.k--;
    else if (BitArrayState.nKSum >= K_SUM_MIN_BOUNDARY[BitArrayState.k + 1]) 
        BitArrayState.k++;

    // output the value (converted to signed)
    return (nValue & 1) ? (nValue >> 1) + 1 : -(nValue >> 1);
}

void CUnBitArray::FlushState(UNBIT_ARRAY_STATE & BitArrayState)
{
    BitArrayState.k = 10;
    BitArrayState.nKSum = (1 << BitArrayState.k) * 16;
}

void CUnBitArray::FlushBitArray()
{
    AdvanceToByteBoundary();
    DecodeValueXBits(8); // ignore the first byte... (slows compression too much to not output this dummy byte)
    m_RangeCoderInfo.buffer = DecodeValueXBits(8);
    m_RangeCoderInfo.low = m_RangeCoderInfo.buffer >> (8 - EXTRA_BITS);
    m_RangeCoderInfo.range = (unsigned int) 1 << EXTRA_BITS;
}

void CUnBitArray::Finalize()
{
    // normalize
    while (m_RangeCoderInfo.range <= BOTTOM_VALUE)
    {   
        m_nCurrentBitIndex += 8;
        m_RangeCoderInfo.range <<= 8;
    }
    
    // used to back-pedal the last two bytes out
    // this should never have been a problem because we've outputted and normalized beforehand
    // but stopped doing it as of 3.96 in case it accounted for rare decompression failures
    if (m_nVersion <= 3950)
        m_nCurrentBitIndex -= 16;
}

void CUnBitArray::GenerateArrayRange(int * pOutputArray, int nElements)
{
    UNBIT_ARRAY_STATE BitArrayState;
    FlushState(BitArrayState);
    FlushBitArray();
    
    for (int z = 0; z < nElements; z++)
    {
        pOutputArray[z] = DecodeValueRange(BitArrayState);
    }

    Finalize();    
}
