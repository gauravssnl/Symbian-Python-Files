#ifdef __SYMBIAN32__

#include <e32def.h>

typedef TInt8				int8_t;
typedef TInt16			int16_t;
typedef TInt32			int32_t;
typedef TInt64			int64_t;

typedef TUint8			uint8_t;
typedef TUint16			uint16_t;
typedef TUint32			uint32_t;
typedef TUint64			uint64_t;

#else

typedef signed char int8_t;
typedef signed short int16_t;
typedef signed int int32_t;
#ifdef ARCH_X86
typedef signed long long int64_t;
#endif

typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
#ifdef ARCH_X86
typedef unsigned long long uint64_t;
#endif

#endif	// platform
