/*
 * AAC.cpp
 *
 *  Created on: Aug 2, 2009
 *      Author: Alexander Demidov
 */

#include <es_sock.h>

#include "FolderPlayView.h"

static TInt sample_rates[] = { 96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000 };

struct ADTS
{
	TUint16	CRC					: 1;	// 0 - Protected by CRC
	TUint16	layer				: 2;	// always 00
	TUint16	version			: 1;	// 0 - MPEG-4, 1 - MPEG-2
	TUint16	sync				: 12;	// sync word (all set)

	TUint16							: 4;
	TUint16	home				: 1;
	TUint16	original		: 1;
	TUint16	channels		: 3;	// number of channels
	TUint16	priv				: 1;
	TUint16	sample_rate	: 4;	// 
	TUint16	profile 		: 2;	// 00 MAIN, 01 LC, 10 SSR, 11 reserved
	
	inline TFourCC DataType() const
	{ return layer == 0 ? KMMFFourCCCodeAAC : KMMFFourCCCodeNULL; }
		
	inline TInt SampleRate() const
	{ return sample_rate < 12 ? Freq2SR(sample_rates[sample_rate]) : 0; }
		
	inline TInt Channels() const
	{ return channels == 2 ? TMdaAudioDataSettings::EChannelsStereo : (channels == 1 ? TMdaAudioDataSettings::EChannelsMono : 0); }
};

bool CFolderView::ParseAAC()
{
	static TBuf8<1024> aBuffer; iRemLen = 0;
	if(iCurrentPos < 0) iCurrentPos = 0;
	
	// if starts with ID3, skip it
	iAudioFile.Read(aBuffer, 10); TInt aPos;
	if(aBuffer.Length() == 10 && aBuffer.Left(3) == _L8("ID3") &&
			(aBuffer[6] & 0x80) == 0 && (aBuffer[7] & 0x80) == 0 && (aBuffer[8] & 0x80) == 0 && (aBuffer[9] & 0x80) == 0)
	{
		aPos = ((TInt)aBuffer[6] << 21) | ((TInt)aBuffer[7] << 14) | ((TInt)aBuffer[8] << 7) | aBuffer[9];
		iAudioFile.Seek(ESeekCurrent, aPos);
	}
	else { aPos = -aBuffer.Length(); iAudioFile.Seek(ESeekCurrent, aPos); }
	
	TInt aSize; iAudioFile.Size(aSize); iTotalLength = aSize - aPos;
	aPos += iCurrentPos; iAudioFile.Seek(ESeekStart, aPos);
	
	// sync
	while(true)
	{
		if(!iAlive) return true;
		iAudioFile.Read(aBuffer, aBuffer.MaxLength()); if(aBuffer.Length() < 4) return false;
		TInt aSync = aBuffer.Locate(0xFF);
		if(aSync != KErrNotFound)
		{
			aPos += aSync;
			iAudioFile.Seek(ESeekStart, aPos); iAudioFile.Read(aBuffer, 4); if(aBuffer.Length() < 4) return false;
			Mem::Swap(&aBuffer[0], &aBuffer[1], 1); Mem::Swap(&aBuffer[2], &aBuffer[3], 1);
			const ADTS& aAudioParam = *(const ADTS*)aBuffer.Ptr();
			if(aAudioParam.sync == 0xFFF)
			{
				iDataType = aAudioParam.DataType(); iSampleRate = aAudioParam.SampleRate(); iChannels = aAudioParam.Channels();
				break;
			}
			else iAudioFile.Seek(ESeekStart, aPos += 2);
		}
		else aPos += aBuffer.Length();
	}
	iCurrentPos = iTotalLength - (aSize - aPos);

	if(iDataType == KMMFFourCCCodeNULL || iSampleRate == 0 || iChannels == 0) return false;
	ScheduleAudioReset();
	
	iAudioFile.Seek(ESeekStart, aPos); OutputBlock(aSize - aPos, ETrue);
	return true;
}
