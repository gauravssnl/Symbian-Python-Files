/*
 ============================================================================
 Name		: FolderPlayView.h
 Author	  : Alexander Demidov
 Copyright   : 
 Description : Declares view class for application.
 ============================================================================
 */

#ifndef __FOLDERPLAYVIEW_h__
#define __FOLDERPLAYVIEW_h__

// INCLUDES
#include <coecntrl.h>
#include <aknappui.h>
#include <fbs.h>
#include <aknlists.h>
#include <aknslider.h>
#include <eikprogi.h> 
#include <MdaAudioOutputStream.h>
#include <Audio.h>
#include <aknnavide.h>
#include <badesca.h>
#include <Etel3rdParty.h>
#include <AknToolbarObserver.h>
#include <charconv.h>

#include <remconcoreapitargetobserver.h>
#include <remconinterfaceselector.h>


class CFolderView : public CCoeControl, public MEikListBoxObserver,
										public MMdaAudioOutputStreamCallback, public MRemConCoreApiTargetObserver,
										public CActive
{
public:
	// New methods

	/**
	 * NewL.
	 * Two-phased constructor.
	 * Create a CFolderView object, which will draw itself to aRect.
	 * @param aRect The rectangle this view will be drawn to.
	 * @return a pointer to the created instance of CFolderView.
	 */
	static CFolderView* NewL(const TRect& aRect);

	/**
	 * NewLC.
	 * Two-phased constructor.
	 * Create a CFolderView object, which will draw itself
	 * to aRect.
	 * @param aRect Rectangle this view will be drawn to.
	 * @return A pointer to the created instance of CFolderView.
	 */
	static CFolderView* NewLC(const TRect& aRect);

	/**
	 * ~CFolderView
	 * Virtual Destructor.
	 */
	virtual ~CFolderView();
	
	virtual void GetHelpContext(TCoeHelpContext& aContext) const;
	
	void SetRootL(const TDesC& anFocus = _L(""));
	void SetPathL(const TDesC& anPath, const TDesC& anFocus = _L(""));
	void SetVirtualPathL(const TDesC& anPath);
	TInt GetItemName(TInt anIndex, TDes& anName) const;
	void BackL();
	void SetPlayingItemL(const TDesC& anPlayingItem);
	HBufC16* GetFileContent(const TDesC& anFile);
	TInt GetTrackTimeL(const TDesC& anPath, TInt anIndex);
	
	void PlayTheList();
	
	void StorePlayStateL();
	void LoadPlayStateL();

protected:
	// Functions from base classes

//	void Draw(const TRect& aRect) const;

	virtual void SizeChanged();
	virtual void FocusChanged(TDrawNow aDrawNow);
	virtual TInt CountComponentControls() const;
	virtual CCoeControl* ComponentControl(TInt aIndex) const;

	/**
	 * From CoeControl, HandlePointerEventL.
	 * Called by framework when a pointer touch event occurs.
	 * Note: although this method is compatible with earlier SDKs, 
	 * it will not be called in SDKs without Touch support.
	 * @param aPointerEvent the information about this event
	 */
	virtual void HandlePointerEventL(const TPointerEvent& aPointerEvent);
	virtual void HandleListBoxEventL(CEikListBox* aListBox, TListBoxEvent aEventType);
	virtual TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
	
	virtual void MaoscOpenComplete(TInt aError);
	virtual void MaoscBufferCopied(TInt aError, const TDesC8& aBuffer);
	virtual void MaoscPlayComplete(TInt aError);
	
	virtual void MrccatoCommand(TRemConCoreApiOperationId aOperationId, TRemConCoreApiButtonAction aButtonAct);

// CActive	
	virtual void RunL();
	virtual void DoCancel();
	
	void GetPlayListL(const TDesC16& anPath);
	bool IsSupported(const TDesC16& anName) const;
	
// engine
	bool ParseFile(const TDesC16& anFile);
	bool ParseWave(TUint32 anChunkEnd = (TUint32)-1, TBool anBigEndian = EFalse);
	bool ParseLPCM();
	bool ParseFLAC();
	bool ParseMAC();
	bool ParseAC3();
	TInt OutputAC3Frame(const TUint8*);
	bool ParseMP3();
	bool ParseOgg();
	bool ParseAAC();
	void OutputBlock(TInt aDataLen, TBool aCountData = EFalse);
	void Flush();
	
	void Start();
	void Stop();
	void Pause();
	void Resume();
	
	void IncrementProgress(TInt aInc);
	TInt Progress() const; 
		
	inline RBuf8& ActiveBuffer()
	{
		return iCurBuffer.Ptr() >= iEvenBuffer.Ptr() &&
						iCurBuffer.Ptr() < iEvenBuffer.Ptr() + iEvenBuffer.MaxLength() ? iEvenBuffer : iOddBuffer;
	}
	inline RBuf8& InactiveBuffer()
	{
		return iCurBuffer.Ptr() >= iEvenBuffer.Ptr() &&
						iCurBuffer.Ptr() < iEvenBuffer.Ptr() + iEvenBuffer.MaxLength() ? iOddBuffer : iEvenBuffer;
	}

private:
	// Constructors

	/**
	 * ConstructL
	 * 2nd phase constructor.
	 * Perform the second phase construction of a
	 * CFolderView object.
	 * @param aRect The rectangle this view will be drawn to.
	 */
	void ConstructL(const TRect& aRect);

	/**
	 * CFolderView.
	 * C++ default constructor.
	 */
	CFolderView();

protected:
// GUI
	CAknSingleGraphicStyleListBox		iListBox;
	CAknSlider											iProgressSlider;
	CEikProgressInfo								iProgressBar;
	CAknNavigationControlContainer* iNaviPane;
	CAknNavigationDecorator*				iVolumeNavi;
	CAknNavigationDecorator*				iBoostNavi;
	TInt														iBoostVal;
// navigator	
	RFs															iFs;
	TPath														iPath;
// audio device and its state
	CMdaAudioOutputStream*					iAudioOutput;
	TFourCC													iAudioDataType;
	TMdaAudioDataSettings						iAudioSettings;
	TBool														iSetAudioParam;		// time to reset the audio device
// double buffer	
	RBuf8														iEvenBuffer;
	RBuf8														iOddBuffer;
// thread synchronization	
	RThread													iMainThread, iAudioThread;
	RSemaphore											iFreeBuffer;
	RMutex													iExclusive;
	RCondVar												iStateChange;
	TBool														iAudioBusy, iBufferPending;
// play sequence	
	CDesC16ArrayFlat								iPlayList;
	TInt														iCurFileIdx;
// special buttons	
	CRemConInterfaceSelector*				iRemSelector;
	
	TInt														iDriveIcon[10];
	const CDesC16ArrayFlat&					iExtensions;
	
	CCnvCharacterSetConverter*			iCharConv;

public:
// current audio data block
	RFile														iAudioFile;
	TFourCC													iDataType;
	TInt														iSampleRate, iChannels;
	TPtr8														iCurBuffer;
	TBool														iAlive, iPause;
	TUint														iRemLen; // remnant data length, left from previous file/packet
	
// progress
	TInt														iTotalLength, iCurrentPos;									
	
	void OutputBuffer();
	void ScheduleAudioReset();
	
	friend class CFolderPlayAppUi;
};


/**
 * CFolderPlayAppUi application UI class.
 * Interacts with the user through the UI and request message processing
 * from the handler class
 */
class CFolderPlayAppUi : public CAknAppUi, public CActive, public MAknToolbarObserver
{
public:
	// Constructors and destructor

	/**
	 * ConstructL.
	 * 2nd phase constructor.
	 */
	void ConstructL();

	/**
	 * CFolderPlayAppUi.
	 * C++ default constructor. This needs to be public due to
	 * the way the framework constructs the AppUi
	 */
	CFolderPlayAppUi() : CActive(CActive::EPriorityStandard), iCallStatusPkg(iCallStatus)
	{ iAppView = NULL; iTelephony = NULL; }

	/**
	 * ~CFolderPlayAppUi.
	 * Virtual Destructor.
	 */
	virtual ~CFolderPlayAppUi();

private:
	// Functions from base classes

	/**
	 * From CEikAppUi, HandleCommandL.
	 * Takes care of command handling.
	 * @param aCommand Command to be handled.
	 */
	void HandleCommandL(TInt aCommand);
	void HandleWsEventL(const TWsEvent& aEvent, CCoeControl* aDestination);
	
	virtual void OfferToolbarEventL(TInt aCommand);

	/**
	 *  HandleStatusPaneSizeChange.
	 *  Called by the framework when the application status pane
	 *  size is changed.
	 */
	void HandleStatusPaneSizeChange();

	/**
	 *  From CCoeAppUi, HelpContextL.
	 *  Provides help context for the application.
	 *  size is changed.
	 */
	CArrayFix<TCoeHelpContext>* HelpContextL() const;
	
// CActive	
	virtual void RunL();
	virtual void DoCancel();

private:
	// Data

	/**
	 * The application view
	 * Owned by CFolderPlayAppUi
	 */
	CFolderView*									iAppView;
	CTelephony*										iTelephony;
	CTelephony::TCallStatusV1			iCallStatus;
	CTelephony::TCallStatusV1Pckg	iCallStatusPkg;
};

inline TInt Freq2SR(TInt anFreq)
{
	switch(anFreq)
	{
		case 96000: return TMdaAudioDataSettings::ESampleRate96000Hz;
		case 64000: return TMdaAudioDataSettings::ESampleRate64000Hz;
		case 48000: return TMdaAudioDataSettings::ESampleRate48000Hz;
		case 44100: return TMdaAudioDataSettings::ESampleRate44100Hz;
		case 32000: return TMdaAudioDataSettings::ESampleRate32000Hz;
		case 24000: return TMdaAudioDataSettings::ESampleRate24000Hz;
		case 22050: return TMdaAudioDataSettings::ESampleRate22050Hz;
		case 16000: return TMdaAudioDataSettings::ESampleRate16000Hz;
		case 12000: return TMdaAudioDataSettings::ESampleRate12000Hz;
		case 11025: return TMdaAudioDataSettings::ESampleRate11025Hz;
		case 8000: return TMdaAudioDataSettings::ESampleRate8000Hz;
		default: return 0;
	}
}

inline TInt SR2Freq(TInt anSR)
{
	switch(anSR)
	{
		case TMdaAudioDataSettings::ESampleRate96000Hz: return 96000;
		case TMdaAudioDataSettings::ESampleRate64000Hz: return 64000;
		case TMdaAudioDataSettings::ESampleRate48000Hz: return 48000;
		case TMdaAudioDataSettings::ESampleRate44100Hz: return 44100;
		case TMdaAudioDataSettings::ESampleRate32000Hz: return 32000;
		case TMdaAudioDataSettings::ESampleRate24000Hz: return 24000;
		case TMdaAudioDataSettings::ESampleRate22050Hz: return 22050;
		case TMdaAudioDataSettings::ESampleRate16000Hz: return 16000;
		case TMdaAudioDataSettings::ESampleRate12000Hz: return 12000;
		case TMdaAudioDataSettings::ESampleRate11025Hz: return 11025;
		case TMdaAudioDataSettings::ESampleRate8000Hz: return 8000;
		default: return 0;
	}
}

#endif // __FOLDERPLAYVIEW_h__
// End of File
