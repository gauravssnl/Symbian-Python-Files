/*
 ============================================================================
 Name		: FolderPlayDocument.h
 Author	  : Alexander Demidov
 Copyright   : 
 Description : Declares document class for application.
 ============================================================================
 */

#ifndef __FOLDERPLAYDOCUMENT_h__
#define __FOLDERPLAYDOCUMENT_h__

// INCLUDES
#include <akndoc.h>
#include <eikapp.h>


/**
 * CFolderPlayDocument application class.
 * An instance of class CFolderPlayDocument is the Document part of the
 * AVKON application framework for the FolderPlay example application.
 */
class CFolderPlayDocument : public CAknDocument
	{
public:
	// Constructors and destructor

	/**
	 * NewL.
	 * Two-phased constructor.
	 * Construct a CFolderPlayDocument for the AVKON application aApp
	 * using two phase construction, and return a pointer
	 * to the created object.
	 * @param aApp Application creating this document.
	 * @return A pointer to the created instance of CFolderPlayDocument.
	 */
	static CFolderPlayDocument* NewL(CEikApplication& aApp);

	/**
	 * NewLC.
	 * Two-phased constructor.
	 * Construct a CFolderPlayDocument for the AVKON application aApp
	 * using two phase construction, and return a pointer
	 * to the created object.
	 * @param aApp Application creating this document.
	 * @return A pointer to the created instance of CFolderPlayDocument.
	 */
	static CFolderPlayDocument* NewLC(CEikApplication& aApp);

	/**
	 * ~CFolderPlayDocument
	 * Virtual Destructor.
	 */
	virtual ~CFolderPlayDocument();

public:
	// Functions from base classes

	/**
	 * CreateAppUiL
	 * From CEikDocument, CreateAppUiL.
	 * Create a CFolderPlayAppUi object and return a pointer to it.
	 * The object returned is owned by the Uikon framework.
	 * @return Pointer to created instance of AppUi.
	 */
	CEikAppUi* CreateAppUiL();

private:
	// Constructors

	/**
	 * ConstructL
	 * 2nd phase constructor.
	 */
	void ConstructL();

	/**
	 * CFolderPlayDocument.
	 * C++ default constructor.
	 * @param aApp Application creating this document.
	 */
	CFolderPlayDocument(CEikApplication& aApp);

	};

#endif // __FOLDERPLAYDOCUMENT_h__
// End of File
