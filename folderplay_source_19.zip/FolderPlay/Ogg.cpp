/*
 * Ogg.cpp
 *
 *  Created on: Jul 17, 2009
 *      Author: Alexander Demidov
 */

#include "ivorbisfile.h"

#include "FolderPlayView.h"


static TUint fread(TAny* aBuf, TUint aSize, TUint aCount, RFile* aFile)
{
	TPtr8 aPtr((TUint8*)aBuf, aSize * aCount);
	if(aFile->Read(aPtr, aPtr.MaxLength()) != KErrNone) return 0;
	return aPtr.Length() / aSize;
}

static TInt fseek(RFile* aFile, TInt64 aOffset64, TInt aOrigin)
{
	TInt aOffset = (TInt)aOffset64;
	return aFile->Seek(aOrigin == SEEK_SET ? ESeekStart :
		(aOrigin == SEEK_END ? ESeekEnd : ESeekCurrent), aOffset) == KErrNone ? 0 : 1;
}

static TInt fclose(RFile*) { return 0; }

static TInt32 ftell(RFile* aFile)
{ TInt aPos = 0; return aFile->Seek(ESeekCurrent, aPos) == KErrNone ? aPos : -1; }

bool CFolderView::ParseOgg()
{
  OggVorbis_File aVF;
	ov_callbacks aCallbacks =
	{
    (size_t (*)(void *, size_t, size_t, void *))  fread,
    (int (*)(void *, ogg_int64_t, int))           fseek,
    (int (*)(void *))                             fclose,
    (long (*)(void *))                            ftell
  };
	if(ov_open_callbacks(&iAudioFile, &aVF, NULL, 0, aCallbacks) < 0) return false;

	vorbis_info* aVI = ov_info(&aVF, -1);
	iSampleRate = Freq2SR(aVI->rate);
	iChannels = aVI->channels == 2 ? TMdaAudioDataSettings::EChannelsStereo :
				(aVI->channels == 1 ? TMdaAudioDataSettings::EChannelsMono : 0);
	if(iSampleRate == 0 || iChannels == 0) { ov_clear(&aVF); return false; }
	iDataType.Set(KMMFFourCCCodePCM16); ScheduleAudioReset();
	
	iTotalLength = ov_pcm_total(&aVF, -1);
	if(iCurrentPos != 0)
	{
		if(iCurrentPos > 0) ov_pcm_seek(&aVF, iCurrentPos);
		else ov_time_seek(&aVF, -iCurrentPos);
	}
 
	while(iAlive)
	{
		iCurrentPos = (TInt)ov_pcm_tell(&aVF);
		
		int current_section; iCurBuffer.SetMax();
    long aLength = ov_read(&aVF, (char*)iCurBuffer.Ptr(), iCurBuffer.MaxLength(), &current_section);
    if(aLength <= 0) break; 
    if(aLength < iCurBuffer.MaxLength()) iCurBuffer.Set(iCurBuffer.MidTPtr(aLength));
 		else OutputBuffer();
  }
  ov_clear(&aVF); return true; 
}
