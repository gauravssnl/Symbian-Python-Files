/*
 ============================================================================
 Name		: FolderPlay.h
 Author	  : Alexander Demidov
 Copyright   : 
 Description : Declares main application class.
 ============================================================================
 */

#ifndef __FOLDERPLAY_H__
#define __FOLDERPLAY_H__

// INCLUDES
#include <aknapp.h>
#include "FolderPlay.hrh"

// UID for the application;
// this should correspond to the uid defined in the mmp file
const TUid KUidFolderPlayApp = { _UID3 };
const TUid KUidHelpFile = { HELPFILE_UID };

// CLASS DECLARATION

/**
 * CFolderPlayApplication application class.
 * Provides factory to create concrete document object.
 * An instance of CFolderPlayApplication is the application part of the
 * AVKON application framework for the FolderPlay example application.
 */
class CFolderPlayApplication : public CAknApplication
	{
public:
	// Functions from base classes

	/**
	 * From CApaApplication, AppDllUid.
	 * @return Application's UID (KUidFolderPlayApp).
	 */
	TUid AppDllUid() const;

protected:
	// Functions from base classes

	/**
	 * From CApaApplication, CreateDocumentL.
	 * Creates CFolderPlayDocument document object. The returned
	 * pointer in not owned by the CFolderPlayApplication object.
	 * @return A pointer to the created document object.
	 */
	CApaDocument* CreateDocumentL();
	};

#endif // __FOLDERPLAYAPPLICATION_H__
// End of File
