/*
 * flac.cpp
 *
 *  Created on: May 24, 2009
 *      Author: Alexander Demidov
 */
#include "public\stream_decoder.h"

#include "FolderPlayView.h"


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// playback control

static void error_callback(const FLAC__StreamDecoder *, FLAC__StreamDecoderErrorStatus, void *) {}

static void metadata_callback(const FLAC__StreamDecoder *, const FLAC__StreamMetadata *metadata, void *pFV)
{
	if(metadata->type != FLAC__METADATA_TYPE_STREAMINFO) return;
	
	CFolderView& aFV = *(CFolderView*)pFV;
	aFV.iDataType.Set(metadata->data.stream_info.bits_per_sample <= 8 ? KMMFFourCCCodePCMU8 :
			(metadata->data.stream_info.bits_per_sample <= 16 ? KMMFFourCCCodePCM16 : KMMFFourCCCodeNULL));
	aFV.iSampleRate = Freq2SR(metadata->data.stream_info.sample_rate);
	aFV.iChannels = metadata->data.stream_info.channels == 2 ? TMdaAudioDataSettings::EChannelsStereo :
			(metadata->data.stream_info.channels == 1 ? TMdaAudioDataSettings::EChannelsMono : 0);
	aFV.ScheduleAudioReset();
	
	aFV.iTotalLength = (TInt)metadata->data.stream_info.total_samples;
	
	if(aFV.iCurrentPos < 0)		// time in ms, not samples
		aFV.iCurrentPos = (TInt)((TUint64)metadata->data.stream_info.sample_rate * (-aFV.iCurrentPos) / 1000);
}

static FLAC__StreamDecoderWriteStatus write_callback(const FLAC__StreamDecoder *, const FLAC__Frame *frame, const FLAC__int32 * const buffer[], void *pFV)
{
	CFolderView& aFV = *(CFolderView*)pFV;
	if(!aFV.iAlive || aFV.iDataType == KMMFFourCCCodeNULL || aFV.iSampleRate == 0 || aFV.iChannels == 0)
		return FLAC__STREAM_DECODER_WRITE_STATUS_ABORT; 

	if(frame->header.number_type == FLAC__FRAME_NUMBER_TYPE_SAMPLE_NUMBER)
		aFV.iCurrentPos = (TInt)frame->header.number.sample_number;
	
	TInt16* aIt = (TInt16*)aFV.iCurBuffer.Ptr(); TInt16* aEnd = (TInt16*)(aFV.iCurBuffer.Ptr() + aFV.iCurBuffer.MaxLength());
	for(TUint i = 0; i < frame->header.blocksize; ++i)
	{
		*aIt = (FLAC__int16)buffer[0][i]; ++aIt;
		if(aFV.iChannels == TMdaAudioDataSettings::EChannelsStereo) { *aIt = (FLAC__int16)buffer[1][i]; ++aIt; }
		if(aIt >= aEnd)
		{
			aFV.OutputBuffer();
			aIt = (TInt16*)aFV.iCurBuffer.Ptr(); aEnd = (TInt16*)(aFV.iCurBuffer.Ptr() + aFV.iCurBuffer.MaxLength());
		}
	}
	aFV.iCurBuffer.Set((TUint8*)aIt, (aEnd - aIt) * 2, (aEnd - aIt) * 2);
	return FLAC__STREAM_DECODER_WRITE_STATUS_CONTINUE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// non stdio stream, based on RFile

static FLAC__StreamDecoderReadStatus read_callback(const FLAC__StreamDecoder *, FLAC__byte buffer[], size_t *bytes, void *pFV)
{
	RFile& aFile = ((CFolderView*)pFV)->iAudioFile; TPtr8 aBuffer(buffer, *bytes);
	if(!((CFolderView*)pFV)->iAlive || aFile.Read(aBuffer, *bytes) != KErrNone) return FLAC__STREAM_DECODER_READ_STATUS_ABORT;
	*bytes = aBuffer.Length();
	return aBuffer.Length() < aBuffer.MaxLength() ? FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM : FLAC__STREAM_DECODER_READ_STATUS_CONTINUE;
}

static FLAC__StreamDecoderSeekStatus seek_callback(const FLAC__StreamDecoder *, FLAC__uint64 absolute_byte_offset, void *pFV)
{
	RFile& aFile = ((CFolderView*)pFV)->iAudioFile;
	TInt aAbsByteOff32 = (TInt)absolute_byte_offset; 
	return aFile.Seek(ESeekStart, aAbsByteOff32) == KErrNone ?
			FLAC__STREAM_DECODER_SEEK_STATUS_OK : FLAC__STREAM_DECODER_SEEK_STATUS_ERROR;
}

static FLAC__StreamDecoderTellStatus tell_callback(const FLAC__StreamDecoder *, FLAC__uint64 *absolute_byte_offset, void *pFV)
{
	RFile& aFile = ((CFolderView*)pFV)->iAudioFile; *absolute_byte_offset = 0; 
	return aFile.Seek(ESeekCurrent, *(TInt*)absolute_byte_offset) == KErrNone ?
			FLAC__STREAM_DECODER_TELL_STATUS_OK : FLAC__STREAM_DECODER_TELL_STATUS_ERROR;
}

static FLAC__StreamDecoderLengthStatus length_callback(const FLAC__StreamDecoder *, FLAC__uint64 *stream_length, void *pFV)
{
	RFile& aFile = ((CFolderView*)pFV)->iAudioFile; *stream_length = 0;
	return aFile.Size(*(TInt*)stream_length) == KErrNone ?
			FLAC__STREAM_DECODER_LENGTH_STATUS_OK : FLAC__STREAM_DECODER_LENGTH_STATUS_ERROR;
}

static FLAC__bool eof_callback(const FLAC__StreamDecoder *, void *pFV)
{
	RFile& aFile = ((CFolderView*)pFV)->iAudioFile;
	TInt aSize; aFile.Size(aSize);
	TInt aPos = 0; aFile.Seek(ESeekCurrent, aPos);
	return aPos >= aSize;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// entry point

bool CFolderView::ParseFLAC()
{
	iRemLen = 0;
	FLAC__StreamDecoder* decoder = FLAC__stream_decoder_new();
	if(decoder == NULL) return false;

	FLAC__stream_decoder_set_md5_checking(decoder, false);
	
	bool aResult = false;
	if(FLAC__stream_decoder_init_stream(decoder, read_callback, seek_callback, tell_callback, length_callback, eof_callback,
			write_callback, metadata_callback, error_callback, this) == FLAC__STREAM_DECODER_INIT_STATUS_OK)
	{
		if(iCurrentPos != 0)
		{
			FLAC__stream_decoder_process_until_end_of_metadata(decoder);
			FLAC__stream_decoder_seek_absolute(decoder, iCurrentPos);
		}
		aResult = (bool)FLAC__stream_decoder_process_until_end_of_stream(decoder);
 	}
	FLAC__stream_decoder_delete(decoder); return aResult;
}
