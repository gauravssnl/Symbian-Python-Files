/*
 ============================================================================
 Name		: FolderPlay.cpp
 Author	  : Alexander Demidov
 Copyright   : 
 Description : Main application class
 ============================================================================
 */

// INCLUDE FILES
#include <eikstart.h>

#include "FolderPlay.hrh"
#include "FolderPlayDocument.h"
#include "FolderPlay.h"


LOCAL_C CApaApplication* NewApplication()
	{
	return new CFolderPlayApplication;
	}

GLDEF_C TInt E32Main()
	{
	return EikStart::RunApplication(NewApplication);
	}

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CFolderPlayApplication::CreateDocumentL()
// Creates CApaDocument object
// -----------------------------------------------------------------------------
//
CApaDocument* CFolderPlayApplication::CreateDocumentL()
	{
	// Create an FolderPlay document, and return a pointer to it
	return CFolderPlayDocument::NewL(*this);
	}

// -----------------------------------------------------------------------------
// CFolderPlayApplication::AppDllUid()
// Returns application UID
// -----------------------------------------------------------------------------
//
TUid CFolderPlayApplication::AppDllUid() const
	{
	// Return the UID for the FolderPlay application
	return KUidFolderPlayApp;
	}

// End of File
