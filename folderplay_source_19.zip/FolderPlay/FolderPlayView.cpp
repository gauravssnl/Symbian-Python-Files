/*
 ============================================================================
 Name		: FolderPlayView.cpp
 Author	  : Alexander Demidov
 Copyright   : 
 Description : Application view implementation
 ============================================================================
 */

// INCLUDE FILES
#include <coemain.h>
#include <avkon.hrh>
#include <aknmessagequerydialog.h>
#include <aknnotewrappers.h>
#include <stringloader.h>
#include <f32file.h>
#include <s32file.h>
#include <e32math.h>			// for Rand
#include <hlplch.h>
#include <badesca.h>
#include <eikclbd.h>
#include <gulicon.h>
#include <akniconarray.h>
#include <AknToolbar.h>
#include <barsread.h>
#include <bautils.h>
#include <utf.h>
#include <aknnavilabel.h>

#include <remconcoreapitarget.h>

#include <FolderPlay.rsg>

#include "FolderPlay.pan"
#include "FolderPlay.h"
#include "FolderPlay.hlp.hrh"
#include "FolderPlayView.h"
#include <FolderPlay.mbg>

_LIT(KPlayStateFile, "PlayState.ini");

const TInt KBufferSize = 0x20000;

static const TUint encoding[] =
{
	KCharacterSetIdentifierUtf8,						// Test = 0,
	KCharacterSetIdentifierCodePage1252,		// UK English = 1,
	KCharacterSetIdentifierCodePage1252,		// French = 2,
	KCharacterSetIdentifierCodePage1252,		// German = 3,
	KCharacterSetIdentifierCodePage1252,		// Spanish = 4,
	KCharacterSetIdentifierCodePage1252,		// Italian = 5,
	KCharacterSetIdentifierCodePage1252,		// Swedish = 6,
	KCharacterSetIdentifierCodePage1252,		// Danish = 7,
	KCharacterSetIdentifierCodePage1252,		// Norwegian= 8,
	KCharacterSetIdentifierCodePage1252,		// Finnish = 9,
	KCharacterSetIdentifierCodePage1252,		// American English = 10,
	KCharacterSetIdentifierCodePage1252,		// Swiss French = 11,
	KCharacterSetIdentifierCodePage1252,		// Swiss German = 12,
	KCharacterSetIdentifierCodePage1252,		// Portuguese = 13,
	KCharacterSetIdentifierIso88593,				// Turkish = 14,
	KCharacterSetIdentifierCodePage1252,		// Icelandic = 15,
	KCharacterSetIdentifierIso88595,				// Russian = 16,
	KCharacterSetIdentifierIso88592,				// Hungarian = 17,
	KCharacterSetIdentifierCodePage1252,		// Dutch = 18,
	KCharacterSetIdentifierCodePage1252,		// Belgian Flemish = 19,
	KCharacterSetIdentifierCodePage1252,		// Australian English = 20,
	KCharacterSetIdentifierCodePage1252,		// Belgian French = 21,
	KCharacterSetIdentifierCodePage1252,		// Austrian German = 22,
	KCharacterSetIdentifierCodePage1252,		// New Zealand English = 23,
	KCharacterSetIdentifierCodePage1252,		// International French = 24,
	KCharacterSetIdentifierIso88592,				// Czech = 25,
	KCharacterSetIdentifierIso88592,				// Slovak = 26,
	KCharacterSetIdentifierIso88592,				// Polish = 27,
	KCharacterSetIdentifierIso88592,				// Slovenian = 28,
	KCharacterSetIdentifierBig5,						// Taiwanese Chinese = 29,
	KCharacterSetIdentifierBig5,						// Hong Kong Chinese = 30,
	KCharacterSetIdentifierGbk,							// Peoples Republic of China's Chinese = 31,
	KCharacterSetIdentifierShiftJis,				// Japanese = 32,
	KCharacterSetIdentifierUtf8,						// Thai = 33,
	KCharacterSetIdentifierUtf8,						// Afrikaans = 34,
	KCharacterSetIdentifierIso88592,				// Albanian = 35,
	KCharacterSetIdentifierUtf8,						// Amharic = 36,
	KCharacterSetIdentifierIso88596,				// Arabic = 37,
	KCharacterSetIdentifierUtf8,						// Armenian = 38,
	KCharacterSetIdentifierUtf8,						// Tagalog = 39,
	KCharacterSetIdentifierIso88595,				// Belarussian = 40,
	KCharacterSetIdentifierUtf8,						// Bengali = 41,
	KCharacterSetIdentifierIso88595,				// Bulgarian = 42,
	KCharacterSetIdentifierUtf8,						// Burmese = 43,
	KCharacterSetIdentifierCodePage1252,		// Catalan = 44,
	KCharacterSetIdentifierIso88592,				// Croatian = 45,
	KCharacterSetIdentifierCodePage1252,		// Canadian English = 46,
	KCharacterSetIdentifierCodePage1252,		// International English = 47,
	KCharacterSetIdentifierCodePage1252,		// South African English = 48,
	KCharacterSetIdentifierIso88594,				// Estonian = 49,
	KCharacterSetIdentifierIso88596,				// Farsi = 50,
	KCharacterSetIdentifierCodePage1252,		// Canadian French = 51,
	KCharacterSetIdentifierCodePage1252,		// Scots Gaelic = 52,
	KCharacterSetIdentifierUtf8,						// Georgian = 53,
	KCharacterSetIdentifierIso88597,				// Greek = 54,
	KCharacterSetIdentifierIso88597,				// Cyprus Greek = 55,
	KCharacterSetIdentifierUtf8,						// Gujarati = 56,
	KCharacterSetIdentifierIso88598,				// Hebrew = 57,
	KCharacterSetIdentifierUtf8,						// Hindi = 58,
	KCharacterSetIdentifierCodePage1252,		// Indonesian = 59,
	KCharacterSetIdentifierUtf8,						// Irish = 60,
	KCharacterSetIdentifierCodePage1252,		// Swiss Italian = 61,
	KCharacterSetIdentifierUtf8,						// Kannada = 62,
	KCharacterSetIdentifierIso88595					// Kazakh = 63,
};


// -----------------------------------------------------------------------------
// CFolderPlayAppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CFolderPlayAppUi::ConstructL()
{
	BaseConstructL(CAknAppUi::EAknEnableSkin);
	
	if(AknLayoutUtils::PenEnabled())
	{
#ifdef __WINSCW__
		CurrentFixedToolbar()->SetToolbarVisibility(ETrue);
		CurrentFixedToolbar()->SetToolbarObserver(this);
#else
		_LIT(KAvkonLibraryPath, "z:\\system\\libs\\avkon.dll");

		typedef CAknToolbar* (*CurrentFixedToolbarFunctionPtr)(CAknAppUi*);

		RLibrary avkon; CleanupClosePushL(avkon);
		TInt err = avkon.Load(KAvkonLibraryPath);
		if(err == KErrNone)
		{
			CurrentFixedToolbarFunctionPtr aCurrentFixedToolbar = (CurrentFixedToolbarFunctionPtr)avkon.Lookup(4485); 
			if(aCurrentFixedToolbar != NULL)
			{
				CAknToolbar* aToolBar = aCurrentFixedToolbar(this);
				if(aToolBar != NULL)
				{
					aToolBar->SetToolbarVisibility(ETrue);
					aToolBar->SetToolbarObserver(this);
				}
			}
		}
		CleanupStack::PopAndDestroy();
#endif
	}

	iAppView = CFolderView::NewL(ClientRect());
	iAppView->SetMopParent(this);
	AddToStackL(iAppView);
	
	CActiveScheduler::Add(this);

	iTelephony = CTelephony::NewL(); iCallStatus.iStatus = CTelephony::EStatusUnknown;
	iTelephony->NotifyChange(iStatus, CTelephony::EVoiceLineStatusChange, iCallStatusPkg);
	SetActive();
}


// -----------------------------------------------------------------------------
// CFolderPlayAppUi::~CFolderPlayAppUi()
// Destructor.
// -----------------------------------------------------------------------------
//
CFolderPlayAppUi::~CFolderPlayAppUi()
{
	Cancel(); delete iTelephony;
	if(iAppView) { RemoveFromStack(iAppView); delete iAppView; iAppView = NULL; }
}

// -----------------------------------------------------------------------------
// CFolderPlayAppUi::HandleCommandL()
// Takes care of command handling.
// -----------------------------------------------------------------------------
//
void CFolderPlayAppUi::HandleCommandL(TInt aCommand)
{
	switch (aCommand)
	{
		case EPlay_Siblings: iAppView->Stop();
		case EPlay: iAppView->MrccatoCommand(ERemConCoreApiPausePlayFunction, ERemConCoreApiButtonClick); break;
		
		case EPlay_This:
		{	
			TFileName aName; TInt aType = iAppView->GetItemName(iAppView->iListBox.CurrentItemIndex(), aName);
			if(aType == EMbmFolderplayFolder)
			{
				iAppView->Stop(); iAppView->iPlayList.Reset(); iAppView->iCurFileIdx = 0; iAppView->SetPlayingItemL(_L(""));
				aName.Insert(0, iAppView->iPath); aName.Append(L'\\'); iAppView->GetPlayListL(aName);
				if(iAppView->iPlayList.Count() > 0) { iAppView->iCurrentPos = 0; iAppView->Start(); }
			}
			else if(aType == EMbmFolderplayFile || aType == EMbmFolderplayVirtual)
			{
				iAppView->Stop(); iAppView->iPlayList.Reset(); iAppView->iCurFileIdx = 0; iAppView->SetPlayingItemL(_L(""));
				aName.Insert(0, iAppView->iPath); iAppView->iPlayList.AppendL(aName);
				iAppView->iCurrentPos = 0; iAppView->Start();
			}
			else if(aType == EMbmFolderplayTrack)
			{
				iAppView->Stop(); iAppView->iPlayList.Reset(); iAppView->iCurFileIdx = 0; iAppView->iPlayList.AppendL(iAppView->iPath);
				TRAPD(err, iAppView->iCurrentPos = -iAppView->GetTrackTimeL(iAppView->iPath, iAppView->iListBox.CurrentItemIndex()))
				if(err == 0 && iAppView->iCurrentPos <= 0) { iAppView->BackL(); iAppView->Start(); } else iAppView->iCurrentPos = 0;
			}
		} break;
			
		case EPlay_Shuffled:
		{
			TFileName aName;
			if(iAppView->GetItemName(iAppView->iListBox.CurrentItemIndex(), aName) != EMbmFolderplayFolder) break;
			
			iAppView->Stop(); iAppView->iPlayList.Reset(); iAppView->iCurFileIdx = 0; iAppView->SetPlayingItemL(_L(""));
			aName.Insert(0, iAppView->iPath); aName.Append(L'\\');
			iAppView->GetPlayListL(aName); if(iAppView->iPlayList.Count() == 0) break;

			TTime aNow; aNow.HomeTime(); TInt64 aSeed = aNow.Int64();
			TInt n = iAppView->iPlayList.Count();
			while(--n > 0) 
			{
				TInt k = Math::Rand(aSeed) % (n + 1);		// 0 <= k <= n
				if(k != n) Mem::Swap(iAppView->iPlayList.At(k), iAppView->iPlayList.At(n), iAppView->iPlayList.Length());
			}
			iAppView->iCurrentPos = 0; iAppView->Start();
		} break;
		
		case EBackward: iAppView->MrccatoCommand(ERemConCoreApiBackward, ERemConCoreApiButtonClick); break;
			
		case EForward: iAppView->MrccatoCommand(ERemConCoreApiForward, ERemConCoreApiButtonClick); break;
				
		case EAknSoftkeyBack: iAppView->BackL(); break;
		
		case ELast_Played:
			iAppView->LoadPlayStateL();
		case ENow_Playing:
			if(iAppView->iCurFileIdx < iAppView->iPlayList.Count())
				iAppView->SetPathL(iAppView->iPlayList[iAppView->iCurFileIdx].Left(iAppView->iPlayList[iAppView->iCurFileIdx].LocateReverse(L'\\') + 1));
			break;
		
		case EStop: iAppView->MrccatoCommand(ERemConCoreApiStop, ERemConCoreApiButtonClick); break;
		
		case EEikCmdExit: case EAknSoftkeyExit: iAppView->StorePlayStateL(); Exit(); break;

		case EHelp:
		{
			CArrayFix<TCoeHelpContext>* buf = CCoeAppUi::AppHelpContextL();
			HlpLauncher::LaunchHelpApplicationL(iEikonEnv->WsSession(), buf);
		} break;
		
		case EAbout:
		{
			CAknMessageQueryDialog* dlg = new (ELeave) CAknMessageQueryDialog();
			dlg->PrepareLC(R_ABOUT_QUERY_DIALOG);
			HBufC* title = iEikonEnv->AllocReadResourceLC(R_ABOUT_DIALOG_TITLE);
			dlg->QueryHeading()->SetTextL(*title);
			CleanupStack::PopAndDestroy(); //title
			HBufC* msg = iEikonEnv->AllocReadResourceLC(R_ABOUT_DIALOG_TEXT);
			dlg->SetMessageTextL(*msg);
			CleanupStack::PopAndDestroy(); //msg
			dlg->RunLD();
		}	break;
		
		default: CAknAppUi::HandleCommandL(aCommand); break;
	}
}

void CFolderPlayAppUi::OfferToolbarEventL(TInt aCommand) { HandleCommandL(aCommand); }

void CFolderPlayAppUi::HandleWsEventL(const TWsEvent& aEvent, CCoeControl* aDestination)
{
	if(aEvent.Type() != KAknUidValueEndKeyCloseEvent)
		CAknAppUi::HandleWsEventL(aEvent, aDestination);
}

// -----------------------------------------------------------------------------
//  Called by the framework when the application status pane
//  size is changed.  Passes the new client rectangle to the
//  AppView
// -----------------------------------------------------------------------------
//
void CFolderPlayAppUi::HandleStatusPaneSizeChange() { iAppView->SetRect(ClientRect()); }

CArrayFix<TCoeHelpContext>* CFolderPlayAppUi::HelpContextL() const
{
	CArrayFixFlat<TCoeHelpContext>* array = new (ELeave) CArrayFixFlat<TCoeHelpContext> (1);
	CleanupStack::PushL(array);
	array->AppendL(TCoeHelpContext(KUidHelpFile, KContextApplication));
	CleanupStack::Pop(array);
	return array;
}

void CFolderPlayAppUi::RunL()
{
	static TBool aPausedByCall = EFalse;
	if(iStatus == KErrNone && iAppView->iAlive)
		switch(iCallStatus.iStatus)
		{
			case CTelephony::EStatusRinging:
			case CTelephony::EStatusDialling:
				if(!iAppView->iPause) { iAppView->Pause(); aPausedByCall = ETrue; }
				else aPausedByCall = EFalse;
				break;
		
			case CTelephony::EStatusIdle:
				if(iAppView->iPause && aPausedByCall) { iAppView->Resume(); aPausedByCall = EFalse; }
				break;
			
			default: break;
		}
	
	if(iStatus != KErrCancel)
	{
		Cancel();
		iCallStatus.iStatus = CTelephony::EStatusUnknown;
		iTelephony->NotifyChange(iStatus, CTelephony::EVoiceLineStatusChange, iCallStatusPkg);
		SetActive();
	}
}

void CFolderPlayAppUi::DoCancel()
{ iTelephony->CancelAsync(CTelephony::EVoiceLineStatusChangeCancel); }

	
// -----------------------------------------------------------------------------
// CFolderView::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFolderView* CFolderView::NewL(const TRect& aRect)
{
	CFolderView* self = CFolderView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
}

// -----------------------------------------------------------------------------
// CFolderView::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFolderView* CFolderView::NewLC(const TRect& aRect)
{
	CFolderView* self = new (ELeave) CFolderView;
	CleanupStack::PushL(static_cast<CCoeControl*>(self));
	self->ConstructL(aRect);
	return self;
}

// -----------------------------------------------------------------------------
// CFolderView::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//

void CFolderView::ConstructL(const TRect& aRect)
{
	CreateWindowL();
	
	iListBox.ConstructL(this, EAknListBoxSelectionList);
	iListBox.SetListBoxObserver(this);
	iListBox.CreateScrollBarFrameL(ETrue);
	iListBox.ScrollBarFrame()->SetScrollBarVisibilityL(CEikScrollBarFrame::EOff, CEikScrollBarFrame::EAuto);
	
	CArrayPtr<CGulIcon>* icons = new (ELeave) CAknIconArray(18);
	CleanupStack::PushL(icons);
	TPtrC KMBMFile = _L("\\resource\\apps\\FolderPlay.mbm");
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayFile, EMbmFolderplayFile_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayFolder, EMbmFolderplayFolder_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayBack, EMbmFolderplayBack_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayRam, EMbmFolderplayRam_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayRom, EMbmFolderplayRom_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayChip, EMbmFolderplayChip_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayPhone, EMbmFolderplayPhone_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayRemovable, EMbmFolderplayRemovable_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayRemote, EMbmFolderplayRemote_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayHd, EMbmFolderplayHd_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayCd, EMbmFolderplayCd_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayFloppy, EMbmFolderplayFloppy_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayUnknown, EMbmFolderplayUnknown_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayAbsent, EMbmFolderplayAbsent_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayPlaying, EMbmFolderplayPlaying_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayPaused, EMbmFolderplayPaused_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayVirtual, EMbmFolderplayVirtual_mask));
	icons->AppendL(iEikonEnv->CreateIconL(KMBMFile, EMbmFolderplayTrack, EMbmFolderplayTrack_mask));
	CleanupStack::Pop(icons); 
	iListBox.ItemDrawer()->ColumnData()->SetIconArray(icons);
	
	TResourceReader aResReader;
	if(AknLayoutUtils::PenEnabled())
	{
		iEikonEnv->CreateResourceReaderLC(aResReader, R_PROGRESS_SLIDER);
		iProgressSlider.ConstructFromResourceL(this, 0, aResReader);
	}
	else
	{
		iEikonEnv->CreateResourceReaderLC(aResReader, R_PROGRESS_BAR);
		iProgressBar.ConstructFromResourceL(aResReader);
		iProgressBar.SetContainerWindowL(*this);
	}
	CleanupStack::PopAndDestroy();
	
	User::LeaveIfError(iFs.Connect()); iFs.ShareAuto();
	iFs.CreatePrivatePath(EDriveC);
	SetRootL();
	
	iAudioOutput = CMdaAudioOutputStream::NewL(*this);
	iAudioOutput->SetPriority(EMdaPriorityNormal, EMdaPriorityPreferenceQuality);
	iEvenBuffer.CreateMaxL(KBufferSize); iOddBuffer.CreateMaxL(KBufferSize);
	
	SetRect(aRect);
	
	iNaviPane = static_cast<CAknNavigationControlContainer*>(CEikStatusPaneBase::Current()->ControlL(TUid::Uid(EEikStatusPaneUidNavi)));
	iVolumeNavi = iNaviPane->CreateVolumeIndicatorL(R_AVKON_NAVI_PANE_VOLUME_INDICATOR);
	static_cast<CAknVolumeControl*>(iVolumeNavi->DecoratedControl())->SetValue(5);
	iBoostNavi = iNaviPane->CreateNavigationLabelL(); iBoostVal = 0;
		
	iRemSelector = CRemConInterfaceSelector::NewL();
	if(iRemSelector && CRemConCoreApiTarget::NewL(*iRemSelector, *this))
		iRemSelector->OpenTargetL();
	
	CActiveScheduler::Add(this);
	
	ActivateL();
	
	iCharConv = CCnvCharacterSetConverter::NewL();
	if((TUint)User::Language() >= sizeof(encoding) / sizeof(*encoding) ||
			iCharConv->PrepareToConvertToOrFromL(encoding[User::Language()], iFs) != CCnvCharacterSetConverter::EAvailable)
		iCharConv->PrepareToConvertToOrFromL(encoding[0], iFs);
}


// -----------------------------------------------------------------------------
// CFolderView::CFolderView()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CFolderView::CFolderView() : CActive(CActive::EPriorityHigh), iPlayList(8),
	iExtensions(*iCoeEnv->ReadDesCArrayResourceL(R_SUPPORTED_EXTENSIONS)), iCurBuffer(NULL, 0)
{
	iAlive = EFalse; iAudioBusy = EFalse;
	
	iMainThread.Open(RThread().Id());
	iMainThread.SetPriority(EPriorityAbsoluteForeground);
	
	iCharConv = NULL;
	
	iVolumeNavi = NULL; iBoostNavi = NULL; iBoostVal = 0;
	iAudioOutput = NULL;
	iCurFileIdx = 0;
	iRemSelector = NULL;
	
	iDriveIcon[EMediaNotPresent] = EMbmFolderplayAbsent;
	iDriveIcon[EMediaUnknown] = EMbmFolderplayUnknown;
	iDriveIcon[EMediaFloppy] = EMbmFolderplayFloppy;
	iDriveIcon[EMediaHardDisk] = EMbmFolderplayHd; 
	iDriveIcon[EMediaCdRom] = EMbmFolderplayCd;
	iDriveIcon[EMediaRam] = EMbmFolderplayRam;
	iDriveIcon[EMediaFlash] = EMbmFolderplayChip;
	iDriveIcon[EMediaRom] = EMbmFolderplayRom;
	iDriveIcon[EMediaRemote] = EMbmFolderplayRemote;
	iDriveIcon[EMediaNANDFlash] = EMbmFolderplayChip;
	
	iExclusive.CreateLocal(); iStateChange.CreateLocal(); iFreeBuffer.CreateLocal(1);
	
	iCurrentPos = iTotalLength = 0;
}

// -----------------------------------------------------------------------------
// CFolderView::~CFolderView()
// Destructor.
// -----------------------------------------------------------------------------
//
CFolderView::~CFolderView()
{
	Stop();
	
	Cancel();
	
	if(iCharConv != NULL) { delete iCharConv; iCharConv = NULL; }
	
	if(iAudioOutput) { delete iAudioOutput; iAudioOutput = NULL; }
	iEvenBuffer.Close(); iOddBuffer.Close();
	iExclusive.Close(); iStateChange.Close(); iFreeBuffer.Close();
	
	iFs.Close();
	
	iMainThread.Close();
	
	if(iBoostNavi) { delete iBoostNavi; iBoostNavi = NULL; }
	if(iVolumeNavi) { delete iVolumeNavi; iVolumeNavi = NULL; }
	
	if(iRemSelector) { delete iRemSelector; iRemSelector = NULL; }
	
	delete &iExtensions;
}


// -----------------------------------------------------------------------------
// CFolderView::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void CFolderView::SizeChanged()
{
	TInt aProgressHeight = AknLayoutUtils::PenEnabled() ? iListBox.ItemHeight() / 2 : iListBox.ItemHeight() / 3;
	TRect rc = Rect(); rc.iBr.iY -= aProgressHeight; iListBox.SetRect(rc);
	rc.iTl.iY = rc.iBr.iY; rc.iBr.iY += aProgressHeight;
	if(AknLayoutUtils::PenEnabled()) iProgressSlider.SetRect(rc); else iProgressBar.SetRect(rc);
}

void CFolderView::FocusChanged(TDrawNow aDrawNow)
{
	if(IsFocused())
  {
		iNaviPane->PushL(iBoostVal == 0 ? *iVolumeNavi : *iBoostNavi);
		
		if(AknLayoutUtils::PenEnabled())
			iProgressSlider.SetValueL(iAlive && iTotalLength > 0 && iCurrentPos < iTotalLength ? (TInt)((TUint64)iCurrentPos * 640 / iTotalLength) : 0);
		else iProgressBar.SetAndDraw(iAlive && iTotalLength > 0 && iCurrentPos < iTotalLength ? (TInt)((TUint64)iCurrentPos * iProgressBar.Info().iFinalValue / iTotalLength) : 0);
	}
	else iNaviPane->Pop();
	if(aDrawNow == EDrawNow) DrawNow(); else DrawDeferred();
}

// -----------------------------------------------------------------------------
// CFolderView::HandlePointerEventL()
// Called by framework to handle pointer touch events.
// Note: although this method is compatible with earlier SDKs, 
// it will not be called in SDKs without Touch support.
// -----------------------------------------------------------------------------
//
void CFolderView::HandlePointerEventL(const TPointerEvent& aPointerEvent)
{
	static TBool aCaptured = EFalse;
	if(iCurFileIdx < iPlayList.Count() && iTotalLength > 0)
	{
		if(aPointerEvent.iType == TPointerEvent::EButton1Down && iAlive)
		{
			TRect rc = Rect(); rc.iTl.iY = rc.iBr.iY - iListBox.ItemHeight() / 2;
			if(rc.Contains(aPointerEvent.iPosition)) { Stop(); aCaptured = ETrue; SetPlayingItemL(_L("")); } else aCaptured = EFalse;
		}
		else if(aPointerEvent.iType == TPointerEvent::EButton1Up && aCaptured)
		{ iCurrentPos = (TInt)((TUint64)iTotalLength * iProgressSlider.Value() / 640); Start(); aCaptured = EFalse; }
 	}
	else aCaptured = EFalse;
	CCoeControl::HandlePointerEventL(aPointerEvent);
}

void CFolderView::HandleListBoxEventL(CEikListBox* /*aListBox*/, TListBoxEvent aEventType)
{
	switch(aEventType)
	{
		case EEventEnterKeyPressed:
		{
			TFileName aName; TInt aEntryType = GetItemName(iListBox.CurrentItemIndex(), aName);
			switch(aEntryType)
			{
				case EMbmFolderplayFile:
					Stop(); iPlayList.Reset(); GetPlayListL(iPath); aName.Insert(0, iPath);
					if(iPlayList.Find(aName, iCurFileIdx) == 0) { iCurrentPos = 0; Start(); }
					break;
					
				case EMbmFolderplayFolder: aName.Insert(0, iPath); aName.Append(L'\\'); SetPathL(aName); break;
					
				case EMbmFolderplayVirtual:
					aName.Insert(0, iPath); TRAPD(err, SetVirtualPathL(aName)) if(err != 0) SetPathL(iPath); break;
				
				case EMbmFolderplayTrack:
					Stop(); iPlayList.Reset(); GetPlayListL(iPath.Left(iPath.LocateReverse(L'\\') + 1));
					if(iPlayList.Find(iPath, iCurFileIdx) == 0)
					{
						TRAPD(err, iCurrentPos = -GetTrackTimeL(iPath, iListBox.CurrentItemIndex()))
						if(err == 0 && iCurrentPos <= 0) { BackL(); Start(); } else iCurrentPos = 0;
					}
					break;

				default: break;
			}
		} break;
		
    default: break;
	}
}

TKeyResponse CFolderView::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
	static TInt aRepeats;
	if(aType == EEventKeyUp)
		switch(aKeyEvent.iScanCode)
		{
			case EStdKeyLeftArrow:
				if(iAlive) MrccatoCommand(ERemConCoreApiBackward, ERemConCoreApiButtonClick);
				else if(aRepeats > 0 && iTotalLength > 0 && iCurFileIdx < iPlayList.Count())
				{ aRepeats = 0; iCurrentPos = (TInt)((TUint64)iTotalLength * Progress() / 640); Start(); }
				return EKeyWasConsumed;
				
			case EStdKeyRightArrow:
				if(iAlive) MrccatoCommand(ERemConCoreApiForward, ERemConCoreApiButtonClick);
				else if(aRepeats > 0 && iTotalLength > 0 && iCurFileIdx < iPlayList.Count())
				{ aRepeats = 0; iCurrentPos = (TInt)((TUint64)iTotalLength * Progress() / 640); Start(); }
				return EKeyWasConsumed;
		
			case EStdKeyYes:
				if(iAlive) { if(iPause) Resume(); else Pause(); }
				return EKeyWasConsumed;
			
			default: break;
		}	
	else if(aType == EEventKey)
	{
		if(aKeyEvent.iRepeats > 0)
			switch(aKeyEvent.iScanCode)
			{
				case EStdKeyLeftArrow:
					if(aRepeats == 0) { if(!iAlive || iTotalLength == 0) return EKeyWasConsumed; Stop(); SetPlayingItemL(_L("")); }
					IncrementProgress(-1 - aRepeats / 3);
					++aRepeats; return EKeyWasConsumed;
					
				case EStdKeyRightArrow:
					if(aRepeats == 0) { if(!iAlive || iTotalLength == 0) return EKeyWasConsumed; Stop(); SetPlayingItemL(_L("")); }
					IncrementProgress(1 + aRepeats / 3);
					++aRepeats; return EKeyWasConsumed;
				
				case EStdKeyYes:
					if(iAlive) MrccatoCommand(ERemConCoreApiStop, ERemConCoreApiButtonClick); return EKeyWasConsumed;
					return EKeyWasConsumed;
					
				default: break;
			}
		else switch(aKeyEvent.iScanCode)
		{
			case EStdKeyUpArrow:
				if(aKeyEvent.iModifiers & (EModifierFunc|EModifierLeftFunc|EModifierRightFunc|EModifierShift|EModifierLeftShift|EModifierRightShift)) 
				{ MrccatoCommand(ERemConCoreApiVolumeUp, ERemConCoreApiButtonPress); return EKeyWasConsumed; }
				break;
				
			case EStdKeyDownArrow:
				if(aKeyEvent.iModifiers & (EModifierFunc|EModifierLeftFunc|EModifierRightFunc|EModifierShift|EModifierLeftShift|EModifierRightShift))
				{ MrccatoCommand(ERemConCoreApiVolumeDown, ERemConCoreApiButtonPress); return EKeyWasConsumed; }
				break;
			
			case EStdKeyLeftArrow:
			case EStdKeyRightArrow:
				aRepeats = 0;
			default : break;
		}
	}
		
	return iListBox.OfferKeyEventL(aKeyEvent, aType);
}

void CFolderView::MrccatoCommand(TRemConCoreApiOperationId aOperationId, TRemConCoreApiButtonAction aButtonAct)
{
	if(aButtonAct == ERemConCoreApiButtonPress || aButtonAct == ERemConCoreApiButtonClick)
		switch(aOperationId)
		{
			case ERemConCoreApiVolumeUp:
			{
				CAknVolumeControl* aVolCtrl = static_cast<CAknVolumeControl*>(iVolumeNavi->DecoratedControl());
				if(aVolCtrl->Value() < 10)
				{
					iBoostVal = 0; aVolCtrl->SetValue(aVolCtrl->Value() + 1); aVolCtrl->DrawDeferred();
					iAudioOutput->SetVolume(iAudioOutput->MaxVolume() * aVolCtrl->Value() / 10);
				}
				else if(iBoostVal < 10)
				{
					if(iBoostVal == 0) iNaviPane->ReplaceL(*iVolumeNavi, *iBoostNavi);
					
					TBuf<10> aBoost; aBoost.Fill(L'\x266B', ++iBoostVal);
					CAknNaviLabel* aBoostCtrl = static_cast<CAknNaviLabel*>(iBoostNavi->DecoratedControl());
					aBoostCtrl->SetTextL(aBoost); aBoostCtrl->DrawDeferred();
				}
			} return;
					
			case ERemConCoreApiVolumeDown: 
			{
				CAknVolumeControl* aVolCtrl = static_cast<CAknVolumeControl*>(iVolumeNavi->DecoratedControl());
				if(iBoostVal > 0)
				{
					TBuf<10> aBoost; aBoost.Fill(L'\x266B', --iBoostVal);
					CAknNaviLabel* aBoostCtrl = static_cast<CAknNaviLabel*>(iBoostNavi->DecoratedControl());
					aBoostCtrl->SetTextL(aBoost); aBoostCtrl->DrawDeferred();
					if(iBoostVal == 0) { iNaviPane->ReplaceL(*iBoostNavi, *iVolumeNavi); aVolCtrl->SetValue(10); } 
				}
				else if(aVolCtrl->Value() > 0)
				{
					aVolCtrl->SetValue(aVolCtrl->Value() - 1); aVolCtrl->DrawDeferred();
					iAudioOutput->SetVolume(iAudioOutput->MaxVolume() * aVolCtrl->Value() / 10);
				}
			} return;

			default: break;
		}
	if(aButtonAct == ERemConCoreApiButtonClick)
		switch(aOperationId)
		{
			case ERemConCoreApiPausePlayFunction:
				if(iAlive) { if(iPause) Resume(); else Pause(); break; }
	
				if(iPath.Length() == 0) break;
				Stop(); iPlayList.Reset(); iCurFileIdx = 0; SetPlayingItemL(_L(""));
				if(iPath[iPath.Length() - 1] == L'\\')
				{
					GetPlayListL(iPath);
					if(iPlayList.Count() > 0)
					{
						TFileName aName; GetItemName(iListBox.CurrentItemIndex(), aName); aName.Insert(0, iPath);
						for(iCurFileIdx = 0; iCurFileIdx < iPlayList.Count(); ++iCurFileIdx)
							if(aName.CompareF(iPlayList[iCurFileIdx]) <= 0) break;
						if(iCurFileIdx < iPlayList.Count()) { iCurrentPos = 0; Start(); }
					}
				}
				else
				{
					GetPlayListL(iPath.Left(iPath.LocateReverse(L'\\') + 1));
					if(iPlayList.Find(iPath, iCurFileIdx) == 0)
					{
						TRAPD(err, iCurrentPos = -GetTrackTimeL(iPath, iListBox.CurrentItemIndex()))
						if(err == 0 && iCurrentPos <= 0) { BackL(); Start(); } else iCurrentPos = 0;
					}
				}
				break;
			
			case ERemConCoreApiStop:
				Stop(); SetPlayingItemL(_L(""));
				if(AknLayoutUtils::PenEnabled())
				{ iProgressSlider.SetValueL(0); iProgressSlider.DrawDeferred(); }
				else iProgressBar.SetAndDraw(0);
				break;
		
			case ERemConCoreApiBackward:
				if(iAlive) { Stop(); if(iCurFileIdx > 0) --iCurFileIdx; iCurrentPos = 0; Start(); }
				break;
			
			case ERemConCoreApiForward:
				if(iAlive && iCurFileIdx + 1 < iPlayList.Count()) { Stop(); ++iCurFileIdx; iCurrentPos = 0; Start(); }		
				break;
			
			case ERemConCoreApiRewind:
				if(iAlive) { Stop(); iCurrentPos = 0; Start(); }
				break;
			
			default: break;
		}		
}

TInt CFolderView::CountComponentControls() const { return 2; }

CCoeControl* CFolderView::ComponentControl(TInt aIndex) const
{ return aIndex == 0 ? (CCoeControl*)&iListBox : (aIndex == 1 ?
		(AknLayoutUtils::PenEnabled() ? (CCoeControl*)&iProgressSlider : (CCoeControl*)&iProgressBar) : NULL); }

// -----------------------------------------------------------------------------
// CClientAppView::GetHelpContext()
// Gets the control's help context.
// -----------------------------------------------------------------------------
 
void CFolderView::GetHelpContext(TCoeHelpContext& aContext) const
{
	// Get the help context for the application
	aContext.iMajor = KUidHelpFile;
 
	// KContextApplication below should refer to the context declared in
	// help.rtf
	aContext.iContext = KContextApplication;
}


////////////////////////////////////////////////////////////////////////////////////////
// Helpers

void CFolderView::SetRootL(const TDesC& anFocus)
{
	TDriveList aDriveList; User::LeaveIfError(iFs.DriveList(aDriveList));

	CDesCArray& itemArray = *static_cast<CDesCArray*>(iListBox.Model()->ItemTextArray());
	itemArray.Reset();

	const CFont* pFont = AknLayoutUtils::FontFromId(EAknLogicalFontPrimarySmallFont);
	
	// mark the playing drive
	TChar aPlaying = iAlive && iCurFileIdx < iPlayList.Count() ? User::UpperCase(iPlayList[iCurFileIdx][0]) : 0;
		
	for(TInt aDrive = 0; aDrive < aDriveList.Length(); ++aDrive)
		if(aDriveList[aDrive])
		{
			TDriveInfo anInfo; iFs.Drive(anInfo, aDrive);
			TInt aIcon = iDriveIcon[anInfo.iType];
			if((anInfo.iDriveAtt & KDriveAttRemovable) &&
					anInfo.iType != EMediaCdRom && anInfo.iType != EMediaFloppy)
				aIcon = EMbmFolderplayRemovable;
			
			TBuf<20> aDriveName; iFs.GetDriveName(aDrive, aDriveName); aDriveName.TrimAll();
			TChar aDriveLetter; RFs::DriveToChar(aDrive, aDriveLetter); aDriveLetter = aDriveLetter.GetUpperCase();
			TBuf<32> aItemText; aItemText.Format(_L("%d\t"), aIcon);
			if(aDriveName.Length() > 0)
				{ aItemText.Append(aDriveName); aItemText.AppendFormat(_L(" (%c:)"), (TUint)aDriveLetter); }
			else aItemText.AppendFormat(_L("Drive %c:"), (TUint)aDriveLetter);
			if(aDriveLetter == aPlaying) aItemText.AppendFormat(_L("\t%d"), iPause ? EMbmFolderplayPaused : EMbmFolderplayPlaying);

			itemArray.AppendL(aItemText);
			if(pFont != NULL)
				iListBox.ItemDrawer()->ColumnData()->SetColumnFontForRowL(itemArray.Count() - 1, 1, pFont);
			if(anFocus.Length() == 2 &&
				User::UpperCase(anFocus[0]) == aDriveLetter.GetUpperCase() && anFocus[1] == L':')
					iListBox.SetCurrentItemIndex(itemArray.Count() - 1);

			if(anFocus.Length() == 0)
				if(anInfo.iType == EMediaRam || anInfo.iType == EMediaHardDisk)
					iListBox.SetCurrentItemIndex(itemArray.Count() - 1);
		}
	
	iPath.Zero(); iListBox.HandleItemAdditionL(); iListBox.DrawNow();
}

void CFolderView::SetPathL(const TDesC& anPath, const TDesC& anFocus)
{
	if(anPath.Length() == 0) { SetRootL(anFocus); return; }
	if(anPath[anPath.Length() - 1] != L'\\') { SetVirtualPathL(anPath); return; }

	CDir* aEntryList;
	User::LeaveIfError(iFs.GetDir(anPath, KEntryAttMatchMask, ESortByName | EAscending, aEntryList));
	CleanupStack::PushL(aEntryList);
	
	CDesCArray& itemArray = *static_cast<CDesCArray*>(iListBox.Model()->ItemTextArray());
	itemArray.Reset();
	
	const CFont* pFont = AknLayoutUtils::FontFromId(EAknLogicalFontPrimarySmallFont);
		
// is this directory playing ?
	TPtrC16 aPlaying; bool aIsFolder = false;
	if(iAlive && iCurFileIdx < iPlayList.Count() && iPlayList[iCurFileIdx].Left(anPath.Length()).CompareF(anPath) == 0)
	{
		aPlaying.Set(iPlayList[iCurFileIdx].Mid(anPath.Length()));
		TInt aIndex = aPlaying.Locate(L'\\');
		if(aIndex != KErrNotFound) { aPlaying.Set(aPlaying.Left(aIndex)); aIsFolder = true; }
	}
	
// iterate through the entries
	TPath aSheet(anPath);
	for(TInt aIndex = 0; aIndex < aEntryList->Count(); ++aIndex)
	{
		TFileName aItemText;
		if((*aEntryList)[aIndex].IsDir()) aItemText.Format(_L("%d\t"), EMbmFolderplayFolder);
		else
		{
			if(!IsSupported((*aEntryList)[aIndex].iName)) continue;
			aSheet.SetLength(anPath.Length());
			aSheet.Append((*aEntryList)[aIndex].iName.Left((*aEntryList)[aIndex].iName.LocateReverse(L'.')));
			aSheet.Append(_L(".cue"));
			aItemText.Format(_L("%d\t"), BaflUtils::FileExists(iFs, aSheet) ? EMbmFolderplayVirtual : EMbmFolderplayFile);
		}
		aItemText.Append((*aEntryList)[aIndex].iName);
		if(aPlaying.Length() > 0 && (bool)(*aEntryList)[aIndex].IsDir() == aIsFolder && (*aEntryList)[aIndex].iName.CompareF(aPlaying) == 0)
			aItemText.AppendFormat(_L("\t%d"), iPause ? EMbmFolderplayPaused : EMbmFolderplayPlaying);
		itemArray.AppendL(aItemText);
		if(pFont != NULL) iListBox.ItemDrawer()->ColumnData()->SetColumnFontForRowL(itemArray.Count() - 1, 1, pFont);
		if((*aEntryList)[aIndex].iName.CompareF(anFocus) == 0) iListBox.SetCurrentItemIndex(itemArray.Count() - 1);
	}
	CleanupStack::PopAndDestroy(aEntryList); //delete aEntryList;
	
	if(anFocus.Length() == 0) iListBox.SetCurrentItemIndex(0);
	
	iPath = anPath; iListBox.HandleItemAdditionL(); iListBox.DrawNow();
}

HBufC16* CFolderView::GetFileContent(const TDesC& anPath)
{
	RFile aFile; if(aFile.Open(iFs, anPath, EFileRead|EFileShareReadersOnly) != KErrNone) return NULL;
	TInt aSize; if(aFile.Size(aSize) != KErrNone) return NULL;
	
	TBuf8<3> aBOM; aFile.Read(aBOM, 3);
	if(aBOM.Length() >= 2 && aBOM[0] == 0xFF && aBOM[1] == 0xFE)
	{
		if(aSize < 4) { aFile.Close(); return NULL; }
		TInt aPos = 2; aFile.Seek(ESeekStart, aPos);
		HBufC16* aUnicode = HBufC16::NewMax((aSize - 2) >> 1); TPtr8 aPtr((TUint8*)aUnicode->Ptr(), aSize - 2);
		aFile.Read(aPtr, aSize - 2); aFile.Close();
		if(aPtr.Length() == aSize - 2) return aUnicode; else { delete aUnicode; return NULL; }
	}
	else if(aBOM.Length() >= 3 && aBOM[0] == 0xEF && aBOM[1] == 0xBB && aBOM[2] == 0xBF)
	{
		if(aSize < 4) { aFile.Close(); return NULL; }
		TInt aPos = 3; aFile.Seek(ESeekStart, aPos);
		RBuf8 aUTF8; aUTF8.Create(aSize - 3); aFile.Read(aUTF8, aSize - 3); aFile.Close();
		HBufC16* aUnicode = CnvUtfConverter::ConvertToUnicodeFromUtf8L(aUTF8);
		aUTF8.Close(); return aUnicode;
	}
	else
	{
		if(aSize == 0) { aFile.Close(); return NULL; }
		TInt aPos = 0; aFile.Seek(ESeekStart, aPos);
		RBuf8 aForeign; aForeign.Create(aSize); aFile.Read(aForeign, aSize); aFile.Close();
		
		HBufC16* aUnicode = HBufC16::NewMax(aForeign.Length());
		TPtr16 aPtr = aUnicode->Des(); TInt aState = CCnvCharacterSetConverter::KStateDefault;
		TInt aRem = iCharConv->ConvertToUnicode(aPtr, aForeign, aState); aForeign.Close();
		if(aRem == 0) return aUnicode; else { delete aUnicode; return NULL; }
	}
}

void CFolderView::SetVirtualPathL(const TDesC& anPath)
{
	TPath aSheetPath(anPath.Left(anPath.LocateReverse(L'.'))); aSheetPath.Append(_L(".cue"));
	HBufC16* aSheetData = GetFileContent(aSheetPath); User::LeaveIfNull(aSheetData);
	CleanupStack::PushL(aSheetData);
	
	CDesCArray& itemArray = *static_cast<CDesCArray*>(iListBox.Model()->ItemTextArray());
	itemArray.Reset();
	
	const CFont* pFont = AknLayoutUtils::FontFromId(EAknLogicalFontPrimarySmallFont);
		
	// current progress in MS
	const TInt aCurTime = 
		iAlive && iCurFileIdx < iPlayList.Count() && iPlayList[iCurFileIdx].CompareF(anPath) == 0 ?
		  (TInt)((TUint64)iCurrentPos * 1000 / SR2Freq(iAudioSettings.iSampleRate)) : 0;
	
	TLex16 parser(*aSheetData); TUint aTrackNum = 0, aCurTrack = 1, aCurDist = (TUint)-1; 
	while(!parser.Eos())
	{
		TPtrC16 aCmd = parser.NextToken();
		if(aCmd.CompareF(_L("TRACK")) == 0)
		{
			parser.SkipSpace(); User::LeaveIfError(parser.Val(aTrackNum));
			if(aTrackNum != (TUint)itemArray.Count() + 1) User::Leave(KErrCorrupt);
		}
		else if(aTrackNum > 0 && aCmd.CompareF(_L("TITLE")) == 0)
		{
			parser.SkipSpace(); TInt aQuatation = _L("\"'«\x2018\x201C").Locate(parser.Get());
			if(aQuatation == KErrNotFound) User::Leave(KErrCorrupt);
			parser.Mark();
			
			aQuatation = parser.Remainder().Locate(_L("\"'»\x2019\x201D")[aQuatation]);
			if(aQuatation == KErrNotFound) User::Leave(KErrCorrupt);
			parser.Inc(aQuatation); if(parser.MarkedToken().Locate(L'\n') != KErrNotFound) User::Leave(KErrCorrupt);
			
			aSheetPath.Format(_L("%d\t"), EMbmFolderplayTrack); aSheetPath.Append(parser.MarkedToken());
			itemArray.AppendL(aSheetPath);
			
			if(pFont != NULL) iListBox.ItemDrawer()->ColumnData()->SetColumnFontForRowL(itemArray.Count() - 1, 1, pFont);
		}
		else if(aTrackNum > 0 && aCmd.CompareF(_L("INDEX")) == 0)
		{
			parser.SkipSpace(); TUint aType; User::LeaveIfError(parser.Val(aType));
			if(aType == 1)
			{
				parser.SkipSpace();
				TUint aMinute; User::LeaveIfError(parser.Val(aMinute)); if(parser.Get() != L':') User::Leave(KErrCorrupt);
				TUint aSecond; User::LeaveIfError(parser.Val(aSecond)); if(parser.Get() != L':') User::Leave(KErrCorrupt);
				TUint aFrame; User::LeaveIfError(parser.Val(aFrame));
				TInt aTime = (aMinute * 60 + aSecond) * 1000 + aFrame * 1000 / 75;			
				if((TUint)Abs(aCurTime - aTime) < aCurDist) { aCurDist = Abs(aCurTime - aTime); aCurTrack = aTrackNum; }
			}
		}
		
		TInt aNewLine = parser.Remainder().Locate(L'\n'); if(aNewLine == KErrNotFound) break;
		parser.Inc(aNewLine + 1);
	}
	
	CleanupStack::PopAndDestroy(aSheetData);
	iListBox.SetCurrentItemIndex(aCurTrack - 1);
	iPath = anPath; iListBox.HandleItemAdditionL(); iListBox.DrawNow();
}

TInt CFolderView::GetTrackTimeL(const TDesC& anPath, TInt anIndex)
{
	TPath aSheetPath(anPath.Left(anPath.LocateReverse(L'.'))); aSheetPath.Append(_L(".cue"));
	HBufC16* aSheetData = GetFileContent(aSheetPath); User::LeaveIfNull(aSheetData);
	CleanupStack::PushL(aSheetData);
	
	TLex16 parser(*aSheetData); TInt aTime = -1; TUint aTrackNum = 0;
	while(!parser.Eos())
	{
		TPtrC16 aCmd = parser.NextToken();
		if(aCmd.CompareF(_L("TRACK")) == 0) { parser.SkipSpace(); User::LeaveIfError(parser.Val(aTrackNum)); }
		else if(aTrackNum == (TUint)anIndex + 1 && aCmd.CompareF(_L("INDEX")) == 0)
		{
			parser.SkipSpace(); TUint aType; User::LeaveIfError(parser.Val(aType));
			if(aType == 1)
			{
				parser.SkipSpace();
				TUint aMinute; User::LeaveIfError(parser.Val(aMinute)); if(parser.Get() != L':') User::Leave(KErrCorrupt);
				TUint aSecond; User::LeaveIfError(parser.Val(aSecond)); if(parser.Get() != L':') User::Leave(KErrCorrupt);
				TUint aFrame; User::LeaveIfError(parser.Val(aFrame));
				aTime = (aMinute * 60 + aSecond) * 1000 + aFrame * 1000 / 75;			
				break;
			}
		}
		TInt aNewLine = parser.Remainder().Locate(L'\n'); if(aNewLine == KErrNotFound) break;
		parser.Inc(aNewLine + 1);
	}
	CleanupStack::PopAndDestroy(aSheetData); return aTime;
}

TInt CFolderView::GetItemName(TInt anIndex, TDes& anName) const
{
	CDesCArray& itemArray = *static_cast<CDesCArray*>(iListBox.Model()->ItemTextArray());
	if(anIndex >= itemArray.Count()) return -1;

	if(iPath.Length() > 0)
	{
		TLex16 aLex(itemArray[anIndex]);
		TInt aIcon; aLex.Val(aIcon); aLex.Inc(); aLex.Mark();
		TInt aTab = aLex.Remainder().Locate(L'\t');
		if(aTab == KErrNotFound) anName = aLex.Remainder(); else { aLex.Inc(aTab); anName = aLex.MarkedToken(); }
		return aIcon;
	}
	else
	{
		anName.SetLength(2);
		anName[0] = itemArray[anIndex][itemArray[anIndex].Locate(L':') - 1];
		anName[1] = L':'; return EMbmFolderplayFolder;
	}
}

void CFolderView::BackL()
{
	if(iPath.Length() == 0) return;
	if(iPath[iPath.Length() - 1] == L'\\') iPath.SetLength(iPath.Length() - 1);
	
	TInt aIndex = iPath.LocateReverse(L'\\') + 1;
	SetPathL(iPath.Left(aIndex), iPath.Mid(aIndex));
}

void CFolderView::GetPlayListL(const TDesC16& anPath)
{
	TPath aEntryPath = anPath; CDir* aEntryList;
	if(iFs.GetDir(anPath, KEntryAttMatchMask, ESortByName | EAscending, aEntryList) != KErrNone) return;
	CleanupStack::PushL(aEntryList);
	for(TInt aIndex = 0; aIndex < aEntryList->Count(); ++aIndex)
	{
		aEntryPath.SetLength(anPath.Length()); aEntryPath.Append((*aEntryList)[aIndex].iName);
		if((*aEntryList)[aIndex].IsDir()) { aEntryPath.Append(L'\\'); GetPlayListL(aEntryPath); }
		else if(IsSupported((*aEntryList)[aIndex].iName))
			iPlayList.AppendL(aEntryPath);
	}
	CleanupStack::PopAndDestroy(aEntryList); //delete aEntryList;
}

bool CFolderView::IsSupported(const TDesC16& anName) const
{
	TInt aExtension = anName.LocateReverse(L'.');
	return aExtension != KErrNotFound &&
		iExtensions.Find(anName.Mid(aExtension + 1), aExtension) == 0;
}

void CFolderView::SetPlayingItemL(const TDesC& anPlayingItem)
{
	TPtrC16 aPlaying; bool aIsFolder = false;
	if(anPlayingItem.Left(iPath.Length()).CompareF(iPath) == 0)
	{
		aPlaying.Set(anPlayingItem.Mid(iPath.Length()));
		TInt aIndex = aPlaying.Locate(L'\\');
		if(aIndex != KErrNotFound) { aPlaying.Set(aPlaying.Left(aIndex)); aIsFolder = true; }
	}

	TFileName aItemText;
	CDesCArray& itemArray = *static_cast<CDesCArray*>(iListBox.Model()->ItemTextArray());
	for(TInt aIndex = 0; aIndex < itemArray.Count(); ++aIndex)
	{
		TInt i = itemArray[aIndex].Locate(L'\t');
		TLex aLex(itemArray[aIndex].Left(i)); TInt aIcon; aLex.Val(aIcon);
		
		TPtrC16 aFile(itemArray[aIndex].Mid(i + 1)); i = aFile.Locate(L'\t');
		if(i != KErrNotFound)		// currently marked as playing
		{
			aFile.Set(aFile.Left(i));
			TInt aColon = aFile.Locate(L':'); if(aColon != KErrNotFound) aFile.Set(aFile.Mid(aColon - 1, 2));
			
			if((aIcon != EMbmFolderplayFile && aIcon != EMbmFolderplayVirtual) == aIsFolder && aFile.CompareF(aPlaying) == 0) continue;
			aItemText = itemArray[aIndex].Left(itemArray[aIndex].LocateReverse(L'\t'));
		}
		else										// currently marked as not playing
		{
			TInt aColon = aFile.Locate(L':'); if(aColon != KErrNotFound) aFile.Set(aFile.Mid(aColon - 1, 2));
			
			if((aIcon != EMbmFolderplayFile && aIcon != EMbmFolderplayVirtual) != aIsFolder || aFile.CompareF(aPlaying) != 0) continue;
			aItemText = itemArray[aIndex]; aItemText.AppendFormat(_L("\t%d"), iPause ? EMbmFolderplayPaused : EMbmFolderplayPlaying);
		}
		itemArray.Delete(aIndex); itemArray.InsertL(aIndex, aItemText);
		iListBox.DrawItem(aIndex);
	}
}

void CFolderView::IncrementProgress(TInt aInc)
{
	if(AknLayoutUtils::PenEnabled())
	{
		TInt aValue = iProgressSlider.Value() + aInc;
		if(aValue >= 640) aValue = 639; else if(aValue < 0) aValue = 0; 
		iProgressSlider.SetValueL(aValue); iProgressSlider.DrawNow();
	}
	else iProgressBar.IncrementAndDraw(aInc);	
}

TInt CFolderView::Progress() const
{ return AknLayoutUtils::PenEnabled() ? iProgressSlider.Value() : iProgressBar.CurrentValue(); }

void CFolderView::StorePlayStateL()
{
	if(iPlayList.Count() == 0) return;
	
	TFileName aPlayStateFile;
	User::LeaveIfError(iFs.PrivatePath(aPlayStateFile));
	aPlayStateFile += KPlayStateFile;
	
	RFileWriteStream aPlayState;
	if(aPlayState.Open(iFs, aPlayStateFile, EFileWrite|EFileShareExclusive|EFileWriteBuffered) != KErrNone)
		User::LeaveIfError(aPlayState.Create(iFs, aPlayStateFile, EFileWrite|EFileShareExclusive|EFileWriteBuffered));
  
	aPlayState.PushL();
  
	aPlayState.WriteUint8L(0);	// version
	aPlayState.WriteInt32L(static_cast<CAknVolumeControl*>(iVolumeNavi->DecoratedControl())->Value());
	aPlayState.WriteInt32L(iCurFileIdx < iPlayList.Count() ? iCurrentPos : 0);
	aPlayState.WriteInt32L(iCurFileIdx < iPlayList.Count() ? iCurFileIdx : 0);
	aPlayState.WriteInt32L(iPlayList.Count());
	for(TInt i = 0; i < iPlayList.Count(); ++i) aPlayState << iPlayList[i];
  
	aPlayState.CommitL(); aPlayState.Pop(); aPlayState.Release();
}

void CFolderView::LoadPlayStateL()
{
	TFileName aPlayStateFile;
	User::LeaveIfError(iFs.PrivatePath(aPlayStateFile));
	aPlayStateFile += KPlayStateFile;
	
	RFileReadStream aPlayState;
	if(aPlayState.Open(iFs, aPlayStateFile, EFileRead|EFileShareReadersOnly|EFileReadBuffered) != KErrNone) return;

	aPlayState.PushL();
	if(aPlayState.ReadUint8L() == 0)
	{
		static_cast<CAknVolumeControl*>(iVolumeNavi->DecoratedControl())->SetValue(aPlayState.ReadInt32L());
		Stop(); SetPlayingItemL(_L("")); iPlayList.Reset();
		iCurrentPos = aPlayState.ReadInt32L();
		iCurFileIdx = aPlayState.ReadInt32L();
		TInt aCount = aPlayState.ReadInt32L();
		for(TInt i = 0; i < aCount; ++i)
		{
			TFileName aTrack; aPlayState >> aTrack;
			if(BaflUtils::FileExists(iFs, aTrack)) iPlayList.AppendL(aTrack);
			else if(iPlayList.Count() < iCurFileIdx) --iCurFileIdx;
			else if(iPlayList.Count() == iCurFileIdx) { iCurFileIdx = 0; iCurrentPos = 0; }
		}
		if(iPlayList.Count() > 0) Start();
	}
	aPlayState.Pop(); aPlayState.Release();
}

// End of File
