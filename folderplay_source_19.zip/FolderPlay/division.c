/*
 * division.c
 *
 *  Created on: Jun 20, 2009
 *      Author: Alexander Demidov
 */

#ifdef __GCCE__ 

extern unsigned int __aeabi_uidivmod(unsigned numerator, unsigned denominator);

int __aeabi_idiv(int numerator, int denominator) 
{
	int neg_result = (numerator ^ denominator) & 0x80000000;
	int result = __aeabi_uidivmod ((numerator < 0) ? -numerator : numerator, (denominator < 0) ? -denominator : denominator);
	return neg_result ? -result : result;
}

unsigned __aeabi_uidiv(unsigned numerator, unsigned denominator) 
{ return __aeabi_uidivmod (numerator, denominator); }
 
#endif // __GCCE__
