/*
 ============================================================================
 Name		: FolderPlayDocument.cpp
 Author	  : Alexander Demidov
 Copyright   : 
 Description : CFolderPlayDocument implementation
 ============================================================================
 */

// INCLUDE FILES
#include "FolderPlayView.h"
#include "FolderPlayDocument.h"

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// CFolderPlayDocument::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFolderPlayDocument* CFolderPlayDocument::NewL(CEikApplication& aApp)
	{
	CFolderPlayDocument* self = NewLC(aApp);
	CleanupStack::Pop(self);
	return self;
	}

// -----------------------------------------------------------------------------
// CFolderPlayDocument::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
CFolderPlayDocument* CFolderPlayDocument::NewLC(CEikApplication& aApp)
	{
	CFolderPlayDocument* self = new (ELeave) CFolderPlayDocument(aApp);

	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

// -----------------------------------------------------------------------------
// CFolderPlayDocument::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CFolderPlayDocument::ConstructL()
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CFolderPlayDocument::CFolderPlayDocument()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CFolderPlayDocument::CFolderPlayDocument(CEikApplication& aApp) :
	CAknDocument(aApp)
	{
	// No implementation required
	}

// ---------------------------------------------------------------------------
// CFolderPlayDocument::~CFolderPlayDocument()
// Destructor.
// ---------------------------------------------------------------------------
//
CFolderPlayDocument::~CFolderPlayDocument()
	{
	// No implementation required
	}

// ---------------------------------------------------------------------------
// CFolderPlayDocument::CreateAppUiL()
// Constructs CreateAppUi.
// ---------------------------------------------------------------------------
//
CEikAppUi* CFolderPlayDocument::CreateAppUiL()
	{
	// Create the application user interface, and return a pointer to it;
	// the framework takes ownership of this object
	return new (ELeave) CFolderPlayAppUi;
	}

// End of File
