/*
 * ac3.cpp
 *
 *  Created on: 15/06/2009
 *      Author: Standard User
 */

#include <es_sock.h>

#include "a52.h"

#include "FolderPlayView.h"


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Seeking through MPEG PS

static bool IsMPEG(const RFile& aStream)
{
	TBuf8<1> aByte; aStream.Read(aByte, 1); TInt aPos = -aByte.Length(); aStream.Seek(ESeekCurrent, aPos); 
	return aByte.Length() == 0 || aByte[0] == 0;
}

static bool SeekMPEG(const RFile& aStream, TInt aPos)
{
	if(aStream.Seek(ESeekStart, aPos) != KErrNone) return false; 
	static TBuf8<0x2000> sBuf; if(aStream.Read(sBuf, sBuf.MaxLength()) != KErrNone) return false;
	
	static const TUint sPrivPesSync = 0xBD010000;
	aPos = sBuf.Find((const TUint8*)&sPrivPesSync, 4); if(aPos == KErrNotFound) return false;
	
	aPos -= sBuf.Length();
	return aStream.Seek(ESeekCurrent, aPos) == KErrNone;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// AC3

static a52_state_t* state = NULL;

static bool SeekAC3(const RFile& aStream, TInt aPos)
{
	if(aStream.Seek(ESeekStart, aPos) != KErrNone) return false; 
	static TBuf8<0x2000> sBuf; if(aStream.Read(sBuf, sBuf.MaxLength()) != KErrNone) return false;
	
	TInt aTemp; aPos = -2;
	do
	{
		static const TUint16 sSync = 0x770B; aPos += 2;
		aTemp = sBuf.Mid(aPos).Find((const TUint8*)&sSync, 2); if(aTemp == KErrNotFound) return false;
		aPos += aTemp; if(aPos + 6 >= sBuf.Length()) return false;
	}	
	while(a52_syncinfo(const_cast<uint8_t*>(sBuf.Ptr() + aPos), &aTemp, &aTemp, &aTemp) == 0);
	
	aPos -= sBuf.Length();
	return aStream.Seek(ESeekCurrent, aPos) == KErrNone;
}

TInt CFolderView::OutputAC3Frame(const TUint8* buf)
{
	TInt aFlags, aBitrate;
	TInt aLength = a52_syncinfo(const_cast<uint8_t*>(buf), &aFlags, &iSampleRate, &aBitrate);
	if(aLength == 0) return 0;
	
	iSampleRate = Freq2SR(iSampleRate); if(iSampleRate == 0) return aLength;
	
	aFlags = ((aFlags & A52_CHANNEL_MASK) != A52_MONO ? A52_STEREO : A52_MONO) | A52_ADJUST_LEVEL; sample_t aLevel = 0x7FFF;	// 16-bit
	if(a52_frame(state, const_cast<uint8_t*>(buf), &aFlags, &aLevel, 0)) return aLength;
	
	iChannels = (aFlags & A52_CHANNEL_MASK) == A52_STEREO ? TMdaAudioDataSettings::EChannelsStereo :
		((aFlags & A52_CHANNEL_MASK) == A52_MONO ? TMdaAudioDataSettings::EChannelsMono : 0);
	if(iChannels == 0) return aLength;
	iDataType.Set(KMMFFourCCCodePCM16); ScheduleAudioReset();
	
	a52_dynrng(state, NULL, NULL);
	
	TInt16* aIt = (TInt16*)iCurBuffer.Ptr(); TInt16* aEnd = (TInt16*)(iCurBuffer.Ptr() + iCurBuffer.MaxLength());
	for(TInt i = 0; i < 6; ++i)
	{
		if(a52_block(state)) break;
		for(TInt j = 0; j < 256; ++j)
		{
			*aIt = (TInt16)a52_samples(state)[j]; ++aIt;																																		// left channel
			if(iChannels == TMdaAudioDataSettings::EChannelsStereo) { *aIt = (TInt16)a52_samples(state)[j + 256]; ++aIt; }	// right channel
			if(aIt >= aEnd)
			{
				OutputBuffer();
				aIt = (TInt16*)iCurBuffer.Ptr(); aEnd = (TInt16*)(iCurBuffer.Ptr() + iCurBuffer.MaxLength());
			}
		}
	}
	iCurBuffer.Set((TUint8*)aIt, (aEnd - aIt) * 2, (aEnd - aIt) * 2);
	return aLength;
}

// AC3 entry

bool CFolderView::ParseAC3()
{
	static TUint8 aData[0x1000];
	if(iCurrentPos < 0) iCurrentPos = 0;
	state = a52_init(); if(state == NULL) return false;
	
	iAudioFile.Size(iTotalLength);
	
	if(IsMPEG(iAudioFile))
	{
		if(iCurrentPos > 0 && !SeekMPEG(iAudioFile, iCurrentPos)) { a52_free(state); return false; } 
		while(iAlive)
		{
			TBuf8<4> aBuf; iAudioFile.Read(aBuf, 4);
			if(aBuf.Length() == 0) break;
			if(aBuf.Length() < 4) { a52_free(state); return false; }
			TUint32 aCode = LittleEndian::Get32(aBuf.Ptr());
			
			if((aCode & 0xFFFFFF) != 0x010000) { a52_free(state); return false; }
			
			if(aCode == 0xBA010000)
			{
				TInt aPos = 9; iAudioFile.Seek(ESeekCurrent, aPos);
				iAudioFile.Read(aBuf, 1); aPos = aBuf[0] & 7;
				iAudioFile.Seek(ESeekCurrent, aPos); continue;
			}
			
			if(aCode == 0xB9010000) continue;

			iAudioFile.Read(aBuf, 2); TInt aPacket = BigEndian::Get16(aBuf.Ptr());
			if(aCode != 0xBD010000) { iAudioFile.Seek(ESeekCurrent, aPacket); continue; }
			
			iAudioFile.Read(aBuf, 3); aPacket -= 3;
			TInt aPos = aBuf[2]; iAudioFile.Seek(ESeekCurrent, aPos); aPacket -= aBuf[2];
			iCurrentPos = aPos;

			// payload		
			iAudioFile.Read(aBuf, 4); aPacket -= aBuf.Length();
			if(aBuf[0] < 0x80 || aBuf[0] > 0x87)
			{ iAudioFile.Seek(ESeekCurrent, aPacket); continue; }
		
			TInt aFrames = aBuf[1], aOffset = BigEndian::Get16(aBuf.Ptr() + 2) - 1;		
	
		// frames
			aPacket -= aOffset;
			if(iRemLen > 0)		// if there is some data left from previous file/packet
			{
				TPtr8 aPtr(aData + iRemLen, sizeof(aData) - iRemLen);
				iAudioFile.Read(aPtr, aOffset); OutputAC3Frame(aData);
			}
			else iAudioFile.Seek(ESeekCurrent, aOffset);	// else ignore the beginning of the packet
		
			TPtr8 aPtr(aData, sizeof(aData)); iAudioFile.Read(aPtr, aPacket); aOffset = 0;
			while(--aFrames > 0)			// iterates only through whole frames
			{
				TInt aLength = OutputAC3Frame(aData + aOffset); if(aLength == 0) break;
				aOffset += aLength;		// next frame
			}
		
			if(aFrames == 0)	// if no error, preserve the leftover
			{
				Mem::Copy(aData, aData + aOffset, aPtr.Length() - aOffset);
				iRemLen = aPtr.Length() - aOffset;
			}
			else iRemLen = 0;	// else ignore the rest of the packet
		}
	}
	else
	{
		iRemLen = 0;
		if(iCurrentPos > 0 && !SeekAC3(iAudioFile, iCurrentPos)) { a52_free(state); return false; }
		TPtr8 aPtr(aData, sizeof(aData)); 
		while(iAlive)
		{
			iAudioFile.Read(aPtr, aPtr.MaxLength()); if(aPtr.Length() < 7) break;
			TInt aFrameLen = OutputAC3Frame(aData);
			if(aFrameLen == 0) { a52_free(state); return false; }
			aFrameLen -= aPtr.Length(); iAudioFile.Seek(ESeekCurrent, aFrameLen);
		
			iCurrentPos = aFrameLen;
		}
	}
	a52_free(state); return true;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LPCM

struct LPCMpack																// starts private LPCM stream payload
{
	TUint8		sub_stream_id;										// 10100***b = audio stream number
	TUint8		frame_headers;										// number of audio frames, whose first byte is in this pack 
	TUint16		first_access_unit_pointer;				// pointer to the first byte of the first frame that the PES PTS applies to

	TUint8		frame												: 5;	// frame number within group of audio frames
	TUint8																: 1;	// reserved
	TUint8		mute												: 1;	// 0 = off, 1 = on
	TUint8		emphasis										: 1;	// 0 = off, 1 = on
	
	TUint8		channels										: 3;	// 0 = 1ch, 1 = 2ch etc.
	TUint8																: 1;	// reserved
	TUint8		sample_rate									: 2;	// 0 = 48kHz, 1 = 96kHz, other = reserved
	TUint8		bits_per_sample							: 2;	// 0 = 16, 1 = 20, 2 = 24, 3 = reserved

	TUint8		dynamic_range_lo						: 5;	// in dB gain = 24.082-6.0206*hi-0.2007*lo
	TUint8		dynamic_range_hi						: 3;	// linear gain = 2^(4-(hi+(lo/30)))
	
	inline TFourCC DataType() const
	{ return bits_per_sample == 0 ? KMMFFourCCCodePCM16B : KMMFFourCCCodeNULL; }
	
	inline TInt SampleRate() const
	{ return sample_rate == 0 ? TMdaAudioDataSettings::ESampleRate48000Hz :
			(sample_rate == 1 ? TMdaAudioDataSettings::ESampleRate96000Hz : 0); }
	
	inline TInt Channels() const
	{ return channels == 1 ? TMdaAudioDataSettings::EChannelsStereo :
			(channels == 0 ? TMdaAudioDataSettings::EChannelsMono : 0); }
};

// LPCM entry

bool CFolderView::ParseLPCM()
{
	if(iCurrentPos < 0) iCurrentPos = 0;
	if(iCurrentPos > 0 && !SeekMPEG(iAudioFile, iCurrentPos)) return false;
	iAudioFile.Size(iTotalLength); iRemLen = 0;
	
	while(iAlive)
	{
		TBuf8<4> aBuf; iAudioFile.Read(aBuf, 4);
		if(aBuf.Length() == 0) break; if(aBuf.Length() < 4) return false;
		TUint32 aCode = LittleEndian::Get32(aBuf.Ptr());
		
		if((aCode & 0xFFFFFF) != 0x010000) return false;

		if(aCode == 0xBA010000)
		{
			TInt aPos = 9; iAudioFile.Seek(ESeekCurrent, aPos);
			iAudioFile.Read(aBuf, 1); aPos = aBuf[0] & 7;
			iAudioFile.Seek(ESeekCurrent, aPos); continue;
		}
		
		if(aCode == 0xB9010000) continue;

		iAudioFile.Read(aBuf, 2); TInt aPacket = BigEndian::Get16(aBuf.Ptr());
		if(/*(aCode & 0xE0000000) != 0xC0000000 &&*/ aCode != 0xBD010000)
		{ iAudioFile.Seek(ESeekCurrent, aPacket); continue; }
		
		iAudioFile.Read(aBuf, 3); aPacket -= 3;
		TInt aPos = aBuf[2]; iAudioFile.Seek(ESeekCurrent, aPos); aPacket -= aBuf[2];
		iCurrentPos = aPos;
		
		LPCMpack aAudioParam; TPtr8 aPtr((TUint8*)&aAudioParam, 7);
		iAudioFile.Read(aPtr, aPtr.MaxLength()); aPacket -= aPtr.Length();
		iDataType = aAudioParam.DataType(); iSampleRate = aAudioParam.SampleRate(); iChannels = aAudioParam.Channels();
		if(aAudioParam.sub_stream_id >= 0xA0 && aAudioParam.sub_stream_id < 0xA8 &&
				iDataType != KMMFFourCCCodeNULL && iSampleRate != 0 && iChannels != 0)
			{ ScheduleAudioReset(); OutputBlock(aPacket); }
		else iAudioFile.Seek(ESeekCurrent, aPacket);
	}
	return true;
}
