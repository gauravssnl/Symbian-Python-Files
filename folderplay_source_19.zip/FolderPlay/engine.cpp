#include <es_sock.h>
#include <e32math.h>

#include "FolderPlayView.h"

// mp2 audio FourCC, if supported
const TUint32 KMMFFourCCCodeMP2 = 0x32504d20;		//(' ','M','P','2')

////////////////////////////////////////////////////////////////////////////////
// folded FourCC (big-endian -> little-endian)

static inline TFourCC operator ~(TFourCC anFourCC)
{
	return anFourCC == KMMFFourCCCodePCM16B ? KMMFFourCCCodePCM16 :
		(anFourCC == KMMFFourCCCodePCMU16B ? KMMFFourCCCodePCMU16 : anFourCC);
}

////////////////////////////////////////////////////////////////////////////////
// outputs the current buffer to the audio device,
// waits for the next available buffer and switchs to it
//
// virtually blocks

void CFolderView::OutputBuffer()
{
	iExclusive.Wait();
	// freeze, if playback is paused
	if(iPause)
	{
		TBool aSetAudioParam = iSetAudioParam;
		if(!aSetAudioParam) iCurBuffer.Set(InactiveBuffer().MidTPtr(0));	// if possible, switch back to the previous buffer
		if(iAudioDataType == KMMFFourCCCodeAAC)														// if AAC, resync the current buffer
		{
			TInt aSync = -2;
			while(true)
			{
				TInt aRelSync = ActiveBuffer().Mid(aSync += 2).Locate(0xFF); if(aRelSync == KErrNotFound) break;
				aSync += aRelSync; if(aSync + 1 >= ActiveBuffer().Length()) break;
				if((ActiveBuffer()[aSync + 1] & 0xF0) == 0xF0)
				{
					Mem::Copy((TUint8*)ActiveBuffer().Ptr(), ActiveBuffer().Ptr() + aSync, ActiveBuffer().Length() - aSync);
					ActiveBuffer().SetLength(ActiveBuffer().Length() - aSync); break;
				}
			}
		}
		while(iPause && iAlive) iStateChange.Wait(iExclusive);						// wait here for resume
		if(!iAlive) { iExclusive.Signal(); return; }
		if(!aSetAudioParam)																								// if switched to the previous buffer, send it, and switch back
		{
			// send the last returned buffer once again
			iStatus = KRequestPending; SetActive(); iBufferPending = ETrue;
			TRequestStatus* aStatus = &iStatus; iMainThread.RequestComplete(aStatus, KErrNone);
			while(iBufferPending && iAlive) iStateChange.Wait(iExclusive);
			// dereference buffer resource and switch to another buffer
			iFreeBuffer.Wait(); iCurBuffer.Set(InactiveBuffer().MidTPtr(0));
		}
	}
	
// if FourCC is scheduled to be changed, wait for audio device to empty out
	if(iSetAudioParam)
	{
		while(iAudioBusy && iAlive) if(iStateChange.TimedWait(iExclusive, 1000000) == KErrTimedOut) iAudioBusy = EFalse;
		if(!iAlive) { iExclusive.Signal(); return; }
	}

// boost PCM audio signal on-the-fly
	if(iBoostVal > 0 && iAudioDataType == KMMFFourCCCodePCM16)
	{
		TInt16* aSample = (TInt16*)&ActiveBuffer()[0]; TInt16* aEnd = aSample + (ActiveBuffer().Length() >> 1);
		TReal aFactor; Math::Pow(aFactor, 10, (TReal)iBoostVal / 10);
		while(aSample < aEnd)
		{
			TInt aBoosted = (TInt)(*aSample * aFactor + (*aSample >= 0 ? .5 : -.5));
			*aSample = aBoosted >= 0x8000 ? 0x7FFF : (aBoosted < -0x8000 ? 0x8000 : (TInt16)aBoosted);
			++aSample;
		}
	}
	
// write to audio device in the main thread (CFolderView::RunL)
	iStatus = KRequestPending; SetActive(); iBufferPending = ETrue;
	TRequestStatus* aStatus = &iStatus; iMainThread.RequestComplete(aStatus, KErrNone);
	while(iBufferPending && iAlive) iStateChange.Wait(iExclusive);
		
	iExclusive.Signal();
// wait for an empty buffer and switch to it
	iFreeBuffer.Wait();
	InactiveBuffer().SetMax(); iCurBuffer.Set(InactiveBuffer().MidTPtr(0));
}

////////////////////////////////////////////////////////////////////////////////
// flushes remaining audio data
//
// <iCurBuffer> must point to the remaining portion of a physical buffer
// virtually blocks

void CFolderView::Flush()
{
	if(iCurBuffer.MaxLength() < iEvenBuffer.MaxLength())	// if there is some data pending
	{
		ActiveBuffer().SetLength(iEvenBuffer.MaxLength() - iCurBuffer.MaxLength());
		OutputBuffer();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// if audio parameters have changed, schedules audio reset as soon as possible

void CFolderView::ScheduleAudioReset()
{
	if(~iDataType != iAudioDataType || iSampleRate != iAudioSettings.iSampleRate || iChannels != iAudioSettings.iChannels)
	{
		Flush(); iSetAudioParam = ETrue;
		iAudioDataType = ~iDataType;
		iAudioSettings.iSampleRate = iSampleRate; iAudioSettings.iChannels = iChannels;
	}
}

////////////////////////////////////////////////////////////////////////////////
// Writes a block of audio data to the logical buffer <iCurBuffer>
//
// <iCurBuffer> must point to the remaining portion of a physical buffer
// <iAudioFile> must be opened and positioned at the start of the block
// <aDataLen> is the block length
//
// the function may block, or return normally,
// thus it can only be called asynchroniously;
// on return <iAudioFile> points just past the end of the block or EOF

void CFolderView::OutputBlock(TInt aDataLen, TBool aCountData)
{
	while(iAlive)
	{
		iAudioFile.Read(iCurBuffer, Min(aDataLen, iCurBuffer.MaxLength()));
		if(aCountData) iCurrentPos += iCurBuffer.Length();
		
		if(iDataType == KMMFFourCCCodePCM16B || iDataType == KMMFFourCCCodePCMU16B)
			for(TInt aIdx = 0; aIdx < iCurBuffer.Length(); aIdx += 2)
				Mem::Swap(&iCurBuffer[aIdx], &iCurBuffer[aIdx + 1], 1);
	
		if(iCurBuffer.Length() < iCurBuffer.MaxLength()) break;
		aDataLen -= iCurBuffer.Length();
		
		OutputBuffer();
	}
	aDataLen = iCurBuffer.Length(); iCurBuffer.SetMax();
	iCurBuffer.Set(iCurBuffer.MidTPtr(aDataLen));
}

bool CFolderView::ParseWave(TUint32 anChunkEnd, TBool anBigEndian)
{
	iCurrentPos = iTotalLength = 0; iRemLen = 0;
	TInt aPos = 0; iAudioFile.Seek(ESeekCurrent, aPos);
	while(iAlive && (TUint32)aPos < anChunkEnd)
	{
		TBuf8<8> aHeader; iAudioFile.Read(aHeader, 8);
		if(aHeader.Length() == 0) break; if(aHeader.Length() < 8) return false;
		TUint32 aSize = anBigEndian ? BigEndian::Get32(aHeader.Ptr() + 4) : LittleEndian::Get32(aHeader.Ptr() + 4);
			
		if(aHeader.Left(4) == _L8("fmt "))
		{
			TBuf8<4> aParam;
			
			iAudioFile.Read(aParam, 2);
			TUint16 aCompression =  anBigEndian ? BigEndian::Get16(aParam.Ptr()) : LittleEndian::Get16(aParam.Ptr());
			iAudioFile.Read(aParam, 2);
			iChannels = anBigEndian ? BigEndian::Get16(aParam.Ptr()) : LittleEndian::Get16(aParam.Ptr());
			if(iChannels == 2) iChannels = TMdaAudioDataSettings::EChannelsStereo;
			else if(iChannels == 1) iChannels = TMdaAudioDataSettings::EChannelsMono;
			else return false;
			iAudioFile.Read(aParam, 4);
			iSampleRate = anBigEndian ? BigEndian::Get32(aParam.Ptr()) : LittleEndian::Get32(aParam.Ptr());
			iSampleRate = Freq2SR(iSampleRate); if(iSampleRate == 0) return false;
			
			TInt aOffset = 6; iAudioFile.Seek(ESeekCurrent, aOffset);
			iAudioFile.Read(aParam, 2);
			TUint16 aBitsPerSample = anBigEndian ? BigEndian::Get16(aParam.Ptr()) : LittleEndian::Get16(aParam.Ptr());
		
			switch(aCompression)
			{
				case 0: iDataType.Set(KMMFFourCCCodeNULL); break;
				case 1:
					if(aBitsPerSample <= 8) iDataType.Set(KMMFFourCCCodePCMU8);
					else if(aBitsPerSample <= 16) iDataType.Set(anBigEndian ? KMMFFourCCCodePCM16B : KMMFFourCCCodePCM16);
					else return false;
					break;
				//case 2: break;
				case 6: iDataType.Set(KMMFFourCCCodeALAW); break;
				case 7: iDataType.Set(KMMFFourCCCodeMuLAW); break;
				case 17: iDataType.Set(iChannels == TMdaAudioDataSettings::EChannelsStereo ?
						KMMFFourCCCodeIMAS : KMMFFourCCCodeIMAD); break;
				//case 20: break;
				case 49: iDataType.Set(KMMFFourCCCodeGSM610); break;
				//case 64: break;
				case 80: iDataType.Set(KMMFFourCCCodeMP2); break; 
				case 85: iDataType.Set(KMMFFourCCCodeMP3); break;
				default: return false;
			}
			ScheduleAudioReset();
		}
		else if(aHeader.Left(4) == _L8("data")) { iTotalLength += aSize; OutputBlock(aSize, ETrue); }
		else if(aHeader.Left(4) == _L8("RIFF"))
		{
			TBuf8<4> aDataType; iAudioFile.Read(aDataType, 4);
			if(aDataType != _L8("WAVE")) return false;
			aSize = LittleEndian::Get32(aHeader.Ptr() + 4);
			if(!ParseWave(aPos + 8 + aSize, EFalse)) return false;
		}
		else if(aHeader.Left(4) == _L8("RIFX"))
		{
			TBuf8<4> aDataType; iAudioFile.Read(aDataType, 4);
			if(aDataType != _L8("WAVE")) return false;
			aSize = BigEndian::Get32(aHeader.Ptr() + 4);
			if(!ParseWave(aPos + 8 + aSize, ETrue)) return false;
		}
		else if(aHeader.Left(4) == _L8("wavl"))
		{ if(!ParseWave(aPos + 8 + aSize, anBigEndian)) return false; }
		
		aPos += 8 + aSize; if(aPos & 1) ++aPos; iAudioFile.Seek(ESeekStart, aPos);
	}
	return true;
}

struct MP3Header
{
	TUint8 sync_hi;						// sync word high (all set)

	TUint8 CRC					: 1;	// 0 - Protected by CRC (16bit CRC follows header)
	TUint8 layer				: 2;	// 00 - reserved, 01 - Layer III, 10 - Layer II, 11 - Layer I
	TUint8 version			: 2;	// 00 - MPEG Version 2.5 (unofficial), 01 - reserved, 10 - MPEG Version 2, 11 - MPEG Version 1
	TUint8 sync_lo			: 3;	// sync word low  (all set)

	TUint8							: 1;	// private
	TUint8 padding			: 1;	// 1 - frame is padded with one extra slot
	//	bits	MPEG1		MPEG2		MPEG2.5 
	//	00		44100		22050		11025 
	//	01		48000		24000		12000 
	//	10		32000		16000		8000 
	//	11					reserved 
	TUint8 sample_rate	: 2;
	TUint8 bitrate			: 4;

	TUint8 emphasis			: 2;	// 00 - none, 01 - 50/15 ms, 10 - reserved, 11 - CCIT J.17
	TUint8 original			: 1;
	TUint8 copyright		: 1;
	TUint8 mode_ext			: 2;	// only used in Joint Stereo
	TUint8 channel_mode	: 2;	// 00 - Stereo, 01 - Joint stereo (Stereo), 10 - Dual channel (2 mono channels), 11 - Single channel (Mono)

	inline TFourCC DataType() const
	{ return layer == 0x1 ? KMMFFourCCCodeMP3 : (layer == 0x2 ? KMMFFourCCCodeMP2 : KMMFFourCCCodeNULL); }
		
	inline TInt SampleRate() const
	{
		static const TInt ac[3][4] =
		{
				{ TMdaAudioDataSettings::ESampleRate11025Hz, 0, TMdaAudioDataSettings::ESampleRate22050Hz, TMdaAudioDataSettings::ESampleRate44100Hz },
				{ TMdaAudioDataSettings::ESampleRate12000Hz, 0, TMdaAudioDataSettings::ESampleRate24000Hz, TMdaAudioDataSettings::ESampleRate48000Hz },
				{ TMdaAudioDataSettings::ESampleRate8000Hz, 0, TMdaAudioDataSettings::ESampleRate16000Hz, TMdaAudioDataSettings::ESampleRate32000Hz }
		};
		
		return sample_rate != 0x3 ? ac[sample_rate][version] : 0;
	}
		
	inline TInt Channels() const
	{ return channel_mode != 0x3 ? TMdaAudioDataSettings::EChannelsStereo : TMdaAudioDataSettings::EChannelsMono; }
};

bool CFolderView::ParseMP3()
{
	static TBuf8<1024> aBuffer; iRemLen = 0;
	if(iCurrentPos < 0) iCurrentPos = 0;
	
	// if starts with ID3, skip it
	iAudioFile.Read(aBuffer, 10); TInt aPos;
	if(aBuffer.Length() == 10 && aBuffer.Left(3) == _L8("ID3") &&
			(aBuffer[6] & 0x80) == 0 && (aBuffer[7] & 0x80) == 0 && (aBuffer[8] & 0x80) == 0 && (aBuffer[9] & 0x80) == 0)
	{
		aPos = ((TInt)aBuffer[6] << 21) | ((TInt)aBuffer[7] << 14) | ((TInt)aBuffer[8] << 7) | aBuffer[9];
		iAudioFile.Seek(ESeekCurrent, aPos);
	}
	else { aPos = -aBuffer.Length(); iAudioFile.Seek(ESeekCurrent, aPos); }
	
	while(true)
	{
		if(!iAlive) return true;
		iAudioFile.Read(aBuffer, aBuffer.MaxLength()); if(aBuffer.Length() < 4) return false;
		TInt aSync = aBuffer.Locate(0xFF);
		if(aSync != KErrNotFound)
		{
			MP3Header aAudioParam; TPtr8 aPtr((TUint8*)&aAudioParam, 4); aPos += aSync;
			iAudioFile.Seek(ESeekStart, aPos); iAudioFile.Read(aPtr, 4); if(aPtr.Length() < 4) return false;
			if(aAudioParam.sync_lo == 0x7)
			{
				iDataType = aAudioParam.DataType(); iSampleRate = aAudioParam.SampleRate(); iChannels = aAudioParam.Channels();
				break;
			}
			else iAudioFile.Seek(ESeekStart, aPos += 2);
		}
		else aPos += aBuffer.Length();
	}

	if(iDataType == KMMFFourCCCodeNULL || iSampleRate == 0 || iChannels == 0) return false;
	ScheduleAudioReset();
	
	TInt aSize; iAudioFile.Size(aSize); iTotalLength = aSize - aPos;
	aPos += iCurrentPos; iAudioFile.Seek(ESeekStart, aPos);
	OutputBlock(aSize - aPos, ETrue);
	return true;
}

bool CFolderView::ParseFile(const TDesC16& anFile)
{
	iAudioFile.Close();
	
	TInt aExtension = anFile.LocateReverse(L'.');
	if(aExtension == KErrNotFound) return false;
	
	if(iAudioFile.Open(iFs, anFile, EFileRead|EFileShareReadersOnly) != KErrNone) return false;

// update visual status
	iStatus = KRequestPending; SetActive(); iBufferPending = EFalse;
	TRequestStatus* aStatus = &iStatus; iMainThread.RequestComplete(aStatus, KErrNone);
	
	TPtrC16 aType(anFile.Mid(aExtension + 1));
	if(aType.CompareF(_L16("wav")) == 0) return ParseWave();
	else if(aType.CompareF(_L16("lpcm")) == 0) return ParseLPCM();
	else if(aType.CompareF(_L16("flac")) == 0) return ParseFLAC();
	else if(aType.CompareF(_L16("ape")) == 0 || aType.CompareF(_L16("mac")) == 0) return ParseMAC();
	else if(aType.CompareF(_L16("ac3")) == 0) return ParseAC3();
	else if(aType.CompareF(_L16("mp3")) == 0) return ParseMP3();
	else if(aType.CompareF(_L16("ogg")) == 0) return ParseOgg();
	else if(aType.CompareF(_L16("aac")) == 0) return ParseAAC();
	
	return true;
}

void CFolderView::PlayTheList()
{
	iRemLen = 0;
	while(iCurFileIdx < iPlayList.Count())
	{
		ParseFile(iPlayList[iCurFileIdx]);
		if(!iAlive) return;
		iTotalLength = iCurrentPos = 0; ++iCurFileIdx;
	}
	Flush();
// wait till playback finishes	
	iExclusive.Wait(); while(iAudioBusy && iAlive) if(iStateChange.TimedWait(iExclusive, 2000000) == KErrTimedOut) iAudioBusy = EFalse; iExclusive.Signal();
// clean up
	iAudioThread.Close();
// update visual status
	iStatus = KRequestPending; SetActive(); iAlive = EFalse; iBufferPending = EFalse;
	TRequestStatus* aStatus = &iStatus; iMainThread.RequestComplete(aStatus, KErrNone);
}

static TInt PlayerFunc(TAny* anFolderView)
{
	CTrapCleanup* cleanup = CTrapCleanup::New();
	TRAPD(ret, ((CFolderView*)anFolderView)->PlayTheList())
	delete cleanup;

	return KErrNone;
}

///////////////////////////////////////////////////////////////////////
// events in the main thread's context

void CFolderView::MaoscOpenComplete(TInt aError)
{
	if(aError != KErrNone) return;

	CAknVolumeControl* aVolCtrl = static_cast<CAknVolumeControl*>(iVolumeNavi->DecoratedControl());
	iAudioOutput->SetVolume(iAudioOutput->MaxVolume() * aVolCtrl->Value() / 10);
	
	if(iAlive && !iPause && iBufferPending) { iStatus = KErrNone; RunL(); return; }
	
	iFreeBuffer.Close(); iFreeBuffer.CreateLocal(1);		// buffer availability sync
	
	if(iAlive && iPause)
	{
		iSetAudioParam = ETrue;
		iExclusive.Wait(); iPause = EFalse; iExclusive.Signal(); iStateChange.Signal();
		SetPlayingItemL(_L("")); SetPlayingItemL(iPlayList[iCurFileIdx]);
		return;
	}
	
	if(iAudioThread.Create(_L("Player"), &PlayerFunc, 0x5000, iEvenBuffer.MaxLength(), 0x200000, this) == KErrNone)
	{
		iEvenBuffer.SetMax(); iOddBuffer.SetMax();
		iCurBuffer.Set(iEvenBuffer.MidTPtr(0));
		
		iAudioThread.SetPriority(EPriorityAbsoluteForegroundNormal);
		
		iAudioBusy = iSetAudioParam = EFalse;
		
		iAlive = ETrue; iAudioThread.Resume();
	}
	else { iAudioThread.Close(); iAudioOutput->Stop(); }
}

void CFolderView::MaoscBufferCopied(TInt /*aError*/, const TDesC8& /*anBuffer*/)
{ iFreeBuffer.Signal(); } 

void CFolderView::MaoscPlayComplete(TInt /*aError*/)
{
	iExclusive.Wait(); iAudioBusy = EFalse; iExclusive.Signal();
	iStateChange.Signal();
}

void CFolderView::RunL()				// synchronously called, no synchronization needed
{
	if(iStatus != KErrNone) return;
	
	if(!iBufferPending)
	{
		if(iAlive) SetPlayingItemL(iPlayList[iCurFileIdx]);
		else
		{
			iAudioOutput->Stop(); SetPlayingItemL(_L(""));
			
			if(IsFocused())
			{
				if(AknLayoutUtils::PenEnabled())
				{ iProgressSlider.SetValueL(0); iProgressSlider.DrawDeferred(); }
				else iProgressBar.SetAndDraw(0);
			}
		}
		return;
	}
	
	if(iPause) iFreeBuffer.Signal();
	else
	{	
		if(iSetAudioParam)
		{
			TRAPD
			(err,
				iAudioOutput->SetDataTypeL(iAudioDataType);
				iAudioOutput->SetAudioPropertiesL(iAudioSettings.iSampleRate, iAudioSettings.iChannels)
			)
			if(err != 0) { iAudioOutput->Stop(); iAudioOutput->Open(&iAudioSettings); return; }
			iSetAudioParam = EFalse;
		}
		iAudioBusy = ETrue; iAudioOutput->WriteL(ActiveBuffer());
	}
	
	if(IsFocused() && iTotalLength > 0 && iCurrentPos < iTotalLength)
	{
		if(AknLayoutUtils::PenEnabled())
		{
			iProgressSlider.SetValueL((TInt)((TUint64)iCurrentPos * 640 / iTotalLength));
			iProgressSlider.DrawDeferred();
		}
		else iProgressBar.SetAndDraw((TInt)((TUint64)iCurrentPos * iProgressBar.Info().iFinalValue / iTotalLength));
	}
	
	iExclusive.Wait(); iBufferPending = EFalse; iExclusive.Signal();
	iStateChange.Signal();
}

void CFolderView::DoCancel()
{
	
}

void CFolderView::Start()
{
	if(iAlive) return;
	
	iAudioDataType = KMMFFourCCCodeNULL;
	iAudioSettings.iSampleRate = 0; iAudioSettings.iChannels = 0;
	iPause = EFalse; iAudioOutput->Open(&iAudioSettings);
}

void CFolderView::Stop()
{
	if(iAlive)
	{
		TRequestStatus aStatus; iAudioThread.Logon(aStatus);
		iExclusive.Wait(); iAlive = EFalse; iExclusive.Signal();
		iFreeBuffer.Signal(10); iStateChange.Signal();	// green light!   
		User::WaitForRequest(aStatus); iAudioThread.Close();
		if(!iPause) iAudioOutput->Stop();
	}
	if(IsActive()) Cancel();					// cancel an outstanding request to write to audio device
}

void CFolderView::Pause()
{
	iPause = ETrue; iAudioOutput->Stop(); iFreeBuffer.Signal(3);
	SetPlayingItemL(_L("")); SetPlayingItemL(iPlayList[iCurFileIdx]);
}

void CFolderView::Resume() { iAudioOutput->Open(&iAudioSettings); }

// end events
