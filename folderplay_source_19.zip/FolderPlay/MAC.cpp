/*
 * MAC.cpp
 *
 *  Created on: 28/05/2009
 *      Author: Alexander Demidov
 */

#include "maclib.h"
#include "RFileIO.h"

#include "FolderPlayView.h"


//static void Delete_APEDecompress(TAny* anAPEDecompress)
//{ delete (IAPEDecompress*)anAPEDecompress; }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// entry point

bool CFolderView::ParseMAC()
{
	CRFileIO aRF(iAudioFile); iRemLen = 0;
	
	TInt aRetVal = 0; IAPEDecompress* aAPEDecompress = CreateIAPEDecompress(&aRF, &aRetVal);
	if(aAPEDecompress == NULL) return false;
	
	//CleanupStack::PushL(TCleanupItem(&Delete_APEDecompress, aAPEDecompress));
	
	TInt aBpS = aAPEDecompress->GetInfo(APE_INFO_BITS_PER_SAMPLE);
	iDataType.Set(aBpS <= 8 ? KMMFFourCCCodePCMU8 : (aBpS <= 16 ? KMMFFourCCCodePCM16 : KMMFFourCCCodeNULL));
	iSampleRate = Freq2SR(aAPEDecompress->GetInfo(APE_INFO_SAMPLE_RATE));
	iChannels = aAPEDecompress->GetInfo(APE_INFO_CHANNELS);
	iChannels = iChannels == 2 ? TMdaAudioDataSettings::EChannelsStereo :
			(iChannels == 1 ? TMdaAudioDataSettings::EChannelsMono : 0);
	if(iDataType == KMMFFourCCCodeNULL || iSampleRate == 0 || iChannels == 0)
	{ delete aAPEDecompress; return false; }
	ScheduleAudioReset();
	
	iTotalLength = aAPEDecompress->GetInfo(APE_INFO_TOTAL_BLOCKS);
	if(iCurrentPos != 0)
	{
		if(iCurrentPos < 0)		// time in ms, not samples
			iCurrentPos = (TInt)((TUint64)aAPEDecompress->GetInfo(APE_INFO_SAMPLE_RATE) * (-iCurrentPos) / 1000);
		aAPEDecompress->Seek(iCurrentPos);
	}

	const TInt aSampleAlign = aAPEDecompress->GetInfo(APE_INFO_BLOCK_ALIGN);
	TInt aBlocksLeft = iTotalLength - iCurrentPos;
	while(iAlive && aBlocksLeft > 0)
	{
		TInt aDecoded = -1; iCurBuffer.SetMax();
		if(aAPEDecompress->GetData((char*)iCurBuffer.Ptr(), iCurBuffer.MaxLength() / aSampleAlign, &aDecoded) != ERROR_SUCCESS || aDecoded <= 0) break;
		aBlocksLeft -= aDecoded; aDecoded *= aSampleAlign;
		if(aDecoded < iCurBuffer.MaxLength()) iCurBuffer.Set(iCurBuffer.MidTPtr(aDecoded));
		else OutputBuffer();
		
		iCurrentPos = aAPEDecompress->GetInfo(APE_DECOMPRESS_CURRENT_BLOCK);
	}
	//CleanupStack::PopAndDestroy();
	delete aAPEDecompress;
	return aBlocksLeft <= 0;
}
