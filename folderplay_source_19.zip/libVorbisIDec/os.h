#ifndef _OS_H
#define _OS_H
/********************************************************************
 *                                                                  *
 * THIS FILE IS PART OF THE OggVorbis 'TREMOR' CODEC SOURCE CODE.   *
 *                                                                  *
 * USE, DISTRIBUTION AND REPRODUCTION OF THIS LIBRARY SOURCE IS     *
 * GOVERNED BY A BSD-STYLE SOURCE LICENSE INCLUDED WITH THIS SOURCE *
 * IN 'COPYING'. PLEASE READ THESE TERMS BEFORE DISTRIBUTING.       *
 *                                                                  *
 * THE OggVorbis 'TREMOR' SOURCE CODE IS (C) COPYRIGHT 1994-2002    *
 * BY THE Xiph.Org FOUNDATION http://www.xiph.org/                  *
 *                                                                  *
 ********************************************************************

 function: #ifdef jail to whip a few platforms into the UNIX ideal.

 ********************************************************************/

#include "os_types.h"

#define BIG_ENDIAN		0
#define LITTLE_ENDIAN 1

#ifndef _V_IFDEFJAIL_H_
	#define _V_IFDEFJAIL_H_
	#ifdef _MSC_VER
		#define STIN static __inline
	#endif
#else
	#define STIN static
#endif

#ifdef _MSC_VER

#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <ctype.h>
#define rint(x)   (floor((x)+0.5f)) 
#define NO_FLOAT_MATH_LIB
#define FAST_HYPOT(a, b) sqrt((a)*(a) + (b)*(b))
#define BYTE_ORDER LITTLE_ENDIAN

#endif

#ifdef __SYMBIAN32__

#define BYTE_ORDER LITTLE_ENDIAN
#define STIN static inline

#include <e32std.h>

inline TInt abs(int n) { return Abs(n); }
inline TInt32 labs(TInt32 n) { return Abs(n); }

inline TInt strlen(const char* str) { return TPtrC8((const TUint8*)str).Length(); }

inline char* strcpy(char* strDestination, const char* strSource)
{	
	TPtrC8 aSrc((const TUint8*)strSource);
	TPtr8 aDst((TUint8*)strDestination, aSrc.Length() + 1);
	aDst.Copy(aSrc); aDst.ZeroTerminate(); return strDestination; 
}

inline char* strcat(char* strDestination, const char* strSource)
{ strcpy(strDestination + strlen(strDestination), strSource); return strDestination; }

inline TInt memcmp(const TAny* buf1, const TAny* buf2, TUint count)
{ return Mem::Compare((const TUint8*)buf1, count, (const TUint8*)buf2, count); }

inline TAny* memchr(const TAny* buf, TChar c, TInt count)
{
	TInt aOff = TPtrC8((const TUint8*)buf, count).Locate(c);
	return aOff != KErrNotFound ? (TUint8*)buf + aOff : NULL;
}

// used for sorting
class TQuickSort : public TSwap, public TKey 
{
public:
	inline TQuickSort(TAny* ar, TUint width, TInt (*cmp)(const TAny*, const TAny*))
	{ _ar = ar; _width = width; _cmp = cmp; }
	
	virtual void Swap(TInt aLeft, TInt aRight) const
	{ Mem::Swap((char*)_ar + aLeft * _width, (char*)_ar + aRight * _width, _width); }
	virtual TInt Compare(TInt aLeft, TInt aRight) const
	{ return (*_cmp)((char*)_ar + aLeft * _width, (char*)_ar + aRight * _width); }

protected:
	TAny*		_ar;
	TUint		_width;
	TInt		(*_cmp)(const TAny*, const TAny*);
};

inline void qsort(TAny* base, TUint num, TUint width, TInt (*compare)(const TAny*, const TAny*))
{ TQuickSort qs(base, width, compare); User::QuickSort(num, qs, qs); }

#define memset(dest, c, count)			Mem::Fill(dest, count, c)

#define free(memblock)							User::Free(memblock)
#define calloc(num, size)						User::AllocZ((TInt)((num) * (size)))
#define malloc(size)								User::Alloc(size)
#define realloc(memblock, size)			User::ReAlloc(memblock, size)
#define toupper(c)									User::UpperCase(c)

#endif

#ifdef HAVE_ALLOCA_H
#  include <alloca.h>
#endif

#ifdef USE_MEMORY_H
#  include <memory.h>
#endif

#ifndef min
#define min(x,y)  ((x)>(y)?(y):(x))
#endif

#ifndef max
#define max(x,y)  ((x)<(y)?(y):(x))
#endif

#ifndef M_PI
#define M_PI (3.1415926536f)
#endif

#endif /* _OS_H */
