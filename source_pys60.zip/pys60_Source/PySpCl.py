import appuifw
import e32
import audio
import os, time

dir = u'e:\\Others\Sounds\\'

def tme():
    global dt
    dt = time.localtime()
    appuifw.note(u"\u0421\u0435\u0433\u043e\u0434\u043d\u044f %s \u0434\u0435\u043d\u044c \u0433\u043e\u0434\u0430" % dt[7], 'info')

def hrplay():
    global hrc
    global hrn
    if dt[3] == 0:
        hrcs = '0'
    elif dt[3] == 1:
        hrcs = '1'
    elif dt[3] == 2:
        hrcs = '2'
    elif dt[3] == 3:
        hrcs = '3'
    elif dt[3] == 4:
        hrcs = '4'
    elif dt[3] == 5:
        hrcs = '5'
    elif dt[3] == 6:
        hrcs = '6'
    elif dt[3] == 7:
        hrcs = '7'
    elif dt[3] == 8:
        hrcs = '8'
    elif dt[3] == 9:
        hrcs = '9'
    elif dt[3] == 10:
        hrcs = '10'
    elif dt[3] == 11:
        hrcs = '11'
    elif dt[3] == 12:
        hrcs = '12'
    elif dt[3] == 13:
        hrcs = '13'
    elif dt[3] == 14:
        hrcs = '14'
    elif dt[3] == 15:
        hrcs = '15'
    elif dt[3] == 16:
        hrcs = '16'
    elif dt[3] == 17:
        hrcs = '17'
    elif dt[3] == 18:
        hrcs = '18'
    elif dt[3] == 19:
        hrcs = '19'
    elif dt[3] == 20:
        hrcs = '20'
    elif dt[3] == 21:
        hrcs = '21'
    elif dt[3] == 22:
        hrcs = '22'
    elif dt[3] == 23:
        hrcs = '23'
    filehrc = dir + hrcs + '.wav'
    if dt[3] == 1 or dt[3] == 21:
        hrns = ''
    elif dt[3] == 2 or dt[3] == 3 or dt[3] == 4 or dt[3] == 22 or dt[3] == 23:
        hrns = 'a'
    else:
        hrns = 'ov'
    filehrn = dir + 'chas' + hrns + '.wav'
    hrc = audio.Sound.open(filehrc)
    hrn = audio.Sound.open(filehrn)
    hrc.play()
    e32.ao_sleep(1.00)
    hrn.play()

def minplay():
    global minca
    global mincb
    global minn
    if dt[4] < 20:
        mincas = 'No_Sound'
    elif 19 < dt[4] < 30:
        mincas = '20'
    elif 29 < dt[4] < 40:
        mincas = '30'
    elif 39 < dt[4] < 50:
        mincas = '40'
    else:
        mincas = '50'
    if dt[4] == 0:
        mincbs = 'rovno'
    elif dt[4] == 1 or dt[4] == 21 or dt[4] == 31 or dt[4] == 41 or dt[4] == 51:
        mincbs = '1a'
    elif dt[4] == 2 or dt[4] == 22 or dt[4] == 32 or dt[4] == 42 or dt[4] == 52:
        mincbs = '2e'
    elif dt[4] == 3 or dt[4] == 23 or dt[4] == 33 or dt[4] == 43 or dt[4] == 53:
        mincbs = '3'
    elif dt[4] == 4 or dt[4] == 24 or dt[4] == 34 or dt[4] == 44 or dt[4] == 54:
        mincbs = '4'
    elif dt[4] == 5 or dt[4] == 25 or dt[4] == 35 or dt[4] == 45 or dt[4] == 55:
        mincbs = '5'
    elif dt[4] == 6 or dt[4] == 26 or dt[4] == 36 or dt[4] == 46 or dt[4] == 56:
        mincbs = '6'
    elif dt[4] == 7 or dt[4] == 27 or dt[4] == 37 or dt[4] == 47 or dt[4] == 57:
        mincbs = '7'
    elif dt[4] == 8 or dt[4] == 28 or dt[4] == 38 or dt[4] == 48 or dt[4] == 58:
        mincbs = '8'
    elif dt[4] == 9 or dt[4] == 29 or dt[4] == 39 or dt[4] == 49 or dt[4] == 59:
        mincbs = '9'
    elif dt[4] == 10:
        mincbs = '10'
    elif dt[4] == 11:
        mincbs = '11'
    elif dt[4] == 12:
        mincbs = '12'
    elif dt[4] == 13:
        mincbs = '13'
    elif dt[4] == 14:
        mincbs = '14'
    elif dt[4] == 15:
        mincbs = '15'
    elif dt[4] == 16:
        mincbs = '16'
    elif dt[4] == 17:
        mincbs = '17'
    elif dt[4] == 18:
        mincbs = '18'
    elif dt[4] == 19:
        mincbs = '19'
    else:
        mincbs = 'No_Sound'
    fileminca = dir + mincas + '.wav'
    filemincb = dir + mincbs + '.wav'

    if dt[4] == 0:
        minns = 'No_Sound'
    elif dt[4] == 1 or dt[4] == 21 or dt[4] == 31 or dt[4] == 41 or dt[4] == 51:
        minns = 'minuta'
    elif dt[4] == 2 or dt[4] == 3 or dt[4] == 4 or dt[4] == 22 or dt[4] == 23 or dt[4] == 24 or dt[4] == 32 or dt[4] == 33 or dt[4] == 34 or dt[4] == 42 or dt[4] == 43 or dt[4] == 44 or dt[4] == 52 or dt[4] == 53 or dt[4] == 54:
        minns = 'minuti'
    else:
        minns = 'minut'
    fileminn = dir + minns + '.wav'
    minca = audio.Sound.open(fileminca)
    mincb = audio.Sound.open(filemincb)
    minn = audio.Sound.open(fileminn)
    minca.play()
    e32.ao_sleep(1.00)
    mincb.play()
    e32.ao_sleep(1.00)
    minn.play()
    e32.ao_sleep(1.00)
    hrc.close()
    hrn.close()
    minca.close()
    mincb.close()
    minn.close()

appuifw.app.title = u"PySpeakClock 0.1a"
tme()
hrplay()
minplay()
appuifw.note(u"\u0413\u043e\u0432\u043e\u0440\u044f\u0449\u0438\u0435 \u0447\u0430\u0441\u044b 1.0a (c) aster404 dimonvideo.ru", 'info')
e32.Ao_lock()
appuifw.app.set_exit()
