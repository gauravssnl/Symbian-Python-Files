def f(x,index):
 x=x.split('-')[index]
 return x
 del x,index

import e32,os
wait=e32.ao_sleep
wait(0.1)
import appuifw
r=appuifw.app.body
r.set(u'//-')
__all__=['write','start','Dfile','Ddir','exit',
  'Cdir','Cdirs','Ddirs','Cdrive','Ddrive']


def Ddrive(x):
 import miso
 from string import uppercase as St
 name=St.find(f(x,2))
 miso.create_drive_subst(name,'')
def Cdrive(x):
 import miso
 from string import uppercase as St
 name=St.find(f(x,2))
 path=f(x,3)
 miso.create_drive_subst(name,unicode(path))
 del miso,St,name,path,x

def Ddirs(x):
 path=f(x,2)
 j=path.split('//')
 disk=j[0]
 j.pop(0)
 if j[-1]=='':j.pop()
 path=[]
 for i in range(len(j)):
  m=disk+'//'
  for p in j:
   m+=p+'//'
  path.append(m)
  j.pop()
 for i in path:os.rmdir(i)



def Cdirs(x):
 path=f(x,2)
 os.makedirs(path)
 del x,path
def Cdir(x):
 path=f(x,2)
 os.mkdir(path)
 del path,x

def exit(x):
 os.write(1,u'\n\nby _killed_ \n')
 os.write(1,u'\n http://killed.h2m.ru/\n\n\n')
 wait(3);os.abort()
def Ddir(x):
 dir=f(x,2)
 os.rmdir(dir)
 del dir,x
def Dfile(x):
 file=f(x,2)
 os.remove(file)
 del x,file

def write(x):
 file=f(x,2)
 text=f(x,3)
 text=text.replace('\xe2\x80\xa9','\n')
 f=open(file,'a')
 f.write(text)
 f.close()
 del x,file,text

def start(x):
 path=u'z:\\system\\programs\\apprun.exe'
 diski=['c:','e:','z:']
 apps='\\system\\apps\\'
 name=f(x,2)
 name1=name+'\\'+name+'.app'
 for i in diski:
  print i+apps+name1
  list=os.listdir(str(i+apps))
  if name not in list:pass
  else:
   e32.start_exe(path,str(i+apps+name1))
 del path,diski,apps,name,x,name1,list

def vorker():
 if r.get().startswith('//-'):
  p=eval(str(r.get().split('-')[1]))
  p(r.get())
  r.set(u'//-')
  del p
 else:
  print '\nError!\n'+r.get()
  print 'That is not linux-mobile command'
r.bind(63586,vorker)