import appuifw,graphics,e32

appuifw.app.body=canvas=appuifw.Canvas()
appuifw.app.screen='full'

l=0
def jvv():
 global l
 l+=1

def jvn():
 global l
 l-=1

def nok():
 appuifw.note(u'nokia',u'info')

def sie():
 appuifw.note(u'siemens',u'info')

def sams():
 appuifw.note(u'samsung',u'info')

def mot():
 appuifw.note(u'motorola',u'info')

def select():
 global l
 functions[l]()

def menu(a):
 global l
 ach=len(a)
 body=graphics.Image.new((125,10+20*ach))
 canvas.bind(63497,jvn)
 canvas.bind(63498,jvv)
 canvas.bind(63557,select)
 body.clear(0)
 while 1:
  body.rectangle((0,0,125,10+20*ach),0xff0000,0xccc000)
  body.rectangle((1,1,124,9),0x000000,0x000000)
  body.line((0,9,124,9),0xff0000)
  body.rectangle((0,10+20*l,125,30+20*l),0x33ffcc,fill=0xcccccc)
  g=0
  for i in a:
   body.text((5,25+20*g),u''+str(i))
   g+=1
  canvas.blit(body,target=(0,170-20*ach))
  e32.ao_sleep(0.01)

items=['siemens','motorola','nokia','samsung','smarts']
functions=[sie,mot,nok,sams,nok]
menu(items)