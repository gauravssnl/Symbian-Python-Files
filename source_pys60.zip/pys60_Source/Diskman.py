#script by _virtual_machine_

def ru(t):return t.decode('utf-8')
def ur(t):return t.encode('utf-8')

import e32,_appuifw
if e32.pys60_version_info[2]<17:
    _appuifw.note(ru("Необходима версия Python не ниже 1.3.17. Пожалуйста обновитесь."),'error')
    _appuifw.app.set_exit()
import e32posix,time

class main:
	def __init__(self):
		#self.lock=e32.Ao_lock()
		#self.path=_appuifw.app.full_name()[0]+':\\nokia\\scripts\\'
		self.path=_appuifw.app.full_name()[0]+':\\System\\Apps\\DiskMan\\'
		self.logs=self.path+'logs\\'
		try:e32posix.stat(self.logs)
		except:e32posix.mkdir(self.logs)
		self.stack=[]
		_appuifw.app.menu=[
		 (ru('Образ'),(
		  (ru('создать'),self.scaner_new),
		  (ru('сравнить'),self.scaner_compare),
		  (ru('удалить'),self.scaner_del))),
		 (ru('Поиск'),(
		  (ru('дубликатов'),self.find_clone),
		  (ru('пустышек'),self.find_null))),
		 (ru('Помощь'),self.help_main),
		 (ru('Выход'),_appuifw.app.set_exit)]
		self.scaner_set(0)
		self.txt_thread=ru('Обработано: ')
		_appuifw.app.exit_key_handler=_appuifw.app.set_exit
		#_appuifw.app.exit_key_handler=self.lock.signal
		#self.lock.wait()
	def scaner_set(self,mode=1):
		if mode:index=_appuifw.app.body.current()
		self.scans=[unicode(file[:-4]) for file in e32posix.listdir(self.logs) if file[-4:]=='.log']
		self.scans.insert(0,ru('Образов: '+str(len(self.scans))).center(21))
		if mode:_appuifw.app.body.set_list(self.scans,index)
		else:
			_appuifw.app.body=_appuifw.Listbox(self.scans)
			_appuifw.app.body.bind(8,self.scaner_del)
	def scaner_del(self):
		index=_appuifw.app.body.current()
		if index==0:return
		e32posix.remove(self.logs+self.scans[index]+'.log')
		self.scaner_set()
	def scaner_new(self):
		self.flag,self.index,self.level=0,0,0
		self.files=[]
		self.body_text()
		_appuifw.app.menu=[
		 (ru('Отменить'),self.find_exit)]
		_appuifw.app.body.set(ru('Обработано: 0'))
		e32.ao_sleep(0.001)
		try:
		    self.scaner_new_in('c:\\')
		    self.scaner_new_in('e:\\')
		except:
			self.files=[]
			self.body_exit()
			return
		_appuifw.app.body.set(ru('Готово.\nВсего файлов и папок: '+str(len(self.files))))
		e32.ao_sleep(0.001)
		try:name=ur(_appuifw.query(ru('Имя образа:'),'text',unicode(time.strftime('%H_%M_%d_%m_')+time.strftime('%Y')[2:])))
		except:
			self.files=[]
			self.body_exit()
			return
		file=open(self.logs+name+'.log','w')
		file.write(repr(self.files))
		file.close()
		_appuifw.note(ru('Сохранено.'))
		self.files=[]
		self.body_exit()
		self.scaner_set()
	def scaner_new_in(self,dir):
		for file in e32posix.listdir(dir):
			self.index+=1
			if self.index==100:
				self.index=0
				self.level+=1
				if self.flag:self.level/self.index
				_appuifw.app.body.set(self.txt_thread+unicode(self.level)+u'00')
				e32.ao_sleep(0.001)
			path=dir+file
			self.files.append(path)
			if (e32posix.stat(path)[0]&0170000)==0040000:self.scaner_new_in(path+'\\')
	def scaner_compare(self):
		index=_appuifw.app.body.current()
		if index==0:return
		file=open(self.logs+self.scans[index]+'.log','r')
		self.files=eval(file.read())
		file.close()
		self.flag,self.index,self.level=0,0,0
		self.files_len=unicode(len(self.files))
		self.files_new=[]
		self.body_text()
		_appuifw.app.menu=[
		 (ru('Отменить'),self.find_exit)]
		_appuifw.app.body.set(ru('Обработано: 0'))
		e32.ao_sleep(0.001)
		try:
		    self.scaner_compare_in('c:\\')
		    self.scaner_compare_in('e:\\')
		except:
			self.files,self.files_new=[],[]
			self.body_exit()
			return
		_appuifw.app.body.set(ru('Новые файлы и папки:\n\n'))
		for file in self.files_new:_appuifw.app.body.add(unicode(file)+'\n\n')
		_appuifw.app.body.add(ru('Удаленные файлы и папки:\n\n'))
		for file in self.files:_appuifw.app.body.add(unicode(file)+'\n\n')
		_appuifw.app.body.set_pos(0),_appuifw.app.body.set_pos(100)
		_appuifw.app.menu=[
		 (ru('Сохранить'),self.find_save),
		 (ru('Назад'),self.body_exit)]
		self.files,self.files_new=[],[]
	def scaner_compare_in(self,dir):
		for file in e32posix.listdir(dir):
			self.index+=1
			if self.index==10:
				self.index=0
				self.level+=1
				if self.flag:self.level/self.index
				_appuifw.app.body.set(self.txt_thread+unicode(self.level)+u'0/'+self.files_len)
				e32.ao_sleep(0.001)
			path=dir+file
			try:self.files.remove(path)
			except:self.files_new.append(path)
			if (e32posix.stat(path)[0]&0170000)==0040000:self.scaner_compare_in(path+'\\')
	def find_clone(self):
		self.flag,self.index,self.level=0,0,0
		self.files,self.clones=[],[]
		self.body_text()
		_appuifw.app.menu=[
		 (ru('Отменить'),self.find_exit)]
		_appuifw.app.body.set(ru('Обработано: 0'))
		e32.ao_sleep(0.001)
		try:
		    self.find_clone_in('c:\\')
		    self.find_clone_in('e:\\')
		except:
			self.files,self.clones=[],[]
			self.body_exit()
			return
		_appuifw.app.body.set(ru('Список дубликатов:\n\n'))
		for object in self.clones:
			e32.ao_sleep(0.001)
			text='\n'
			for index in range(len(object[2])):text+=str(index+1)+') '+object[2][index]+'\n'
			_appuifw.app.body.add(ru('Файл '+object[1]+'\nс размером '+str(object[0])+' байт\nнаходится в папках:'+text+'\n'))
		_appuifw.app.body.set_pos(0),_appuifw.app.body.set_pos(100)
		_appuifw.app.menu=[
		 (ru('Сохранить'),self.find_save),
		 (ru('Назад'),self.body_exit)]
		self.files,self.clones=[]
	def find_clone_in(self,dir):
		for file in e32posix.listdir(dir):
			stat=e32posix.stat(dir+file)
			if (stat[0]&0170000)==0040000:self.find_clone_in(dir+file+'\\')
			elif (stat[0]&0170000)==0100000:
				for object in self.files:
					if object[0]==stat[6]:
						if object[1]==file:
							flag=0
							index=0
							while index<len(self.clones):
								if self.clones[index][0]==stat[6]:
									if self.clones[index][1]==file:
										self.clones[index][2].append(dir)
										flag=1
										break
								index+=1
							if flag:break
							else:self.clones.append([stat[6],file,[dir,object[2]]])
				self.files.append([stat[6],file,dir])
				self.index+=1
				if self.index==10:
					self.index=0
					self.level+=1
					if self.flag:self.level/self.index
					_appuifw.app.body.set(self.txt_thread+unicode(self.level)+u'0')
					e32.ao_sleep(0.001)
	def find_null(self):
		self.flag,self.index,self.level=0,0,0
		self.nulls=[]
		self.body_text()
		_appuifw.app.menu=[
		 (ru('Отменить'),self.find_exit)]
		_appuifw.app.body.set(ru('Обработано: 0'))
		e32.ao_sleep(0.001)
		try:
		    self.find_null_in('c:\\')
		    self.find_null_in('e:\\')
		except:
			self.nulls=[]
			self.body_exit()
			return
		_appuifw.app.menu=[
		 (ru('Сохранить'),self.find_save),
		 (ru('Назад'),self.body_exit)]
		_appuifw.app.body.set(ru('Список пустышек:\n\n'))
		for path in self.nulls:
			e32.ao_sleep(0.001)
			_appuifw.app.body.add(ru(path+'\n\n'))
		_appuifw.app.body.set_pos(0),_appuifw.app.body.set_pos(100)
		self.nulls=[]
	def find_null_in(self,dir):
		for file in e32posix.listdir(dir):
			path=dir+file
			stat=e32posix.stat(path)
			if (stat[0]&0170000)==0040000:self.find_null_in(path+'\\')
			elif (stat[0]&0170000)==0100000:
				if stat[6]==0:self.nulls.append(path)
				self.index+=1
				if self.index==100:
					self.index=0
					self.level+=1
					if self.flag:self.level/self.index
					_appuifw.app.body.set(self.txt_thread+unicode(self.level)+u'00')
					e32.ao_sleep(0.001)
	def find_save(self):
		try:name=ur(_appuifw.query(ru('Имя отчета:'),'text',unicode(time.strftime('%H_%M_%d_%m_')+time.strftime('%Y')[2:])))
		except:return 1
		path=self.path[0]+':\\DiskMan\\'
		try:e32posix.stat(path)
		except:e32posix.mkdir(path)
		file=open(path+name+'.txt','w')
		file.write(ur(_appuifw.app.body.get()))
		file.close()
		_appuifw.note(ru('Сохранено.'))
	def find_exit(self):
		self.flag=1
	def body_text(self):
		self.stack.append([_appuifw.app.body,_appuifw.app.menu])
		_appuifw.app.body=_appuifw.Text()
		_appuifw.app.body.focus,_appuifw.app.body.color=False,0
	def body_exit(self):
		_appuifw.app.body,_appuifw.app.menu=self.stack.pop()
	def help_main(self):
		self.body_text()
		_appuifw.app.menu=[
		 (ru('О программе'),lambda:self.help_part('about')),
		 (ru('Работа с образами'),lambda:self.help_part('scaner')),
		 (ru('Режимы поиска'),lambda:self.help_part('find')),
		 (ru('Назад'),self.body_exit)]
		self.help_part('about')
	def help_part(self,part):
		if part=='about':text='           О программе.\n\nНазвание: DiskMan 1.00\nАвтор: _virtual_machine_\nМесто жительства:\n   www.dimonvideo.ru\nВозможности программы:\n  -создание образов дисков;\n  -сравнение образов и выявление изменений;\n  -поиск одинаковых файлов;\n  -поиск пустых файлов.\n'
		else:
		    file=open(self.path+'help\\'+part+'.txt','r')
		    text=file.read()
		    file.close()
		_appuifw.app.body.set(ru(text))
		_appuifw.app.body.set_pos(0),_appuifw.app.body.set_pos(170)

main()