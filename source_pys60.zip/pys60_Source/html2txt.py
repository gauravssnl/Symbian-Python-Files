#----------- HTML2TXT ------------#
#----- created by Ash_Rockit -----#
#------------------------------#
import appuifw,e32,powlite_fm
def ru(x): return x.decode('utf-8')
lock = e32.Ao_lock()
manager = powlite_fm.manager()
appuifw.app.title = ru('html2txt')
appuifw.app.body=text=appuifw.Text()
#------------------------------#
code_html = ['<hr>','<br>','</ br>','<center>','</center>','<b>','</b>','<u>','</u>','<i>','</i>','<p>','</p>']
code_txt = ['\n---\n','\n','\n','','','','','','','','','  ','']
#------------------------------#
text.set(ru('Programm created by Ash_Rockit'))
def OPEN_FILE():
  global html,filename_html
  filename_html = manager.AskUser(find='file',ext=['.html','.htm'])
  file_html = open(filename_html, 'r')
  html = file_html.read()
  file_html.close()
  TRIMMED()
#------------------------------#
def TRIMMED():
  global html
  html=html[html.find('<body>')+6:html.find('</body>')]
  for trim in range(0,len(code_html)):
    try:
      html=html.replace(code_html[trim],code_txt[trim])
    except:
      pass
  text.clear()
  text.add(unicode(html))
#------------------------------#
def SAVE():
  global filename_html
  filename_txt = filename_html[0:filename_html.find('.')]+'(trimmed).txt'
  file_txt = open(filename_txt, 'w')
  file_txt.write(html)
  file_txt.close()
  appuifw.note(u'Complete','info')
#------------------------------#
def EXIT():
  appuifw.set_exit()
#------------------------------#
def CLEAR():
  text.clear()
#------------------------------#
appuifw.app.menu = [(ru('Открыть Файл'),OPEN_FILE),(ru('Сохранить Файл'),SAVE),(ru('Очистить'),CLEAR),(ru('Выход'),EXIT)]
lock.wait()
#------------------------------#