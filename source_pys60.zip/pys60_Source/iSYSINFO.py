import appuifw,sysinfo,e32,uikludges
def ru(x):return x.decode('utf-8')
def bak():
 uikludges.set_right_softkey_text(ru('Назад'))
e=0
def aboutme():appuifw.note(ru('dimontyay@rambler.ru\nICQ: 401886867'))
trying=ru('Пробуем...')
si=u'>>> import sys\n>>> '
def intro():
 global txt
 appuifw.app.screen='large'
 appuifw.app.body=txt=appuifw.Text()
 txt.focus=False
 txt.color=0xff0000
 txt.font=u'LatinBold12'
 txt.set(ru('\n\n\n\n\n\n\n sysinfo info by '))
 txt.style=(appuifw.STYLE_BOLD|appuifw.STYLE_ITALIC|appuifw.STYLE_UNDERLINE)
 txt.color=0x0000ff
 txt.add(ru('dimontyay'))
i=0
def quit():
 appuifw.app.set_exit()
exapp=(ru('Выход'),quit)
def intro1():
 global i
 g="\n"*(7-i)
 i=i+1
 txt.font=u'LatinBold12'
 txt.style=0
 txt.color=0xff0000
 txt.set(ru(g))
 txt.add(ru(' sysinfo info by '))
 txt.style=(appuifw.STYLE_BOLD|appuifw.STYLE_ITALIC|appuifw.STYLE_UNDERLINE)
 txt.color=0x0000ff
 txt.add(ru('dimontyay'))
 e32.ao_yield()
 if i<8:intro1()
back1=ru('Назад')
def bat():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.battery()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает текущий  уровень батареи от 0 до 7, где 0 означает, что батарея пуста, а 7, что она полная.'))
 def tbat():
  appuifw.app.exit_key_handler=bat
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.battery())
  txt.set(si+u'sysinfo.battery()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,bat),back,exapp]
 appuifw.app.menu=[(trying,tbat),back,exapp]
def distwi():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.display_twips()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает ширину и высоту дисплея в твипах.'))
 def tdistwi():
  appuifw.app.exit_key_handler=distwi
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.display_twips())
  txt.set(si+u'sysinfo.display_twips()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,distwi),back,exapp]
 appuifw.app.menu=[(trying,tdistwi),back,exapp]
def dispix():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.display_pixels()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает ширину и высоту дисплея в пикселях.'))
 def tdispix():
  appuifw.app.exit_key_handler=dispix
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.display_pixels())
  txt.set(si+u'sysinfo.display_pixels()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,dispix),back,exapp]
 appuifw.app.menu=[(trying,tdispix),back,exapp]
def fredri():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.free_drivespace()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает количество свободного места на дисках в байтах.'))
 def tfredri():
  appuifw.app.exit_key_handler=fredri
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.free_drivespace())
  txt.set(si+u'sysinfo.free_drivespace()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,fredri),back,exapp]
 appuifw.app.menu=[(trying,tfredri),back,exapp]
def ime():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.imei()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает IMEI код устройства как строку Юникод.'))
 def time():
  appuifw.app.exit_key_handler=ime
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.imei())
  txt.set(si+u"sysinfo.imei()\nu'"+per+"'\n>>> ")
  appuifw.app.menu=[(back1,ime),back,exapp]
 appuifw.app.menu=[(trying,time),back,exapp]
def maxramsiz():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.max_ramdrive_size()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает максимальный размер RAM на устройстве.'))
 def tmaxramsiz():
  appuifw.app.exit_key_handler=maxramsiz
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.max_ramdrive_size())
  txt.set(si+u'sysinfo.max_ramdrive_size()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,maxramsiz),back,exapp]
 appuifw.app.menu=[(trying,tmaxramsiz),back,exapp]
def totram():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.total_ram()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает количество RAM памяти на устройстве.'))
 def ttotram():
  appuifw.app.exit_key_handler=totram
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.total_ram())
  txt.set(si+u'sysinfo.total_ram()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,totram),back,exapp]
 appuifw.app.menu=[(trying,ttotram),back,exapp]
def freram():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.free_ram()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает количество свободной RAM памяти на устройстве.'))
 def tfreram():
  appuifw.app.exit_key_handler=freram
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.free_ram())
  txt.set(si+u'sysinfo.free_ram()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,freram),back,exapp]
 appuifw.app.menu=[(trying,tfreram),back,exapp]
def totrom():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.total_rom()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает количество ROM памяти на устройстве.'))
 def ttotrom():
  appuifw.app.exit_key_handler=totrom
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.total_rom())
  txt.set(si+u'sysinfo.total_rom()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,totrom),back,exapp]
 appuifw.app.menu=[(trying,ttotrom),back,exapp]
def rintyp():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.ring_type()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru("\n\nДанная функция возвращает тип звукового сигнала как строку, которая может принять одно из следующих значений: 'normal', 'ascending', 'ring_once', 'beep' или 'silent'."))
 txt.style=(appuifw.STYLE_BOLD|appuifw.STYLE_ITALIC)
 txt.add(ru(' В 1st Edition не поддерживается! Поэтому нет примера.'))
 appuifw.app.menu=[back,exapp]
def osver():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.os_version()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает номер версии операционной системы.\n\t*Старший номер версии. От 0 до 127 включительно.\n\t*Младший номер версии. От 0 до 99 включительно.\n\t*Номер строения версии. От 0 до 32767 включительно.'))
 def tosver():
  appuifw.app.exit_key_handler=osver
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.os_version())
  txt.set(si+u'sysinfo.os_version()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,osver),back,exapp]
 appuifw.app.menu=[(trying,tosver),back,exapp]
def sig():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.signal()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает текущий  уровень сигнала от 0 до 7, где 0 означает, что сигнала нет, а 7, что он уверенный.'))
 def tsig():
  appuifw.app.exit_key_handler=sig
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.signal())
  txt.set(si+u'sysinfo.signal()\n'+per+'\n>>> ')
  appuifw.app.menu=[(back1,sig),back,exapp]
 appuifw.app.menu=[(trying,tsig),back,exapp]
def swver():
 appuifw.app.exit_key_handler=mainmenu
 bak()
 txt.font=u'LatinBold12'
 txt.color=0xff0000
 txt.highlight_color=0xcccccc
 txt.style=appuifw.HIGHLIGHT_SHADOW
 txt.set(u'sysinfo.sw_version()')
 txt.font=u'Alpi12'
 txt.color=0
 txt.style=0
 txt.add(ru('\n\nДанная функция возвращает версию прошивки как строку Юникод.'))
 def tswver():
  appuifw.app.exit_key_handler=swver
  txt.font=u'LatinBold12'
  txt.color=0x008000
  per=str(sysinfo.sw_version())
  txt.set(si+u"sysinfo.sw_version()\nu'"+per+"'\n>>> ")
  appuifw.app.menu=[(back1,swver),back,exapp]
 appuifw.app.menu=[(trying,tswver),back,exapp]
def mainmenu():
 appuifw.app.menu=[(ru('Узнать о функции'),((u'battery()',bat),(u'display_twips()',distwi),(u'display_pixels()',dispix),(u'free_drivespace()',fredri),(u'imei()',ime),(u'max_ramdrive_size()',maxramsiz),(u'total_ram()',totram),(u'free_ram()',freram),(u'total_rom()',totrom),(u'ring_type()',rintyp),(u'os_version()',osver),(u'signal()',sig),(u'sw_version()',swver))),(ru('О...'),aboutme),exapp]
 intro1()
 uikludges.set_right_softkey_text(ru('Выйти'))
 appuifw.app.exit_key_handler=quit
intro()
appuifw.app.menu=[(ru('Начать изучение'), mainmenu),(ru('О...'),aboutme),exapp]
back=(ru('На главную'),mainmenu)


