#
# pdis.repo.skeleton
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Kenneth Oksanen <cessu@iki.fi>
#          Ken Rimey <rimey@hiit.fi>
#          Torsten Rueger <torsten@omenapuu.de>
#          Tero Hasu <tero.hasu@hut.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import time
import sys

from pdis.lib.logging import logwrite, log_exception
from pdis.lib.best_threading import start_thread
from pdis.lib.priority import set_thread_priority
from pdis.lib.PQueue import PQueue
from pdis.versioning.et_metadata import compile_xpath
from pdis.xpath.xpath_exceptions import *
from pdis.pipe.pipe import connect_client
from pdis.pipe.message_pipe_exceptions import *
from pdis.repo.repository import Repository, NoSuchCollection
from pdis.repo.file import get_file, NoSuchFile

enable_profiling = False
profiling_bias = 0.0012
profiling_output_file = "c:\\repo.profile"

fault_mapping = {
    NoSuchCollection: (550, "No such collection."),
    XPathParseError: (501, "XPath parse error."),
    XPathNotImplementedError: (504, "XPath feature unimplemented."),
    XPathEvaluationError: (553, "XPath evaluation error."),
    }

def fault_info():
    """
    Return a reply code and message text for the current exception.
    """
    type, value = sys.exc_info()[:2]
    if type == Fault:
        return value.code, value.message
    elif type in fault_mapping:
        return fault_mapping[type]
    else:
        log_exception()
        return 451, str(type)

class RepoSkeleton:
    def __init__(self, repo_dir, pipe_manager,
                 request_shutdown = None,
                 experimental = False):
        self.repo_dir = repo_dir
        self.pipe_manager = pipe_manager
        self.request_server_shutdown = request_shutdown
        self.experimental = experimental

        self.trace = False
        self.t0 = time.clock()

        self.repo = None
        self.queue = PQueue()

        self.public_collections = []

    def start(self):
        """Start server."""
        start_thread(target = self._profiled_loop,
                     name = "repository-core-thread")
        while self.repo is None:
            time.sleep(0.1)

    def _profiled_loop(self):
        if not enable_profiling:
            self._loop()
        else:
            import profile
            p = profile.Profile(bias=profiling_bias)
            p.runcall(self._loop)
            p.dump_stats(profiling_output_file)

    def stop(self):
        """Shut down server."""
        self._handle_request(None, None, "exit", ())
        while self.repo is not None:
            time.sleep(0.1)

    def startup(self, pipe, remote_address=()):
        """Message pipe callback"""
        pipe.id = allocate_pipe_id()
        pipe.address = remote_address
        pipe.repo_id = ""
        pipe.greeting = {}
        pipe.urgent = True           # Can only go from True to False.
        pipe.stopped = False
        pipe.notify = False
        pipe.live_queries = {}      # query ID -> LiveQuery instance
        pipe.sync_dialogs = {}      # dialog ID -> SyncDialog instance
        pipe.exported_collections = None

        self._handle_request(pipe, None, "pipe_startup", ())

    def shutdown(self, pipe):
        """Message pipe callback"""
        self._handle_request(pipe, None, "pipe_shutdown", ())

    def _send_greeting(self, pipe):
        """Send hello message."""
        if pipe.exported_collections is None:
            pipe.exported_collections = list(self.public_collections)

        greeting = {
            "repo id" : self.repo.get_repo_id(),
            "repo name" : self.repo.get_repo_name(),
            "platform" : sys.platform,
            "collections" : pipe.exported_collections,
            }

        try:
            pipe.send("hello", greeting)
        except SessionClosed:
            # This might be the initial hello for a really short session
            # involving only some asynchronous requests that are already
            # queued.
            pass

    sync_methods = [
        "flush", "enable_tracing",
        "get_repo_id", "get_repo_name", "set_repo_name",
        "get_public_collections", "set_public_collections",
        "export_collection", "list_pipes", "get_neighbors", "pick_pipe",
        "acquire", "release",
        "collection_exists", "list_collections",
        "get_all_ids", "get_mrca", "get",
        "create", "modify",
        "query", "count",
        "connect", "disconnect",
        "start_sync", "stop_sync", "list_dialogs"]

    async_methods = [
        "die", "hello", "enable_notifications",
        "create_collection", "remove_collection",
        "create_noreply", "modify_noreply", "put", "kill",
        "start_live_query", "terminate_live_query",
        "start_sync_dialog", "terminate_sync_dialog",
        "sync_dialog_results", "sync_dialog_results_complete",
        "sync_dialog_update", "sync_dialog_get", "sync_dialog_put",
        "sync_dialog_confirm", "sync_dialog_reconfirm"]

    special_sync_methods = ["get_file", "remote"]

    special_async_methods = []

    standard_methods = (sync_methods + async_methods
                        + special_sync_methods + special_async_methods)

    experimental_methods = []

    def _allow(self, method):
        if method in self.experimental_methods and not self.experimental:
            return False
        return method in self.standard_methods

    def receive(self, pipe, msgno, method, params, *attachments):
        """
        Message pipe callback

        The XML message pipe invokes this callback when a message
        arrives with a request to be handled.
        """
        if self.repo is None:
            return

        if not self._allow(method):
            logwrite("Unknown method: %s" % method)
            pipe.stopped = True
            pipe.close()
            return

        if method == "connect":
            # Because setting up a connection may take some time, we
            # do it in the handler thread before passing the request
            # along to the repository core.
            sync_pipe = None
            try:
                address, = params
                address = tuple(address)
                sync_pipe = self._require_connection(address)
            except ConnectionFailed:
                logwrite("Connection failed: %s" % repr(address))
            except:
                log_exception("Connection failed: %s" % repr(address))
            params = sync_pipe,
        elif method == "remote":
            try:
                result = self._execute_remote(
                    params[0], params[1], params[2:], *attachments)
                params = (True, result[0])
                attachments = result[1:]
            except:
                params = (False, fault_info())
                attachments = []

        self._handle_request(pipe, msgno, method, params, *attachments)

    def _require_connection(self, address):
        """
        Return a pipe to the specified address, opening it if necessary.
        """
        pipe = self.pipe_manager.lookup_by_address(address)
        if pipe is None:
            # The following will invoke startup(), causing an urgent
            # "pipe_startup" command to be queued before the command
            # that required the connnection.  This means that the pipe
            # will have an ID and be registered with the pipe manager
            # before connect() executes.
            pipe = connect_client(address,
                                  target = self,
                                  remote_address = address)
            pipe.urgent = False
        return pipe

    def _execute_remote(self, neighbor, method, params, *attachments):
        p = self._pick_pipe(neighbor)
        if p is None:
            raise Fault(421, "Not connected to %s." % neighbor)

        if method in self.sync_methods + self.special_sync_methods:
            return p.call2(method, params, *attachments)
        elif method in self.async_methods + self.special_async_methods:
            p.send2(method, params, *attachments)
            return (True,)
        else:
            raise ProtocolError

    def _pick_pipe(self, repo_id):
        candidates = [p for p in self.pipe_manager.get_pipes()
                      if p.repo_id == repo_id]
        for transport in ["loopback", "bt", "tcp"]:
            for p in candidates:
                if p.address and p.address[0] == transport:
                    return p
        for p in candidates:
            return p
        return None

    def _handle_request(self, *args):
        if self.repo is None:
            return

        pipe = args[0]
        urgent = pipe is None or pipe.urgent

        # The idea here is that each message pipe may invoke
        # callbacks with its own internal thread.  We funnel them
        # all through a queue to the worker thread of the strictly
        # single-threaded repository core.
        self.queue.put(args, urgent=urgent)

    def _loop(self):
        """
        Process requests from the queue.
        """
        try:
            set_thread_priority(10)

            repo = Repository(self.repo_dir, self.pipe_manager)
            repo.open()

            self.repo = repo
            while self.repo:
                self._process_request(*self.queue.get())
        except:
            log_exception("Skeleton loop terminated by exception.")
        logwrite("Skeleton loop exited.")

    def _process_request(self, pipe, msgno, method, params, *attachments):
        # We must not process the request if a prior request resulted
        # in an error that could not be handled by returning a fault.
        if pipe and pipe.stopped and method != "pipe_shutdown":
            return

        trace = self.trace
        if trace:
            t1 = time.clock()
            t2 = 0

        try:
            if method in self.async_methods:
                getattr(self, method)(pipe, *params)
            elif method in self.special_async_methods:
                getattr(self, method)(pipe, params, *attachments)
            elif method in self.sync_methods:
                try:
                    result = getattr(self, method)(pipe, *params)
                    if trace:
                        t2 = time.clock()
                except:
                    pipe.fault(msgno, *fault_info())
                else:
                    pipe.reply(msgno, result)
            elif method in self.special_sync_methods:
                try:
                    result = getattr(self, method)(pipe, params, *attachments)
                    if trace:
                        t2 = time.clock()
                except:
                    pipe.fault(msgno, *fault_info())
                else:
                    pipe.reply2(msgno, *result)
            else:
                assert msgno is None    # Internal method
                getattr(self, method)(pipe, *params)
        except NoSuchCollection:
            pass
        except:
            log_exception('Exception for method "%s".  Closing pipe.' % method)
            if pipe:
                pipe.stopped = True
                pipe.close()

        if trace:
            t0 = self.t0
            if not t2:
                t2 = time.clock()
            logwrite("%.2f %.2f %.2f %s" % (t1 - t0, t2 - t0, t2 - t1, method))

    #
    # Internal methods
    #

    def exit(self, pipe):
        self.repo.close()
        self.repo = None                # Turn off request processing.
        logwrite("Repository closed.")

    def pipe_startup(self, pipe):
        """
        Initial callback for a new pipe

        The initiator of the connection may be either the other
        endpoint or us.
        """
        self._send_greeting(pipe)
        self.pipe_manager.connected(pipe)

    def pipe_shutdown(self, pipe):
        """
        Final callback for a closing pipe
        """
        for query_id in pipe.live_queries:
            self.terminate_live_query(pipe, query_id)
        for dialog_id in pipe.sync_dialogs:
            self.terminate_sync_dialog(pipe, "connection closed", dialog_id)
        self.pipe_manager.disconnected(pipe)

    #
    # Synchronous methods
    #

    def flush(self, pipe):
        return True

    def enable_tracing(self, pipe, trace):
        old_value = self.trace
        self.trace = trace
        return old_value

    def get_repo_id(self, pipe):
        return self.repo.get_repo_id()

    def get_repo_name(self, pipe):
        return self.repo.get_repo_name()

    def set_repo_name(self, pipe, name):
        self.repo.set_repo_name(name)
        return True

    def get_public_collections(self, pipe):
        return self.public_collections

    def set_public_collections(self, pipe, collections):
        self.public_collections = collections
        return True

    def export_collection(self, pipe, collection, pipe_id):
        p = self.pipe_manager.lookup_by_id(pipe_id)
        if p is None:
            return False

        if collection not in p.exported_collections:
            p.exported_collections.append(collection)
            self._send_greeting(p)

        return True

    def list_pipes(self, pipe, filter = {}):
        def get_info(p):
            info = p.info
            return {"id" : p.id,
                    "initiator?" : info.initiator,
                    "address" : p.address,   # [] if unknown.
                    "repo id" : p.repo_id,   # "" if unknown.
                    "greeting" : p.greeting, # {} if no hello received.
                    "urgent" : p.urgent,
                    "packets read" : info.packets_in,
                    "packets written" : info.packets_out,
                    "bytes read" : info.bytes_in,
                    "bytes written" : info.bytes_out,
                    "start timestamp" : info.start_timestamp,
                    "last timestamp" : info.last_timestamp,
                    }

        return [get_info(p) for p in self._filter_pipes(filter)]

    def _filter_pipes(self, filter):
        def matches(p, filter):
            for key, value in filter.iteritems():
                if key == "id":
                    if value != p.id:
                        return False
                elif key == "repo id":
                    if value != p.repo_id:
                        return False
                elif key == "repo-to-repo?":
                    if value != (p.repo_id != ""):
                        return False
                else:
                    return False
            return True

        return [p for p in self.pipe_manager.get_pipes()
                if matches(p, filter)]

    def get_neighbors(self, pipe):
        return self.pipe_manager.get_neighbors()

    def pick_pipe(self, pipe, repo_id):
        p = self._pick_pipe(repo_id)
        if p is not None:
            return p.id
        else:
            return 0

    def acquire(self, pipe, name):
        return self.repo.acquire(name)

    def release(self, pipe, name):
        return self.repo.release(name)

    def collection_exists(self, pipe, collection):
        return self.repo.collection_exists(collection)

    def list_collections(self, pipe):
        return self.repo.list_collections()

    def get_all_ids(self, pipe, collection):
        c = self.repo.open_collection(collection)
        return c.get_all_ids()

    def get_mrca(self, pipe, collection, item_ids):
        c = self.repo.open_collection(collection)
        return c.get_mrca(item_ids)

    def get(self, pipe, collection, item_id):
        c = self.repo.open_collection(collection)
        return c.get_item(item_id)

    def create(self, pipe, collection, item, key=None):
        c = self.repo.open_collection(collection)
        return c.create_item(item, (), key)

    def modify(self, pipe, collection, item, parent_items):
        c = self.repo.open_collection(collection)
        return c.create_item(item, parent_items)

    def query(self, pipe, collection, xpath, options):
        namespace_mapping = options.get("namespace_mapping", {})
        keys = options.get("keys", None)
        ids_only = options.get("ids_only", False)
        most_recent_only = options.get("most_recent_only", False)

        c = self.repo.open_collection(collection)
        return c.query(xpath, namespace_mapping,
                       keys, ids_only, most_recent_only)

    def count(self, pipe, collection, xpath, options):
        namespace_mapping = options.get("namespace_mapping", {})
        keys = options.get("keys", None)
        most_recent_only = options.get("most_recent_only", False)

        c = self.repo.open_collection(collection)
        return c.count(xpath, namespace_mapping, keys, most_recent_only)

    def connect(self, pipe, sync_pipe):
        """
        Set up a message pipe.
        """
        # The connection will already have been made and the remote
        # address converted into a pipe by the inbound thread
        # presenting the request.
        if sync_pipe is not None:
            return sync_pipe.id
        else:
            return 0

    def disconnect(self, pipe, pipe_id):
        """
        Shut down a message pipe.
        """
        sync_pipe = self.pipe_manager.lookup_by_id(pipe_id)
        if sync_pipe is not None:
            sync_pipe.close()
            return True

        return False

    def start_sync(self, pipe, pipe_id,
                   local_collection, remote_collection,
                   xpath="", namespace_mapping=None):
        """
        Request establishment of a sync dialog.
        """
        if namespace_mapping is None:
            namespace_mapping = {}

        sync_pipe = self.pipe_manager.lookup_by_id(pipe_id)
        if sync_pipe is None:
            return False

        if local_collection.startswith("_") \
               or remote_collection.startswith("_"):
            return False

        c = self.repo.open_collection(local_collection)

        for dialog in sync_pipe.sync_dialogs.values():
            if c.sync_dialog_exists(dialog) \
                   and dialog.remote_collection == remote_collection \
                   and dialog.xpath == xpath \
                   and dialog.namespace_mapping == namespace_mapping:
                return True

        if sync_pipe.info.initiator:
            dialog_id = allocate_sync_dialog_id(0)
        else:
            dialog_id = allocate_sync_dialog_id(1)

        sync_dialog = SyncDialog(
            self, sync_pipe,
            local_collection, remote_collection,
            xpath, namespace_mapping, dialog_id)
        sync_pipe.sync_dialogs[dialog_id] = sync_dialog

        try:
            sync_pipe.send("start_sync_dialog",
                           local_collection, remote_collection,
                           xpath, namespace_mapping,
                           dialog_id)
        except SessionClosed:
            return False

        self.pipe_manager.sync_dialog_state_changed(sync_dialog)
        c.start_sync_dialog(sync_dialog)
        return True

    def stop_sync(self, pipe, pipe_id,
                  local_collection, remote_collection,
                  xpath="", namespace_mapping=None):
        """
        Request termination of a sync dialog.
        """
        if namespace_mapping is None:
            namespace_mapping = {}

        sync_pipe = self.pipe_manager.lookup_by_id(pipe_id)
        if sync_pipe is None:
            return False

        c = self.repo.get_collection(local_collection)
        if c is None:
            return False

        for dialog in sync_pipe.sync_dialogs.values():
            if c.sync_dialog_exists(dialog) \
                   and dialog.remote_collection == remote_collection \
                   and dialog.xpath == xpath \
                   and dialog.namespace_mapping == namespace_mapping:
                c.terminate_sync_dialog(dialog)
                dialog.terminate("client request")
                return True

        return False

    def list_dialogs(self, pipe, filter = {}):
        return self._list_dialogs(filter)

    def _list_dialogs(self, filter = {}):
        results = []
        for p in self.pipe_manager.get_pipes():
            for dialog in p.sync_dialogs.values():
                c = self.repo.get_collection(dialog.local_collection)
                if c and c.sync_dialog_exists(dialog):
                    info = dialog.get_info()
                    for name, value in filter.iteritems():
                        if info.get(name) != value:
                            break
                    else:
                        results.append(info)
        return results

    #
    # Asynchronous methods
    #

    def die(self, pipe):
        logwrite("Server shutdown requested.")
        if self.request_server_shutdown:
            self.request_server_shutdown()

    def hello(self, pipe, greeting):
        pipe.greeting = greeting
        if not pipe.repo_id:
            pipe.repo_id = greeting.get("repo id", "")

            agent = greeting.get("agent", False)
            if agent:
                pipe.urgent = False
                pipe.set_priority(-10)
            elif pipe.repo_id:
                pipe.urgent = False
                pipe.set_priority(0)
            else:
                pipe.set_priority(20)

            self.pipe_manager.initialized(pipe)

    def enable_notifications(self, pipe, value):
        pipe.notify = value
        if value:
            collections = self.repo.list_collections()
            while collections:
                pipe.send("collections_available", collections[0:20])
                del collections[0:20]

            neighbors = self.pipe_manager.get_neighbors()
            for repo_id, count in neighbors.items():
                pipe.send("connected", repo_id, count)

            for info in self._list_dialogs():
                pipe.send("sync_dialog_state_changed", info)

    def create_collection(self, pipe, collection):
        self.repo.create_collection(collection)

    def remove_collection(self, pipe, collection):
        self.repo.remove_collection(collection)

    create_noreply = create
    modify_noreply = modify

    def put(self, pipe, collection, item):
        c = self.repo.open_collection(collection)
        c.put_item(item)

    def kill(self, pipe, collection, item):
        c = self.repo.open_collection(collection)
        c.kill_item(item)

    def start_live_query(self, pipe, collection, xpath, options, query_id):
        namespace_mapping = options.get("namespace_mapping", {})
        keys = options.get("keys", None)
        ids_only = options.get("ids_only", (False, True))
        most_recent_only = options.get("most_recent_only", False)

        if query_id in pipe.live_queries:
            raise ProtocolError

        if len(ids_only) != 2:
            raise ProtocolError

        live_query = LiveQuery(pipe, collection, keys,
                               xpath, namespace_mapping,
                               ids_only, most_recent_only, query_id)
        pipe.live_queries[query_id] = live_query

        c = self.repo.open_collection(collection)
        c.start_live_query(live_query)

    def terminate_live_query(self, pipe, query_id):
        live_query = pipe.live_queries.get(query_id)
        if live_query is None:
            raise ProtocolError

        c = self.repo.get_collection(live_query.collection)
        if c:
            c.terminate_live_query(live_query)

    def start_sync_dialog(self, pipe,
                          remote_collection, local_collection,
                          xpath, namespace_mapping,
                          dialog_id):
        if dialog_id in pipe.sync_dialogs:
            raise ProtocolError

        sync_dialog = SyncDialog(
            self, pipe,
            local_collection, remote_collection,
            xpath, namespace_mapping, dialog_id)
        pipe.sync_dialogs[dialog_id] = sync_dialog

        if local_collection.startswith("_") \
               or not self.repo.collection_exists(local_collection):
            sync_dialog.terminate("no such collection", quietly = True)
        else:
            self.pipe_manager.sync_dialog_state_changed(sync_dialog)
            c = self.repo.open_collection(local_collection)
            c.start_sync_dialog(sync_dialog)

    def terminate_sync_dialog(self, pipe, reason, dialog_id = None):
        if dialog_id is None:
            dialog_id = reason
            reason = "unknown"

        sync_dialog = self._lookup_sync_dialog(pipe, dialog_id)
        if not sync_dialog.terminated:
            c = self.repo.get_collection(sync_dialog.local_collection)
            if c:
                c.terminate_sync_dialog(sync_dialog)
                sync_dialog.terminated = reason
                self.pipe_manager.sync_dialog_state_changed(sync_dialog)

    def sync_dialog_results(self, pipe, item_ids, dialog_id):
        sync_dialog = self._lookup_sync_dialog(pipe, dialog_id)

        c = self.repo.open_collection(sync_dialog.local_collection)
        for id in item_ids:
            c.check_matching_item_id(id, sync_dialog)

    def sync_dialog_results_complete(self, pipe, dialog_id):
        self._lookup_sync_dialog(pipe, dialog_id)
        pipe.send("sync_dialog_confirm", dialog_id)

    def sync_dialog_update(self, pipe, item, dialog_id):
        sync_dialog = self._lookup_sync_dialog(pipe, dialog_id)

        c = self.repo.open_collection(sync_dialog.local_collection)
        c.put_matching_item(item, sync_dialog)

    def sync_dialog_get(self, pipe, item_id, dialog_id):
        sync_dialog = self._lookup_sync_dialog(pipe, dialog_id)

        c = self.repo.open_collection(sync_dialog.local_collection)
        item = c.get_item(item_id)
        if item:
            pipe.send("sync_dialog_update", item, dialog_id)

    def sync_dialog_put(self, pipe, item, dialog_id):
        sync_dialog = self._lookup_sync_dialog(pipe, dialog_id)

        c = self.repo.open_collection(sync_dialog.local_collection)
        c.put_item(item, (pipe, sync_dialog.remote_collection))

    def sync_dialog_confirm(self, pipe, dialog_id):
        sync_dialog = self._lookup_sync_dialog(pipe, dialog_id)

        sync_dialog.confirmation_received = True
        if sync_dialog.reconfirmation_received:
            sync_dialog.sync_timestamp = time.time()
            self.pipe_manager.sync_dialog_state_changed(sync_dialog)

        pipe.send("sync_dialog_reconfirm", dialog_id)

    def sync_dialog_reconfirm(self, pipe, dialog_id):
        sync_dialog = self._lookup_sync_dialog(pipe, dialog_id)

        sync_dialog.reconfirmation_received = True
        if sync_dialog.confirmation_received:
            sync_dialog.sync_timestamp = time.time()
            self.pipe_manager.sync_dialog_state_changed(sync_dialog)

    def _lookup_sync_dialog(self, pipe, dialog_id):
        sync_dialog = pipe.sync_dialogs.get(dialog_id)
        if sync_dialog is None:
            raise ProtocolError
        return sync_dialog

    #
    # Special synchronous methods
    #

    def get_file(self, pipe, (collection, file_id)):
        try:
            data = get_file(self.repo, collection, file_id)
            return (True, data)
        except NoSuchFile:
            return (False,)

    def remote(self, pipe, (status, result), *attachments):
        # The remote call will already have been executed by the
        # inbound thread presenting the request.
        if status:
            result = [result]
            result.extend(attachments)
            return result
        else:
            raise Fault(*result)

class LiveQuery:
    """
    Live query state
    
    This class holds all of the information relevant to a live query.
    Its data members are public.
    """
    def __init__(self, pipe, collection, keys,
                 xpath, namespace_mapping,
                 ids_only, most_recent_only, query_id):
        self.pipe = pipe
        self.collection = collection
        self.keys = keys
        self.xpath = xpath
        self.namespace_mapping = namespace_mapping
        self.parsed_xpath = compile_xpath(xpath, namespace_mapping)
        self.ids_only = ids_only
        self.most_recent_only = most_recent_only
        self.query_id = query_id

    def results(self, items, results_complete):
        self._send("live_query_results", items, results_complete, self.query_id)

    def update(self, items_added, items_removed):
        self._send("live_query_update", items_added, items_removed,
                   self.query_id)

    def _send(self, method, *params):
        try:
            self.pipe.send(method, *params)
        except SessionClosed:
            pass

class SyncDialog:
    """
    Sync dialog state
    
    This class holds all of the information relevant to a sync dialog.
    Its data members are public.
    """
    def __init__(self, skeleton, pipe,
                 local_collection, remote_collection,
                 xpath, namespace_mapping,
                 dialog_id):
        self.skeleton = skeleton
        self.pipe = pipe
        self.local_collection = local_collection
        self.remote_collection = remote_collection
        self.xpath = xpath
        self.namespace_mapping = namespace_mapping
        self.parsed_xpath = compile_xpath(xpath, namespace_mapping)
        self.dialog_id = dialog_id

        self.confirmation_received = False
        self.reconfirmation_received = False
        self.start_timestamp = time.time()
        self.sync_timestamp = 0
        self.terminated = False         # Set to termination reason.

    def __str__(self):
        pipe = self.pipe

        if pipe.address:
            where = ':'.join(map(str, pipe.address))
        elif pipe.repo_id:
            where = pipe.repo_id
        else:
            where = '<unknown>'

        if self.xpath:
            where += ' (xpath = "%s")' % self.xpath

        return ('<sync "%s" <-> "%s" @ %s>'
                % (self.local_collection, self.remote_collection, where))

    def results(self, item_ids):
        self._send("sync_dialog_results", item_ids, self.dialog_id)

    def results_complete(self):
        self._send("sync_dialog_results_complete", self.dialog_id)

    def update(self, item, source_info):
        if source_info != (self.pipe, self.remote_collection):
            self._send("sync_dialog_update", item, self.dialog_id)

    def request_needed_item(self, item_id):
        self._send("sync_dialog_get", item_id, self.dialog_id)

    def send_superseding_item(self, item):
        self._send("sync_dialog_put", item, self.dialog_id)

    def terminate(self, reason, quietly = False):
        """
        Send a "terminate_sync_dialog" message to our peer.

        The value of "reason" will be one of the following:
         * "client request"
         * "repository shutting down"
         * "collection removed"
         * "no such collection"
         * "permission denied"
         * "connection closed" (simulated by receiver)
         * "unknown"
        """
        self.terminated = reason
        self._send("terminate_sync_dialog", reason, self.dialog_id)
        if not quietly:
            self.skeleton.pipe_manager.sync_dialog_state_changed(self)

    def _send(self, method, *params):
        try:
            self.pipe.send(method, *params)
        except SessionClosed:
            pass

    def get_info(self):
        p = self.pipe
        return {
            "pipe id" : p.id,
            "address" : p.address,
            "repo id" : p.repo_id,
            "greeting" : p.greeting,
            "dialog id" : self.dialog_id,
            "local collection" : self.local_collection,
            "remote collection" : self.remote_collection,
            "xpath" : self.xpath,
            "namespace mapping" : self.namespace_mapping,
            "start timestamp" : self.start_timestamp,
            "sync timestamp" : self.sync_timestamp,
            "terminated" : self.terminated,
            }

_pipe_id_count = 0

def allocate_pipe_id():
    """
    Return a new non-zero integer for use as a pipe ID.
    """
    global _pipe_id_count
    _pipe_id_count += 1
    return _pipe_id_count

_sync_dialog_id_count = 0

def allocate_sync_dialog_id(parity):
    """
    Return a new sync dialog ID string.

    Dialog IDs must be unique among those for each sync connection,
    including across both endpoints.  We achieve this by requiring
    even parity for IDs allocated by the initiator of a connection,
    and odd parity for IDs allocated by the accepting peer.

    Dialog IDs are not unique across different sync connections.
    """
    global _sync_dialog_id_count
    _sync_dialog_id_count += 1
    return str(2 * _sync_dialog_id_count + parity)
