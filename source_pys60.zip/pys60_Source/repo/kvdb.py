#
# pdis.repo.kvdb
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# This software derives in part from dumbdbm.py in Python 2.3.3,
# which is subject to the terms and conditions reproduced in the
# file COPYING.PYTHON in the top-level folder of this source tree.

"""A very simple dbm clone.

KVDB stands for key-value database.  Keys and values are arbitrary
byte strings.

Each database is stored as either one or two files, depending on
whether it was created in in-line-only format.  For database spam,
the directory file spam.dir contains the keys, while the data file
spam.dat contains the values.  In in-line-only format, all values
are included in spam.dir.
"""

# Although this code uses the file extensions "dir" and "dat", it is
# completely incompatible with dumbdbm.  It refuses to read dumbdbm
# databases, and it creates databases that are classified as
# unrecognizable by whichdb.
#
# The first line of the directory file looks like
#    "hiit.fi/2005/kvdb %d\n" % blocksize
# where blocksize is either a positive integer or zero, with zero
# indicating that all values are included in-line in the directory file.
#
# An arbitrary number of index entries follows.  If several of these
# specify the same key, all but the last are ignored.

# There are three possible formats.  An out-of-line entry looks like
# this:
#    "%d %d %d\n%s\n" % (key_size, value_size, value_position, key)
# An in-line entry looks like this:
#    "%d %d\n%s\n%s\n" % (key_size, value_size, key, value)
# Finally, an entry of the form
#    "%d\n%s\n" % (key_size, key)
# indicates that the key is not present in the database (nullifying
# any preceding entries specifying that key).
#
# For out-of-line entries, value_position is the blocksize-aligned
# offset into the data file of the value's first byte, and value_size
# is the number of bytes in the value.

# XXX Bugs to report for dumbdbm:
# - The mode parameter was being passed as bufsize.
# - The original intent was to keep the directory file consistent with
#   the data file.  This was broken in 2000 by a patch that claimed to
#   be fixing a "silly bug" (unbounded growth of the directory file).

import sys
import os

try:
    from UserDict import DictMixin      # Not available in Python 2.2.
except ImportError:
    class DictMixin: pass

_magic = "hiit.fi/2005/kvdb"

error = IOError                         # For anydbm

if sys.platform == "symbian_s60":
    # Specifying a binary stream on Symbian OS makes flush()
    # nonfunctional but otherwise has no effect.  (XXX Is this
    # fixed in Python for Series 60 v1.0?)
    def _tweak_mode(mode):
        return mode.replace('b', '')
else:
    def _tweak_mode(mode):
        return mode

class _Database(DictMixin):

    def __init__(self, name,
                 blocksize, inline_max, inline_only,
                 relative_compaction_threshold, absolute_compaction_threshold):
        assert blocksize > 0
        if inline_only:
            blocksize = 0

        self._name = name
        self._blocksize = blocksize
        self._inline_max = inline_max
        self._inline_only = inline_only
        self._relative_compaction_threshold = relative_compaction_threshold
        self._absolute_compaction_threshold = absolute_compaction_threshold

        self._dirfilename = name + '.dir'
        self._datfilename = name + '.dat'
        self._bakfilename = name + '.bak'
        self._tmpfilename = name + '.tmp'

        # The index is an in-memory dict, mirroring the directory file.
        # It maps keys to either values or (position, size) pairs.
        self._index = {}

        # We keep track of the number entries in the directory file.
        # If the difference between this and len(self._index) exceeds
        # the specified relative and absolute thresholds, we rewrite
        # the directory file.
        self._entries_in_file = 0

        # Create the directory file if it does not exist.
        if not os.path.exists(self._dirfilename):
            f = file(self._dirfilename, _tweak_mode('wb'))
            f.write("%s %d\n" % (_magic, self._blocksize))
            f.close()

        # Open the directory file for updating and read its header.
        self._dirfile = file(self._dirfilename, _tweak_mode('r+b'))
        try:
            magic, extra = self._dirfile.readline().split()
            if magic != _magic:
                raise error
            self._blocksize = int(extra)
            self._inline_only = (self._blocksize == 0)
        except:
            self._dirfile.close()
            raise error, "Bad header for directory file."

        # Read the contents of the directory file.
        try:
            while True:
                line = self._dirfile.readline()
                if not line:
                    break

                numbers = map(int, line.split())
                if len(numbers) == 3:
                    key_size, value_size, value_position = numbers
                    n = key_size + 1
                    data = self._dirfile.read(n)
                    if len(data) != n:
                        raise error
                    key = data[:-1]
                    newline = data[-1]
                    if newline != '\n':
                        raise error
                    self._index[key] = (value_position, value_size)
                elif len(numbers) == 2:
                    key_size, value_size = numbers
                    n = key_size + value_size + 2
                    data = self._dirfile.read(n)
                    if len(data) != n:
                        raise error
                    key = data[:key_size]
                    newline = data[key_size]
                    value = data[key_size + 1 : -1]
                    newline2 = data[-1]
                    if newline != '\n' or newline2 != '\n':
                        raise error
                    self._index[key] = value
                elif len(numbers) == 1:
                    key_size, = numbers
                    n = key_size + 1
                    data = self._dirfile.read(n)
                    if len(data) != n:
                        raise error
                    key = data[:-1]
                    newline = data[-1]
                    if newline != '\n':
                        raise error
                    del self._index[key]
                else:
                    raise error

                self._entries_in_file += 1
        except:
            print "Repairing corrupt directory file." # XXX
            self._compact()

        # Now also open the data file for updating, creating it first
        # if necessary.
        if not self._inline_only:
            if not os.path.exists(self._datfilename):
                f = file(self._datfilename, _tweak_mode('wb'))
                f.close()

            self._datfile = file(self._datfilename, _tweak_mode('r+b'))

    def _maybe_compact(self):
        n = len(self._index)
        excess = self._entries_in_file - n
        if excess > self._relative_compaction_threshold * n \
               and excess > self._absolute_compaction_threshold:
            self._compact()

    def _compact(self):
        self._dirfile.close()

        f = file(self._tmpfilename, _tweak_mode('wb'))
        try:
            f.write("%s %d\n" % (_magic, self._blocksize))
            for key, value in self._index.iteritems():
                if isinstance(value, str):
                    f.write("%d %d\n%s\n%s\n"
                            % (len(key), len(value), key, value))
                else:
                    position, size = value
                    f.write("%d %d %d\n%s\n"
                            % (len(key), size, position, key))
        finally:
            f.close()

        try:
            os.remove(self._bakfilename)
        except os.error:
            pass

        try:
            os.rename(self._dirfilename, self._bakfilename)
        except os.error:
            pass

        try:
            os.rename(self._tmpfilename, self._dirfilename)
        except os.error:
            pass

        self._dirfile = file(self._dirfilename, _tweak_mode('r+b'))
        self._dirfile.seek(0, 2)        # To end.
        self._entries_in_file = len(self._index)

    def sync(self):
        # Note that we are not calling os.fsync().
        if not self._inline_only:
            self._datfile.flush()
        self._dirfile.flush()

    def __getitem__(self, key):
        value = self._index[key]        # May raise KeyError.
        if isinstance(value, str):
            return value
        else:
            position, size = value
            self._datfile.seek(position)
            data = self._datfile.read(size)
            assert len(data) == size
            return data

    def __delitem__(self, key):
        del self._index[key]            # May raise KeyError.
        self._dirfile.write("%d\n%s\n" % (len(key), key))
        self._entries_in_file += 1
        self._maybe_compact()

    def __setitem__(self, key, value):
        if not type(key) == type('') == type(value):
            raise TypeError, "Keys and values must be strings."

        if self._inline_only or len(value) <= self._inline_max:
            self._index[key] = value
            self._dirfile.write("%d %d\n%s\n%s\n"
                                % (len(key), len(value), key, value))
            self._entries_in_file += 1
            self._maybe_compact()
            return

        pos = self._store_value(key, value)
        if pos is None:
            return                  # Position and size are unchanged.

        size = len(value)
        self._index[key] = (pos, size)
        self._dirfile.write("%d %d %d\n%s\n" % (len(key), size, pos, key))
        self._entries_in_file += 1
        self._maybe_compact()

    def _store_value(self, key, value):
        if key in self._index:
            entry = self._index[key]
            if isinstance(entry, tuple):
                # See whether the new value is small enough to fit in the
                # (padded) space currently occupied by the old value.
                pos, size = entry
                n = self._blocksize
                oldblocks = (size + n - 1) // n
                newblocks = (len(value) + n - 1) // n
                if newblocks <= oldblocks:
                    self._update_value(pos, value)
                    if len(value) == size:
                        return None # Position and size are unchanged.
                    return pos

        return self._append_value(value)

    # Write val to the data file, starting at offset pos.  The caller
    # is responsible for ensuring that there's enough room starting at
    # pos to hold val, without overwriting some other value.
    def _update_value(self, pos, val):
        f = self._datfile
        f.seek(pos)
        f.write(val)

    # Append val to the data file, starting at a blocksize-aligned
    # offset.  The data file is first padded with NUL bytes (if needed)
    # to get to an aligned offset.  Return the starting offset of val.
    def _append_value(self, val):
        f = self._datfile
        f.seek(0, 2)                    # To end.
        pos = int(f.tell())
        n = self._blocksize
        npos = ((pos + n - 1) // n) * n
        f.write('\0' * (npos-pos) + val)
        return npos

    def keys(self):
        return self._index.keys()

    def has_key(self, key):
        return key in self._index
    __contains__ = has_key

    def iterkeys(self):
        return self._index.iterkeys()
    __iter__ = iterkeys

    def __len__(self):
        return len(self._index)

    def close(self):
        if self._index is not None:
            self._index = None
            if not self._inline_only:
                self._datfile.close()
            self._dirfile.close()

def open(name, flag=None, mode=0666,
         blocksize=512, inline_max=32, inline_only=False,
         relative_compaction_threshold=1.0, absolute_compaction_threshold=100):
    """Open the named database and return the corresponding object.

    Optional arguments as defined for anydbm:

    The flag argument, used to control how the database is opened in
    the other DBM implementations, is ignored in this module; the
    database is always opened for update, and will be created if it
    does not exist.

    The optional mode argument is the UNIX mode of the file, used only
    when the database has to be created.  However, it is currently
    ignored in this module.  It defaults to octal code 0666 (and will
    be modified by the prevailing umask).

    The remaining parameters are intended to be specified as keyword
    arguments, and are as follows.

    blocksize - a positive integer determining the alignment of values
    in the data file if a new database has to be created.

    inline_max - an integer determining the maximum length of values
    to be stored in-line in the directory file (the contents of which
    are mirrored in memory).

    inline_only - a boolean flag indicating whether to ignore the
    value of inline_max and instead store all values in-line.  This is
    a permanent property of the database; the value of the flag is
    ignored (and the value of inline_max is not) unless a new database
    has to be created.

    relative_compaction_threshold, absolute_compaction_threshold -
    these parameters control when the directory file should be
    rewritten, namely when the number of superseded entries exceeds
    both the absolute threshold and the product of the relative
    threshold and the number of active entries.
    """
    return _Database(name, blocksize, inline_max, inline_only,
                     relative_compaction_threshold, absolute_compaction_threshold)
