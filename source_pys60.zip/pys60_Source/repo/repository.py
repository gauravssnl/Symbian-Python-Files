#
# pdis.repo.repository
#
# Copyright 2003-2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Kenneth Oksanen <cessu@iki.fi>
#          Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
PDIS repository based on dbm-style persistent hash maps
"""

# About Unicode:
#
# This code follows the usual convention of representing only ascii
# strings as octet strings (type str) and all others as unicode
# strings (type unicode).  In particular, collection names and object
# IDs (and therefore item IDs too) can be unicode strings.
#
# XML documents are an exception.  They may be represented as either
# utf-8-encoded octet strings or unicode strings.

import os
import time

from pdis.repo.collection import Collection, NoSuchCollection
from pdis.repo.item_cache import ItemCache
from pdis.lib.hex_id import create_id
from pdis.repo import hash_map

cache_size = 1000

class Repository:
    """
    The repository

    The purpose of this class is to manage collections and
    repository-wide bookkeeping.
    """

    def __init__(self, dir, listener):
        """
        Initialize a repository instance.

        This does not yet touch the file system.
        """
        self.dir = dir
        self.listener = listener
        self.collections = {}
        self.cache = ItemCache(cache_size)

        # This is a collection of general-purpose locks managed
        # through the acquire() and release() calls.  The keys are
        # lock names and the values are time stamps.
        self.locks = {}

    def open(self):
        """
        Open the repository.
        """
        # Create the database directory if necessary:
        if not os.path.isdir(self.dir):
            try:
                os.makedirs(self.dir)
            except AttributeError:
                # Workaround for missing makedirs() on Symbian OS.
                os.mkdir(self.dir)

        # Open or create the three repository-wide persistent maps:
        self.repo_map = self.open_db("repository", "c")
        self.collection_map = self.open_db("collections", "c")

        # The repository ID is just a persistent random hex ID at the
        # moment, but later it will be the signature of the repository's
        # public key.
        if "id" not in self.repo_map:
            self.repo_map["id"] = create_id()
        self.repo_id = self.repo_map["id"]

        # The repository name is an arbitrary unicode string that the
        # user can set.
        if "name" not in self.repo_map:
            self.repo_map["name"] = ""
        self.repo_name = self.repo_map["name"]

        # We require the current logical clock, self.lclock, to be equal
        # to or larger than the largest value present on an item in the
        # repository.  New items must be assigned still larger values.
        #
        # Rather than store the current logical clock on disk, we
        # store a value that is required to be greater than or equal
        # to its value.  This is called the persistent logical clock.
        if "lclock" not in self.repo_map:
            self.repo_map["lclock"] = "0"
        self.persistent_lclock = int(self.repo_map["lclock"])
        self.lclock = self.persistent_lclock

        # We'll number new collections using a counter, which we
        # initialize to a safe value here.
        self.last_collection_id = 0
        for key in self.collection_map.keys():
            id = int(self.collection_map[key])
            self.last_collection_id = max(self.last_collection_id, id)

    def close(self):
        """
        Shut down the repository.
        """
        while self.collections:
            name, collection = self.collections.popitem()
            collection.close("repository shutting down")

        self._set_persistent_lclock(self.lclock)

        self.repo_map.close()
        self.collection_map.close()

    def get_repo_id(self):
        """
        Return the repository ID (an opaque, globally unique string).

        This does not require filesystem access.
        """
        return self.repo_id

    def get_repo_name(self):
        """
        Return the repository's informal name.

        This does not require filesystem access.
        """
        return self.repo_name

    def set_repo_name(self, name):
        """
        Set the repository's informal name.
        """
        self.repo_map["name"] = self.repo_name = name

    def get_collection(self, name):
        """
        Return the Collection instance, or None if it is not open.
        """
        return self.collections.get(name)

    def open_collection(self, name):
        """
        Return the Collection instance, creating it if necessary.

        Raises NoSuchCollection on failure to open the collection.
        """
        if name not in self.collections:
            self.collections[name] = Collection(name, self)
        return self.collections[name]

    def create_collection(self, name):
        """
        Create the collection on disk if it does not already exist.

        Returns True if successful (or if nothing needs to be done).
        """
        if self.collection_exists(name):
            return True

        self.last_collection_id += 1
        id = str(self.last_collection_id)

        self.open_db(id + "-data", "n", inline=False).close()
        self.open_db(id + "-index", "n").close()
        self.open_db(id + "-prefixes", "n").close()
        self.collection_map[name] = id

        self.listener.collection_added(name)

        return True

    def remove_collection(self, name):
        """
        Remove the collection from disk if it exists.

        Also closes the collection if it is open.  Returns True if
        successful (or if nothing needs to be done).
        """
        if not self.collection_exists(name):
            return True

        if name in self.collections:
            self.collections[name].close("collection removed")
            del self.collections[name]

        id = self.collection_map[name]
        del self.collection_map[name]

        self.remove_db(id + "-data")
        self.remove_db(id + "-index")
        self.remove_db(id + "-prefixes")

        self.listener.collection_removed(name)

        return True

    def collection_exists(self, name):
        """
        Return True if the collection exists on disk.
        """
        return name in self.collection_map

    def list_collections(self):
        names = self.collection_map.keys()
        names.sort()
        return names

    def acquire(self, name):
        if name in self.locks:
            return False
        else:
            self.locks[name] = time.time()
            return True

    def release(self, name):
        if name in self.locks:
            del self.locks[name]
            return True
        else:
            return False

    # 
    # Methods for use by the Collection implementation
    #

    # Database files

    def open_db(self, name, flag = 'r', inline = True):
        return hash_map.open(self._fullpath(name), flag, inline = inline)

    def remove_db(self, name):
        hash_map.remove(self._fullpath(name))

    def _fullpath(self, name):
        return os.path.normpath(os.path.join(self.dir, name))

    # Logical clock

    def tick(self):
        """
        Generate a new logical clock value.

        The logical clock must be monotonically increasing and
        persistent, but in order to improve performance, we increment
        the persistent value only every 100th time.  This is okay
        because gaps don't matter in the logical clock values.
        """
        self.lclock += 1
        self._update_persistent_lclock()
        return self.lclock

    def tick_to(self, lclock):
        """
        Adjust the logical clock forward to the given value.
        """
        if lclock > self.lclock:
            self.lclock = lclock
            self._update_persistent_lclock()

    def _update_persistent_lclock(self, slack = 100):
        """
        Bump the persistent logical clock to a reasonable value if necessary.
        """
        if self.lclock > self.persistent_lclock:
            self._set_persistent_lclock(self.lclock + slack)

    def _set_persistent_lclock(self, value):
        """
        Set the persistent logical clock to the given value.
        """
        self.persistent_lclock = value
        self.repo_map["lclock"] = str(self.persistent_lclock)
