#
# pdis.repo.server
#
# Copyright 2003-2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Kenneth Oksanen <cessu@iki.fi>
#          Ken Rimey <rimey@hiit.fi>
#          Torsten Rueger <torsten@omenapuu.de>
#          Tero Hasu <tero.hasu@hut.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import time

from pdis.lib.logging import logwrite
from pdis.pipe.pipe import start_pipe_server, SessionClosed
from pdis.repo.skeleton import RepoSkeleton

class PipeManager:
    """
    Keep track of open pipes.

    Forwards repository-wide notifications to each registered pipe
    that wants them.

    The get_pipes() and lookup_by_*() methods are thread-safe.
    We require this so they can be called from inbound message pipe
    threads in skeleton.py.
    """
    def __init__(self):
        self.pipes = []
        self.neighbors = {}             # Map repo ID to count.

    def lookup_by_id(self, pipe_id):
        for p in self.get_pipes():
            if p.id == pipe_id:
                return p
        return None

    def lookup_by_address(self, address):
        for p in self.get_pipes():
            if p.address == address:
                return p
        return None

    def get_pipes(self):
        return list(self.pipes)

    def get_neighbors(self):
        return dict(self.neighbors)

    def connected(self, pipe):
        self.pipes.append(pipe)

    def initialized(self, pipe):
        id = pipe.repo_id
        if id:
            count = self.neighbors.get(id, 0)
            count += 1
            self.neighbors[id] = count
            self._send("connected", id, count)

    def disconnected(self, pipe):
        self.pipes.remove(pipe)
        id = pipe.repo_id
        if id:
            count = self.neighbors[id]
            count -= 1
            if count == 0:
                del self.neighbors[id]
            else:
                self.neighbors[id] = count
            self._send("disconnected", id, count)

    def sync_dialog_state_changed(self, dialog):
        if dialog.terminated:
            logwrite("%s terminated: %s." % (dialog, dialog.terminated))
        elif dialog.sync_timestamp:
            logwrite("%s stable." % dialog)
        else:
            logwrite("%s started." % dialog)

        info = dialog.get_info()
        self._send("sync_dialog_state_changed", info)

    def collection_added(self, collection):
        self._send("collection_added", collection)

    def collection_removed(self, collection):
        self._send("collection_removed", collection)

    def _send(self, method, *params):
        for pipe in self.pipes:
            if pipe.notify:
                try:
                    pipe.send(method, *params)
                except SessionClosed:
                    pass

class RepoServer:
    """
    Server instance
    """
    def __init__(self, repo_dir, **keys):
        """
        Instantiate server.
        """
        self.pipe_servers = []
        self.pipe_manager = PipeManager()
        self.skeleton = RepoSkeleton(repo_dir, self.pipe_manager, **keys)
        self.skeleton.start()

    def listen(self, listening_address):
        """
        Start serving on the specified network transport.
        """
        server = start_pipe_server(listening_address,
                                   target = self.skeleton)
        self.pipe_servers.append(server)

    def close(self, timeout = 0):
        """
        Shut down server.

        This method can safely be called more than once.
        """
        endtime = time.time() + timeout

        # Stop accepting incoming connections.
        servers = self.pipe_servers
        for server in servers:
            server.close()

        # Wait for all servers to close.
        for server in servers:
            remaining = endtime - time.time()
            if remaining <= 0:
                break
            server.close(remaining)

        # Shut down the repository.
        self.skeleton.stop()

        # Do an asynchronous close on all open pipes.
        pipes = self.pipe_manager.get_pipes()
        for pipe in pipes:
            pipe.close()

        # Wait for all pipes to close.
        for pipe in pipes:
            remaining = endtime - time.time()
            if remaining <= 0:
                break
            pipe.close(remaining)
