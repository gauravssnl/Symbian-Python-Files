#
# pdis.repo.collection
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Kenneth Oksanen <cessu@iki.fi>
#          Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from pdis.versioning.et_metadata import ETItem, compile_xpath
from pdis.versioning.pdis_metadata import \
     tombstone_string, split_item_id, key_from_id, \
     create_item_id, create_object_id, create_version_id, \
     create_version_prefix, get_next_version_number
from pdis.xpath import XPathError

class NoSuchCollection(Exception):
    pass

class Collection:
    """
    Handle for one of the collections in a repository

    Each instance maintains all live queries and sync dialogs for
    a particular collection.
    """

    def __init__(self, name, repo):
        """
        Open the collection.
        """
        self.name = name
        self.repo = repo

        if not repo.collection_exists(name):
            raise NoSuchCollection

        id = repo.collection_map[name]
        self.data_map = repo.open_db(id + "-data", "w")
        self.index_map = repo.open_db(id + "-index", "w")
        self.prefix_map = repo.open_db(id + "-prefixes", "w")

        self.live_queries = []
        self.sync_dialogs = []

    def close(self, reason):
        """
        Close the collection.

        No other methods can be called after this.
        """
        # XXX Currently collections are only ever closed when they
        # are removed from disk or the repository terminates.
        self.live_queries = []
        while self.sync_dialogs:
            self.sync_dialogs.pop().terminate(reason)
        self.data_map.close()
        self.index_map.close()
        self.prefix_map.close()

    def get_all_ids(self):
        """
        Return a list of all item IDs present in the collection.

        In conjunction with get_item(), this provides a way to access the
        complete contents of a collection, including superseded items.
        """
        return self.data_map.keys()

    def get_item(self, id):
        """
        Return the specified item as a string.

        If the item is not found in the collection, return the empty string.
        """
        if id in self.data_map:
            return self.data_map[id]
        else:
            return ""

    def get_mrca(self, ids):
        """
        Attempt to return the most recent common ancestor of the specified versions.

        If the most recent common ancestor is not identifiable or not
        available, return the empty string.
        """
        if not ids:
            return ""

        object = key_from_id(ids[0])
        for id in ids[1:]:
            if key_from_id(id) != object:
                return ""

        versions = [split_item_id(id)[1] for id in ids]

        try:
            items = [self._fetch_item(object, v) for v in versions]
        except KeyError:
            return ""

        common_ancestors = items[0].get_ancestors()
        for i in items[1:]:
            common_ancestors.intersection_update(i.get_ancestors())

        candidate_versions = common_ancestors.get_candidates_for_most_recent()
        if not candidate_versions:
            return ""

        candidate_items = []
        unavailable_versions = []
        for v in candidate_versions:
            try:
                item = self._fetch_item(object, v)
                candidate_items.append(item)
            except KeyError:
                unavailable_versions.append(v)

        for v in unavailable_versions:
            for i in candidate_items:
                if i.supersedes_version(v):
                    break
            else:
                return ""

        candidate_items.sort()
        most_recent = candidate_items[-1]

        try:
            return self.data_map[most_recent.get_id()]
        except KeyError:
            # It is possible that we don't actually have a copy of the
            # item in this collection's data map, because it might have
            # come from the cache, which is shared with other collections.
            return ""

    def create_item(self, item_string, parent_item_strings, object = None):
        """
        Add an item to the collection and return its metadata.

        The provided parent items may be the whole item or only their
        metadata.  The object ID, if specified, must be consistent
        with the parent items.  If no object ID and no parent items
        are specified, a new unique object ID is generated.
        """
        parent_items = [ETItem(s, metadata_only = True)
                        for s in parent_item_strings]
        for i in parent_items:
            if not i.has_valid_metadata():
                raise ValueError, "Invalid metadata in parent item."

        item = ETItem(item_string)
        item.clear_all_metadata()

        if object is None:
            if parent_items:
                object = parent_items[0].get_object_id()
            else:
                object = create_object_id()

        items = self._fetch_items(object)

        lclock = self.repo.tick()
        version = self._new_version_id(object, items)
        if len(parent_items) > 1:
            item.init_join(object, version, parent_items, lclock)
        else:
            item.init(object, version, parent_items, lclock)

        self._store_item(item)
        self._update_current_items(item, items)

        item.clear_all_but_metadata()
        return item.tostring()

    def kill_item(self, item_string):
        """
        Create a tombstone to supersede the given item.
        """
        # XXX Make this a no-op when the item is not current.
        self.create_item(tombstone_string, [item_string])

    def put_item(self, item_string, source_info = None):
        """
        Copy an item into the collection.
        
        The item must already have complete and valid metadata.
        Because the item is not new, it or items that supersede it
        may already exist in the collection.  This routine is used
        in synchronization.
        """
        item = ETItem(item_string)
        if not item.has_valid_metadata():
            raise ValueError, "Item has invalid metadata."

        object = item.get_object_id()
        version = item.get_version_id()
        versions = self._get_object_versions(object)
        if version in versions:
            return                      # Item already in collection.

        if item.get_id() not in self.data_map:
            self.repo.tick_to(item.get_lclock())
            self.data_map[item.get_id()] = item_string

        items = [self._fetch_item(object, v) for v in versions]
        for i in items:
            if i.supersedes_version(version):
                return                # No change in current versions.

        self._update_current_items(item, items, source_info)

    def query(self, xpath, namespace_mapping, keys=None,
              ids_only=False, most_recent_only=False):
        """
        Execute an XPath query and return the matching current items.

        The result is a list of either item IDs or items, depending on
        the value of ids_only.
        """
        xpath = compile_xpath(xpath, namespace_mapping)
        return self._query(xpath, keys, ids_only, most_recent_only)

    def _query(self, parsed_xpath, keys=None,
               ids_only=False, most_recent_only=False):
        if keys is None:
            keys = self._get_keys()

        result = []
        for object in keys:
            for item in self._fetch_matching_items(object, parsed_xpath,
                                                   most_recent_only):
                id = item.get_id()
                if ids_only:
                    result.append(id)
                else:
                    result.append(self.data_map[id])
        return result

    def count(self, xpath, namespace_mapping, keys=None, most_recent_only=False):
        """
        Return a tuple of the number of objects/versions that satisfy the query.

        The first value will be less than or equal to the second.

        If most_recent_only is not specified, an object is counted
        once if at least one current version satisfies the query.
        """
        if keys is None:
            keys = self._get_keys()

        xpath = compile_xpath(xpath, namespace_mapping)
        object_count = 0
        version_count = 0
        for object in keys:
            matches = False
            for item in self._fetch_matching_items(object, xpath, most_recent_only):
                matches = True
                version_count += 1
            if matches:
                object_count += 1
        return object_count, version_count

    def start_live_query(self, live_query):
        """
        Start a live query.

        This implementation fulfills the initial phase of the query
        immediately.  The argument is a LiveQuery (see server.py).

        Unlike in ordinary queries, the value of ids_only for a live
        query is a pair of booleans referring to items added and items
        removed, respectively.
        """
        xpath = live_query.parsed_xpath
        keys = live_query.keys
        ids_only = live_query.ids_only
        most_recent_only = live_query.most_recent_only

        # Fulfill the initial phase of the query immediately.
        results = self._query(xpath, keys, ids_only[0], most_recent_only)
        while True:
            chunk = results[0:20]
            del results[0:20]

            live_query.results(chunk, not results)
            if not results:
                break

        self.live_queries.append(live_query)

    def terminate_live_query(self, live_query):
        """
        Causes the specified live query to cease issuing notifications.

        Note that there may be buffered messages already on the way.
        """
        if live_query in self.live_queries:
            self.live_queries.remove(live_query)

    def live_query_exists(self, live_query):
        """
        Return True if the live query is active.
        """
        return live_query in self.live_queries

    def start_sync_dialog(self, sync_dialog):
        """
        Start a sync dialog.

        The argument is a SyncDialog (see server.py).
        """
        xpath = sync_dialog.parsed_xpath

        results = []
        for object in self._get_keys():
            for item in self._fetch_items(object):
                if item.matches(xpath):
                    results.append(item.get_id())

        while results:
            sync_dialog.results(results[0:20])
            del results[0:20]

        sync_dialog.results_complete()

        self.sync_dialogs.append(sync_dialog)

    def terminate_sync_dialog(self, sync_dialog):
        """
        Causes the specified sync dialog to cease issuing notifications.

        Note that there may be buffered messages already on the way.
        """
        if sync_dialog in self.sync_dialogs:
            self.sync_dialogs.remove(sync_dialog)

    def sync_dialog_exists(self, sync_dialog):
        """
        Return True if the sync dialog is active.
        """
        return sync_dialog in self.sync_dialogs

    def check_matching_item_id(self, id, sync_dialog):
        """
        Handle notification that an item is available and current in a remote collection.

        If we have neither the item nor one that supersedes it, we request it.
        If we have an item that supersedes it and doesn't match the sync
        dialog's filter, the remote collection doesn't contain the superseding
        item and won't be receiving it via the sync dialog, so we send it.

        This method is called when a "sync_dialog_results" message is received.
        """
        if self._send_superseding_items(id, sync_dialog):
            sync_dialog.request_needed_item(id)

    def put_matching_item(self, item_string, sync_dialog):
        """
        Handle an item received from a remote collection, where it is current.

        If we have an item that supersedes this one and doesn't match the sync
        dialog's filter, the remote collection doesn't contain the superseding
        item and won't be receiving it via the sync dialog, so we send it.

        This method is called when a "sync_dialog_update" message or a
        "get_reply" message is received.
        """
        self.put_item(item_string, (sync_dialog.pipe, sync_dialog.remote_collection))

        item = ETItem(item_string, metadata_only = True)
        self._send_superseding_items(item.get_id(), sync_dialog)

    def _send_superseding_items(self, id, sync_dialog):
        """
        Send items superseding the specified one to a remote collection.

        More specifically, just one of the superseding items is sent,
        and only if none of them match the sync dialog's filter.  The
        idea is to send the minimum necessary to cause the specified
        item to no longer be current at the remote collection.

        The method returns True if the specified item is needed (is
        neither present nor superseded) in the local collection.
        """
        object, version = split_item_id(id)

        versions = self._get_object_versions(object)
        if version in versions:
            return False

        superseding_items = []
        for v in versions:
            i = self._fetch_item(object, v)
            if i.supersedes_version(version):
                superseding_items.append(i)

        if not superseding_items:
            return True

        for i in superseding_items:
            if i.matches(sync_dialog.parsed_xpath):
                return False

        superseding_id = superseding_items[-1].get_id()
        sync_dialog.send_superseding_item(self.data_map[superseding_id])

        return False

    def _update_current_items(self, item, items, source_info = None):
        """
        Add a new current item for an object.

        We assume that the caller has already fetched a list of
        current items for this object and determined that the new item
        is not present and will be current.  We also assume that the
        new item has already been stored in the data map.

        This method updates the index map so as to add the new version
        and remove any versions that it supersedes.  It also performs
        redundancy suppression if necessary.  It issues callbacks as
        appropriate.
        """
        join_set = item.get_join_set()
        if join_set:
            for other_item in items:
                if other_item.get_join_set() == join_set:
                    if item.supersedes_version(other_item.get_version_id()):
                        pass
                    elif other_item < item:
                        # Suppress the other item.
                        tombstone = self._store_tombstone(other_item, items + [item])
                        items = self._update_without_suppression(tombstone, items)
                        return self._update_without_suppression(item, items, source_info)
                    else:
                        # Suppress the item, issuing combined callbacks
                        # for the item and the tombstone.
                        tombstone = self._store_tombstone(item, items + [item])
                        return self._update_without_suppression(tombstone, items)

        # No redundancy suppression required.
        return self._update_without_suppression(item, items, source_info)

    def _update_without_suppression(self, item, items, source_info = None):
        assert item not in items

        current_items = []
        superseded_items = []
        for i in items:
            if item.supersedes_version(i.get_version_id()):
                superseded_items.append(i)
            else:
                current_items.append(i)
        current_items.append(item)
        current_items.sort()

        current_versions = [i.get_version_id() for i in current_items]

        key = item.get_object_id()
        self._set_object_versions(key, current_versions)
        self._send_live_query_callbacks(key, items, current_items)
        self._send_sync_dialog_callbacks(item, superseded_items, source_info)
        return current_items

    def _store_tombstone(self, item, items):
        assert item in items
        tombstone = ETItem(tombstone_string)
        lclock = self.repo.tick()
        object = item.get_object_id()
        version = self._new_version_id(object, items)
        tombstone.init(object, version, [item], lclock)
        self._store_item(tombstone)
        return tombstone

    def _send_live_query_callbacks(self, key, old_current_items, new_current_items):
        """
        Send live query callbacks.
        """
        old_current_items = [i for i in old_current_items if not i.is_tombstone()]
        new_current_items = [i for i in new_current_items if not i.is_tombstone()]

        for q in self.live_queries:
            if q.keys is None or key in q.keys:
                self._send_live_query_callback(q, old_current_items, new_current_items)

    def _send_live_query_callback(self, q, old, new):
        if not q.most_recent_only:
            new, old = ([i for i in new if i not in old],
                        [i for i in old if i not in new])

        try:
            new = self._filter_items(new, q.parsed_xpath, q.most_recent_only)
            old = self._filter_items(old, q.parsed_xpath, q.most_recent_only)
        except XPathError:
            return

        if q.most_recent_only:
            if new == old:
                new = old = []

        if new or old:
            if q.ids_only[0]:
                added = [i.get_id() for i in new]
            else:
                added = [self.data_map[i.get_id()] for i in new]

            if q.ids_only[1]:
                removed = [i.get_id() for i in old]
            else:
                # XXX The following line of code is liable to break someday
                # if superseded entries are removed from the database.
                removed = [self.data_map[i.get_id()] for i in old]

            q.update(added, removed)

    def _send_sync_dialog_callbacks(self, new_item, superseded_items, source_info = None):
        """
        Send sync dialog callbacks.

        The new item is one that has just been added to the repository
        and is current.  The superseded items list must include all of
        the items newly superseded by the new item.  A change notification
        is sent for each sync dialog that matches either the new item
        or one of the superseded items.
        """
        for q in self.sync_dialogs:
            try:
                for i in [new_item] + superseded_items:
                    if i.matches(q.parsed_xpath):
                        break
                else:
                    continue

                id = new_item.get_id()
                q.update(self.data_map[id], source_info)
            except XPathError:
                pass

    def _new_version_id(self, object, current_items):
        """
        Generate a new version ID of the form "prefix:number".

        The prefix distinguishes the counters maintained by different
        repositories or collections for the same object.
        """
        if object in self.prefix_map:
            prefix = self.prefix_map[object]
            count = get_next_version_number(prefix, current_items)
        else:
            prefix = create_version_prefix()
            count = get_next_version_number(prefix, current_items)
            while count > 1:
                # Pick a different prefix if there is a collision.
                prefix = create_version_prefix()
                count = get_next_version_number(prefix, current_items)
            self.prefix_map[object] = prefix
        return create_version_id(prefix, count)

    def _get_keys(self):
        """
        Return a list of the object IDs present in the collection.
        """
        keys = self.index_map.keys()
        if "" in keys:
            keys.remove("")
            keys.insert(0, "")
        return keys

    def _get_object_versions(self, object):
        """
        Return a list of current version IDs for a given object.
        """
        if object not in self.index_map:
            return []
        else:
            return self.index_map[object].split()

    def _set_object_versions(self, object, version_ids):
        """
        Update the list of current version IDs for a given object.

        The list must be in standard total order (based on lclock).
        """
        self.index_map[object] = " ".join(version_ids)

    def _fetch_items(self, object):
        """
        Return the current versions of an object as parsed items.
        """
        return [self._fetch_item(object, version)
                for version in self._get_object_versions(object)]

    def _fetch_matching_items(self, object, xpath, most_recent_only):
        """
        Return the current versions of an object matching an XPath.

        If most_recent_only is specified, only the most recent matching
        version is returned.
        """
        items = [i for i in self._fetch_items(object) if not i.is_tombstone()]
        return self._filter_items(items, xpath, most_recent_only)

    def _filter_items(self, items, xpath, most_recent_only):
        if not most_recent_only:
            return [i for i in items if i.matches(xpath)]
        else:
            items = list(items)
            items.reverse()
            for i in items:
                if i.matches(xpath):
                    return [i]
            return []

    def _fetch_item(self, object, version):
        """
        Get a parsed item.
        """
        id = create_item_id(object, version)

        item = self.repo.cache.get(id)
        if item is not None:
            return item

        item = ETItem(self.data_map[id])
        self.repo.cache.set(id, item)
        return item

    def _store_item(self, item):
        """
        Save a parsed item.
        """
        self.data_map[item.get_id()] = item.tostring()
