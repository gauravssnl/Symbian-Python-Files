#
# pdis.repo.file
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Support for file system access in repository
"""

import os
import md5

from pdis.lib.element import XML
from pdis.versioning.et_metadata import get_key
from pdis.fsync.file_utils import is_prefix
from pdis.repo.collection import NoSuchCollection

class NoSuchFile(Exception):
    pass

def read_file(path, file_id):
    """
    Return the contents of a file.

    Raises IOError if the file cannot be read or if its contents do
    not hash to the file ID.
    """
    f = file(path, "rb")
    try:
        data = f.read()
        if md5.new(data).hexdigest() != file_id:
            raise IOError, "Hash does not match."
        return data
    finally:
        f.close()

def get_roots(repo, collection_name):
    """
    Return a list of roots of directory trees associated with the collection.

    Having more than one mapping for a single collection is illegal
    according to our current model, but if we find several, we simply
    return all of the paths.
    """
    try:
        exports_collection = repo.open_collection("__exports__")
    except NoSuchCollection:
        return []

    exports = exports_collection.query("/directory", {},
                                       keys=[collection_name])
    return [XML(item).findtext("path") for item in exports]

def get_file(repo, collection_name, file_id):
    """
    Return file contents hashing to the given file ID.

    Raises NoSuchFile if no matching file is found in a directory
    tree associated with the specified collection.
    """
    roots = get_roots(repo, collection_name)
    if not roots:
        raise NoSuchFile

    try:
        files_collection = repo.open_collection("__files__")
    except NoSuchCollection:
        raise NoSuchFile

    # Although indexing the records in __files__ by path instead of
    # by hash works out well overall, it is slightly awkward here.
    # Looking up records by hash takes some time, but we only do it
    # when we expect to read and transmit the contents of a file,
    # which will also take some time.
    xpath = '/file[md5 = "%s"]'  % file_id
    for item in files_collection.query(xpath, {}):
        path = get_key(XML(item))
        for root in roots:
            if is_prefix(root, path):
                try:
                    return read_file(path, file_id)
                except IOError:
                    files_collection.kill_item(item)
    else:
        raise NoSuchFile
