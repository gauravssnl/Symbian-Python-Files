#
# pdis.repo.hash_map
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Enhanced dbm interface

The underlying dbm implementation is either dbhash or kvdb.

This module adds the following features:
 - Unicode keys and values are automatically encoded using utf-8.  Keys
   (but not values) outside 7-bit ascii are decoded before being returned.
 - With sync mode, which is enabled by default, all changes are immediately
   written through to disk.
 - A convenience function is provided for removing databases.
 - A small cache is maintained to enhance performance.
"""

import os

import codecs              # Avoid pause due to implicit import later.

try:
    from dbhash import open as _open
    using_kvdb = False
except ImportError:
    from pdis.repo.kvdb import open as _open
    using_kvdb = True

from pdis.lib.compat import decode_if_necessary

def open(filename, flag='r', mode=0600, inline=False):
    """
    See anydbm.open().

    Specifying the inline flag requests that the database be created
    in one-file format if kvdb is in use.
    """
    if using_kvdb:
        db = _open(filename, flag, mode,
                   blocksize=1, inline_only=inline)
        return HashMap(db, enable_caching=not inline)
    else:
        db = _open(filename, flag, mode)
        return HashMap(db, enable_caching=True)

def remove(name):
    _remove(name)
    for extension in [".db", ".pag", ".dir", ".dat", ".bak"]:
        _remove(name + extension)

def _remove(filename):
    try:
        os.remove(filename)
    except OSError:
        pass

class HashMap:
    def __init__(self, db, sync_mode=True,
                 cache_limit=10000, enable_caching=True):
        self.db = db
        self.sync_mode = sync_mode

        if not enable_caching:
            cache_limit = 0

        self.cache = {}
        self.cache_size = 0
        self.cache_limit = cache_limit

        if self.sync_mode:
            self.sync()

    def __getitem__(self, key):
        key = self._encode(key)
        if key in self.cache:
            return self.cache[key]
        else:
            value = self.db[key]
            self._remember(key, value)
            return value

    def __setitem__(self, key, value):
        key = self._encode(key)
        value = self._encode(value)
        self.db[key] = value
        self._forget(key)
        self._remember(key, value)
        if self.sync_mode:
            self.sync()

    def __delitem__(self, key):
        key = self._encode(key)
        del self.db[key]
        self._forget(key)
        if self.sync_mode:
            self.sync()

    def __contains__(self, key):
        key = self._encode(key)
        return self.db.has_key(key)

    def keys(self):
        keys = self.db.keys()
        return [decode_if_necessary(key) for key in keys]

    def close(self):
        self.db.close()

    def sync(self):
        self.db.sync()

    def _encode(self, s):
        if isinstance(s, unicode):
            return s.encode("utf-8")
        else:
            return s

    def _remember(self, key, value):
        assert key not in self.cache
        self.cache[key] = value
        self.cache_size += len(value)
        while self.cache_size > self.cache_limit:
            k, v = self.cache.popitem()
            self.cache_size -= len(v)

    def _forget(self, key):
        if key in self.cache:
            value = self.cache[key]
            del self.cache[key]
            self.cache_size -= len(value)
