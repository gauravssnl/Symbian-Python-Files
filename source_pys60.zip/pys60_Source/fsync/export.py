#
# pdis.fsync.export
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Associate file trees with metadata collections.

The functions export() and unexport() add and remove records of
the following form from the local collection named __exports__:

    <directory pdis:key="...">
      <path>...</path>
    </directory>

The key is the name of a metadata collection.  The path defines
the root of the exported file tree and must be absolute and in
os-native format.

We require that each metadata collection be associated with only one
path.  (It is appealing to try to use most_recent_only mode to enforce
this, but that doesn't work because of interference with records of
other types--e.g., collection--that happen to share the same key.)
"""

import os

from pdis.lib.element import Element, addsubelement
from pdis.versioning.et_metadata import get_key
from pdis.access.et_repo_access import RepoAccess

def export_file_tree(root, collection):
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        raise ValueError('Directory does not exist: %s' % root)

    repo = RepoAccess(client_name="export")
    try:
        exports = repo.open_collection("__exports__", only_if_exists=False)

        entries = exports.query("/directory", key=collection)
        if entries:
            for entry in entries:
                if entry.findtext("path") != root:
                    raise ValueError('Collection "%s" is already mapped.' % collection)
        else:
            repo.create_collection(collection)

            entry = Element("directory")
            addsubelement(entry, "path", root)
            exports.create(entry, key=collection)
    finally:
        repo.close()

def unexport_file_tree(root, collection=None):
    root = os.path.abspath(root)

    repo = RepoAccess(client_name="unexport")
    try:
        exports = repo.open_collection("__exports__", only_if_exists=False)

        entries = exports.query('/directory[path = "%s"]' % root)
        if not entries:
            raise ValueError('Directory is not exported: %s' % root)

        if collection is None:
            if len(entries) > 1:
                raise ValueError('Must specify collection for multiply exported directory.')
            else:
                collection = get_key(entries[0])

        for entry in entries:
            if get_key(entry) == collection:
                exports.kill(entry)

        _clean_up(repo, collection)
    finally:
        repo.close()

def _clean_up(repo, collection):
    xpath = '(/pdis:ad | /pdis:file)[repo = "%s" and collection = "%s"]'
    xpath = xpath % (repo.get_repo_id(), collection)
    for entry in repo.query(collection, xpath):
        repo.kill(collection, entry)
