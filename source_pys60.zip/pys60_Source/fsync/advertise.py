#
# pdis.fsync.advertise
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Maintenance of shared advertisement and file records

This code maintains two types of records in each file metadata
collection.  The first advertises the availability somewhere of
some content, the MD5 hash of which is the record's key:

    <pdis:ad pdis:key="...">
      <repo>...</repo>
      <collection>...</collection>
    </pdis:ad>

The second type of record is an assertion by some repository and
collection regarding the MD5 hash of the content that should be
stored at a particular file path:

    <pdis:file pdis:key="...">
      <md5>...</md5>
      <repo>...</repo>
      <collection>...</collection>
    </pdis:file>

The record's key is the file path relative to the exported root.
This is written with slash ('/') characters as the separator (with
no leading slash), independently of the local OS convention.

In order to enable the user to unexport a directory by simply deleting
its metadata collection, this code also removes directory records
that refer to nonexistent metadata collections from __exports__.
"""

import os
from Queue import Queue

from pdis.lib.logging import *
from pdis.lib.element import Element, addsubelement
from pdis.versioning.pdis_metadata import key_from_id
from pdis.versioning.et_metadata import get_id, get_key, qualify
from pdis.access.et_repo_access import RepoAccess, Fault
from pdis.fsync.file_utils import to_shared_path, to_local_path

class Advertiser:
    def __init__(self, address=("loopback",)):
        # Map export record IDs to live query handles.
        self.state = {}

        # Map collection names to export record IDs.  This is only
        # for making sure that each collection name appears in just
        # one export record.
        self.index = {}

        # Queue of (function, argument-list) pairs:
        self.queue = Queue()

        self.repo = RepoAccess(address, listener=self, agent=True,
                               client_name="file advertiser")
        self.repo_id = self.repo.get_repo_id()

        self.repo.create_collection("__files__")

        listener = _LiveQueryListener(self.queue, self.exports_updated, None)
        self.repo.create_live_query("__exports__", listener.update, "/directory")

    def close(self):
        self.queue.put((None, None))

    def loop(self):
        try:
            self._loop()
        except:
            log_exception("File advertising loop terminated by exception.")

        self.repo.close()

    def _loop(self):
        while True:
            f, args = self.queue.get()
            if f is None:
                break

            try:
                f(*args)
            except Fault, e:
                # E.g., file metadata collection has disappeared and
                # we haven't cleaned up yet.
                log_exception("Ignoring '%s' in file advertising loop." % e)

    #
    # Repo callbacks
    #

    def collection_removed(self, collection):
        self.queue.put((self._collection_removed, (collection,)))

    def _collection_removed(self, collection):
        if collection in self.index:
            id = self.index[collection]
            if id in self.state:
                item = self.repo.get("__exports__", id)
                if item is not None:
                    self.repo.kill("__exports__", item)

    #
    # __exports__ callbacks
    #

    def exports_updated(self, added, removed):
        for id in removed:
            self._export_removed(id)
        for item in added:
            self._export_added(item)

    def _export_added(self, item):
        id = get_id(item)
        collection = get_key(item)
        path = item.findtext("path")

        if collection in self.index:
            existing_id = self.index[collection]
            if existing_id in self.state:
                # Having more than one exports record for the same
                # collection is not allowed, and so we shouldn't
                # normally see this.  Such extra export records are
                # inconsistent with how we maintain shared file
                # records, so let's eliminate them when we see them.
                self.repo.kill("__exports__", item)
                return

        if not self.repo.collection_exists(collection):
            self.repo.kill("__exports__", item)
            return

        listener = _LiveQueryListener(
            self.queue, self.files_updated, self.files_synchronized,
            collection, path, {})

        xpath = '/file[starts-with(@pdis:key, "%s%s")]'
        xpath = xpath % (path, os.sep)
        self.state[id] = self.repo.create_live_query(
            "__files__", listener.update, xpath,
            ids_only=(False, False),
            most_recent_only=True)

        self.index[collection] = id

    def _export_removed(self, id):
        if id in self.state:
            self.state[id].terminate()
            del self.state[id]

    #
    # __files__ callbacks
    #

    def files_updated(self, added, removed, collection, root, counts):
        # We handle additions before removals so reference counts
        # don't transition through zero, and so modifications to
        # shared file records are handled properly.
        paths_updated = []
        for item in added:
            path = to_shared_path(get_key(item), root)
            hash = item.findtext("md5")

            counts[hash] = counts.get(hash, 0) + 1
            if counts[hash] == 1:
                self._add_advertisement(hash, collection)

            if item.findtext("collection") != collection:
                self._update_file_record(hash, path, collection)
                paths_updated.append(path)

        for item in removed:
            path = to_shared_path(get_key(item), root)
            hash = item.findtext("md5")

            assert counts[hash] > 0
            counts[hash] -= 1
            if counts[hash] == 0:
                self._remove_advertisement(hash, collection)

            if item.findtext("collection") != collection:
                if path not in paths_updated:
                    self._remove_file_record(path, collection)

    def files_synchronized(self, collection, root, counts):
        # Finish updating advertisements.
        xpath = '/pdis:ad[repo = "%s" and collection = "%s"]'
        xpath = xpath % (self.repo_id, collection)
        ids = self.repo.query(collection, xpath, ids_only=True)
        for hash in map(key_from_id, ids):
            if counts.get(hash, 0) == 0:
                self._remove_advertisement(hash, collection)

        # Finish updating shared file records.
        xpath = '/pdis:file[repo = "%s" and collection = "%s"]'
        xpath = xpath % (self.repo_id, collection)
        for id in self.repo.query(collection, xpath, ids_only=True):
            path = to_local_path(key_from_id(id), root)
            files_xpath = '/file[not(collection = "%s")]' % collection
            if not self.repo.query("__files__", files_xpath,
                                   key=path, ids_only=True):
                item = self.repo.get(collection, id)
                if item is not None:
                    self.repo.kill(collection, item)

    def _add_advertisement(self, hash, collection):
        if not self._get_advertisements(hash, collection):
            ad = Element(qualify("ad"))
            addsubelement(ad, "repo", self.repo_id)
            addsubelement(ad, "collection", collection)
            self.repo.create(collection, ad, key=hash)

    def _remove_advertisement(self, hash, collection):
        for ad in self._get_advertisements(hash, collection):
            self.repo.kill(collection, ad)

    def _get_advertisements(self, hash, collection):
        xpath = '/pdis:ad[repo = "%s" and collection = "%s"]'
        xpath = xpath % (self.repo_id, collection)
        return self.repo.query(collection, xpath, key=hash)

    def _update_file_record(self, hash, path, collection):
        existing = self._get_file_records(path, collection)
        if not existing:
            new = Element(qualify("file"))
            addsubelement(new, "md5", hash)
            addsubelement(new, "repo", self.repo_id)
            addsubelement(new, "collection", collection)
            self.repo.create(collection, new, key=path)
        else:
            for old in existing:
                if old.findtext("md5") != hash:
                    old.find("md5").text = hash
                    self.repo.modify(collection, old)

    def _remove_file_record(self, path, collection):
        for old in self._get_file_records(path, collection):
            self.repo.kill(collection, old)

    def _get_file_records(self, path, collection):
        xpath = '/pdis:file[repo = "%s" and collection = "%s"]'
        xpath = xpath % (self.repo_id, collection)
        return self.repo.query(collection, xpath, key=path)

class _LiveQueryListener:
    def __init__(self, queue, update_callback, sync_callback, *extra):
        self.queue = queue
        self.update_callback = update_callback
        self.sync_callback = sync_callback
        self.extra = extra
        self._in_sync = False

    def update(self, added, removed, in_sync):
        if added or removed:
            if self.update_callback:
                self._put(self.update_callback, added, removed, *self.extra)

        if in_sync and not self._in_sync:
            self._in_sync = True
            if self.sync_callback:
                self._put(self.sync_callback, *self.extra)

    def _put(self, fun, *args):
        self.queue.put((fun, args))

if __name__ == "__main__":
    init_logging(EchoLogger())
    advertiser = Advertiser(("tcp", "localhost", 35800))
    advertiser.loop()
