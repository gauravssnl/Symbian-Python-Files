#
# pdis.access.file_access
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Client library for PDIS file access

This API augments the one provided in pdis.access.et_repo_access with
fetching of advertised files from neighboring repositories.
"""

from pdis.access import et_repo_access

class RepoAccess(et_repo_access.RepoAccess):
    def get_advertised_file(self, collection, file_id):
        ads = [(ad.findtext("repo"), ad.findtext("collection"))
               for ad in self.query(collection, "/pdis:ad", key=file_id)]
        for peer in self.get_collection_peers(collection):
            if peer in ads:
                data = self.get_remote_file(peer[0], peer[1], file_id)
                if data is not None:
                    return data
        return None

    def get_collection_peers(self, collection):
        myself = self.get_repo_id()
        results = []
        for info in self.list_dialogs({"local collection": collection}):
            peer = (info["repo id"], info["remote collection"])
            if peer not in results:
                results.append(peer)
        results.sort()
        return ([(myself, collection)]
                + [x for x in results if x[0] == myself and x[1] != collection]
                + [x for x in results if x[0] != myself])
