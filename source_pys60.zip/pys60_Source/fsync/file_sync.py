#
# pdis.fsync.file_sync
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
File synchronization

This code attempts to create local replicas of files mentioned in file
metadata records wherever no local original is present.  It adds
entries mentioning the metadata collection to __files__.
"""

import os
import time
from Queue import Queue, Empty

from pdis.lib import logging
from pdis.lib.best_threading import start_thread
from pdis.lib.element import Element, addsubelement
from pdis.versioning.pdis_metadata import key_from_id
from pdis.versioning.et_metadata import get_key
from pdis.fsync.file_utils import to_local_path, get_size_and_mtime, file_touched
from pdis.fsync.file_access import RepoAccess, RepoListener

retry_interval = 10
request_timeout = 60

class FileSync:
    def __init__(self, address = ("loopback",)):
        # Map metadata collection names to live queries.
        self.live_queries = {}

        # Map metadata collection names to maps from local paths to hashes.
        self.wanted = {}

        # Queues of (function, argument-list) pairs:
        self.queue = Queue()
        self.idle_queue = Queue()
        self.retry_queue = Queue()

        # Timestamps used for pacing:
        self.outstanding = 0    # Time last outstanding request was sent.
        self.last_retry = 0     # Time of last retry.

        self.repo = RepoAccess(address, agent = True,
                               client_name = "file sync",
                               listener = RepoListener(self.receive_data))

        self.repo.create_collection("__files__")

        listener = _LiveQueryListener(self.queue, self.exports_updated, None)
        self.repo.create_live_query(
            "__exports__", listener.update, "/directory",
            most_recent_only=True)

    def timer_loop(self):
        while True:
            time.sleep(retry_interval)
            nop = lambda: None
            self.queue.put((nop, ()))

    def loop(self):
        block = True
        while True:
            while True:
                try:
                    fun, args = self.queue.get(block)
                except Empty:
                    break

                try:
                    fun(*args)
                except:
                    logging.log_exception("Ignoring exception in file sync loop.")

                block = False

            try:
                block = not self.idle()
            except:
                block = True
                logging.log_exception("Ignoring exception in file sync idle task.")

    def idle(self):
        outstanding = self.outstanding
        if outstanding:
            elapsed = time.time() - outstanding
            if elapsed < request_timeout:
                return False

        try:
            fun, args = self.idle_queue.get_nowait()
        except Empty:
            return self.idle_retry()

        fun(*args)
        return True

    def idle_retry(self):
        last_retry = self.last_retry
        if last_retry:
            elapsed = time.time() - last_retry
            if elapsed < retry_interval - 0.1:
                return False

        more = self._idle_retry()
        if not more:
            self.last_retry = time.time()
        return more

    def _idle_retry(self):
        if self.retry_queue.empty():
            self.refill_retry_queue()
            return False

        try:
            fun, args = self.retry_queue.get_nowait()
        except Empty:
            return False

        fun(*args)
        return not self.outstanding

    #
    # __exports__ live query callback
    #

    def exports_updated(self, added, removed):
        for id in removed:
            self.export_removed(key_from_id(id))
        for item in added:
            self.export_added(get_key(item), item.findtext("path"))

    def export_added(self, collection, path):
        logging.logwrite("Collection %s: %s" % (collection, path))
        self.repo.create_collection(collection)
        self.wanted[collection] = {}
        listener = _LiveQueryListener(self.queue,
                                      self.metadata_updated,
                                      self.metadata_synchronized,
                                      collection, path)
        self.live_queries[collection] = self.repo.create_live_query(
            collection, listener.update, '/pdis:file',
            ids_only=(False, False),
            most_recent_only=True)

    def export_removed(self, collection):
        self.live_queries[collection].terminate()
        del self.live_queries[collection]
        del self.wanted[collection]

    #
    # Metadata live query callbacks
    #

    def metadata_updated(self, added, removed, collection, root):
        if collection not in self.wanted:
            return
        wanted = self.wanted[collection]

        paths_updated = []
        for item in added:
            path = to_local_path(get_key(item), root)
            hash = item.findtext("md5")
            wanted[path] = hash
            paths_updated.append(path)
            self.idle_queue.put((self.maybe_add_file, (hash, path, collection)))

        for item in removed:
            path = to_local_path(get_key(item), root)
            if path not in paths_updated:
                hash = item.findtext("md5")
                del wanted[path]
                xpath = '/file[md5 = "%s" and collection = "%s"]'
                xpath = xpath % (hash, collection)
                existing = self.repo.query("__files__", xpath, key=path)
                for files_entry in existing:
                    self.remove_file(files_entry)

    def metadata_synchronized(self, collection, root):
        self.idle_queue.put((self._metadata_synchronized, (collection, root)))

    def _metadata_synchronized(self, collection, root):
        logging.logwrite("Synchronized: %s" % collection)
        if collection not in self.wanted:
            return
        wanted = self.wanted[collection]
        xpath = '/file[collection = "%s"]' % collection
        for files_entry in self.repo.query("__files__", xpath):
            if get_key(files_entry) not in wanted:
                self.remove_file(files_entry)

    #
    # Other callbacks
    #

    def refill_retry_queue(self):
        count = 0
        for collection, wanted in self.wanted.items():
            for path, hash in wanted.items():
                if hash:
                    count += 1
                    self.retry_queue.put((self.maybe_add_file,
                                          (hash, path, collection)))
        if count:
            logging.logwrite("Refilled retry queue with %s entries." % count)

    def maybe_add_file(self, hash, path, collection):
        if collection not in self.wanted:
            return
        wanted = self.wanted[collection]
        status = self.check_file(hash, path, collection)
        if status == "present":
            wanted[path] = None
        elif status == "needed" and can_overwrite(path):
            if self.repo.async_get_file(collection, hash, path):
                self.outstanding = time.time()

    def receive_data(self, hash, path, data = None):
        self.queue.put((self._receive_data, (hash, path, data)))

    def _receive_data(self, hash, path, data):
        self.outstanding = 0
        if data is None:
            logging.logwrite("File not available: %s" % path)
        else:
            for collection, wanted in self.wanted.items():
                for path, wanted_hash in wanted.items():
                    if wanted_hash == hash:
                        status = self.check_file(hash, path, collection)
                        if status == "present":
                            wanted[path] = None
                        elif status == "needed":
                            if self.add_file(hash, path, collection, data):
                                wanted[path] = None

    #
    # File manipulations
    #

    def remove_file(self, files_entry):
        if file_touched(files_entry):
            return

        path = get_key(files_entry)
        try:
            os.remove(path)
        except OSError:
            logging.logwrite("Could not remove: %s" % path)
            return

        logging.logwrite("Removed: %s" % path)
        self.repo.kill("__files__", files_entry)

    def add_file(self, hash, path, collection, data):
        tmp_path = os.path.join(os.path.dirname(path), "." + hash)
        try:
            if not write_file(tmp_path, data):
                return False

            while not self.repo.acquire(path):
                logging.logwrite("File sync waiting for lock: %s" % path)
                time.sleep(0.2)
            try:
                status, existing = self.check_file2(hash, path, collection)
                if status != "needed":
                    return status == "present"

                if not rename_file(tmp_path, path, tmp_path + "~"):
                    return False

                logging.logwrite("Wrote: %s" % path)

                size, mtime = get_size_and_mtime(path)
                if not existing:
                    entry = Element("file")
                    addsubelement(entry, "md5", hash)
                    addsubelement(entry, "size", str(size))
                    addsubelement(entry, "mtime", str(mtime))
                    addsubelement(entry, "collection", collection)
                    self.repo.create("__files__", entry, key=path)
                else:
                    for entry in existing:
                        entry.find("md5").text = hash
                        entry.find("size").text = str(size)
                        entry.find("mtime").text = str(mtime)
                        assert entry.findtext("collection") == collection
                        self.repo.modify("__files__", entry)

                return True
            finally:
                self.repo.release(path)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def check_file(self, hash, path, collection):
        """
        Return "present", "blocked", or "needed".
        """
        status, existing = self.check_file2(hash, path, collection)
        return status

    def check_file2(self, hash, path, collection):
        existing = self.repo.query("__files__", "/file", key=path)
        for item in existing:
            if item.findtext("md5") == hash:
                return "present", existing
        if not existing and os.path.exists(path):
            return "blocked", existing
        for item in existing:
            if item.findtext("collection") != collection or file_touched(item):
                return "blocked", existing
        return "needed", existing

def can_overwrite(path):
    if os.path.exists(path):
        if not os.path.isfile(path) or not os.access(path, os.W_OK):
            return False
    return can_create(path)

def can_create(path):
    dir, base = os.path.split(path)
    if os.path.exists(dir):
        return os.path.isdir(dir) \
               and os.access(dir, os.R_OK | os.W_OK | os.X_OK)
    else:
        return base and can_create(dir)

def write_file(path, data):
    dir = os.path.dirname(path)
    try:
        if not os.path.isdir(dir):
            os.makedirs(dir)
    except OSError:
        logging.logwrite("Could not create directory: %s" % dir)
        return False

    try:
        f = file(path, "w")
        try:
            f.write(data)
        finally:
            f.close()
    except IOError:
        logging.logwrite("Could not write file: %s" % path)
        return False

    return True

def rename_file(src, dst, tmp):
    try:
        os.rename(src, dst)
    except OSError:
        try:
            os.rename(dst, tmp)
            try:
                os.rename(src, dst)
            finally:
                os.remove(tmp)
        except OSError:
            logging.logwrite("Could not replace file: %s" % dst)
            return False
    return True

class _LiveQueryListener:
    def __init__(self, queue, update_callback, sync_callback, *extra):
        self.queue = queue
        self.update_callback = update_callback
        self.sync_callback = sync_callback
        self.extra = extra
        self._in_sync = False

    def update(self, added, removed, in_sync):
        if added or removed:
            if self.update_callback:
                self._put(self.update_callback, added, removed, *self.extra)

        if in_sync and not self._in_sync:
            self._in_sync = True
            if self.sync_callback:
                self._put(self.sync_callback, *self.extra)

    def _put(self, fun, *args):
        self.queue.put((fun, args))

if __name__ == "__main__":
    from pdis.lib.best_threading import start_thread
    logging.init_logging(logging.EchoLogger())
    synchronizer = FileSync()
    start_thread(synchronizer.loop)
    synchronizer.timer_loop()
