#
# pdis.fsync.file_utils
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
File utility functions
"""

import os
import md5

from pdis.versioning.et_metadata import get_key

def to_shared_path(path, root):
    """
    Relativize path and convert from OS-specific separators to slashes.

    The root must also be specified in local format.
    """
    result = []
    while path != root:
        path, tail = os.path.split(path)
        if not tail:
            raise ValueError, "Path not under root."
        result.append(tail)
    result.reverse()
    return "/".join(result)

def to_local_path(path, root):
    """
    Absolutize path and convert from slashes to OS-specific separators.

    The root may be specified in either format.

    Raises ValueError if the result would not be under the specified
    root (because the specified path is absolute or uses "..").
    """
    root = os.path.abspath(root)
    path = os.path.abspath(os.path.join(root, path))
    if not is_prefix(root, path):
        raise ValueError, "Result path not under root."
    return path

def optimize_root_set(roots):
    """
    Eliminate redundant paths from the given set.

    A path is redundant if the subtree that it defines is included in
    the subtree defined by one of the other paths.
    """
    results = []
    for candidate in roots:
        for result in list(results):
            if is_prefix(result, candidate):
                break
            elif is_prefix(candidate, result):
                results.remove(result)
        else:
            results.append(candidate)
    return results

def is_prefix(root, path):
    """
    Test if the subtree defined by the first path includes the second.
    """
    if not path.startswith(root):
        return False      # This first test is purely an optimization.

    while path != root:
        path, tail = os.path.split(path)
        if not tail:
            return False
    return True

def get_size_and_mtime(path):
    """
    Return the file's size and its last-modified time.
    """
    result = os.stat(path)
    return result.st_size, result.st_mtime

def get_size_and_hash(path):
    """
    Return the file's size and the MD5 hash of its contents.

    The hash is returned as a hex digest string.
    """
    f = file(path)
    try:
        size = 0
        hash = md5.new()
        while True:
            chunk = f.read(8 * 1024)
            if not chunk:
                return size, hash.hexdigest()
            size += len(chunk)
            hash.update(chunk)
    finally:
        f.close()

def file_touched(files_entry):
    """
    Return True if a stat of the file gives changed results.

    The argument must be an entry from the __files__ collection.
    """
    return _file_touched(get_key(files_entry),
                         files_entry.findtext("size"),
                         files_entry.findtext("mtime"))

def _file_touched(path, saved_size, saved_mtime):
    try:
        size, mtime = get_size_and_mtime(path)
    except OSError:
        return True
    return str(size) != saved_size or str(mtime) != saved_mtime

def write_file(path, data):
    dir = os.path.dirname(path)
    try:
        if not os.path.isdir(dir):
            os.makedirs(dir)
    except OSError:
        return False

    try:
        f = file(path, "wb")
        try:
            f.write(data)
        finally:
            f.close()
    except IOError:
        return False

    return True

def rename_file(src, dst, tmp):
    try:
        os.rename(src, dst)
    except OSError:
        try:
            os.rename(dst, tmp)
            try:
                os.rename(src, dst)
            finally:
                os.remove(tmp)
        except OSError:
            return False
    return True

if __name__ == '__main__':
    import time

    if os.name == "e32":
        drive = "c:"
        filename = "c:\\test.tmp"
        filename2 = "c:\\test.tmp"
    else:
        from tempfile import mktemp
        drive = ""
        filename = mktemp()
        filename2 = mktemp()

    a0 = os.path.normpath(os.path.join(drive, "/"))
    a1 = os.path.normpath(os.path.join(drive, "/foo"))
    a2 = os.path.normpath(os.path.join(drive, "/foo/bar"))

    # Test to_shared_path().
    assert to_shared_path(a2, a0) == "foo/bar"
    assert to_shared_path(a2, a1) == "bar"
    assert to_shared_path(a2, a2) == ""
    assert to_shared_path(a1, a0) == "foo"
    assert to_shared_path(a1, a1) == ""
    assert to_shared_path(a0, a0) == ""

    try:
        to_shared_path(a1, a2)
    except ValueError:
        pass
    else:
        assert False

    # Test to_local_path().
    assert to_local_path("bar", a1) == a2
    assert to_local_path(".", a1) == a1
    assert to_local_path("", a1) == a1
    assert to_local_path("foo/bar", a0) == a2
    assert to_local_path("foo", a0) == a1
    assert to_local_path(".", a0) == a0
    assert to_local_path("", a0) == a0

    try:
        to_local_path("..", a1)
    except ValueError:
        pass
    else:
        assert False

    try:
        to_local_path("/", a1)
    except ValueError:
        pass
    else:
        assert False

    # Test optimize_root_set().
    for input, output in [
        ([], []),
        (["a"], ["a"]),
        (["a", "a"], ["a"]),
        (["a", "a", "a"], ["a"]),
        (["a", "b"], ["a", "b"]),
        (["a", "a", "b", "b"], ["a", "b"]),
        (["a", "b", "a", "b", "a", "b"], ["a", "b"]),
        (["a/x", "a/y", "a/z"], ["a/x", "a/y", "a/z"]),
        (["a/x", "a/y", "a/z", "a"], ["a"]),
        (["a", "a/x", "a/y", "a/z"], ["a"]),
        (["a", "a/b", "a/b/c", "a/b/c/d"], ["a"]),
        (["a/b/c/d", "a/b/c", "a/b", "a"], ["a"]),
        ]:
        assert optimize_root_set(input) == output

    # Test is_prefix().
    assert is_prefix(a0, a0)
    assert is_prefix(a0, a1)
    assert is_prefix(a0, a2)

    assert not is_prefix(a1, a0)
    assert is_prefix(a1, a1)
    assert is_prefix(a1, a2)

    assert not is_prefix(a2, a0)
    assert not is_prefix(a2, a1)
    assert is_prefix(a2, a2)

    # Test get_size_and_mtime().
    n = 0
    times = []
    while len(times) < 3:
        f = file(filename, "wb")
        f.write("x" * n)
        f.close()

        size, mtime = get_size_and_mtime(filename)
        assert size == n
        n += 1

        if not times or mtime != times[-1]:
            times.append(mtime)
    dt = times[2] - times[1]
    print "Ticks per second =", 1.0 / dt

    # Test get_size_and_hash().
    for n, expected in [(0, "d41d8cd98f00b204e9800998ecf8427e"),
                        (1, "9dd4e461268c8034f5c8564e155c67a6"),
                        (1001, "6a202626c2096e9cc2d75a0082a6536f"),
                        (123456, "b5b79a8efe770de02cb42403ab662d09")]:
        f = file(filename, "wb")
        f.write("x" * n)
        f.close()

        t0 = time.clock()

        size, hash = get_size_and_hash(filename)
        assert size == n
        assert hash == expected

        t1 = time.clock()

    if t1 > t0:
        print "Bytes per second =", n / float(t1 - t0)

    # Test [_]file_touched().
    size, mtime = get_size_and_mtime(filename)
    assert not _file_touched(filename, str(size), str(mtime))
    file(filename, "wb").close()
    assert _file_touched(filename, str(size), str(mtime))

    size, mtime = get_size_and_mtime(filename)
    assert not _file_touched(filename, str(size), str(mtime))
    os.remove(filename)                 # Clean up while we're at it.
    assert _file_touched(filename, str(size), str(mtime))

    # Test write_file().
    def read_file(path):
        f = file(path)
        try:
            return f.read()
        finally:
            f.close()

    assert write_file(filename, "apple")
    assert read_file(filename) == "apple"
    os.remove(filename)

    dir = filename
    path = os.path.join(dir, "foo")
    assert write_file(path, "orange")
    assert read_file(path) == "orange"
    os.remove(path)
    os.rmdir(dir)

    os.mkdir(filename)
    assert not write_file(filename, "fig")
    os.rmdir(filename)

    # Test rename_file().
    path = filename
    tmp_path = filename2

    assert write_file(path, "old")
    assert write_file(tmp_path, "new")
    assert rename_file(tmp_path, path, tmp_path + "~")
    assert read_file(path) == "new"

    assert write_file(tmp_path, "newer")
    assert rename_file(tmp_path, path, tmp_path + "~")
    assert read_file(path) == "newer"

    os.remove(path)
    assert not os.path.exists(tmp_path)
    assert not os.path.exists(tmp_path + "~")

    print "All tests passed."
