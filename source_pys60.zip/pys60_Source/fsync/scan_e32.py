#
# pdis.fsync.scan_e32
#
# Copyright 2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Monitor the file system and scan for changes (Symbian OS).
"""

from AOQueue import AOQueue
from miso import FsNotifyChange
from pdis.lib.logging import *
from pdis.fsync.scan import Scanner

class _Autoscanner:
    def __init__(self, address=("loopback",), destination="__files__"):
        self.scanner = Scanner(address, destination,
                               root_set_changed_callback=self.roots_changed)
        self.active = {}        # Map path to (count, FsNotifyChange).
        self.queue = AOQueue()

    def close(self):
        self._put(None)

    def monitor(self, path):
        self._put(self._monitor, path)

    def cancel(self, path):
        self._put(self._cancel, path)

    def _put(self, f, *args):
        self.queue.put((f, args))

    def loop(self):
        try:
            while True:
                f, args = self.queue.get()
                if f is None:
                    break
                f(*args)
        except:
            log_exception("File system change monitor terminated by exception.")

        self.scanner.close()

    def _monitor(self, path):
        if path in self.active:
            i, fs = self.active[path]
            self.active[path] = i + 1, fs
        else:
            fs = FsNotifyChange()
            self.active[path] = 1, fs
            self._scan(path)

    def _cancel(self, path):
        i, fs = self.active[path]
        if i > 1:
            self.active[path] = i - 1, fs
        else:
            fs.close()
            del self.active[path]

    def callback(self, path, error):
        self._put(self._callback, path, error)

    def _callback(self, path, error):
        if error:
            logwrite("Error %s: %s" % (error, path))
        else:
            logwrite("Changed: %s" % path)
            self._scan(path)

    def _scan(self, path):
        def callback(error):
            self.callback(path, error)

        if path in self.active:
            i, fs = self.active[path]
            fs.notify_change(1, callback, unicode(path))
            self.scanner.scan([path])

    def roots_changed(self):
        pass

class Autoscanner(_Autoscanner):
    def __init__(self, address=("loopback",), destination="__files__"):
        self.roots = []
        _Autoscanner.__init__(self, address, destination)

    def roots_changed(self):
        old = self.roots
        new = self.scanner.get_roots()

        logwrite("Updating autoscanner root set: %s" % new)
        self.roots = new

        for path in old:
            if path not in new:
                self.cancel(path)

        for path in new:
            if path not in old:
                self.monitor(path)

if __name__ == '__main__':
    import e32
    from pdis.fsync.export import export_file_tree

    init_logging(FileLogger("scan.txt"))

    export_file_tree("E:\\Images", "images/")

    print "Starting autoscanner..."
    e32.ao_yield()

    monitor = Autoscanner(address=("tcp", "localhost", 35800),
                          destination="files")
    monitor.loop()
