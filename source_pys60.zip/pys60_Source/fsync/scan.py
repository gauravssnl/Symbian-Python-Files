#
# pdis.fsync.scan
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#          Pekka Kanerva <Pekka.Kanerva@hiit.FI>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Walk file system to discover new, changed, and deleted files.

For each file, this code maintains a record of the following
form in the local collection named __files__.

    <file pdis:key="...">
      <md5>...</md5>
      <size>...</size>
      <mtime>...</mtime>
      <collection>...</collection>
    </file>

The key is the absolute file path in os-native format.  It may
be unicode.

The last modified time is the number of seconds since the epoch,
possibly in floating point.

If a collection property is present, its value is the name of
a local collection into which the file has been copied from
elsewhere.  If it is absent, the present file contents were
discovered locally while scanning.
"""

# The following comments are from some time ago and presumably predate
# the crude purge functionality.

# XXX Only create records for exported paths.
# XXX Remove unexported records.

import os
import time

from pdis.lib.logging import logwrite
from pdis.lib.element import Element, addsubelement
from pdis.versioning.et_metadata import get_key
from pdis.access.et_repo_access import RepoAccess
from pdis.access.collection_monitor import CollectionMonitor
from pdis.fsync.file_utils import optimize_root_set, \
     get_size_and_mtime, get_size_and_hash, file_touched

def decode(path):
    if isinstance(path, str):
        path = path.decode("utf-8")
    return path

class Scanner:
    def __init__(self, address=("loopback",), destination="__files__",
                 root_set_changed_callback=None):
        """
        Connect a Scanner instance to a repository.
        """
        self.root_set_changed_callback = root_set_changed_callback
        self.repo = RepoAccess(address, agent=True,
                               client_name="file scanner")
        self.db = self.repo.open_collection(destination,
                                            only_if_exists=False)
        self.exports_monitor = CollectionMonitor(
            self.repo, "__exports__", "/directory",
            callback=self._exports_changed)

    def close(self):
        """
        Disconnect a Scanner instance.
        """
        self.repo.close()

    def loop(self):
        """
        Periodically scan all exported roots.
        """
        self.scan(interval=10)

    def scan(self, paths=None, purge=False, verify=False, interval=None):
        """
        Scan a number of directory trees and files.

        If no path list is specified, all exported roots are scanned.
        """
        while True:
            t0 = time.time()

            if paths is not None:
                roots = paths
            else:
                roots = self.get_roots()

            for path in roots:
                if os.path.isdir(path):
                    self.scan_directory(path, verify=verify)
                elif os.path.isfile(path):
                    self.scan_file(path)
                else:
                    logwrite("No such file or directory: %s" % path)

            if purge:
                roots = self.get_roots()
                self.purge(roots)

            t1 = time.time()
            #print "Scan time:", t1 - t0

            if interval is None:
                break
            else:
                time.sleep(interval)

    def scan_directory(self, root, verify=False):
        """
        Walk a directory tree and update records in __files__.
        """
        root = decode(os.path.abspath(root))
        if not os.path.isdir(root):
            logwrite("No such directory: %s" % root)
            return

        index = {}
        xpath = '/file[starts-with(@pdis:key, "%s%s")]' % (root, os.sep)
        for entry in self.db.query(xpath):
            path = get_key(entry)
            if path not in index:
                index[path] = entry
            else:
                # This is abnormal, but fixable.
                self.db.kill(entry)

        os.path.walk(root, self._visit_directory, (index, verify))

        if index:
            logwrite("Removing %s entries." % len(index))
            for entry in index.values():
                self.db.kill(entry)

    def _visit_directory(self, data, dir, names):
        exceptions = [name for name in names if name.startswith(".")]
        for name in exceptions:
            names.remove(name)
        for name in names:
            name = decode(name)
            path = os.path.join(dir, name)
            if os.path.isfile(path):
                self._visit_file(data, path)

    def _visit_file(self, (index, verify), path):
        if path in index:
            entry = index[path]
            del index[path]
            if not verify and not file_touched(entry):
                return
        self.scan_file(path)

    def scan_file(self, path):
        """
        Update a record in __files__.
        """
        path = decode(os.path.abspath(path))
        while not self.repo.acquire(path):
            logwrite("Scanner waiting for lock:" % path)
            time.sleep(0.2)
        try:
            self._scan_file(path)
        finally:
            self.repo.release(path)

    def _scan_file(self, path):
        entries = self.db.query("/file", key=path)
        try:
            size, mtime = get_size_and_mtime(path)
            size, hash = get_size_and_hash(path)
        except (OSError, IOError):
            return

        if not entries:
            logwrite("Added: %s" % path)
            entry = Element("file")
            addsubelement(entry, "md5", hash)
            addsubelement(entry, "size", str(size))
            addsubelement(entry, "mtime", str(mtime))
            self.db.create(entry, key=path)
        else:
            for entry in entries:
                touched = (entry.findtext("mtime") != str(mtime))
                changed = (entry.findtext("md5") != hash)
                if touched or changed:
                    entry.find("md5").text = hash
                    entry.find("size").text = str(size)
                    entry.find("mtime").text = str(mtime)
                    if changed:
                        logwrite("Modified: %s" % path)
                        for child in entry.findall("collection"):
                            entry.remove(child)
                    else:
                        logwrite("Touched: %s" % path)
                    self.db.modify(entry)

    def purge(self, roots):
        if not roots:
            xpath = "/file"
        else:
            test = " or ".join([
                'starts-with(@pdis:key, "%s%s")' % (root, os.sep)
                for root in roots])
            xpath = "/file[not(%s)]" % test
        entries = self.db.query(xpath)
        if entries:
            logwrite("Purging %s entries." % len(entries))
            for entry in entries:
                self.db.kill(entry)

    def get_roots(self):
        roots = [export.findtext("path")
                 for export in self.exports_monitor.query()]
        return optimize_root_set(roots)

    def _exports_changed(self):
        if self.root_set_changed_callback is not None:
            self.root_set_changed_callback()

if __name__ == '__main__':
    import sys
    from pdis.lib.logging import *

    class Logger(FileLogger):
        def write(self, *args, **keys):
            FileLogger.write(self, *args, **keys)
            if os.name == "e32":
                import e32
                e32.ao_yield()

    init_logging(Logger("scan.txt", echo=True))

    if os.name == "e32":
        roots = ["C:\\Images", "E:\\Images"]
    else:
        roots = sys.argv[1:]

    scanner = Scanner(address=("tcp", "localhost", 35800),
                      destination="files")
    try:
        t0 = time.time()
        scanner.scan(roots)
        t1 = time.time()

        logwrite("Total time = %.1f" % (t1 - t0))
    finally:
        scanner.close()
