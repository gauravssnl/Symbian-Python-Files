#
# pdis.access.file_access
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Client library for PDIS file access

This API augments the one provided in pdis.access.et_repo_access
to support fetching of files from neighboring repositories.
"""

from pdis.lib import logging
from pdis.access import et_repo_access

class RepoListener:
    def __init__(self, file_handler):
        self.file_handler = file_handler

    def dispatch_remote_response(self, method, success, result,
                                 params, client_data, *attachments):
        if success:
            name = method + "_response"
            if hasattr(self, name):
                getattr(self, name)(result, params, client_data, *attachments)
        else:
            code, message = result
            logging.logwrite("Remote method %s returned fault %s: %s"
                             % (method, code, message))

    def get_file_response(self, success, params, client_data, data = None):
        assert success and data is not None or not success and data is None
        hash = params[1]
        self.file_handler(hash, client_data, data)

class RepoAccess(et_repo_access.RepoAccess):
    def async_get_file(self, collection, file_id, client_data):
        myself = self.get_repo_id()
        ads = [(ad.findtext("repo"), ad.findtext("collection"))
               for ad in self.query_object(collection, file_id, "/pdis:ad")]
        for peer in self.get_collection_peers(collection):
            if peer in ads:
                remote_repo, remote_collection = peer
                if remote_repo == myself:
                    source_route = ()
                else:
                    source_route = (remote_repo,)

                self.send_remote_request(
                    "get_file", (remote_collection, file_id),
                    client_data, source_route)
                return True

        return False

    def get_collection_peers(self, collection):
        myself = self.get_repo_id()
        results = []
        for info in self.call("list_dialogs"):
            if info["local collection"] == collection:
                peer = (info["repo id"], info["remote collection"])
                if peer not in results:
                    results.append(peer)
        results.sort()
        return [(myself, collection)] \
               + [x for x in results if x[0] == myself and x[1] != collection] \
               + [x for x in results if x[0] != myself]
