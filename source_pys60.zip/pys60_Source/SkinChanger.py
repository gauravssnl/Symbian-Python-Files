import appuifw,e32,os,lite_fm,appswitch,keycapture,graphics
from key_codes import *

app_lock=e32.Ao_lock()

def ru(x):return x.decode('utf-8')
def exit():
 app_lock.signal()
 appuifw.app.set_exit()

round=appuifw.Text()
appuifw.app.screen='normal'
round.set(ru('              by G.F.Ferre'))
appuifw.app.body=round

if os.path.exists('e:\\system\\apps\\SkinChanger\\SkinChanger.app'):
 FilePath='e:\\others\\SkinChanger\\pmp3_skins'
 stFile='e:\\others\\SkinChanger\\st_skins'
else:
 FilePath='c:\\others\\SkinChanger\\pmp3_skins'
 stFile='c:\\others\\SkinChanger\\st_skins'
if os.path.exists('e:\\system\\apps\\PowerMP3\\PowerMP3.app'):
 SkinPath='e:\\system\\libs\\plugins\\10207882.mbm'
 PmPath='e:\\System\\Apps\\PowerMP3\\PowerMP3.app'
else:
 SkinPath='c:\\system\\libs\\plugins\\10207882.mbm'
 PmPath='c:\\System\\Apps\\PowerMP3\\PowerMP3.app'
if os.path.exists('e:\\system\\apps\\stICQ\\stICQ.app'):
 stPath='e:\\system\\apps\\stICQ\\images.mbm'
 stStart='e:\\system\\apps\\stICQ\\stICQ.app'
else:
 stPath='c:\\system\\apps\\stICQ\\images.mbm'
 stStart='c:\\system\\apps\\stICQ\\stICQ.app'
def startmp3():
 e32.start_exe('Z:\System\Programs\AppRun.exe',PmPath)
def selectskin():
 appuifw.note(ru('Выберите скин'))
 file=lite_fm.manager(FilePath,ext='.mbm')
 if file==None:
  appuifw.note(ru('Скин не выбран'),'error')
 if file!=None:
  e32.file_copy(SkinPath,ru(file))
  appswitch.end_app(u'PowerMP3') or appswitch.end_app(u'Winamp')
  e32.start_exe('Z:\System\Programs\AppRun.exe',PmPath)
  e32.ao_sleep(1)
 if (appswitch.application_list(1)[0]==u'Winamp') or (appswitch.application_list(1)[0]==u'PowerMP3'):
  appuifw.note(ru('Скин сменен'),'conf',1)
def hotkey(a):
 if (appswitch.application_list(1)[0]==u'Winamp') or (appswitch.application_list(1)[0]==u'PowerMP3'):
  appuifw.note(ru('Выберите скин'),'info',1)
  appswitch.switch_to_fg(u'SkinChanger')
  filehot=lite_fm.manager(FilePath,ext='.mbm')
  if filehot==None:
   appuifw.note(ru('Скин не выбран'),'error')
  if filehot!=None:
   e32.file_copy(SkinPath,ru(filehot))
   appswitch.end_app(u'PowerMP3') or appswitch.end_app(u'Winamp')
   e32.start_exe('Z:\System\Programs\AppRun.exe',PmPath)
   e32.ao_sleep(1.1)
  if (appswitch.application_list(1)[0]==u'Winamp') or (appswitch.application_list(1)[0]==u'PowerMP3'):
   appuifw.note(ru('Скин сменен'),'conf',1)
a=keycapture.KeyCapturer(hotkey)
a.keys=0xf80b,0xf80b
a.forwarding = 1
a.start()
def help():
 appuifw.app.title=ru('Помощь')
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('SkinChanger by G.F.Ferre\n\nПрограмма для быстрой смены скинов плейера PowerMP3 или icq-клиента stICQ.Все скины(а точнее файлы mbm-формата от скина), помещать в папку е(c):/others/SkinChanger/pmp3_skins(для плеера) и е(c):/others/SkinChanger/st_skins(для стАСИ).\n\nСкин может иметь абсолютно любое имя, удобное для Вас, как на русском так и на английском языке.\n\nУправление:после запуска программы выберите нужный пункт из меню.При запуске, автоматически будет активирована горячая клавиша - "карандаш", если нажать ее, находясь в плейере, запустится функция смены скина(если конечно SkinChanger у Вас запущен).\n\nПосле запуска функции смены скина, выберите нужный Вам из списка, дальше программа все сделает сама.\n\n    special for DimonVideo.ru'))
 txt.set_pos(0)
 txt.set_pos(180)
 appuifw.app.menu=[(ru('Назад'),backmenu)]
def backmenu():
 appuifw.app.title=ru('SkinChanger')
 round.set(ru('              by G.F.Ferre'))
 appuifw.app.body=round
 appuifw.app.menu=[(ru('Сменить скин'),((ru('Сменить в PowerMP3'),selectskin),(ru('Сменить в stICQ'),stSetSkin))),(ru('Запустить'),((ru('Запустить PowerMP3'),startmp3),(ru('Запустить stICQ'),stICQstart))),(ru('Помощь'),help),(ru('Выход'),exit)]
###########
def stICQstart():
 e32.start_exe('z:\\system\\programs\\AppRun.exe',stStart)
def stSetSkin():
 appuifw.note(ru('Выберите скин'))
 file=lite_fm.manager(stFile,ext='.mbm')
 if file==None:
  appuifw.note(ru('Скин не выбран'),'error')
 if file!=None:
  e32.file_copy(stPath,ru(file))
  appswitch.end_app(u'stICQ') or appswitch.end_app(u'ICQmobile')
  e32.start_exe('z:\\system\\programs\\AppRun.exe',stStart)
  e32.ao_sleep(1)
 if (appswitch.application_list(1)[0]==u'stICQ') or (appswitch.application_list(1)[0]==u'ICQmobile'):
  appuifw.note(ru('Скин сменен'),'conf',1)
##########
appuifw.app.menu=[(ru('Сменить скин'),((ru('Сменить в PowerMP3'),selectskin),(ru('Сменить в stICQ'),stSetSkin))),(ru('Запустить'),((ru('Запустить PowerMP3'),startmp3),(ru('Запустить stICQ'),stICQstart))),(ru('Помощь'),help),(ru('Выход'),exit)]

appuifw.app.exit_key_handler=exit
app_lock.wait()