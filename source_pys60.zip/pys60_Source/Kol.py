# этот script тянет различные формы и текст с экрана


import appuifw
from appuifw import *
import e32
# вызов графики
from graphics import *



# создание тренера вызова
def quit():
    global running
    running=0
    appuifw.app.set_exit()

# установка большого размера экрана
appuifw.app.screen='large'

# назначение начального изображения (белый)
img=Image.new((176,208))

# добавление различных фигур и текста к изображению
# coord. Последовательность x1,x2,y1,y2
# для команды линии(line) х1 и х2 это координаты первой точки, у1 и у2 второй 
img.line((15,50,155,38),0xff00ee,width=20)
# квадрат. Значение х1 и х2 должны быть х1<у1 х2<у2
img.rectangle((20,70,160,130),0x959080,width=15)
# Для эллипса Значение х1 и х2 должны быть х1<у1 х2<у2
img.ellipse((20,70,160,130),0xA1A1A1,width=20)
#команда width=*задает толщину штриха, точки или линии поэтому команда point(точка) превращается в круг
img.point((85.,100.),0xff0000,width=40)
img.point((80.,100.),0x000000,width=10)
img.text((35,20), u'\u041d\u043e\u0432\u044b\u0439 \u0432\u0437\u0433\u043b\u044f\u0434',0xff0000)


# назначить функцию измены (которая изменяет снова и снова)
# в этом случае изменяется изображение, с названием img используется блитирующая функция
def handle_redraw(rect):
    canvas.blit(img)

running=1

# определение холста, включение отзыва функции измены
canvas=appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)

# установка app.body в холст
appuifw.app.body=canvas

app.exit_key_handler=quit


# создание цикла, чтобы экран изменялся снова и снова, пока кнопка выхода не будет нажата 
while running:
    # измена экрана
    handle_redraw(())
    # "уступите" должен быт здесь, чтобы ключевые нажимы могли быть изменены
    e32.ao_yield()







        


 



