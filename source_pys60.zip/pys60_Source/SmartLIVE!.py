import appuifw
from appuifw import *
import e32,os
from graphics import *

from key_codes import*

def vyhod():appuifw.app.set_exit()
appuifw.app.exit_key_handler=vyhod

def ru(x): return x.decode('utf-8')
app.screen='full'
ao=e32.Ao_lock()
global img
def handle_redraw(rect):
 canvas.blit(img)
canvas=appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)
appuifw.app.body=canvas
u_key=0
# nachalo____________________

# global
stop=1
path=u'test.fry'
plen=20
state=0
edit_x=5
edit_y=5

def ekran():
 global path,plen,img
 img=Image.new((176,208))
 img.rectangle((2,2,175,140),0x000000,width=200)
 img.text((176/2-40,30),ru('Smart.LIVE!'),0xffffff,font='title')
 img.text((176/2-55,50),ru('версия 1.0 релиз'),0xff0000,font='symbol')
 img.text((10,65),ru('Автор: Игорь aka kAIST'),0xff0000,font='symbol')
 img.text((5,77),ru('e-mail:'),0xff0000,font='symbol')
 img.text((45,77),ru('igor.kaist@gmail.com'),0x0000ff,font='symbol')
 img.text((5,89),ru('icq: 211141235'),0xff0000,font='symbol')
 if path==u'test.tur':
  plen=20

 img.rectangle((0,100,176,190),0xffffff,width=1)
 path_name=path
 if path==u'test.fry':path_name=ru('Пустое поле')
 img.text((3,112),ru('Загружено: ')+path_name,0xffffff,font='dense')
 img.line((0,115,176,115),0xffffff,width=1)
 naw=str(plen)
 img.text((3,128),ru('Размер поля: ')+naw+u'x'+naw+u' pix.',0xffffff,font='dense')
 img.line((0,115,176,115),0xffffff,width=1)
 img.text((3,205),ru('Меню'),0xffffff,font='symbol')
 img.text((130,205),ru('Выход'),0xffffff,font='symbol')
 img.line((0,131,176,131),0xffffff,width=1)
 img.text((40,143),ru('Назначение кнопок:'),0x00ff00,font='dense')
 img.text((3,154),ru('0-остановить(эволюция/редакт)'),0xffffff,font='dense')
 img.text((3,165),ru('Вверх,вниз,влево,вправо'),0xffffff,font='dense')
 img.text((48,176),ru('-управление (редактор)'),0xffffff,font='dense')
 img.text((3,187),ru('ОК-создать/убить клетку(ред.)'),0xffffff,font='dense')


 handle_redraw(())



#<1>#




#         выбор файла
def vybor():
 global path,prog,plen
 list=os.listdir('e:/Python/SmartLive!')
 k=len(list)
 for m in range(1,k+1):
  list[m-1]=list[m-1].decode('utf-8')    
 index = appuifw.popup_menu(list,ru('Открыть файл:'))
 path=list[index]
 f=open('e:/Python/SmartLive!/'+path,'rb')
 t=f.read()
 f.close()
 prog=t.split('\r\n')
 plen=int(prog[0])+1









#  глобальные переменные
pole={}
sk=1
die={}
live={}
#   формирование поля

def formirovanie():
 global prog,plen,pole
 for j in pole.keys():del pole[j]
 for y in range(0,plen):
  for x in range(0,plen):
   tek=(y*(plen)+x)+1
   if prog[tek]==u'1':
    a=x*100+y
    pole[a]=1




#  функция вокруг

def vokrug(x,y):
 global pole,plen
 sum=0
 pos=[[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1],[0,-1],[1,-1]]
 for a in pos:
  x_new=x+a[0]
  y_new=y+a[1]
  zap=y_new*100+x_new
  if pole.has_key(zap):sum=sum+1 
  x_new=x
  y_new=y
 return sum
#     рисовать экран

def draw(rezhim):
 global pole,img,plen,sk,path
 k=2
 img=Image.new((176,208))
 img.rectangle((2,2,175,140),0x000000,width=200)
 if plen<60:k=3
 if plen<42:k=4
 if plen<30:k=5
 if plen<28:k=6
 if plen<21:k=7
 delta_y=100-plen*k/2
 delta_x=90-plen*k/2
 img.rectangle((delta_x-4,5,delta_x+plen*k+2,plen*k+11),0xff0000,width=2)
 w=str(k)
 img.text((2,187),ru('zoom'),0xffffff,font='dense')
 img.text((135,205),ru('k=')+str(sk).decode('utf-8'),0xffffff,font=u'Acb14')
 img.text((5,205),w.decode('utf-8'),0xffffff,font=u'Acb14')

 img.text((119,187),ru('поколение'),0xffffff,font='dense')
 img.rectangle((0,176,176,208),0xffffff,width=1)
 img.line((30,176,30,208),0xffffff,width=1)
 img.line((116,176,116,208),0xffffff,width=1)
 img.text((32,187),ru('файл:')+path[0:10]+u'..',0xffffff,font='dense')
 simb=[ru('Live!'),ru('Пауза'),ru('Редакт.')]
 simb_my=simb[rezhim]
 img.text((32,200),ru('режим: ')+simb_my,0xffffff,font='dense')
 

 for a in pole.keys():
  y=int(a/100)
  x=(a-int(a/100)*100)
  img.point((x*k+delta_x,y*k+10),0xffffff,width=k)
 handle_redraw(())
# гибель живых клеток

def gibel():
 global die,pole
 for i in die.keys():del die[i] 
 for a in pole.keys():
  d=a
  y=int(d/100)
  x=d-int(d/100)*100
  sum=vokrug(x,y)
  if (sum<2) or (sum>3):die[a]=u'1'

# live

def lived():
 global pole,live,plen
 for i in live.keys():del live[i]
 for x in range(0,plen):
  for y in range(0,plen):
   a=y*100+x
   if (pole.has_key(a))==0:
    if vokrug(x,y)==3:
     live[a]=u'1'

def open_file():
 global sk
 vybor()
 formirovanie()
 ekran()
 sk=0

#                pause
def pause():
 global state
 state=1
#________________________
def tochka(x,y,rezh):
 global pole,plen,img
 k=2
 if plen<60:k=3
 if plen<42:k=4
 if plen<30:k=5
 if plen<28:k=6
 if plen<21:k=7
 delta_y=100-plen*k/2
 delta_x=90-plen*k/2
 a=y*100+x
 if rezh==0:
  if pole.has_key(a):
   img.point((x*k+delta_x,y*k+10),0xffffff,width=k)
  if pole.has_key(a)==0:
   img.point((x*k+delta_x,y*k+10),0x000000,width=k)
 if rezh==1:
  if pole.has_key(a):
   img.point((x*k+delta_x,y*k+10),0x0000ff,width=k)
  if pole.has_key(a)==0:
   img.point((x*k+delta_x,y*k+10),0x00ff00,width=k)
 handle_redraw(())

def vverh():
 global edit_x,edit_y
 if edit_y>0:
  tochka(edit_x,edit_y,0)
  edit_y=edit_y-1
  tochka(edit_x,edit_y,1)

def vniz():
 global edit_x,edit_y,plen
 if edit_y<(plen-1):
  tochka(edit_x,edit_y,0)
  edit_y=edit_y+1
  tochka(edit_x,edit_y,1)

def nalevo():
 global edit_x,edit_y
 if edit_x>0:
  tochka(edit_x,edit_y,0)
  edit_x=edit_x-1
  tochka(edit_x,edit_y,1)

def napravo():
 global edit_x,edit_y,plen
 if edit_x<(plen-1):
  tochka(edit_x,edit_y,0)
  edit_x=edit_x+1
  tochka(edit_x,edit_y,1)

def redakt():
 global edit_x,edit_y,pole,pole
 a=edit_y*100+edit_x
 if pole.has_key(a):
  del pole[a]
  tochka(edit_x,edit_y,1)
 else:
  pole[a]=u'1'
  tochka(edit_x,edit_y,1)
def null():
 x=0


def zavershit():
 global stop
 stop=0
 ekran()
 canvas.bind(EKeySelect,lambda:null())
 canvas.bind(EKeyLeftArrow,lambda:null())
 canvas.bind(EKeyRightArrow,lambda:null())
 canvas.bind(EKeyUpArrow,lambda:null())
 canvas.bind(EKeyDownArrow,lambda:null())
 canvas.bind(EKey5,lambda:null())

def redaktor():
 global pole,img,plen,sk,path,edit_x,edit_y,stop
 stop=1
 sk=0
 jaj=1
 edit_x=5
 edit_y=5
 if path==u'test.fry':
  while jaj:
   u_len=query(ru('Размер поля:'),'number')
   jaj=0
   if u_len<10 or u_len>81:
    note(ru('Размер поля должен быть\nот 10 до 81'),'error')
    jaj=1
  plen=u_len
  path=u'new.fry'
 draw(2)
 tochka(edit_x,edit_y,1)
 canvas.bind(EKeySelect,lambda:redakt())
 canvas.bind(EKeyLeftArrow,lambda:nalevo())
 canvas.bind(EKeyRightArrow,lambda:napravo())
 canvas.bind(EKeyUpArrow,lambda:vverh())
 canvas.bind(EKeyDownArrow,lambda:vniz())
 canvas.bind(EKey0,lambda:zavershit())

def new_pole():
 global img,sk,pole,plen,path
 for a in pole.keys():
  del pole[a]
 sk=0
 x=1
 path=u'new.fry'
 while 1:
  d=query(ru('Размер поля:'),'number')
  if d>9 and d<81:break
  note(ru('Размер поля должен быть\nот 10 до 81'),'error')
 plen=d
 ekran()




#________________________

#               play
def play():
 global sk,state,u_sk
 state=0
 canvas.bind(EKey0,lambda:pause())
 draw(state)
 e32.ao_sleep(0.1)
 while state==0:
  lived()
  gibel()
  for a in live.keys():pole[a]=u'1'
  for b in die.keys():del pole[b]
  draw(state) 
  sk=sk+1
  e32.ao_sleep(0.01)
 draw(1)

def save():
 global path,pole,plen
 z=1
 buf=1
 while z:
  x_path=query(ru('Сохранить как...'),'text',path)
  z=0
  if len(x_path)<2:z=1
 list=os.listdir('e:/Python/SmartLive!')
 for a in list:
  if x_path==a:buf=0
 if buf==0:
  buf=query(ru('Файл\n')+x_path+ru('\nуже существует. Перезаписать?'),'query')
 if buf==1:
  file=open('e:/Python/SmartLive!/'+x_path,'w')
  file.close()
  os.remove('e:/Python/SmartLive!/'+x_path)
  t=open('e:/Python/SmartLive!/'+x_path,'w')
  g=str(plen-1)
  t.write(g+u'\r\n')
  for x in range(0,plen):
   for y in range(0,plen):
    a=y*100+x
    if pole.has_key(a):
     t.write(u'1'+u'\r\n')
    else:t.write(u'0'+u'\r\n')
  t.close()
  note(ru('Файл записан!'),'info')

def delete():
 list=os.listdir('e:/Python/SmartLive!')
 k=len(list)
 for m in range(1,k+1):
  list[m-1]=list[m-1].decode('utf-8')    


 j=popup_menu(list,ru('удалить:'))
 w=list[j]
 k=query('Удалить файл '.decode('utf-8')+w+u' ?','query')
 if k==1:os.remove(u'e:/Python/SmartLive!/'+w)
 note(w+ru('\n удален!'),'info')

#while 1:
u_sk=10
ekran()
appuifw.app.menu=[(ru('Файл'),((ru('Открыть'),open_file),(ru('Сохранить'),save),(ru('Новый'),new_pole),(ru('Удалить'),delete))),(ru('Эволюция!'),play),(ru('Редактор'),redaktor)]




ao.wait()