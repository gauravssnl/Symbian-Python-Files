import appuifw
import e32
import os
import thread
import time
import sys
import audio
import location

def ru(x):
  return x.decode('utf-8')
def ur(x):
  return x.encode('utf-8')

def printout(mess, clr = 0x0, addline = True):
  appuifw.app.body.color = clr
  appuifw.app.body.set_pos(appuifw.app.body.len())
  appuifw.app.body.add(mess)
  if addline:
    appuifw.app.body.set_pos(appuifw.app.body.len())
    appuifw.app.body.add(u"\n")
  try: appuifw.app.body.focus = False
  except: pass
  e32.ao_yield()

def anote(mess):
  appuifw.note(mess,"info")
def aerror(mess):
  appuifw.note(mess,"error")

try:
  import appswitch 
  from key_tricks import * 
  import uitricks
  import miso
except:
  aerror(ru("Ошибка при загрузке СТОРОННИХ модулей"))
  aerror(ru("Необходимо поставить подборку модулей"))
  os.abort()

def print_exception():
  import sys
  import traceback
  type, value, tb = sys.exc_info()
  sys.last_type = type
  sys.last_value = value
  sys.last_traceback = tb
  tblist = traceback.extract_tb(tb)
  del tblist[:1]
  list = traceback.format_list(tblist)
  if list:
    list.insert(0, u"Trace:\n")
  list[len(list):] = traceback.format_exception_only(type, value)
  tblist = tb = None
  printout(unicode(str(list).replace("\\n","\n")))

alarmcells = []
old_cellid = (0,0,0,0)
running = 0
vibrate = 1
thread_running = 0
gas_path = u"C:/"
sound_path = ''
sound_path2 = ''
runninginstandaloneapp = True
app_path = ru(os.path.split(sys.argv[0])[0]+"\\")
if app_path.find(ru("Python")) != -1:
  runninginstandaloneapp = False
gas_path = app_path+u"sets\\"
sound_path = app_path+'alarm.mp3'
sound_path2 = app_path+'alarm_off.mp3'

if not os.path.exists(gas_path):
  try:
    os.mkdir(gas_path)
  except:None
if not os.path.exists(gas_path):
  anote(ru("Не могу создать папку для хранения наборов!"))
  os.abort()

def vibra_thread():
  global vibrate
  global thread_running
  thread_running = 1
  try:
    while vibrate == 1:
      miso.vibrate(100, 100)
      e32.ao_sleep(0.5)
      miso.vibrate(100, 50)
      e32.ao_sleep(0.5)
      miso.vibrate(500, 100)
      e32.ao_sleep(1)
  except: 
    None
  
  thread_running = 0

def sound_play():
  global sound_path,s
  try:
    s = audio.Sound.open(sound_path)
    s.play(audio.KMdaRepeatForever)
  except:pass

def on_off_sound():
  if os.path.exists(sound_path):
    try:
      os.rename(sound_path, sound_path2)
      printout (ru("ЗВУК ВЫКЛЮЧЕН"))
    except:
      printout (ru("Не удалось выключить звук!"), clr = 0xff0000)
  else:
    try:
      os.rename(sound_path2, sound_path)
      printout (ru("ЗВУК ВКЛЮЧЕН"))
    except:
      printout (ru("Не удалось включить звук!"), clr = 0xff0000)
  
def set_alarm_cell():
  global alarmcells , vibrate, old_cellid
  clean_alarms() 
  vibrate = 1
  alarmcells.append(old_cellid)
  print_alarms()

def stop_alarm():
  global vibrate, main_menu
  vibrate = 0
  global s
  try:
    s.stop()
  except:pass
  main_menu.pop(0)


def print_alarms():
  global alarmcells  
  printout (ru('\nАктивные вышки:'), clr = 0x0000ff)
  if len(alarmcells) == 0:
    printout(ru("не установлены"))
    return
  for elem in alarmcells:
    printout (unicode(str(elem)))

def clean_alarms():
  global alarmcells  
  while (len(alarmcells) != 0):
    alarmcells.pop()

def empty_alarm_set():
  clean_alarms()
  print_alarms()
 
def update_file(filename, fixcell):
  global gas_path
  file = open(ur(filename),'a')
  try:
    file.write(u"\n" + str(fixcell)+u"\n")
    file.close()
    printout (unicode(os.path.split(filename)[1])+ru(" дополнен кодом вышки ")+unicode(str(fixcell)))
  except:
    printout (u"Update file: save error!")
 
def create_alarm_set():
  global old_cellid
  fixcell = old_cellid
  filename = appuifw.query(ru('Имя набора:'),'text',u"new_set")
  if filename == None:
    return
  try:
    k = gas_path + ru(ur(filename) + ".gas")  
    file = open(ur(k),u'w+')
    file.write(str(fixcell)+u"\n")
    file.close()
    printout (ru("Набор ") + unicode(filename)+ru(" создан с номером соты ") + unicode(str(fixcell)))
  except:
    printout (u"Create file: save error!")

def is_py(x): 
  return os.path.splitext(x)[1] == '.gas' 

def choose_cells_set():
  global alarmcells
  global vibrate
  
  if os.path.exists(gas_path): 
    script_list = filter(is_py, os.listdir(gas_path))
    index = appuifw.selection_list(map(ru, script_list))
    if index == None:
      return
    
    file = open(ur(gas_path+ru(script_list[index])),'r') 
    
    clean_alarms()
    
    def _getline(line):
      if len(line) == 1 or len(line) == 0:
        return None
      if line[-1] == u"\n":
        if line[-2] == u"\r":
          line = line[:-2]
        else:
          line = line[:-1]
      return line
      
    for line in file:
      tmp = _getline(line)
      if tmp == None: continue
      tmp = tmp[1:-1].split(", ")
      cell = (int(tmp[0]),int(tmp[1]),int(tmp[2]),int(tmp[3]))
      alarmcells.append(cell)
      
    print_alarms()
    vibrate = 1

def update_cells_set():
  global alarmcells
  global vibrate
  global old_cellid
  fixcell = old_cellid
  if os.path.exists(gas_path): 
    script_list = filter(is_py, os.listdir(gas_path))
    index = appuifw.selection_list(map(ru, script_list))
    if index == None:
      return
    update_file(gas_path+ru(script_list[index]),fixcell)

def delete_cells_set():
  if os.path.exists(gas_path): 
    script_list = filter(is_py, os.listdir(gas_path))
    index = appuifw.selection_list(map(ru, script_list))
    if index == None:
      return
    if appuifw.query(ru("Удалить ")+ru(script_list[index])+ru("?"),'query',True):
       try:
         os.remove(ur(gas_path+ru(script_list[index])))
         anote(ru('Набор удален'))
       except:
         aerror(ru('Ошибка удаления'))

def About():
  authorinfo = """Produced by Atrant\natrant@front.ru"""
  anote(ru(authorinfo))
  programinfo = """GSM Location v2.0"""
  anote(ru(programinfo))
  programinfo = """Обновление и обсуждение программы всегда на dimonvideo.ru"""
  anote(ru(programinfo))

def test_vibra_thread():
  try:
    miso.vibrate(30, 30)
    e32.ao_sleep(0.2)
    miso.vibrate(30, 30)
  except:  pass

def switchback():
  appswitch.switch_to_bg(u"GSMLocation")

def WatchCellsOff():
  global running, thread_running
  if running == 0: return
  printout(ru("Останавливаю слежение, ждите..."),clr=0xff0000)
  if thread_running: stop_alarm()
  running = 0

def WatchCells():
  global vibrate, running, alarmcells, old_cellid, thread_running, main_menu
  old_cellid = -1
  if running == 0: running = 1
  else: return
  main_menu.pop(0)
  main_menu.insert(0, (ru("Откл. слежение"), WatchCellsOff))
  printout(ru("\nСлежение активно"), clr=0x0000ff)
  while running:
    mcc, mnc, lac, cellid = location.gsm_location()
    cellid = (mcc,mnc,lac,cellid)
    if (str(old_cellid) != str(cellid)):
      old_cellid = cellid  
      vibrate = 1
      printout (ru("Код текущей вышки:\n") + unicode(str(cellid)))
      #printout (location.gsm_location())
      #if (0,0,0,0) == cellid:
      #  printout (u"=====")
    
    if (thread_running == 0) and (vibrate == 1):
      for cell in alarmcells:
        if (str(cellid) == str(cell)):
          appswitch.switch_to_fg(u"GSMLocation")
          main_menu.insert(0, (ru("ОСТАНОВ ТРЕВОГИ"), stop_alarm))
          printout (ru("ТРЕВОГА ТРЕВОГА ТРЕВОГА :)"))
          sound_play()
          try:
            thread.start_new_thread(vibra_thread,())
          except:
            printout (ru("Ошибка запуска потока"))
          break;
  
    e32.ao_sleep(5)
    e32.ao_yield()
  printout(ru("Слежение неактивно"), clr=0x0000ff)
  main_menu.pop(0)
  try:
    main_menu.insert(0, (ru("Запуск слежения"), WatchCells))
  except: print_exception()

def RememberPlace():
  global main_menu, running, WatchCellsOff
  if running == 1:
    aerror(ru("Сначала отключите слежение!"))
    return
  def _Cancel():
    WatchCellsOff()
    global cancel
    cancel = True
  global cancel
  cancel = False
  running = 1
  appuifw.app.menu = [(ru("Достаточно"), WatchCellsOff),(ru("Отмена"), _Cancel)]
  printout(ru("\nФиксирую коды вышек:"), clr = 0x0000ff)
  found_cells = []
  tmp_cellid = (0,0,0,0)
  while running:
    mcc, mnc, lac, cellid = location.gsm_location()
    cellid = (mcc,mnc,lac,cellid)
    if (str(tmp_cellid) != str(cellid)):
      tmp_cellid = cellid 
      found = False
      for cell in found_cells:
        if cell == cellid:
          found = True
          break
      if found: continue
      printout (unicode(str(cellid)))
      found_cells.append(cellid)

    e32.ao_sleep(5)
    e32.ao_yield()
  if cancel: 
    printout(ru("Запоминание места отменено"))
    appuifw.app.menu = main_menu
    return
  filename = appuifw.query(ru('Имя набора:'),'text',u"new_set")
  if filename != None:
    try:
      k = gas_path + ru(ur(filename) + ".gas")  
      file = open(ur(k),u'w+')
      for fixcell in found_cells:
        file.write(str(fixcell)+u"\n")
      file.close()
      printout (ru("Набор ") + unicode(filename)+ru(" создан"))
    except:
      printout (u"Не удалось сохранить информацию в файл!")
  else: printout(ru("Запоминание места отменено"))
  appuifw.app.menu = main_menu

def Exit():
  global script_lock, runninginstandaloneapp
  WatchCellsOff()
  script_lock.signal()
  if runninginstandaloneapp == True:
    appuifw.app.set_exit()

if runninginstandaloneapp == True:
  appuifw.app.body = appuifw.Text()
script_lock = e32.Ao_lock()
uitricks.set_text(u'Back',EAknSoftkeyExit) 

appuifw.app.exit_key_handler = switchback
#appuifw.app.exit_key_handler = Exit
main_menu = [
        (ru("Запуск слежения"), WatchCells),
        (ru("Активные вышки"), ((ru("установить"),choose_cells_set),(ru("сбросить"),empty_alarm_set),(ru("показать"), print_alarms))),
        (ru("Текущая вышка"),((ru("Создать нов. набор"),create_alarm_set),(ru("Дополнить набор"),update_cells_set),(ru("Удалить набор"),delete_cells_set),(ru("Уст. активной"),set_alarm_cell))),
        (ru("Инструменты"),((ru("Сохранить место"), RememberPlace),(ru("Звук вкл/выкл"), on_off_sound))),
        (ru("О программе"), About),
        (ru("Выход"), Exit)]
appuifw.app.menu = main_menu
try:
   thread.start_new_thread(test_vibra_thread,())
except:
   printout (ru("Ошибка запуска проверки вибрации"))
    
if os.path.exists(sound_path):
 printout (ru("ЗВУК ВКЛЮЧЕН\n"), clr=0xff0000)
else:
 printout (ru('ЗВУК ВЫКЛЮЧЕН\n'))

if runninginstandaloneapp == False:
  old_handler = appuifw.app.exit_key_handler
  appuifw.app.exit_key_handler = Exit
  script_lock.wait() 
  appuifw.app.exit_key_handler = old_handler
