#by Seldon86 

TEXT_COLOR=0x00ff00#RGB
FON_COLOR=0xffffff#RGB
TIME_REDRAW=0.2#secund

import e32,sysinfo,fgimage,graphics,appuifw

img=graphics.Image.new((32,11))
fg=fgimage.FGImage() 
appuifw.app.body=appuifw.Canvas()
while 1:
 img.clear(FON_COLOR)
 img.text((1,10),unicode(str(sysinfo.free_ram()/1048576.0)[:5]),TEXT_COLOR)
 fg.set(131,0,img._bitmapapi()) 
 e32.ao_sleep(TIME_REDRAW)