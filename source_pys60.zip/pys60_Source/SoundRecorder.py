import appuifw
import e32
#импортируем модуль звука
import audio
from rusos import*

# определяем имя и путь файла звука которое будет записываться и воспроизводится 
filename = 'c:\\boo.wav'

# определяем записываемую часть:
def recording():
    global S
    # открываем звуковой файл для записи 
    S=audio.Sound.open(filename)
    # начинаем запись запись будет остановлена если будет команда closing()
    S.record()
    print ru("запись начата нажмите стоп для остановки записи")

# определяем записывающую часть:
def playing():
    global S
    try:
        # открываем файл для чтения
        S=audio.Sound.open(filename)
        # проигрываем файл
        S.play()
        print ru("воспроизведение")
    except:
        print ru("запишите сперва звук!")

# останавливаем запись / воспроизведение и закрываем звуковой файл
def closing():
    global S
    S.stop()
    S.close()
    print ru("закрываем")


def exit_key_handler():
    script_lock.signal()
    appuifw.app.set_exit()
    

script_lock = e32.Ao_lock()

appuifw.app.title = ru("запись звука")

# define the application menu
appuifw.app.menu = [(ru("воспроизведение"), playing),
                    (ru("запись"), recording),
                    (ru("стоп"), closing)]

appuifw.app.exit_key_handler = exit_key_handler
script_lock.wait()


 

