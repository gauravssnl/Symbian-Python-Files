from appuifw import *
from e32 import ao_sleep,Ao_lock
from sysagent import *
from esysagent import *


def viewsysagent():
 app.body.clear()
 status=current_call()
 if status==ESACallNone:
  text="No call"
 elif status==ESACallVoice:
  text="Voice call"
 
 elif status==ESACallFax:
  text="Fax call"

 elif status==ESACallData:
  text="Data call"

 elif status==ESACallAlerting:
  text="Alerting call"

 elif status==ESACallRinging:
  text="Ringing call"

 elif status==ESACallAlternating:
  text="Alternate call"

 elif status==ESACallDialling:
  text="Dial call"

 elif status==ESACallAnswering:
  text="Answering call"

 elif status==ESACallDisconnecting:
  text="Call disconnected"

 app.body.add(u'%s\n'%text)

 status = battery_strength()
 if status == ESABatteryAlmostEmpty:
  text="Battery almost empty" 
 elif status == ESABatteryLow:
  text="Battery low"
 elif status ==ESABatteryFull:
  text="Battery full"
 app.body.add(u'%s\n'%text)
  
 status = profile()

 status = phone_status()
 if status == ESAPhoneOff:
  text="Phone is off"
 elif status==ESAPhoneOn:
  text="Phone is on"
 app.body.add(u'%s\n'%text)
  
 status = SIM_status()
 if status == ESASimOk:
  text="SIM is ok"
 elif status == ESASimNotPresent:
  text="SIM is not present !!!"
 elif status == ESASimRejected:
  text="SIM has been rejected !"
 app.body.add(u'%s\n'%text)


 status = network_strength()
 if status == ESANetworkAvailable:
  text="Network available" 
 elif status == ESANetworkUnAvailable:
  text="Network is unavailable !"
 else:
  text="Network unknown status" 
 app.body.add(u'%s\n | %d'%(text,status))
  
 status = network_status()
 if status == ESANetworkStrengthNone:
  text="Network strength none"
 elif status == ESANetworkStrengthLow:
  text="Network strength low"
 elif status == ESANetworkStrengthMedium:
  text="Network strength medium"
 elif status == ESANetworkStrengthHigh:
  text="Network strength high"
 elif status == ESANetworkStrengthUnknown:
  text="Network strength unknown"
 app.body.add(u'%s\n'%text)

 status = charger_status()
 if status == ESAChargerConnected:
  text="Charger is connected" 
 elif status == EESAChargerDisconnected:
  text="Charger is disconnected"
 elif status == ESAChargerNotCharging:
  text="Charger is not charging"
 else:
  text="Charger unknown status"
 app.body.add(u'%s\n'%text)
  
 status = data_port()
 if status == ESADataPortIdle: 
  text="Data port idle"
 elif status == ESADataPortBusy:
  text="Data port busy"
 else:
  text="Data port unknown status" 
 app.body.add(u'%s\n | %d'%(text,status))


 status = inbox_status()
 if status == ESAInboxEmpty:
  text="Inbox empty"
 elif status == ESADocumentsInInbox:
  text="Inbox is not empty"
 app.body.add(u'%s\n'%text)

 status = outbox_status()
 if status == ESAOutboxEmpty:
  text="Outbox empty"
 elif status == ESADocumentsInOutbox:
  text="Outbox is not empty"
 app.body.add(u'%s\n'%text)

 status = irda_status()
 if status==ESAIrLoaded:
  text="IRDA Irlap layer loaded"
 elif status==ESAIrDiscoveredPeer:
  text=""

 elif status==ESAIrLostPeer:
  text="IRDA Discovery begin"

 elif status==ESAIrConnected:
  text="IRDA Discovery end"

 elif status==ESAIrBlocked:	
  text="IRDA Irlap layer blocked"

 elif status==ESAIrDisConnected: 
  text="IRDA Irlap layer disconnected"

 elif status==ESAIrUnloaded:	
  text="IRDA Irlap layer unloaded"
 else:
  text="IRDA unknown status" 
 app.body.add(u'%s\n | %d'%(text,status))

 status = clock()
 if status == ESAAm:
  text="Clock is AM"
 elif status == ESAPm:
  text="Clock is PM"
 else:
  text="Clock Unknown status"  
 app.body.add(u'%s\n | %d'%(text,status))
 
lock=Ao_lock()
app.body=Text()
app.body.clear()
app.exit_key_handler=lock.signal
app.menu = [(u"View sysagent info",viewsysagent)]
lock.wait()