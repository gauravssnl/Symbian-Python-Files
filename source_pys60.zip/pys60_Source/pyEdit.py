
import e32
import appuifw
import messaging

import sys
import os

import pyS60uiutil

global options_menu_h
global doc_list
global default_path

global sentences_list
global clipboard_content

EDITOR_CONFIG_FILE = 'dat/pyeditconf'
EDITOR_CONFIG_VERS = '4'
EDITOR_CONFIG_HEAD = '<---pyEdit configuration file--->'
escript_lock = e32.Ao_lock()

global txtcodec
global favdocs
global miscconf
global settings_changed

#=
#= Editor configuration.
#=
def write_config_header(cfile):
    """
    Writes a header to the configuration file. The file is validated based
    on this header.
    """
    cfile.write(EDITOR_CONFIG_HEAD+'\n'+EDITOR_CONFIG_VERS+'\n')

def check_config_header(cfile):
    """
    Validate the configuration file based on the header information.
    """
    if not cfile.readline()[:-1] == EDITOR_CONFIG_HEAD: return False
    if not cfile.readline()[:-1] == EDITOR_CONFIG_VERS: return False
    return True
    
class text_codecs:
    """
    Text codec configuration.
    """
    def __init__(self):
        self.codec_lst = ['utf-8',
                          'utf-16',
                          'latin-1',
                          'iso-8859-1',
                          'ascii']
        self.default_codec_ix = 0

    def get_codec(self, index):
        return self.codec_lst[index]

    def get_default_codec_index(self):
        return self.default_codec_ix

    def set_default_codec_index(self, index):
        self.default_codec_ix = index
        
    def get_unicoded_codec_lst(self):
        ulist = []
        for i in self.codec_lst: ulist.append(unicode(i))
        return ulist

    def save_config(self, cfile):
        try:
            cfile.write(str(self.default_codec_ix)+'\n')
        except:
            appuifw.note(u'Configuration (codec) write error', 'error')

    def read_config(self, cfile):
        try:
            s = cfile.readline().lstrip().rstrip()
            self.set_default_codec_index(int(s))
        except:
            appuifw.note(u'Configuration (codec) read error', 'error')

class favorite_docs:
    """
    Favorite documents configuration.
    """
    def __init__(self):
        self.nr_of_docs = 7
        self.doc_lst = []
        for i in range(self.nr_of_docs):
            self.doc_lst.append('<not selected>')
            
    def get_unicoded_doc_lst(self):
        ulist = []
        for i in self.doc_lst: ulist.append(unicode(i))
        return ulist

    def get_doc(self, index):
        return self.doc_lst[index]
        
    def set_doc(self, index, docname):
        self.doc_lst[index] = docname

    def select_doc(self, index):
        if not self.get_doc(index) == '<not selected>':
            if appuifw.query(u'Leave item unassigned?', 'query'):
                self.set_doc(index, '<not selected>')
                return
        fb = pyS60uiutil.dirBrowser('Select favorite document')
        doc = fb.select(None)
        if doc == None or doc == ('', ''): return
        doc_name = os.path.join(doc[0], doc[1])
        if not os.path.isfile(doc_name):
            appuifw.note(u'Not a regular file', 'error')
        else:
            self.set_doc(index, doc_name)

    def save_config(self, cfile):
        try:
            cfile.write(str(self.nr_of_docs)+'\n')
            for i in self.doc_lst:
                cfile.write(i+'\n')
        except:
            appuifw.note(u'Configuration (favorites) write error', 'error')

    def read_config(self, cfile):
        try:
            s = cfile.readline().lstrip().rstrip()
            for i in range(int(s)):
                s = cfile.readline()
                if i < self.nr_of_docs:
                    self.set_doc(i, s.lstrip().rstrip())
        except:
            appuifw.note(u'Configuration (favorites) read error', 'error')

class miscconfig:
    """
    Miscellaneous configuration data.
    """
    def __init__(self):
        self.default_sentences_file = '<not selected>'
        self.initial_work_directory = '<not selected>'
        self.screen_mode = 'normal'
        self.font        = None
        self.font_color  = None

    def select_default_sentences_file(self):
        if not self.get_default_sentences_file() == '<not selected>':
            if appuifw.query(u'Leave sentences unassigned?', 'query'):
                self.default_sentences_file = '<not selected>'
                return
        fb = pyS60uiutil.dirBrowser('Select default sentences')
        doc = fb.select(None)
        if doc == None or doc == ('', ''): return
        doc_name = os.path.join(doc[0], doc[1])
        if not os.path.isfile(doc_name):
            appuifw.note(u'Not a regular file', 'error')
        else:
            self.default_sentences_file = doc_name
            #= Take the selected sentences_file into use...
            load_sentences_file(self.default_sentences_file)
            
    def get_default_sentences_file(self):
        return self.default_sentences_file

    def select_initial_work_directory(self):
        if not self.get_initial_work_directory() == '<not selected>':
            if appuifw.query(u'Leave directory unassigned?', 'query'):
                self.initial_work_directory = '<not selected>'
                return
        old_dir = self.initial_work_directory
        if old_dir == '<not selected>': old_dir = None
        fb = pyS60uiutil.dirBrowser('Select default work directory')
        dir = fb.select(old_dir)
        if dir == None or dir == ('', ''): return
        if not os.path.isdir(dir[0]):
            appuifw.note(u'Not a directory', 'error')
        else:
            self.initial_work_directory = dir[0]

    def get_initial_work_directory(self):
        return self.initial_work_directory

    def select_screen_mode(self):
        modes = ['normal', 'large', 'full']
        umodes = [u'normal', u'large', u'full']
        ix = appuifw.popup_menu(umodes)
        if not ix == None:
            self.screen_mode = modes[ix]

    def get_screen_mode(self):
        return self.screen_mode
    
    def select_font(self):
        dlg = pyS60uiutil.fontSelectionDlg()
        self.font = dlg.select()
        
    def get_font(self):
        return self.font

    def select_font_color(self):
        if self.font_color == None:
            self.font_color = (0, 0, 0)
        predef_menu = [(u'Black',  (0,0,0)),   \
                       (u'Blue',   (0,0,255)), \
                       (u'Green',  (0,255,0)), \
                       (u'Red',    (255,0,0)), \
                       (u'Custom', self.font_color)]
	custom_index = 4
        dlg = pyS60uiutil.fontColorSelectionDlg(None, predef_menu, custom_index)
        self.font_color = dlg.select()
        
    def get_font_color(self):
        return self.font_color

    def save_config(self, cfile):
        try:
            cfile.write(self.default_sentences_file+'\n')
            cfile.write(self.initial_work_directory+'\n')
            cfile.write(self.screen_mode+'\n')
            if self.font == None:
                cfile.write('<nofont>\n')
            else:
                cfile.write(str(self.font)+'\n')
            if self.font_color == None:
                cfile.write('<nofontcolor>\n')
            else:
                cfile.write(str(self.font_color[0]) + ' ' +
                            str(self.font_color[1]) + ' ' +
                            str(self.font_color[2]) + ' ' +'\n')
        except:
            appuifw.note(u'Configuration (misc) write error', 'error')

    def read_config(self, cfile):
        try:
            #= Read default sentence file
            s = cfile.readline().lstrip().rstrip()
            if not s == '': self.default_sentences_file = s
            #= Read initial work directory
            s = cfile.readline().lstrip().rstrip()
            if not s == '': self.initial_work_directory = s
            #= Read screen mode
            s = cfile.readline().lstrip().rstrip()
            if not s == '': self.screen_mode = s
            #= Read font
            s = cfile.readline().lstrip().rstrip()
            if unicode(s) in appuifw.available_fonts():
                self.font = unicode(s)
            #= Read font color
            s = cfile.readline().lstrip().rstrip()
            if not s == '<nofontcolor>':
                s = s.split()
                self.font_color = (int(s[0]), int(s[1]), int(s[2]))
        except:
            appuifw.note(u'Configuration (misc) read error', 'error')

def editor_settings():
    """
    Editor configuration interface.
    """
    global txtcodec, favdocs, miscconf
    global doc_list, settings_changed

    tab_list = [u'Codec', u'Docs', u'Misc']
    settings_changed = False

    def conf_exit():
        appuifw.app.set_tabs([], lambda x: None)
        pyS60uiutil.restore_app_info(edit_app_info)        
        config_lock.signal()
        
    def setting_page(page_ix):
        appuifw.app.menu = []
        if page_ix == 0:
            def _make_lbox_menu():
                lbmenu = txtcodec.get_unicoded_codec_lst()
                lix = doc_list.get_active_doc().get_codec()
                lbmenu[lix] = lbmenu[lix] + u' *'
                return lbmenu
            def cb():
                global settings_changed
                settings_changed = True
                doc_list.get_active_doc().set_codec(lbox.current())
                #= Refresh the tabs and active page.
                appuifw.app.set_tabs(tab_list, setting_page)
                appuifw.app.activate_tab(page_ix)
                lbox.set_list(_make_lbox_menu(), lbox.current())
            lbox = appuifw.Listbox(_make_lbox_menu(), cb)
            appuifw.app.body = lbox
        elif page_ix == 1:
            def cb():
                global settings_changed
                settings_changed = True
                #= Tabs must removed and added again due to fileBrowser
                appuifw.app.set_tabs([], lambda x: None)
                favdocs.select_doc(lbox.current())
                #= Refresh the tabs and active page.
                appuifw.app.set_tabs(tab_list, setting_page)
                appuifw.app.activate_tab(page_ix)
                lbox.set_list(favdocs.get_unicoded_doc_lst(), lbox.current())
            lbox = appuifw.Listbox(favdocs.get_unicoded_doc_lst(), cb)
            appuifw.app.body = lbox
        elif page_ix == 2:
            #=
            #=  More stuff later on
            #=
            def _make_lbox_menu():
                tmp = miscconf.get_default_sentences_file()
                tmp = u'Sentences: ' + unicode(os.path.split(tmp)[1])
                lst = [tmp]
                lst.append(u'Work dir: ' + \
                           unicode(miscconf.get_initial_work_directory()))
                lst.append(u'Screen mode')
                lst.append(u'Font')
                lst.append(u'Font color')
                return lst
            def cb():
                global settings_changed
                settings_changed = True
                #= Tabs must removed and added again due to fileBrower
                appuifw.app.set_tabs([], lambda x: None)
                i = lbox.current()
                if i == 0:
                    miscconf.select_default_sentences_file()
                elif i == 1:
                    miscconf.select_initial_work_directory()
                elif i == 2:
                    miscconf.select_screen_mode()
                elif i == 3:
                    miscconf.select_font()
                elif i == 4:
                    miscconf.select_font_color()
                #= Refresh the tabs and active page.
                appuifw.app.set_tabs(tab_list, setting_page)
                appuifw.app.activate_tab(page_ix)
                lbox.set_list(_make_lbox_menu(), lbox.current())
            lbox = appuifw.Listbox(_make_lbox_menu(), cb)
            appuifw.app.body = lbox

    edit_app_info = pyS60uiutil.save_current_app_info()

    appuifw.app.t = None
    config_lock = e32.Ao_lock()
    appuifw.app.screen = 'normal'
    appuifw.app.exit_key_handler = conf_exit
    appuifw.app.set_tabs(tab_list, setting_page)
    appuifw.app.activate_tab(0)
    setting_page(0)
    config_lock.wait()

    if settings_changed:
        apply_editor_settings()
        if not appuifw.query(u'Save changes as default settings', 'query'):
            return
        #= Store default codec
        txtcodec.set_default_codec_index(doc_list.get_active_doc().get_codec())
        try:
            full_dir = os.path.split(EDITOR_CONFIG_FILE)[0]
            if not os.path.isdir(full_dir): os.mkdir(full_dir)
            config_file = file(EDITOR_CONFIG_FILE, 'wb')
        except:
            appuifw.note(u'Error while creating configuration file', 'error')
            return
        #= Each class writes its own data.
        write_config_header(config_file)
        txtcodec.save_config(config_file)
        favdocs.save_config(config_file)
        miscconf.save_config(config_file)
        config_file.close()
    else:
        appuifw.note(u'Settings not changed', 'conf')

def read_editor_settings():
    """
    Read the editor settings from a configuration file.
    """
    global txtcodec, favdocs, miscconf
    if os.path.isfile(EDITOR_CONFIG_FILE):
        config_file = file(EDITOR_CONFIG_FILE, 'r')
        if check_config_header(config_file) == True:
            txtcodec.read_config(config_file)
            favdocs.read_config(config_file)
            miscconf.read_config(config_file)
        config_file.close()
        apply_editor_settings()

def apply_editor_settings():
    """
    Apply certain editor parameters read from the configuration file
    or set by the user.
    """
    global miscconf, default_path
    current_text = appuifw.app.t.get()
    current_pos  = appuifw.app.t.get_pos()
    tmp = miscconf.get_font()
    if not tmp == None: appuifw.app.t.font  = tmp
    tmp = miscconf.get_font_color()
    if not tmp == None: appuifw.app.t.color = tmp
    appuifw.app.t.clear()
    appuifw.app.t.set(current_text)
    appuifw.app.t.set_pos(current_pos)

    default_path = miscconf.get_initial_work_directory()
    if default_path == '<not selected>':
        default_path = None
    appuifw.app.screen = miscconf.get_screen_mode()

#=
#= Directory and file selection
#=
def select_file(default_path, message):
    sel = pyS60uiutil.dirBrowser(message).select(default_path)
    if sel == None or sel == ('', ''):
        return None
    else:
        return sel

#=
#= Saving
#=
def convert_text(teksti, codec):
    """
    Converts the unicoded text to a format specified by codec; such as
    'ascii', 'iso-8859-1', or 'latin-1'.
    """
    cnt_euro = cnt_parag = cnt_other = i = 0
    output = ''
    while 1:
        try:
            #= First lets see whether a character encodes properly, i.e.,
            #= encode the character using 'strict' (default) conversion.
            output = output + teksti[i].encode(codec)
        except UnicodeError:
            #= If the character does not encode properly lets see whether it is
            #= something that can be converted to a character that closely
            #= looks like the original one. If we have no replacement for it
            #= then lets encode the character again using 'replace' mode
            #= meaning that Python inserts 'question mark' in the place of the
            #= original character.
            # print u'Uncodable (iso) char >' + teksti[i] + u'<'
            # print ord(teksti[i])
            if teksti[i] == u'\u20ac':
                #= 'Euro sign'
                output = output + 'e'
                cnt_euro += 1
            elif teksti[i] == u'\u2029':
                #= 'New Line' which is actually 'paragraph separator'.
                output = output + '\n'
                cnt_parag += 1
            else:
                #= Instead of calling encode() we could insert the question
                #= mark immediately. Well, in this way we ensure 'standard
                #= operation'.
                output = output + teksti[i].encode(codec, 'replace')
                cnt_other += 1
        except IndexError:
            break
        i = i + 1
    if cnt_euro or cnt_other:
        #= Lets inform the user that all the characters could not be saved as
        #= they were originally. However, 'paragraph separator' -> 'new line'
        #= conversion is not error but merely natural behavior.
        msg = u''
        if cnt_other:
            msg += unicode(str(cnt_other)) + u' chars replaced with ?\n'
        if cnt_euro:
            msg += unicode(str(cnt_euro)) + u' ' + u'\u20ac' + \
                   u' replaced with e\n'
        appuifw.note(msg, 'info')        
    return output

def save(file_name, text, codec):
    #= If the text is being saved in other than 'UTF-8' or 'UTF-16' coding
    #= all the used characters may not be supported. The euro sign and 'new
    #= line' used in Text UI control are some examples.
    #= Since Python 2.2 does not support codec.register_error (available on
    #= Python 2.3 onwards) lets do conversion in a hard way, i.e., call
    #= a function to do appropriate conversion.
    if not ((codec == 'utf-8') or (codec == 'utf-16')):
        text = convert_text(text, codec)
    else:
        text = text.encode(codec)
    mfile = file(file_name, 'wb')
    mfile.write(text)
    mfile.close()

def save_file_as(teksti):
    """
    Note: the content of the currently active document is not necessarily up
    to date in the 'doc' object.
    """
    global doc_list, txtcodec, default_path
    path = select_file(default_path, 'Select directory')
    if path == None:
        appuifw.note(u'File NOT saved', 'info')
        return
    default_path = path[0]
    fname = appuifw.query(u'Type file name', 'text', unicode(path[1]))
    if fname == None:
        appuifw.note(u'File NOT saved', 'info')
        return
    full_doc_name = os.path.join(path[0], fname)

    if os.path.isdir(full_doc_name):
        appuifw.note(u'Cannot overwrite directory', 'error')
        return
    if os.path.isfile(full_doc_name):
        if not appuifw.query(unicode('Overwrite ' + full_doc_name + '?'),
                             'query'):
            appuifw.note(u'File NOT saved', 'info')
            return
    try:
        codec = txtcodec.get_codec(doc_list.get_active_doc().get_codec())
        save(full_doc_name, teksti, codec)
        doc_list.get_active_doc().set_full_name(full_doc_name)
        appuifw.note(u'File saved', 'conf')
    except UnicodeError,detail:
        appuifw.note(u'Error while saving!\n' + unicode(detail),
                     'error')
    #except:
    #    appuifw.note(u'Error while saving!', 'error')

def save_file(teksti):
    """
    Note: the content of the currently active document is not necessarily up
    to date in the 'doc' object.
    """
    global doc_list
    name = doc_list.get_active_doc().get_full_name()
    if name == '<noname>':
        save_file_as(teksti)
    else:
        global txtcodec
        codec = txtcodec.get_codec(doc_list.get_active_doc().get_codec())
        try:
            save(name, teksti, codec)
            appuifw.note(u'File saved', 'conf')
        except UnicodeError,detail:
            appuifw.note(u'Error while saving!\n' + unicode(detail),
                         'error')
        #except:
        #    appuifw.note(u'Error while saving!', 'error')

#=
#= Loading and inserting
#=
def load(file_name, codec=None):
    """
    Load the given file. If the text codec is not provided the user will be
    prompted to select one. In the case the user is prompted to select codec
    the codec will be used for this document unless otherwise commanded.
    """
    if codec == None:
        global txtcodec
        menu = txtcodec.get_unicoded_codec_lst()
        codec_ix = appuifw.popup_menu(menu)
        if codec_ix == None: return None, None
        codec = txtcodec.get_codec(codec_ix)
    else:
        #= Since the codec is already known, no need to return index here.
        codec_ix = None
    mfile = file(file_name, 'r')
    teksti = mfile.read() #= reads everything.
    mfile.close()
    return teksti.decode(codec), codec_ix

def insert_file():
    global default_path

    s = select_file(default_path, 'Select file to insert')
    if s == None:
        appuifw.note(u'No file loaded!', 'info');
        return
    default_path = s[0]
    full_doc_name = os.path.join(s[0], s[1])
    if os.path.isdir(full_doc_name):
            appuifw.note(u'Cannot insert a directory!', 'error')
            return
    try:
        teksti, dummy = load(full_doc_name)
        if teksti == None: return
    except UnicodeError, detail:
        appuifw.note(u'Error while reading!\n' + unicode(detail),
                     'error')
        return
    #except:
    #    appuifw.note(u'Error while reading!', 'error')
    #    return
    appuifw.app.t.add(unicode(teksti))

def load_file(full_doc_name):
    if os.path.isdir(full_doc_name):
        appuifw.note(u'Cannot load a directory!', 'error')
        return
    if not os.path.isfile(full_doc_name):
        appuifw.note(u'File does not exist', 'error')
        return
    try:
        teksti, codec_ix = load(full_doc_name)
        if teksti == None: return
    except UnicodeError, detail:
        appuifw.note(u'Error while reading!\n' + unicode(detail), 'error')
        return
    #except:
    #    appuifw.note(u'Error while reading!', 'error')
    #    return
    if ((doc_list.get_nr_of_docs() == 1) and
        (doc_list.get_active_doc().get_full_name() == '<noname>') and
        (appuifw.app.t.len() == 0)):
        #= If only one doc exists, it has no name and its empty
        #= then 'overwrite' the document because it's the initial
        #= document.
        doc = doc_list.get_active_doc()
        doc.set_full_name(full_doc_name)
        doc.set_codec(codec_ix)
    else:
        doc = document()
        doc.set_full_name(full_doc_name)
        doc.set_codec(codec_ix)
        doc_list.add_doc(doc)
        switch_to_doc(doc)
    #= Note: the loaded content will be saved to 'doc' when switched to
    #= another doc so no need to do it here.
    appuifw.app.t.set(unicode(teksti))
    appuifw.app.t.set_pos(0)
    options_menu_h.set_menu()
    
def load_document():
    global default_path
    s = select_file(default_path, 'Select file to load')
    if s == None:
        appuifw.note(u'No file loaded!', 'info');
        return
    default_path = s[0]
    load_file(os.path.join(s[0], s[1]))

def load_favorite():
    global favdocs
    menu = favdocs.get_unicoded_doc_lst()
    ix = appuifw.popup_menu(menu)
    if ix == None or menu[ix] == unicode('<not selected>'): return
    load_file(favdocs.get_doc(ix))

#=
#= Switch to anoher open document.
#=
def switch_to_doc(doc):
    global doc_list
    active_doc = doc_list.get_active_doc()
    if not active_doc == None:
        #= Save the latest information of the currently active document
        active_doc.set_content(appuifw.app.t.get())
        active_doc.set_position(appuifw.app.t.get_pos())
    #= Insert the new document
    doc.set_content_visible()
    appuifw.app.t.set_pos(doc.get_position())
    doc_list.set_active_doc(doc)

#=
#= Select document from the list of open docs.
#=
def select_doc_from_list():
    global doc_list
    ix = appuifw.popup_menu(doc_list.get_name_list(True))
    if ix == None: return
    switch_to_doc(doc_list.get_doc_by_index(ix))

#=
#= SMS
#=
def send_as_sms():
    """
    Send currently active document using SMS.
    """
    # Note: cannot use the number mode for querying the recipient number for
    #       two reasons. 1) not possible to add '+' 2) if the number begins
    #       with zero the leading zero(es) is dropped from then answer.
    #
    #       Maximum short message length is 160 characters. The longer messages
    #       will be send in several separate messages.
    length = appuifw.app.t.len()
    if not length:
        appuifw.note(u'Nothing to send!', 'info');
        return
    nr_of_messages = (length / 160) + 1
    if nr_of_messages > 1:
        if not appuifw.query(unicode('Requires ' + str(nr_of_messages) + \
                                     ' messages. Continue?'), 'query'): return
    recipient = appuifw.query(u'Recipients number', 'text')
    if recipient == None: return
    i = 0
    while i < nr_of_messages:
        messaging.sms_send(str(recipient), appuifw.app.t.get(i*160,160))
        i += 1
    appuifw.note(unicode(str(nr_of_messages)) + u' messages sent.', 'conf')

#=
#= Sentences
#=
def load_sentences_file(file_to_load=None):
    sentence_list = None
    if file_to_load == None:
        s = select_file(None, 'Select sentences to load')
    else:
        s = os.path.split(file_to_load)
    if s == None:
        appuifw.note(u'No sentences loaded!', 'info');
    else:
        snt_file = os.path.join(s[0], s[1])
        if os.path.isdir(snt_file):
            appuifw.note(u'Cannot load a directory!', 'error')
        else:
           try:
               #= The sentence list is always coded using utf-16.
               sentence_list, dummy = load(snt_file, 'utf-16')
           except UnicodeError, detail:
               appuifw.note(u'Error while reading!\n' + unicode(detail),
                            'error')
           except:
               appuifw.note(u'Error while reading!', 'error')
    sentences = []
    if not sentence_list == None:
        for item in sentence_list.splitlines():
            #= Make sure the reserved 'word' is dropped
            #= from the sentence list.
            if not item == '<load sentences>':
                sentences.append(unicode(item))
    sentences.append(u'<load sentences>')
    return sentences

def get_sentence():
    #=  Create a menu that can be used to select certain senteces.
    #=  Also one that can be used to select loading a new file...
    global sentences_list
    sentence_items = sentences_list
    ix = appuifw.popup_menu(sentence_items)
    if ix == None: return u''
    sentence = sentence_items[ix]
    if sentence[:11] == u'<tabulator>':
        words = sentence[11:].split('+', 1)
        try:
            sentence = u' '*int(words[0])
            if len(words) > 1: sentence += words[1]
        except:
            sentence = u''
    if sentence == u'<load sentences>':
        sentences_list = load_sentences_file()
        sentence = u''
    return sentence

def set_default_sentences_file():
    global sentences_list, miscconf
    snt_file = miscconf.get_default_sentences_file()
    if snt_file == '<not selected>':
        sentences_list = [u'<tabulator>4',
                          u'<tabulator>1+- ',
                          u'<tabulator>5+* ',
                          u'<tabulator>9+o ',
                          u'<load sentences>']
    else:
        sentences_list = load_sentences_file(snt_file)
    
#=
#= Document info
#=
def get_doc_info():
    global doc_list, txtcodec
    s1 = u'Chars: ' + unicode(appuifw.app.t.len())
    s2 = u'Codec: ' + \
         unicode(txtcodec.get_codec(doc_list.get_active_doc().get_codec()))
    s3 = u'Name: ' + unicode(doc_list.get_active_doc().get_full_name())
    return s1 + u'\n' + s2 + u'\n' + s3

#=
#= Create a new document
#=
def create_document():
    global doc_list, txtcodec
    doc = document()
    doc.set_codec(txtcodec.get_default_codec_index())
    doc_list.add_doc(doc)
    switch_to_doc(doc)
    options_menu_h.set_menu()

#=
#= Close document
#=
def close_document():
    """
    Closes currently active document. If this is the last document then a new
    one is created automatically.
    """
    if appuifw.app.t.len():
        if not appuifw.query(u'Want to close current document?', 'query'):
            return
    global doc_list
    doc_list.del_doc()
    if doc_list.get_nr_of_docs() == 0:
        create_document()
    else:
        doc = doc_list.get_active_doc()
        doc.set_content_visible()
        appuifw.app.t.set_pos(doc.get_position())
        options_menu_h.set_menu()

#=
#= File manager handling
#=
def file_manager_installation_path():
    #= If pyFileManager has been installed it should be located in
    #= one of the following directories.
    lookup_dirs = ['C:\system\Apps\pyFileMngrS60\default.py', \
                   'E:\System\Apps\pyFileMngrS60\default.py', \
                   'C:\system\Apps\Python\my\pyFileManager.py', \
                   'E:\System\Apps\Python\my\pyFileManager.py', \
                   os.path.join(str(os.path.split(appuifw.app.full_name())[0]),
                                'my\pyFileManager.py')]
    for dir in lookup_dirs:
        if os.path.isfile(dir): return dir
    return None

def run_file_manager():
    #= The pyFileManager could be integrated to the pyEdit but in order
    #= to keep the editor smaller lets keep the pyFileManager as
    #= a separate program.
    __fmgrpath__ = file_manager_installation_path()
    if __fmgrpath__ == None:
        appuifw.note(u'pyFileManager not installed!', 'error')
        return
    #= Save the current editor application info before executing the file
    #= manager. Once the file manager exits restore the editor app info.
    #= Lets set screen size to 'normal' before execution since the file
    #= manager does not handle it, yet.
    edit_app_info = pyS60uiutil.save_current_app_info()
    appuifw.app.screen = 'normal'
    execfile(__fmgrpath__, locals())
    pyS60uiutil.restore_app_info(edit_app_info)

#=
#= About
#=
def about_pyEditS60():
    fv = pyS60uiutil.fileViewer('About pyEdit')
    fv.load(os.path.join(os.path.split(appuifw.app.full_name())[0],
                         'pyedits60about.txt'))
    fv.view()

#=
#= Help
#=
def help_pyEditS60():
    fv = pyS60uiutil.fileViewer('Help pyEdit', joystick=True)
    fv.load(os.path.join(os.path.split(appuifw.app.full_name())[0],
                         'pyedits60help.txt'))
    fv.view()

#=
#= Copy/Cut'n'Paste
#=
class selection_param_t:
    """
    Data type used for storing text region selection parameters.
    """
    def __init__(self):
        self.sp  = None #= start position
        self.ep  = None #= end position
        self.off = None #= 1 if start char is newline; 0 otherwise
        self.content = None #= Original text

def paste_clipboard():
    global clipboard_content
    if clipboard_content:
        appuifw.app.t.add(clipboard_content)

def text_region_start():
    global options_menu_h, selprm
    options_menu_h.set_selection_state(True)
    options_menu_h.set_menu()
    selprm = selection_param_t()
    selprm.sp = appuifw.app.t.get_pos()
    selprm.content = appuifw.app.t.get()
    #= If the char in the start position is newline add space to make
    #= highlighting visible. Space will be removed once selection has
    #= been made
    chr = appuifw.app.t.get(selprm.sp, 1)
    if chr == u'\u2029':
        appuifw.app.t.add(u' ')
        selprm.off = 1
        chr = u' '
    else: selprm.off = 0
    appuifw.app.t.delete(selprm.sp, 1)
    appuifw.app.t.set_pos(selprm.sp)
    appuifw.app.t.style = appuifw.STYLE_BOLD | \
                          appuifw.STYLE_UNDERLINE | \
                          appuifw.HIGHLIGHT_ROUNDED
    appuifw.app.t.add(chr)
    appuifw.app.t.style = 0
    appuifw.app.t.set_pos(selprm.sp)

def text_region_cancel():
    global options_menu_h, selprm
    options_menu_h.set_selection_state(False)
    options_menu_h.set_menu()
    appuifw.app.t.clear()
    appuifw.app.t.set(selprm.content)
    appuifw.app.t.set_pos(selprm.sp)
    del selprm
    
def text_region_end(operation):
    global options_menu_h, selprm, clipboard_content    
    options_menu_h.set_selection_state(False)
    options_menu_h.set_menu()
    selprm.ep = appuifw.app.t.get_pos()
    if (selprm.sp == selprm.ep) or (selprm.sp + selprm.off == selprm.ep):
        #= No real selection -> same as cancel
        text_region_cancel()
        return
    if selprm.sp < selprm.ep:
        selected_text = selprm.content[selprm.sp : selprm.ep - selprm.off]
        if operation == 'cut':
            selprm.content = selprm.content[ : selprm.sp] + \
                             selprm.content[selprm.ep - selprm.off : ]
        clipboard_content = selected_text
        cursor_position = selprm.ep - selprm.off
    elif selprm.sp > selprm.ep:
        selected_text = selprm.content[selprm.ep : selprm.sp + 1]
        if operation == 'cut':
            selprm.content = selprm.content[ : selprm.ep] + \
                             selprm.content[selprm.sp + 1: ]
        clipboard_content = selected_text
        cursor_position = selprm.ep
    appuifw.app.t.clear()
    appuifw.app.t.set(selprm.content)
    appuifw.app.t.set_pos(cursor_position)
    #= Show the content of the selected text region.
    appuifw.note(unicode(selected_text), 'info')
    del selprm
    
#=
#= Options menu handling
#=
class options_menu:
    """
    Handles the main options menu. The menu is 'dynamic', i.e., it changes
    according to the operations performed by the user.
    """
    def __init__(self):
        #= If the pyFileManager has been installed add it to the options menu.
        self.filemngrpath = file_manager_installation_path()
        self.selection_active = False

    def set_selection_state(self, state):
        """
        False - normal operation, True - selection
        """
        self.selection_active = state
    
    def set_menu(self):
        """
        Create and set main options menu.
        """
        global doc_list
        
        if self.selection_active:
            appuifw.app.menu = [(u'Copy selection', \
                                 lambda: text_region_end('copy')),
                                (u'Cut selection', \
                                 lambda: text_region_end('cut')),
                                (u'Cancel selection', text_region_cancel)]
        else:
            appuifw.app.menu = [(u'Sentences',
                                 lambda: appuifw.app.t.add(get_sentence())),
                                (u'Start selection', text_region_start),
                                (u'Paste clipboard', paste_clipboard)]

            nr = doc_list.get_nr_of_docs()
            if nr > 1:
                item = unicode('Switch document (' + str(nr) + ')')
                appuifw.app.menu.append((item, select_doc_from_list))
        
            #= Sub-menu for loading and inserting from a file
            sub_menu_load = ((u'Favorites', load_favorite),
                             (u'Load', load_document),
                             (u'Insert', insert_file))
            appuifw.app.menu.append((u'Load / Insert', sub_menu_load))

            #= Sub-menu for saving to a file
            sub_menu_save = ((u'Save',
                              lambda: save_file(appuifw.app.t.get())),
                             (u'Save as',
                              lambda: save_file_as(appuifw.app.t.get())))
            appuifw.app.menu.append((u'Save (as)', sub_menu_save))
        
            appuifw.app.menu.append((u'Document info', lambda: \
                                     appuifw.note(get_doc_info(), 'info')))
            appuifw.app.menu.append((u'New', create_document))
            appuifw.app.menu.append((u'Close', close_document))

            appuifw.app.menu.append((u'Settings', editor_settings))

            #= Sub-menu for tools
            sub_menu_tools = ((u'Send as text message', send_as_sms),)
            if not self.filemngrpath == None:
                sub_menu_tools += ((u'File manager', run_file_manager),)
            appuifw.app.menu.append((u'Tools', sub_menu_tools))
            
        #= These should be available always.
        sub_menu_help = ((u'Help', help_pyEditS60),
                         (u'About', about_pyEditS60))
        appuifw.app.menu.append((u'Help', sub_menu_help))

#=
#= Document holder
#=
class document:
    """
    Document info.
    """
    def __init__(self, full_name='<noname>'):
        self.codec_ix = 0
        self.full_name = full_name
        self.content = u''
        self.cursor_position = 0

    def get_codec(self):
        return self.codec_ix

    def set_codec(self, codec_ix):
        self.codec_ix = codec_ix

    def get_path(self):
        return os.path.split(self.full_name)[0]

    def get_name(self):
        return os.path.split(self.full_name)[1]

    def get_full_name(self):
        return self.full_name

    def set_full_name(self, full_name):
        self.full_name = full_name

    def set_position(self, pos):
        self.cursor_position = pos

    def get_position(self):
        return self.cursor_position
    
    def set_content_visible(self):
        """
        Set the content of the document visit in Text UI control.
        The content in 'doc' will be removed in order to save memory.
        """
        appuifw.app.t.clear()
        if self.content == None: return
        appuifw.app.t.set(self.content)
        self.content = None

    def set_content(self, content):
        """
        Set new content for the document.
        """
        self.content = content

#=
#= Document list handler
#=
class document_list:
    """
    Keeps track on currently open documents.
    """
    def __init__(self):
        self.doc_list = []
        self.active_ix = None

    def add_doc(self, doc):
        self.doc_list.append(doc)

    def del_doc(self):
        #= Note, only currently active doc can be deleted.
        self.doc_list.remove(self.get_active_doc())
        if len(self.doc_list) == 0:
            self.active_ix = None
        else:
            self.active_ix = 0

    def get_nr_of_docs(self):
        return len(self.doc_list)

    def get_name_list(self, mark_active=False):
        list = []
        if mark_active:
            active_doc = self.doc_list[self.active_ix] 
            for i in self.doc_list:
                if i == active_doc:
                    list.append(unicode('*'+i.get_name()))
                else:
                    list.append(unicode(' '+i.get_name()))
        else:
            for i in self.doc_list:
                list.append(unicode(i.get_name()))
        return list

    def set_active_doc(self, doc):
        self.active_ix = self.doc_list.index(doc)

    def get_active_doc(self):
        if self.active_ix == None: return None
        return self.doc_list[self.active_ix]

    def get_doc_by_index(self, index):
        return self.doc_list[index]

#=
#= The editor
#=
def pyEditorS60():
    global txtcodec, favdocs, miscconf
    global options_menu_h, doc_list
    global clipboard_content, default_path
    
    #= Check if the currently installed pyS60uiutil module version is
    #= compatible with this version of pyEdit.
    if pyS60uiutil.version_compatibility((0,4)) == False:
        msg = 'pyS60uiutil\nversion %d.%d.%d\ntoo old' % pyS60uiutil.version
        appuifw.note(unicode(msg), 'error')
        return

    old_app_gui_data = pyS60uiutil.save_current_app_info()
    appuifw.app.title = u'pyEdit for S60'
    appuifw.app.t = appuifw.Text(u'')
    appuifw.app.body = appuifw.app.t

    clipboard_content = None
    default_path = None

    txtcodec = text_codecs()
    favdocs  = favorite_docs()
    miscconf = miscconfig()
    read_editor_settings()    

    set_default_sentences_file()
    stick = pyS60uiutil.jumpTextCursorWithJoystick(appuifw.app.t)

    doc_list = document_list()
    initial_doc = document()
    initial_doc.set_codec(txtcodec.get_default_codec_index())
    doc_list.add_doc(initial_doc)
    doc_list.set_active_doc(initial_doc)
    
    def my_exit():
        global doc_list
        nr = doc_list.get_nr_of_docs()
        cnf = True
        if nr > 1:
            cnf = appuifw.query(unicode('Want to exit?\n' + str(nr) +\
                                        ' open docs.'), 'query')
        elif appuifw.app.t.len():
            cnf = appuifw.query(u'Want to exit?', 'query')
        if not cnf: return
        pyS60uiutil.restore_app_info(old_app_gui_data)
        escript_lock.signal()
    appuifw.app.exit_key_handler = my_exit

    options_menu_h = options_menu()
    options_menu_h.set_menu()

    escript_lock.wait() #= Wait for exiting...
    
if __name__ == '__main__':
    localpath = str(os.path.split(appuifw.app.full_name())[0])
    localpath = os.path.join(localpath, 'my')
    EDITOR_CONFIG_FILE = os.path.join(localpath, EDITOR_CONFIG_FILE)
    pyEditorS60()
