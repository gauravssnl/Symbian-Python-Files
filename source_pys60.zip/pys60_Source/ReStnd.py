import appuifw,keypress,e32,appswitch,os,audio
def ru(x):return x.decode('utf-8')
app_lock=e32.Ao_lock()

round = appuifw.Text()
appuifw.app.screen='normal'
round.set(u'              by G.F.Ferre')
appuifw.app.body=round

IconPath='e:\\system\\apps\\ReStnd\\ReStnd.aif'
PathS='e:\\system\\apps\\ReStnd\\others\\sound.mp3'

if os.path.exists(PathS):
 PathS=audio.Sound.open('e:\\system\\apps\\ReStnd\\others\\sound.mp3')
 IconPath='e:\\system\\apps\\ReStnd\\ReStnd.aif'
else:
 PathS=audio.Sound.open('c:\\system\\apps\\ReStnd\\others\\sound.mp3')
 IconPath='c:\\system\\apps\\ReStnd\\ReStnd.aif'

def exit():
 app_lock.signal()
 appuifw.app.set_exit()
def folders7():
 if appuifw.query(ru('Значки в меню расставлены?'),'query') == True:
  appuifw.note(ru('Ничего не жмите, до звукового сигнала'))
  appswitch.end_app(u'Menu') or appswitch.end_app(u'\u041c\u0435\u043d\u044e')
  appswitch.switch_to_fg(u'Phone') or appswitch.switch_to_fg(u'Telephone') or appswitch.switch_to_fg(u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d')
  e32.start_exe('z:\\system\\programs\\apprun.exe','z:\\system\\apps\\Menu\\Menu.app')
  os.rename(IconPath,IconPath+'_fr')
  keypress.simulate_key(63495,63495)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63497,63497)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63554,63554)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(9)
  keypress.simulate_key(63554,63554)
  PathS.play()
  os.rename(IconPath+'_fr',IconPath)
 else:
  appuifw.note(ru('Отменено'))
  return
def folders8():
 if appuifw.query(ru('Значки в меню расставлены?'),'query') == True:
  appuifw.note(ru('Ничего не жмите, до звукового сигнала'))
  appswitch.end_app(u'Menu') or appswitch.end_app(u'\u041c\u0435\u043d\u044e')
  appswitch.switch_to_fg(u'Phone') or appswitch.switch_to_fg(u'Telephone') or appswitch.switch_to_fg(u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d')
  e32.start_exe('z:\\system\\programs\\apprun.exe','z:\\system\\apps\\Menu\\Menu.app')
  os.rename(IconPath,IconPath+'_fr')
  keypress.simulate_key(63495,63495)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63497,63497)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63554,63554)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(9)
  keypress.simulate_key(63554,63554)
  PathS.play()
  os.rename(IconPath+'_fr',IconPath)
 else:
  appuifw.note(ru('Отменено'))
  return
def rename7():
 if appuifw.query(ru('Значки в меню расставлены?'),'query') == True:
  appuifw.note(ru('Ничего не жмите, до звукового сигнала'))
  appswitch.end_app(u'Menu') or appswitch.end_app(u'\u041c\u0435\u043d\u044e')
  appswitch.switch_to_fg(u'Phone') or appswitch.switch_to_fg(u'Telephone') or appswitch.switch_to_fg(u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d')
  e32.start_exe('z:\\system\\programs\\apprun.exe','z:\\system\\apps\\Menu\\Menu.app')
  os.rename(IconPath,IconPath+'_fr')
  keypress.simulate_key(63495,63495)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63497,63497)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63554,63554)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(9)
  keypress.simulate_key(63554,63554)
  PathS.play()
  os.rename(IconPath+'_fr',IconPath)
 else:
  appuifw.note(ru('Отменено'))
  return
def rename8():
 if appuifw.query(ru('Значки в меню расставлены?'),'query') == True:
  appuifw.note(ru('Ничего не жмите, до звукового сигнала'))
  appswitch.end_app(u'Menu') or appswitch.end_app(u'\u041c\u0435\u043d\u044e')
  appswitch.switch_to_fg(u'Phone') or appswitch.switch_to_fg(u'Telephone') or appswitch.switch_to_fg(u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d')
  e32.start_exe('z:\\system\\programs\\apprun.exe','z:\\system\\apps\\Menu\\Menu.app')
  os.rename(IconPath,IconPath+'_fr')
  keypress.simulate_key(63495,63495)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63497,63497)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63496,63496)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63554,63554)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(0.1)
  keypress.simulate_key(63498,63498)
  e32.ao_sleep(9)
  keypress.simulate_key(63554,63554)
  PathS.play()
  os.rename(IconPath+'_fr',IconPath)
 else:
  appuifw.note(ru('Отменено'))
  return
def about():
 appuifw.note(u'ReStnd v.0.01\nby G.F.Ferre\nDimonVideo.ru')

appuifw.app.menu=[(ru('Папка в папке'),((ru('Для 7ой оси'),folders7),(ru('Для 8-8.1 осей'),folders8))),(ru('Переименовать'),((ru('Для 7ой оси'),rename7),(ru('Для 8-8.1 осей'),rename8))),(ru('О проге'),about),(ru('Выход'),exit)]
appuifw.app.exit_key_handler=exit
app_lock.wait()