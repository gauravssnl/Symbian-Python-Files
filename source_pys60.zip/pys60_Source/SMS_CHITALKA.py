# -*- coding: utf-8 -*-
# writer fann95
import graphics
import topwindow
import appuifw
import inbox
import e32
import audio
import sys
import appuifw
sys.setdefaultencoding("utf-8")
id=0
def ru(x):return x.decode("utf-8")

def mess(id_mess):
 global id
 global sms_topwindow,sms_Image
 sms_topwindow = topwindow.TopWindow()
 id=id_mess
 x_max,y_max = sms_topwindow.maximum_size
 sms_topwindow.size = (x_max,y_max)
 sms_topwindow.fading =1
 e32.ao_sleep(1)
 adresat=sms.address(id)
 mes=sms.content(id)
 sms_topwindow.show()
 sms_Image = graphics.Image.new((x_max-5,y_max-5))
 sms_Image.text((5,10),("  ОТ   "+"   "+adresat))
 sms_Image.text((5,20),("     "+mes))
 sms_Image.text((-x_max+5,40),("     "+mes))
 sms_Image.text((-x_max*2+10,60),("     "+mes))
 sms_Image.text((-x_max*3+15,80),("     "+mes))
 sms_Image.text((-x_max*4+20,80),("     "+mes))
 sms_Image.text((-x_max*5+25,100),("     "+mes))
 sms_topwindow.add_image(sms_Image,(5,5))
 
 audio.say("получено новое сообщение")
 e32.ao_sleep(1)
 audio.say("отправитель")
 e32.ao_sleep(1)
 audio.say(adresat)
 audio.say("текст сообщения")
 e32.ao_sleep(1.5)
 audio.say(mes)
 e32.ao_sleep(5) 
 sms_topwindow.hide()     



prog_lock=e32.Ao_lock()
old_title=appuifw.app.title
appuifw.app.title=(ru("SMSvoice1.0"))
round=appuifw.Text()
appuifw.app.screen="normal"
round.set(ru("        программа от FANN95"+"\n"+"\n"+"\n"+"    ожидаем входящее смс"))
appuifw.app.body=round
sms=inbox.Inbox()
sms.bind(mess)
def exit():
    if appuifw.query(ru("хочеш выйти?"),"query")==1:
       appuifw.app.title=old_title
       appuifw.app.set_exit()
    else:
       appuifw.note(ru("отмена"))
appuifw.app.menu=[(ru("выход"),exit)]
prog_lock.wait()
