
import appuifw

appuifw.note(u"Hello")

appuifw.note(u"File not found", "error")

appuifw.note(u"Upload done", "conf")
