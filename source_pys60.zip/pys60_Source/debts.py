import appuifw
import os
import e32
import time
import uikludges  

def ru(x):
  return x.encode('utf-8')
def ur(x):
  return x.decode('utf-8')


class Dolgi:
  def __init__(self):
    self.script_lock = e32.Ao_lock()

  def anote(self, mess):
    appuifw.note(mess,"info")
  def aerror(self, mess):
    appuifw.note(mess,"error")
  
  def extension(self,x): 
    return os.path.splitext(x)[1].lower() == ".db" 
    
  def run(self):
    if os.path.exists('e:/system/apps/debts/debts.app') == 1:
      self.dpath = u"E:\\System\\Apps\\Debts\\Base\\"
    else:
      self.dpath = u"C:/System/Apps/Debts/Base/"
    if not os.path.exists(self.dpath):
      try:
        os.mkdir(self.dpath)
      except:None
    if not os.path.exists(self.dpath):
      aerror(ur("Нет доступа к папке с данными"))
      return
      
    self.showbase()
    self.script_lock.wait()
    appuifw.app.body = None
    self.lb = None

  def get_info(self,filename):
    try:
      self.file = open(ru(filename))
      self.who = ur(self.file.readline())[:-1]
      #self.file.readline()
      self.date = ur(self.file.readline())[:-1]
      #self.date = time.strptime(self.date,u"%d.%m.%Y") 
      #self.date = time.localtime(self.date)
      self.what = ur(self.file.readline())[:-1]
      self.file.close() 
    except:
      self.aerror(ur("Ошибка при работе с файлом ") + filename)
      return False
    return True  


  def showbase(self):
    try:
      appuifw.app.body=txt=appuifw.Text() 
      txt.focus = False
    except:
      None
      
    uikludges.set_right_softkey_text(u"Exit")
    self.who = ur("Вова Путин")
    self.what = u"1000000$"
    self.date = time.time()
    appuifw.app.exit_key_handler = self.exit_key_handler
    appuifw.app.menu =  [(ur("Записать"), self.createnew_item),
      						(ur("Посмотреть"),self.view_item),
      						(ur("Удалить"),self.delete_item),
      						(ur("Изменить"),self.edit_item),
      						(ur("О программе"),self.showabout)]
    #appuifw.app.body.clear()
    appuifw.app.body = None
    if os.path.exists(self.dpath): 
      self.flist = filter(self.extension, os.listdir(self.dpath))
      if (len(self.flist) == 0):
        self.anote (ur("Никто Вам ничего не должен :)"))
        return
      self.full = []
      for f in self.flist:
        if self.get_info(self.dpath+ur(f)): # получим записи в self: who date
          self.full.append((self.what,self.who + u" "+ self.date));
        
      #self.lb = appuifw.Listbox(map(unicode,self.flist), self.menupopup)
      if (len(self.full) == 0):
        self.anote (ur("Никто Вам ничего не должен :)"))
        return
      appuifw.app.title = ur("Долги ") + "[" +str(len(self.full))+ "]"
      self.lb = appuifw.Listbox(self.full, self.menupopup)
      self.lb.bind(8,self.deletion) 
      appuifw.app.body = self.lb
    else:
      self.anote(u"Path " + self.dpath + u" not found")
      self.exit_key_handler()

  def menupopup(self):
    self.ind = appuifw.popup_menu([ur("Записать"),ur("Посмотреть"),ur("Удалить"),ur("Изменить"),ur("О программе")])
    if self.ind == None:
      return
    elif self.ind == 0:
      self.createnew_item()
    elif self.ind == 1:
      self.view_item()
    elif self.ind == 2:
      self.deletion()
    elif self.ind == 3:
      self.edit_item()
    elif self.ind == 4:
      self.showabout()

  def showabout(self):
    self.anote(ur("Atrant\natrant@front.ru\nICQ:399976"))  
   
  def exit_key_handler(self):
    appuifw.app.exit_key_handler = None
    self.script_lock.signal()
    
  def edit_item(self):
    try:
      self.ind = self.lb.current()
      self.file = open(ru(self.dpath+ur(self.flist[self.ind]))) 
      self.who = ur(self.file.readline())[:-1]
      ur(self.file.readline())[:-1]
      #self.date = ur(self.file.readline())[:-1]
      #self.date = time.strptime(self.date,u"%d.%m.%Y")
      #self.date = time.localtime(self.date)
      self.what = ur(self.file.readline())[:-1]
      self.file.close()
    except:
      self.aerror(ur("Ошибка при работе с файлом"))
      return

    if self._createitem() == True:
      os.remove(ru(self.dpath+ur(self.flist[self.ind])))
    self.showbase()

  def deletion(self):
    self.delete_item()
  
  def delete_item(self):
    if appuifw.query(ur("Вы уверены?"),'query',True):
      try:
        os.remove(ru(self.dpath+ur(self.flist[self.lb.current()])))
      except:
        self.aerror(u"Couldn't delete file")
      self.showbase()
      
  def view_item(self):
    self.pristavka = (ur("  Кто: "),ur("Когда: "),ur("  Что: "))
    self.i = 0;
    self.t = appuifw.Text()
    appuifw.app.body = self.t
    #self.t.focus = False
    appuifw.app.body.clear()
    try:
      self.file = open(ru(self.dpath+ur(self.flist[self.lb.current()]))) 
      while (self.i < 3):
        self.s = ur(self.file.readline())
        self.t.color = (255,0,0)
        appuifw.app.body.add(self.pristavka[self.i])
        self.t.color = (0,0,255)
        appuifw.app.body.add(unicode(self.s))
        self.i+=1
      self.file.close()  
      appuifw.app.menu = [(u"Back",self.showbase)]
      appuifw.app.exit_key_handler = self.showbase
      uikludges.set_right_softkey_text(u"Back")
    except:
      self.aerror(ur("Ошибка при считывании файла"))
  def _createitem(self):
    self.who = appuifw.query(ur('КТО:'),'text',self.who) 
    if self.who == None:
      return
    self.what = appuifw.query(ur('ЧТО:'),'text',self.what)
    if self.what == None:
      return
    self.date = time.time()
    self.date = appuifw.query(ur('КОГДА:'),'date',self.date)
    if self.date == None:
      return
    self.date = time.localtime(self.date)
    self.date = time.strftime(u"%d.%m.%Y",self.date)
    self.uniquename = time.strftime(u"%Y%m%d_%H%M%S",time.localtime())
    self.who = ru(self.who+"\n")
    self.what = ru(self.what+"\n")
    self.date = ru(self.date+"\n")
    #self.uniquename = self.dpath+ur(self.what[:-1] + self.uniquename+".db")
    self.uniquename = self.dpath+ ur(self.what[:-1] + self.uniquename+".db")

    try:
      self.file = open(ru(self.uniquename),'w+')
      self.file.write(self.who)
      self.file.write(self.date)
      self.file.write(self.what)
      self.file.close()
    except:
      self.aerror(ur("Ошибка при записи файла"))
      return False
    return True

  def createnew_item(self):
    self._createitem()
    self.showbase()

appuifw.app.body=txt=appuifw.Text()
appuifw.app.title = ur("Долги")
Dolgi().run()    
txt.focus = True
uikludges.set_right_softkey_text(u"Exit")

appuifw.app.set_exit() 
