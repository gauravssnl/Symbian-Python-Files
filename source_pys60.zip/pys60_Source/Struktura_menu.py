import appuifw
import e32
import os
import switchoff
# импортируем нужные модули

def ru(x):
  return x.decode('utf-8')
# пишем по-русски

def exit_key_handler():
  app_lock.signal()
# задаем кнопку выхода
app_lock=e32.Ao_lock()


if not os.path.isdir('E:/dioc'):
    os.makedirs('E:/dioc')
# если отсутствует,то создаем папку dioc

appuifw.app.body=k=appuifw.Canvas()
appuifw.app.screen='full'
appuifw.app.title=(ru('меню'))
k.text((1,15),ru('несложная программа для'),0x0000f0,font=u'alp13')
k.text((1,25),ru('сохранения структуры меню'),0x0000f0,font=u'alp13')
k.text((1,35),ru('специально для сайта'),0x0000f0,font=u'alp13')
e32.ao_sleep(1.5)
k.text((1,50),ru('PYTHONS.RU'),0x00f000)
# создаем графическое окно программы и выводим на него надписи

def begin():
  appuifw.app.body=k=appuifw.Canvas()
  k.text((1,15),ru('1.Сохранить структуру меню'),0x005555)
  k.text((1,30),ru('2.Вернуть структуру меню'),0x005555)
  k.text((1,45),ru('3.Выход'),0x005555)
  k.bind(49,save)
  k.bind(50,save1)
  k.bind(51,exit)
# задаем графическое окно программы,которое будет использовано,как меню.И делаем привязку к клавишам.

def save():
    e32.file_copy('E:\dioc','C:\System\Data\Applications.dat')
    appuifw.note(ru('структура меню сохранена!'),'info')
# создаем функцию сохранения структуры меню.

def save1():
    e32.file_copy('C:\System\Data','E:\dioc\Applications.dat')
    appuifw.note(ru('структура меню восстановлена!'),'info')
    m=appuifw.query(ru('перезагрузить телефон?'),'query')
    if m==1:
        appuifw.note(ru('перезагрузка...'),'conf')
        switchoff.Restart()
# создаем функцию восстановления структуры меню и перезагрузки смарта.

def exit():
    appuifw.app.set_exit()
#вызываем выход из программы

appuifw.app.menu=[(ru('запуск'),begin)]

appuifw.app.exit_key_handler = exit_key_handler
# создаем меню и возвращаем функцию правой софт клавише