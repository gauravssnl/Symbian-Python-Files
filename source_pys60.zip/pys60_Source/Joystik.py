#by Nativ
#9.11.2007  00:30

import appuifw 
import keycapture
import keypress

def ru(x):
    return x.decode('utf-8')
def ur(x):
    return x.encode('utf-8')

def anote(mess):
  appuifw.note(mess,"info")

appuifw.app.screen = 'normal'
round=appuifw.Text()
round.color=(50,50,50)
appuifw.app.title = ru('Joystik')
round.add('')
round.set(ru('              Joystik v0.1  \n         Created by -=Nativ=-\n            идея   Rommyn \n\nДля работы должна постоянно висеть в трее!Для быстрого отключения используйте кнопку РТТ!'))
appuifw.app.body=round
appuifw.app.body.focus = False

def kl(k):keypress.simulate_key(k,k)

def levo():
  capturer.start()
  kl(63495)

def pravo():
  capturer.start()
  kl(63496)

def verx():
  capturer.start()
  kl(63497)

def niz():
  capturer.start()
  kl(63498)

def ok():
  capturer.start()
  kl(63557)

def off():
  capturer.stop()
  anote(ru('Клава отключена'))

def on():
  capturer.start()
  anote(ru('Клава включена'))

def hotkey(key):
    if (key == 52):
        levo()
    elif (key == 54):
        pravo()
    elif (key == 50):
        verx()
    elif (key == 56):
        niz()
    elif (key == 53):
        ok()
    elif (key == 63562):
        off()

capturer = keycapture.KeyCapturer(hotkey)
capturer.keys = (50,52,53,54,56,63562)
capturer.forwarding = 0
capturer.start()

def about():
  anote(ru("Joystik v.0.1 "))
  anote(u"Greated by Nativ\nnativ_1989@mail.ru")

def exit():
    if appuifw.query(ru('Хотите выйти?'),'query'):
        appuifw.app.set_exit()
        capturer.stop()

appuifw.app.exit_key_handler=exit

appuifw.app.menu = [(ru('Старт'),on),(ru('Стоп'),off),(ru('О проге...'),about),(ru('Выход'),exit)]
