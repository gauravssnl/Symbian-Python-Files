
import appuifw, audio

text = appuifw.query(u"Type a word:", "text")
audio.say(text)
