import os,e32,appuifw,keypress,appswitch,time,inbox,thread
from graphics import *
from key_codes import *
from graphics import *

class Logger:
    def __init__(self, log_name):
        self.logfile = log_name
        self.mutex = thread.allocate_lock()
        
    def write(self, obj):
        self.mutex.acquire()
        try:
            log_file = open(self.logfile, 'a')
            log_file.write(obj)
            log_file.close()
        finally:
            self.mutex.release()
        
    def writelines(self, obj):
        self.write(''.join(list))
        
    def flush(self):
        pass

class Main:
  def open_script(self,f):
    #try: Filed=open(f,'r')
    #except:
      #ui.error("open file")
    #  pass
    Filed=open(f,'r')
    file_data=Filed.readlines()
    Filed.close()
    script=[]
    for line in file_data:
      tmp=line.split('~')
      command=[]
      for do in tmp[1].split('|'):
        if do[-1:]=="\n": do=do[:-1]
        command.append(do)
      script.append((tmp[0], command))
    return script
	    
  def run_script(self,script,first):
    for line in script:
      key=line[0]
      command=line[1]
      if key=="app":
        if command[0]=="True":
            utils.run(command[1])
        else:
            app=command[1].split("\\")[-1][:-4]
            appswitch.switch_to_fg(app)
      elif key=="key":
        print "KEY: "+command[1]+"\n"
        if command[0][:1]=="+":
            e32.ao_sleep(float(command[0][1:]))
            keypress.simulate_key(utils.convert(command[1]), \
            utils.convert(command[1]))
        else:
            if first==True:
                calendar.add("time",key,command)
      elif key=="fg":
        if command[0][:1]=="+":
            e32.ao_sleep(float(command[0][1:]))
            command=(command[1],command[2])
            calendar.add("time",key,command)
            appswitch.switch_to_fg(u'Phone')
        else:
            if first==True:
                calendar.add("time","fg_time",command)
      elif key=="sms":
        #script2={}
        #i=1
        #while i<len(command):
        #  script2[command[0]].append(command[i])
        calendar.add("sms",key,command[1])
      elif key=="exit":
        if command[0][:1]=="+":
              e32.ao_sleep(float(command[0][1:]))
              exit()
        else:
          if first==True:
            command=(command[0],"",)
            calendar.add("time",key,command)
    
class Calendar:
  def add(self, task_type, key, command):
    global task_time, task_sms
    if task_type=="time":
      if command[0] not in task_time.keys():
        task_time[command[0]]=[key, command[1]]
	try:
	  task_time[command[0]].append(command[2])
	except IndexError:
	  pass
      else:
        #ui.error["time busy"]
	pass
    if task_type=="sms":
      task_sms=command
      
  def run(self):
    global run, task_time, task_sms, sms, in_box
    while run==True:
      now_time=time.strftime("%H.%M")
      print now_time
      if now_time in task_time:
        task=task_time.get(now_time)
	if task[0]=="key":
	  print "KEYa: "+task[1][:-2]+"\n"
          keypress.simulate_key(utils.convert(task[1]),\
          utils.convert(task[1]))
	elif task[0]=="fg_time":
	  print "FGTa: "+task[1]+", "+task[2]+"\n"
	  command=(task[1],task[2])
	  calendar.add("time","fg",command)
	  appswitch.switch_to_fg(u'Phone')
	elif task[0]=="fg":
	  print "FGa:"+task[1]+"\n"
	  appswitch.switch_to_fg(u""+task[1])
	elif task[0]=="exit":
          print "EXITa\n"
	  exit()
      if sms<len(in_box.sms_messages()):
	print "sms\n"
        sms+=1
	main.run_script(main.open_script(task_sms),True)
      e32.ao_sleep(60)
	
class UI:
  def __init__(self):
    appuifw.app.screen='normal'
    appuifw.app.title=u"Autokey v0.1"
    in_listbox=[utils.ru("Запустить скрипт"),utils.ru("Новый скрипт"), \
    utils.ru("Редактировать скрипт"),utils.ru("Настройки"),utils.ru("Помощь"), \
    utils.ru("О программе"),utils.ru("Выход")]
    self.lbox=appuifw.Listbox(in_listbox,self.press)
    appuifw.app.body=self.lbox
    lock()
    
  def press(self):
    select=self.lbox.current()
    if select==0: self.run()
    elif select==1: self.new()
    elif select==2: self.o_edit()
    elif select==3: self.setting()
    elif select==4: self.help()
    elif select==5: self.setting()
    elif select==6: exit()
     
  def run(self):
    self.files=utils.in_dir("e:\\Others\\Scripts")
    self.lbox2=appuifw.Listbox(self.files,self.press_open)
    appuifw.app.body=self.lbox2
    
  def new(self):
    name=appuifw.query(utils.ru("Имя скрипта:"), "text")
    if utils.create_file(name)==True:
      self.edit()
    else:
      self.__init__
    
  def o_edit(self):
    self.files=utils.in_dir("e:\\Others\\Scripts")
    self.lbox2=appuifw.Listbox(self.files,self.open2)
    appuifw.app.body=self.lbox2
    
  def edit(self):
    global gscript
    in_listbox=[]
    for line in gscript:
      if line[0]=="app":
        in_listbox.append(utils.ru("Приложение"))
      elif line[0]=="key":
        in_listbox.append(utils.ru("Клавиша: ")+line[1][1])
      elif line[0]=="fg":
        in_listbox.append(utils.ru("Спрятать"))
      elif line[0]=="sms":
        in_listbox.append(utils.ru("Приход смс"))
      elif line[0]=="exit":
        in_listbox.append(utils.ru("Выход"))
    try:
        self.lbox2=appuifw.Listbox(in_listbox,self.edit_item)
        appuifw.app.body=self.lbox2
    except ValueError:
        appuifw.app.body=appuifw.Text(utils.ru("Нет действий"))
    appuifw.app.exit_key_handler=self.__init__
    appuifw.app.menu = [(utils.ru("Добавить"), self.add_item),  (utils.ru("Удалить"), self.delete),  (utils.ru("Редактировать"), self.edit_item),  (utils.ru("Сохранить"), utils.save)]
    
  def help(self):
    pass
    
  def about(self):
    pass
    
  def press_open(self):
    global run
    select=self.lbox2.current()
    main.run_script(main.open_script("e:\\Others\\Scripts\\"+self.files[select]), True)
    if run==False:
      run=True
      calendar.run()

  def open2(self):
    global run, gscript, file
    select=self.lbox2.current()
    file="e:\\Others\\Scripts\\"+self.files[select]
    gscript=main.open_script(file)
    self.edit()
      
  def press_edit(self):
    pass
   
  def add_item(self):
    in_listbox=[]
    in_listbox.append(utils.ru("Приложение"))
    in_listbox.append(utils.ru("Клавиша: "))
    in_listbox.append(utils.ru("Спрятать"))
    in_listbox.append(utils.ru("Приход смс"))
    in_listbox.append(utils.ru("Выход"))
    self.lbox2=appuifw.Listbox(in_listbox,self.press_add)
    appuifw.app.body=self.lbox2
    appuifw.app.exit_key_handler=self.__init__
   
  def edit_item(self):
    global gscript
    current=self.lbox2.current()
    item=gscript[current]
    if item[0]=="app":
      if item[1][1]!="":
            title=item[1][1].split("\\" )[-1]
      else: title="Приложение"
      self.temp1=item[1][0]
      self.temp2=item[1][1]
      self.temp3=None
      self.boxe=appuifw.Listbox([utils.ru("Запускать: "+str(self.temp1)), utils.ru(title)],self.press_inedit_app)
      appuifw.app.body=self.boxe
      while self.temp3==None:
        e32.ao_sleep(0.1)
      if self.temp1==0: item[1][0]="True"
      else: item[1][0]="False"
      item[1][1]=self.temp2
      self.edit_item()
    elif item[0]=="key":
      appuifw.app.exit_key_handler=self.edit
      self.temp2=item[1][1]
      self.temp1=item[1][0]
      self.temp3=None
      list=[]
      list.append(utils.ru("Время"))
      list.append(utils.ru("Клавиша"))
      self.boxe=appuifw.Listbox(list,self.press_inedit_key)
      appuifw.app.body=self.boxe
      while self.temp3==None:
        e32.ao_sleep(0.1)
      item[1][0]=self.temp1
      item[1][1]=self.temp2
      self.edit_item()
    elif item[0]=="fg":
      filds=[(utils.ru("Свернуть"), "text", u""+item[1][0]), (utils.ru("Развернуть"), "text", u""+item[1][1]), (utils.ru("Приложение"), "text", u""+item[1][2])]
      f=appuifw.Form(filds, appuifw.FFormEditModeOnly)
      f.execute()
      item[1][0]=f[0][2]
      item[1][1]=f[1][2]
      item[1][2]=f[2][2]
    elif item[0]=="sms":
      filds=[(utils.ru("Скрипт"), "text", u""+item[1][1]),]
      f=appuifw.Form(filds, appuifw.FFormEditModeOnly)
      f.execute()
      item[1][1]=f[0][2]
    elif item[0]=="exit":
      filds=[(utils.ru("Время"), "text", u""+item[1][0]),]
      f=appuifw.Form(filds, appuifw.FFormEditModeOnly)
      f.execute()
      item[1][0]=f[0][2]
    print item
    gscript[current]=item
    
  def press_add(self):
    global gscript
    select=self.lbox2.current()
    if select==0:
      gscript.append(["app",["True", ""]])
    elif select==1:
      gscript.append(["key",["+0", ""]])
    elif select==2:
      gscript.append(["fg",["+0", "0.00", ""]])
    elif select==3:
      gscript.append(["sms",["run", ""]])
    elif select==4:
      gscript.append(["exit",["+0"]])
    self.edit()
      
  def delete(self):
    global gscript
    del gscript[self.lbox2.current()]
    self.edit()
    
  def key_event(self,event):
    if event['type']==appuifw.EEventKeyDown:
      self.temp2=utils.convert2(event['scancode'])

  def press_inedit_key(self):
    appuifw.app.exit_key_handler=self.edit
    appuifw.app.menu = []
    item=self.boxe.current()
    if item==0:
      filds=[(utils.ru("Время"), "text", u""+self.temp1)]
      f=appuifw.Form(filds, appuifw.FFormEditModeOnly)
      f.execute()
      self.temp1=f[0][2]
    elif item==1:
      self.temp2=None
      img=None
      appuifw.app.body=canvas=appuifw.Canvas(event_callback=self.key_event,redraw_callback=None)
      img=Image.new(canvas.size)
      img.text((40, 70), utils.ru("Нажмите клавишу"))
      canvas.blit(img)
      while self.temp2==None:
        e32.ao_sleep(0.1)
    self.temp3=1
    
  def setting(self):
    pass
        
  def press_inedit_app(self):
    global file2
    appuifw.app.exit_key_handler=self.edit
    appuifw.app.menu = []
    item=self.boxe.current()
    if item==0:
      self.temp1=appuifw.popup_menu([utils.ru("Да"),utils.ru("Нет")])
    elif item==1:
      file2=None
      fb.call()
      while file2==None:
        e32.ao_sleep(0.1)
      self.temp2=file2
    self.temp3=1
      
class Utils:
  def ru(seld,msg):
    try:
        result=unicode(msg, "utf8")
    except:
        result=u""+msg
    return result
    
  def in_dir(self,path):
    in_dir=os.listdir(path)
    files=[]
    for name in in_dir:
      files.append(u""+name)
    return files
    
  def run(self,app):
    e32.start_exe(u"z:\\system\\programs\\apprun.exe",u""+app)
    print "run"
    
  def convert(self,key):
    print key
    if key=="EKeyLeftSoftkey": return EKeyLeftSoftkey
    elif key=="EKeyRightSoftkey": return EKeyRightSoftkey
    elif key=="EKeySelect": return EKeySelect
    elif key=="EKeyEdit": return EKeyEdit
    elif key=="EKeyMenu": return EKeyMenu
    elif key=="EKeyLeftArrow": return EKeyLeftArrow
    elif key=="EKeyRightArrow": return EKeyRightArrow
    elif key=="EKeyUpArrow": return EKeyUpArrow
    elif key=="EKeyDownArrow": return EKeyDownArrow
    elif key=="EKey1": return EKey1
    elif key=="EKey2": return EKey2
    elif key=="EKey3": return EKey3
    elif key=="EKey4": return EKey4
    elif key=="EKey5": return EKey5
    elif key=="EKey6": return EKey6
    elif key=="EKey7": return EKey7
    elif key=="EKey8": return EKey8
    elif key=="EKey9": return EKey9
    elif key=="EKey0": return EKey0
    elif key=="EKeyStar": return EKeyStar
    elif key=="EKeyHash": return EKeyHash
    else: exit()
    
  def convert2(self,key):
    if key==EKeyLeftSoftkey: return "EKeyLeftSoftkey"
    elif key==EKeyRightSoftkey: return "EKeyRightSoftkey"
    elif key==EKeySelect: return "EKeySelect"
    elif key==EKeyEdit: return "EKeyEdit"
    elif key==EKeyMenu: return "EKeyMenu"
    elif key==EKeyLeftArrow: return "EKeyLeftArrow"
    elif key==EKeyRightArrow: return "EKeyRightArrow"
    elif key==EKeyUpArrow: return "EKeyUpArrow"
    elif key==EKeyDownArrow: return "EKeyDownArrow"
    elif key==EKey1: return "EKey1"
    elif key==EKey2: return "EKey2"
    elif key==EKey3: return "EKey3"
    elif key==EKey4: return "EKey4"
    elif key==EKey5: return "EKey5"
    elif key==EKey6: return "EKey6"
    elif key==EKey7: return "EKey7"
    elif key==EKey8: return "EKey8"
    elif key==EKey9: return "EKey9"
    elif key==EKey0: return "EKey0"
    elif key==EKeyStar: return "EKeyStar"
    elif key==EKeyHash: return "EKeyHash"
    else: return ""
     
  def save(self):
    global file, gscript
    Filed=open(file,'w')
    for line in gscript:
      Filed.write(line[0]+"~")
      t=0
      for value in line[1]:
        if t==1: Filed.write("|")
        Filed.write(value)
        t=1
      Filed.write("\n")
    Filed.close()
    
  def create_file(self,name):
    path="e:\\Others\\Scripts"
    if not os.path.exists(path):
      os.makedirs(path)
    if not os.path.exists(path+"\\"+name+".cfg"):
      open(path+"\\"+name+".cfg", "w")
    else:
      appuifw.note(utils.ru("Файл с таким именем уже существует!"), "info")
      return False
    return True
    
class FileBrowser:
    def __init__(self):
        self.file=None
    def list_dir(self,dir=None):
        if dir==None:
            list=[((i,u"Drive")) for i in e32.drive_list()]
        else:
            os.chdir(dir)
            list=[]
            d=[]
            f=[]
            list.append(("..","Dir"))
            for i in os.listdir(os.getcwd()):
                if os.path.isdir(os.getcwd()+i):
                    d.append((i,u"Dir"))
                else:
                    f.append((i,u"File"))
            list.extend(d)
            list.extend(f)
        return list
    def print_list(self,list):
        l=[]
        self.list=list
        for i in list:
            l.append(utils.ru(i[0]))
        self.box=appuifw.Listbox(l,self.select)
        appuifw.app.body=self.box
    def select(self):
        global file2
        item=self.list[self.box.current()]
        if item[1]==u"Dir":
            self.print_list(self.list_dir(os.getcwd()+item[0]))
        elif item[1]==u"Drive":
            self.print_list(self.list_dir(item[0]))
        elif item[1]==u"File":
            file2=item[0]
    def call(self):
        self.print_list(self.list_dir())
        
def exit():
    global run,lock
    run=False
    lock.signal()
    
def lock():
    global lock
    lock=e32.Ao_lock()
    lock.wait()

my_log = Logger(os.path.join("e:\\Others", "adebug.txt"))
sys.stderr = sys.stdout = my_log

run=False
task_time={}
task_sms=None
in_box=inbox.Inbox()
sms=in_box.sms_messages()
gscript=[]
file=None
file2=None

utils=Utils()
fb=FileBrowser()
main=Main()
calendar=Calendar()
ui=UI()
