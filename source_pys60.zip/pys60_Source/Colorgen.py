import appuifw,os
userc=ch=hl=r=g=b=hlr=hlg=hlb=you=0
addi=5
def ru(x):return x.decode('utf-8')
try:import e32,clipboard,uikludges
except:
 appuifw.note(ru('Скачайте подборку сторонних модулей'),'error')
 os.abort()
uikludges.set_right_softkey_text(ru('Выход'))
def info11():
 t.color=18175
 t.set(ru('Данная команда изменяет количество красного в генерируемом цвете.'))
 t.color=0xffffff
 t.add(u'   ')
def info12():
 t.color=18175
 t.set(ru('Данная команда изменяет количество зелёного в генерируемом цвете.'))
 t.color=0xffffff
 t.add(u'   ')
def info13():
 t.color=18175
 t.set(ru('Данная команда изменяет количество синего в генерируемом цвете.'))
 t.color=0xffffff
 t.add(u'   ')
def info31():
 t.color=18175
 t.set(ru('Данная команда изменяет количество красного в цвете подсветки.'))
 t.color=0xffffff
 t.add(u'   ')
def info32():
 t.color=18175
 t.set(ru('Данная команда изменяет количество зелёного в цвете подсветки.'))
 t.color=0xffffff
 t.add(u'   ')
def info33():
 t.color=18175
 t.set(ru('Данная команда изменяет количество синего в цвете подсветки.'))
 t.color=0xffffff
 t.add(u'   ')
def info21():
 t.color=18175
 t.set(ru('Данная команда убирает подсветку кода.'))
 t.color=0xffffff
 t.add(u'   ') 
def info22():
 t.color=18175
 t.set(ru('Данная команда делает подсветку кода прямоугольной.'))
 t.color=0xffffff
 t.add(u'   ') 
def info23():
 t.color=18175
 t.set(ru('Данная команда делает подсветку кода закругленной.'))
 t.color=0xffffff
 t.add(u'   ') 
def info24():
 t.color=18175
 t.set(ru('Данная команда превращает подсветку кода в тень.'))
 t.color=0xffffff
 t.add(u'   ') 
def info():
 def noact():pass
 t.bind(63495,noact)
 t.bind(63496,noact)
 t.bind(63497,noact)
 t.bind(63498,noact)
 uikludges.set_right_softkey_text(ru('Назад'))
 appuifw.app.exit_key_handler=begin0
 t.font=u'LatinBold12'
 t.color=18175
 t.set(ru('Выберите пункт меню, с которым бы вы хотели ознакомиться.'))
 t.color=0xffffff
 t.add(u'   ')
 appuifw.app.menu=[(ru('Цвет текста'),((ru('Красный'),info11),(ru('Зеленый'),info12),(ru('Синий'),info13),(ru('Всё'),info14),(u'hex',info15),(ru('Схема'),info16))),(ru('Тип подсветки'),((ru('Нет'),info21),(ru('Прямоугольная'),info22),(ru('Закругленная'),info23),(ru('Тень'),info24))),(ru('Цвет подсветки'),((ru('Красный'),info31),(ru('Зеленый'),info32),(ru('Синий'),info33),(ru('Всё'),info34),(u'hex',info35),(ru('Схема'),info36))),(ru('Копия в буфер...'),((ru('как hex'),info41),(ru('как dec'),info42))),(ru('Клавиши'),infoo)]
def info15():
 t.color=18175
 t.set(ru('Данная команда распознаёт введённый вами шестнадцатиричный код, задает его как генерируемый цвет и развивает на количество красного, зелёного и синего.'))
 t.color=0xffffff
 t.add(u'   ')
def info16():
 t.color=18175
 t.set(ru('Данная команда даёт вам возможность выбрать один из предложенных готовых кодов генерируемого цвета.'))
 t.color=0xffffff
 t.add(u'   ')
def info36():
 t.color=18175
 t.set(ru('Данная команда даёт вам возможность выбрать один из предложенных готовых цветов подсветки.'))
 t.color=0xffffff
 t.add(u'   ') 
def info41():
 t.color=18175
 t.set(ru('Данная команда даёт вам возможность скопировать в буфер обмена код генерируемого цвета в формате hex.'))
 t.color=0xffffff
 t.add(u'   ')
def info42():
 t.color=18175
 t.set(ru('Данная команда даёт вам возможность скопировать в буфер обмена код генерируемого цвета в формате dec.'))
 t.color=0xffffff
 t.add(u'   ') 
def info35():
 t.color=18175
 t.set(ru('Данная команда распознаёт введённый вами шестнадцатиричный код, задает его как цвет подсветки.'))
 t.color=0xffffff
 t.add(u'   ') 
def info14():
 t.color=18175
 t.set(ru('Данная команда изменяет количество красного, зелёного и синего в генерируемом цвете.'))
 t.color=0xffffff
 t.add(u'   ') 
def info34():
 t.color=18175
 t.set(ru('Данная команда изменяет количество красного, зелёного и синего в цвете подсветки.'))
 t.color=0xffffff
 t.add(u'   ') 
def infoo():
 t.color=18175
 t.set(ru('Кнопки влево/вправо убаляют/добавляют к цвету определенне число (по стандарту 5). кнопки 0-9 изменяют это число соответственно.'))
 t.color=0xffffff
 t.add(u'   ')
def cbhex():clipboard.Set(str(hex(userc)))
def cbdec():clipboard.Set(str(userc))
def aboutme():
 appuifw.note(u'dimontyay@rambler.ru\nICQ: 401886867')
 appuifw.note(ru('Помощь:\nAtrant\nSph1nkS'))
 appuifw.note(ru('N-GAGE QD тест:\nDimontyay'))
 appuifw.note(ru('3230 тест:\ndark knight vladek'))
 appuifw.note(ru('6630 тест:\nSph1nkS'))
 appuifw.note(ru('N70 тест:\nAtrant'))
 appuifw.note(ru('Иконка:\nAxy'))
 appuifw.note(ru('colorgen 1.5'))
def quit():appuifw.app.set_exit()
appuifw.app.screen='large'
appuifw.app.body=t=appuifw.Text()
t.focus=False
i=0
f=0
t.color=0xff0000
t.set(ru('\n'*13+'    colorgen от '))
t.color=255
t.style=(appuifw.STYLE_BOLD|appuifw.STYLE_UNDERLINE|appuifw.STYLE_ITALIC)
t.add(u'dimontyay')
t.style=0
t.add(u'  \n')
while i<13:
 t.delete(0,1)
 i+=1
 e32.ao_sleep(1./24)
t.color=0
t.style=0
t.font=u'Alpi12'
while f<22:
 f+=1
 t.set_pos(28)
 t.add(ru('     Генерация цветов.')[22-f])
 e32.ao_sleep(1./24)
t.set_pos(t.len())
t.color=0xffffff
t.add(u'\n\n\n\n\n')
def sstart():
 appuifw.app.menu=[]
 global f
 global i
 i=0
 while i<25:
  t.delete(26,1)
  t.delete(0,1)
  i+=1
  t.set_pos(50)
  t.add(u' ')
  t.set_pos(24)
  t.add(u' ')
  e32.ao_yield()
 begin0()
appuifw.app.menu=[(ru('Запустить'),sstart)]
def nothing():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=10
def nothing1():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=1
def nothing2():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=2
def nothing3():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=3
def nothing4():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=4
def nothing5():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=5
def nothing6():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=6
def nothing7():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=7
def nothing8():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=8
def nothing9():
 t.set_pos(t.len()-1)
 t.delete(t.len()-3,1)
 global addi
 addi=9
def thing1():
 t.set_pos(t.len())
 global you
 if you<2:you+=1
 else:you=0
 begin()
def thing2():
 t.set_pos(t.len())
 global you
 if you>0:you-=1
 else:you=2
 begin()
def thing3():
 t.set_pos(t.len())
 if you==0:
  global r
  if r+addi<256:r+=addi
  else:r=255
 elif you==1:
  global g
  if g+addi<256:g+=addi
  else:g=255
 else:
  global b
  if b+addi<256:b+=addi
  else:b=255
 begin()
def thing4():
 t.set_pos(t.len())
 if you==0:
  global r
  if r-addi>0:r-=addi
  else:r=0
 elif you==1:
  global g
  if g-addi>0:g-=addi
  else:g=0
 else:
  global b
  if b-addi>0:b-=addi
  else:b=0
 begin()
def delt():
 t.set_pos(t.len())
 t.add(u' ')
t.bind(48,nothing)
t.bind(49,nothing1)
t.bind(50,nothing2)
t.bind(51,nothing3)
t.bind(52,nothing4)
t.bind(53,nothing5)
t.bind(54,nothing6)
t.bind(55,nothing7)
t.bind(56,nothing8)
t.bind(57,nothing9)
t.bind(42,nothing)
t.bind(35,nothing)
t.bind(8,delt)
def iall():
 ired()
 igreen()
 iblue()
def iallhl():
 iredhl()
 igreenhl()
 ibluehl()
def ired():
 global r
 r=appuifw.query(ru('Количество красного (0-255):'),'number',r)
 if r>255 or r==None:
  appuifw.note(ru('Число должно лежать в промежутке от 0 до 255'),'error')
  ired()
 begin()
def igreen():
 global g
 g=appuifw.query(ru('Количество зеленого (0-255):'),'number',g)
 if g>255 or g==None:
  appuifw.note(ru('Число должно лежать в промежутке от 0 до 255'),'error')
  igreen()
 begin()
def iblue():
 global b
 b=appuifw.query(ru('Количество синего (0-255):'),'number',b)
 if b>255 or b==None:
  appuifw.note(ru('Число должно лежать в промежутке от 0 до 255'),'error')
  iblue()
 begin()
def iredhl():
 global hlr
 hlr=appuifw.query(ru('Количество красного (0-255):'),'number',hlr)
 if hlr>255 or hlr==None:
  appuifw.note(ru('Число должно лежать в промежутке от 0 до 255'),'error')
  iredhl()
 begin()
def igreenhl():
 global hlg
 hlg=appuifw.query(ru('Количество зеленого (0-255):'),'number',hlg)
 if hlg>255 or hlg==None:
  appuifw.note(ru('Число должно лежать в промежутке от 0 до 255'),'error')
  igreenhl()
 begin()
def ibluehl():
 global hlb
 hlb=appuifw.query(ru('Количество синего (0-255):'),'number',hlb)
 if hlb>255 or hlb==None:
  appuifw.note(ru('Число должно лежать в промежутке от 0 до 255'),'error')
  ibluehl()
 begin()
def ihex():
 try:
  itemp=str(hex(userc))[2:]
  h16=appuifw.query(ru('Hex число без 0x(0-ffffff):'),'text',unicode(itemp))
  if len(h16)>6:
   appuifw.note(ru('Не может быть числом цвета'),'error')
   ihex()
  else:
   h16=u'0'*(6-len(h16))+h16
   global r,g,b
   r=int('0x'+h16[:2],16)
   g=int('0x'+h16[2:4],16)
   b=int('0x'+h16[-2:],16)
   begin()
 except:
  appuifw.note(ru('Встречаются посторонние символы'),'error')
  ihex()
def ihexhl():
 try:
  hlh16=appuifw.query(ru('Hex число без 0x(0-ffffff):'),'text')
  if len(hlh16)>6:
   appuifw.note(ru('Не может быть числом цвета'),'error')
   ihexhl()
  else:
   hlh16=u'0'*(6-len(hlh16))+hlh16
   global hlr,hlg,hlb
   hlr=int('0x'+hlh16[:2],16)
   hlg=int('0x'+hlh16[2:4],16)
   hlb=int('0x'+hlh16[-2:],16)
   begin()
 except:
  appuifw.note(ru('Встречаются посторонние символы'),'error')
  ihexhl()
def hlno():
 global hl
 hl=0
 begin()
def hlnorm():
 global hl
 hl=appuifw.HIGHLIGHT_STANDARD
 begin()
def hlround():
 global hl
 hl=appuifw.HIGHLIGHT_ROUNDED
 begin()
def hlshadow():
 global hl
 hl=appuifw.HIGHLIGHT_SHADOW
 begin()
def sgreen():
 if ch==0:
  global r,g,b
  r=0
  g=255
  b=0
 elif ch==1:
  global hlr,hlg,hlb
  hlr=0
  hlg=255
  hlb=0
 begin()
def sred():
 if ch==0:
  global r,g,b
  r=255
  g=0
  b=0
 elif ch==1:
  global hlr,hlg,hlb
  hlr=255
  hlg=0
  hlb=0
 begin()
def sblue():
 if ch==0:
  global r,g,b
  r=0
  g=0
  b=255
 elif ch==1:
  global hlr,hlg,hlb
  hlr=0
  hlg=0
  hlb=255
 begin()
def sorange():
 if ch==0:
  global r,g,b
  r=255
  g=128
  b=0
 elif ch==1:
  global hlr,hlg,hlb
  hlr=255
  hlg=128
  hlb=0
 begin()
def syellow():
 if ch==0:
  global r,g,b
  r=255
  g=255
  b=0
 elif ch==1:
  global hlr,hlg,hlb
  hlr=255
  hlg=255
  hlb=0
 begin()
def sblue1():
 if ch==0:
  global r,g,b
  r=0
  g=255
  b=255
 elif ch==1:
  global hlr,hlg,hlb
  hlr=0
  hlg=255
  hlb=255
 begin()
def sviolet():
 if ch==0:
  global r,g,b
  r=255
  g=0
  b=255
 elif ch==1:
  global hlr,hlg,hlb
  hlr=255
  hlg=0
  hlb=255
 begin()
def choosec():
 global ch
 ch=0
 cho=appuifw.popup_menu([ru('Красный'),ru('Оранжевый'),ru('Желтый'),ru('Зелёный'),ru('Голубой'),ru('Синий'),ru('Фиолетовый')])
 if cho==0:sred()
 elif cho==1:sorange()
 elif cho==2:syellow()
 elif cho==3:sgreen()
 elif cho==4:sblue1()
 elif cho==5:sblue()
 elif cho==6:sviolet()
def choosechl():
 global ch
 ch=1
 cho=appuifw.popup_menu([ru('Красный'),ru('Оранжевый'),ru('Желтый'),ru('Зелёный'),ru('Голубой'),ru('Синий'),ru('Фиолетовый')])
 if cho==0:sred()
 elif cho==1:sorange()
 elif cho==2:syellow()
 elif cho==3:sgreen()
 elif cho==4:sblue1()
 elif cho==5:sblue()
 elif cho==6:sviolet()
def begin0():
 t.font=u'LatinBold19'
 t.bind(63495,thing4)
 t.bind(63496,thing3)
 t.bind(63497,thing2)
 t.bind(63498,thing1)
 begin()
def begin():
 uikludges.set_right_softkey_text(ru('Выход'))
 appuifw.app.exit_key_handler=appuifw.app.set_exit
 hexr=str(hex(r))[2:]
 if len(hexr)<2:hexr='0'+hexr
 hexg=str(hex(g))[2:]
 if len(hexg)<2:hexg='0'+hexg
 hexb=str(hex(b))[2:]
 if len(hexb)<2:hexb='0'+hexb
 hexrhl=str(hex(hlr))[2:]
 if len(hexrhl)<2:hexrhl='0'+hexrhl
 hexghl=str(hex(hlg))[2:]
 if len(hexghl)<2:hexghl='0'+hexghl
 hexbhl=str(hex(hlb))[2:]
 if len(hexbhl)<2:hexbhl='0'+hexbhl
 newcolor='0x'+hexr+hexg+hexb
 newcolorhl='0x'+hexrhl+hexghl+hexbhl
 global userc
 userc=int(newcolor,16)
 t.style=hl
 t.highlight_color=int(newcolorhl,16)
 t.color=userc
 t.set(ru(str(userc)+'\n'))
 t.add(ru(str(hex(userc))))
 if you==0:
  t.color=0x555555
  redtext='\n- '
  redtext2=' +'
 else:
  redtext='\n  '
  redtext2=''
  t.color=0xff0000
 t.add(ru('\n'+redtext+'Красный:\t'+str(r)+redtext2))
 if you==1:
  t.color=0x555555
  redtext='\n- '
  redtext2=' +'
 else:
  t.color=0xff00
  redtext='\n  '
  redtext2=''
 t.add(ru(redtext+'Зеленый:\t'+str(g)+redtext2))
 if you==2:
  t.color=0x555555
  redtext='\n- '
  redtext2=' +'
 else:
  t.color=0xff
  redtext='\n  '
  redtext2=''
 t.add(ru(redtext+'Синий:\t\t'+str(b)+redtext2))
 t.highlight_color=userc
 t.style=appuifw.HIGHLIGHT_ROUNDED
 t.add(u'\n\t\t\t\t\t')
 t.color=0xffffff
 t.style=0
 t.add(u' \n\n\n')
 appuifw.app.menu=[(ru('Цвет текста'),((ru('Красный'),ired),(ru('Зеленый'),igreen),(ru('Синий'),iblue),(ru('Всё'),iall),(u'hex',ihex),(ru('Схема'),choosec))),(ru('Тип подсветки'),((ru('Нет'),hlno),(ru('Прямоугольная'),hlnorm),(ru('Закругленная'),hlround),(ru('Тень'),hlshadow))),(ru('Цвет подсветки'),((ru('Красный'),iredhl),(ru('Зеленый'),igreenhl),(ru('Синий'),ibluehl),(ru('Всё'),iallhl),(u'hex',ihexhl),(ru('Схема'),choosechl))),(ru('Копия в буфер...'),((ru('как hex'),cbhex),(ru('как dec'),cbdec))),(ru('Справка'),info),(ru('О...'),aboutme),(ru('Выход'),quit)]
