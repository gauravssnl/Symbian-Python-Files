
import os, os.path

PATH = u"C:\\Data\\MyApp"
if not os.path.exists(PATH):
        os.makedirs(PATH)
