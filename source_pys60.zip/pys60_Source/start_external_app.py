# Calling a native symbian app from within your script 

import appuifw
import e32

def camera():
    try:
        #start_exe(filename, command [,wait ])
        # this starts the normal camera app on your phone
        e32.start_exe('z:\\system\\programs\\apprun.exe', 'z:\\system\\apps\\camcorder\\camcorder.app')
    except:
        print "something wrong"



def exit_key_handler():
    script_lock.signal()
    appuifw.app.set_exit()
    

script_lock = e32.Ao_lock()

appuifw.app.title = u"test"

appuifw.app.menu = [(u"camera", camera)]

appuifw.app.exit_key_handler = exit_key_handler
script_lock.wait()


 

