
a = [1, 2, "a", 1, "b", 2, "b"]
print len(dict([(x, True) for x in a]))
