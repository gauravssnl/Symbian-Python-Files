#script by _virtual_machine_

def ru(t):return t.decode('utf-8')
def ur(t):return t.encode('utf-8')

import e32,_appuifw
if e32.pys60_version_info[2]<15:
    _appuifw.note(ru("Необходима версия Python не ниже 1.3.15. Пожалуйста обновитесь."),'error')
    _appuifw.app.set_exit()	
import e32posix,time,_sysinfo,_graphics,_location,fgimage,appswitch

class image:
	def __init__(self,type,arg1=0,arg2=8):
		type_map={'scrshot':self._scrshot,'new':self._new,'canvas':self._canvas,'list':self._list}
		type_map[type](arg1,arg2)
		self._draw=_graphics.Draw(self._image)
		for method in _graphics._draw_methods:setattr(self,method,getattr(self._draw,method))
	def _scrshot(self,arg1,arg2):
		self._image=_graphics.screenshot()
		self._bitmapapi=self._image._bitmapapi
	def _new(self,arg1,arg2):
		self._image=_graphics.ImageNew(arg1,arg2)
		self._bitmapapi=self._image._bitmapapi
	def _canvas(self,arg1,arg2):
		try:self._image=_appuifw.Canvas(arg1,arg2)
		except:self._image=_appuifw.Canvas(arg1,arg2,None)
		self.bind=self._image.bind
		self._uicontrolapi=self._image._uicontrolapi
	def _list(self,arg1,arg2):
		self.imgs,self.masks=[],[]
		files=[file for file in e32posix.listdir(arg1) if file[-4:].lower()=='.png']
		self.size=_graphics.ImageInspect(arg1+'\\'+files[0])[0]
		for file in files:
			if file[0]=='_':
				self.masks.append(_graphics.ImageNew(self.size,1))
				self.lock=e32.Ao_lock()
				self.masks[-1].load(arg1+'\\'+file,lambda errcode: self.lock.signal())
				self.lock.wait()
			else:
			    self.imgs.append(_graphics.ImageNew(self.size,arg2))
			    self.lock=e32.Ao_lock()
			    self.imgs[-1].load(arg1+'\\'+file,lambda errcode: self.lock.signal())
			    self.lock.wait()
		self.len=len(self.imgs)
		self._image=_graphics.ImageNew(self.size,arg2)
		self._bitmapapi=self._image._bitmapapi

class plugin:
	def __init__(self,path):
		self.path=path
		file=open(self.path,'r')
		self.data=eval(file.read())
		file.close()
		[self.type,self.name]=self.data[:2]
		typemap={'inf':self.inf_load,'ani':self.ani_load,'txt':self.txt_load,'id':self.id_load}
		self.load=typemap[self.type]
		self.load_flag=1
		self.fgi=fgimage.FGImage()
		self.back_flag=1
		self.freq_step=0
	def fore(self,mode):
		self.freq_step+=1
		if mode==3 or mode==self.flag:
		    if self.back_flag:
		        self.back_flag=0
		        self.fgi.unset()
		        self.freq_step=self.freq
		elif mode==4 or self.freq_step>self.freq:
		    self.back_flag=1
		    self.freq_step=0
		    self.draw(mode)
		    self.fgi.set(self.img_x,self.img_y,self.img._bitmapapi())
	def back(self):
		self.fore(4)
		self.fore(3)
	def blit(self,img):
		img.blit(self.img,target=(self.img_x,self.img_y))
	def select(self,img):
		self.draw()
		img.rectangle((self.img_x-2,self.img_y-2,self.img_x+self.img_w+2,self.img_y+self.img_h+2),0)
	def keys(self,keycode):
		self.keymap.get((keycode[0],keycode[1]),self.keymap_pass)()
		self.save()
	def inf_load(self):
		self.load_flag=0
		self.save,self.sets,self.draw=self.inf_save,self.inf_sets,self.inf_draw
		[self.code,self.freq,self.flag,self.img_x,self.img_y,self.img_w,self.img_h,self.img_color_r,self.img_color_g,self.img_color_b,self.frame_color_r,self.frame_color_g,self.frame_color_b,self.frame_width,self.text_x,self.text_y,self.text_color_r,self.text_color_g,self.text_color_b,self.text_font]=self.data[2:]
		self.img=image('new',(self.img_w,self.img_h))
		self.fonts=[font for font in _appuifw.available_fonts() if font.find(u'60')==-1]
		if self.text_font not in self.fonts:self.text_standart()
		self.text=eval('lambda:'+self.code)
		try:self.text()
		except:self.text=lambda:u'ERROR'
		self.keymap={
		 (0,52):self.text_font_sub,(0,54):self.text_font_add,(0,53):self.text_standart,(0,55):self.frame_width_sub,(0,57):self.frame_width_add,(0,56):self.frame_width_standart,
		 (42,14):self.img_x_sub,(42,15):self.img_x_add,(42,16):self.img_y_sub,(42,17):self.img_y_add,(42,49):self.img_color_r_add,(42,52):self.img_color_r_sub,(42,50):self.img_color_g_add,(42,53):self.img_color_g_sub,(42,51):self.img_color_b_add,(42,54):self.img_color_b_sub,(42,55):self.img_color_r_standart,(42,56):self.img_color_g_standart,(42,57):self.img_color_b_standart,
		 (48,14):self.img_w_sub,(48,15):self.img_w_add,(48,16):self.img_h_sub,(48,17):self.img_h_add,(48,49):self.frame_color_r_add,(48,52):self.frame_color_r_sub,(48,50):self.frame_color_g_add,(48,53):self.frame_color_g_sub,(48,51):self.frame_color_b_add,(48,54):self.frame_color_b_sub,(48,55):self.frame_color_r_standart,(48,56):self.frame_color_g_standart,(48,57):self.frame_color_b_standart,
		 (127,14):self.text_x_sub,(127,15):self.text_x_add,(127,16):self.text_y_sub,(127,17):self.text_y_add,(127,49):self.text_color_r_add,(127,52):self.text_color_r_sub,(127,50):self.text_color_g_add,(127,53):self.text_color_g_sub,(127,51):self.text_color_b_add,(127,54):self.text_color_b_sub,(127,55):self.text_color_r_standart,(127,56):self.text_color_g_standart,(127,57):self.text_color_b_standart
		}
		self.draw()
	def inf_save(self):
		file=open(self.path,'w')
		file.write(`[self.type,self.name,self.code,self.freq,self.flag,self.img_x,self.img_y,self.img_w,self.img_h,self.img_color_r,self.img_color_g,self.img_color_b,self.frame_color_r,self.frame_color_g,self.frame_color_b,self.frame_width,self.text_x,self.text_y,self.text_color_r,self.text_color_g,self.text_color_b,self.text_font]`)
		file.close()
	def inf_sets(self):
		form=_appuifw.Form([
		 (ru('Имя'),'text',self.name),
		 (ru('Шрифт'),'combo',(self.fonts,self.fonts.index(self.text_font))),
		 (ru('Поверх'),'combo',([
		  ru('всего'),
		  ru('рабочего стола'),
		  ru('приложений')],self.flag))],17)
		form.execute()
		self.name,self.text_font,self.flag=form[0][2],self.fonts[form[1][2][1]],int(form[2][2][1])
		self.save()
	def inf_draw(self,mode=0):
		self.img.rectangle((0,0,self.img_w,self.img_h),(self.frame_color_r,self.frame_color_g,self.frame_color_b),fill=(self.img_color_r,self.img_color_g,self.img_color_b),width=self.frame_width)
		self.img.text((self.text_x,self.text_y),self.text(),(self.text_color_r,self.text_color_g,self.text_color_b),font=self.text_font)
	def ani_load(self):
		self.load_flag=0
		self.save,self.sets=self.ani_save,self.ani_sets
		[self.flag,self.freq,self.img_x,self.img_y]=self.data[2:]
		self.img=image('list',self.path.split('.')[0])
		[self.img_w,self.img_h]=self.img.size
		if self.img.len==len(self.img.masks):
		    self.draw=self.ani_draw_mask
		    self.scr=image('new',self.img.size)
		    self.scr_flag=0
		else:self.draw=self.ani_draw
		self.seek=0
		self.keymap={(42,14):self.img_x_sub,(42,15):self.img_x_add,(42,16):self.img_y_sub,(42,17):self.img_y_add}
		self.draw()
	def ani_save(self):
		file=open(self.path,'w')
		file.write(`[self.type,self.name,self.flag,self.freq,self.img_x,self.img_y]`)
		file.close()
	def ani_sets(self):
		form=_appuifw.Form([
		 (ru('Имя'),'text',self.name),
		 (ru('Скорость'),'number',self.freq)],17)
		form.execute()
		self.name,self.freq=form[0][2],int(form[1][2])
		self.save()
	def ani_draw(self,mode=0):
		self.seek+=1
		if self.seek==self.img.len:self.seek=0
		self.img.blit(self.img.imgs[self.seek])
	def ani_draw_mask(self,mode=0):
		self.seek+=1
		if self.seek==self.img.len:self.seek=0
		if mode==2:
		    if self.scr_flag:
		        self.scr_flag=0
		        self.scr.blit(image('scrshot'),source=((self.img_x,self.img_y),(self.img_x+self.img_w,self.img_y+self.img_h)))
		elif not self.scr_flag:
		    self.scr_flag=1
		    self.scr.clear()
		self.img.blit(self.scr)
		self.img.blit(self.img.imgs[self.seek],mask=self.img.masks[self.seek])
	def txt_load(self):
		self.load_flag=0
		self.save,self.sets,self.draw=self.txt_save,self.txt_sets,self.txt_draw
		[self.freq,self.flag,self.text,self.step,self.img_x,self.img_y,self.img_w,self.img_h,self.text_x,self.text_y,self.text_color_r,self.text_color_g,self.text_color_b,self.text_font]=self.data[2:]
		self.fonts=[font for font in _appuifw.available_fonts() if font.find(u'60')==-1]
		if self.text_font not in self.fonts:self.text_standart()
		self.seek=self.img_w+self.text_x
		self.img=image('new',(self.img_w,self.img_h))
		self.scr=image('new',(self.img_w,self.img_h))
		self.scr_flag=0
		self.keymap={
		 (0,52):self.text_font_sub,(0,54):self.text_font_add,(0,53):self.text_standart,
		 (42,14):self.img_x_sub,(42,15):self.img_x_add,(42,16):self.img_y_sub,(42,17):self.img_y_add,
		 (48,14):self.scr_w_sub,(48,15):self.scr_w_add,(48,16):self.scr_h_sub,(48,17):self.scr_h_add,
		 (127,14):self.text_x_sub,(127,15):self.text_x_add,(127,16):self.text_y_sub,(127,17):self.text_y_add,(127,49):self.text_color_r_add,(127,52):self.text_color_r_sub,(127,50):self.text_color_g_add,(127,53):self.text_color_g_sub,(127,51):self.text_color_b_add,(127,54):self.text_color_b_sub,(127,55):self.text_color_r_standart,(127,56):self.text_color_g_standart,(127,57):self.text_color_b_standart
		}
		self.draw()
	def txt_save(self):
		file=open(self.path,'w')
		file.write(`[self.type,self.name,self.freq,self.flag,self.text,self.step,self.img_x,self.img_y,self.img_w,self.img_h,self.text_x,self.text_y,self.text_color_r,self.text_color_g,self.text_color_b,self.text_font]`)
		file.close()
	def txt_sets(self):
		form=_appuifw.Form([
		 (ru('Имя'),'text',self.name),
		 (ru('Текст'),'text',self.text),
		 (ru('Шрифт'),'combo',(self.fonts,self.fonts.index(self.text_font))),
		 (ru('Скорость'),'number',self.freq),
		 (ru('Шаг'),'number',self.step)],17)
		form.execute()
		self.name,self.text,self.text_font,self.freq,self.step=form[0][2],form[1][2],self.fonts[form[2][2][1]],int(form[3][2]),int(form[4][2])
		self.save()
	def txt_draw(self,mode=0):
		if mode==2:
			self.seek-=self.step
			if self.seek<=-self.img_w:self.seek=self.img_w+self.text_x
			if self.scr_flag:
			    self.scr_flag=0
			    self.scr.blit(image('scrshot'),source=((self.img_x,self.img_y),(self.img_x+self.img_w,self.img_y+self.img_h)))
		elif not self.scr_flag:
			self.seek=self.text_x
			self.scr_flag=1
			self.scr.clear()
		self.img.blit(self.scr)
		self.img.text((self.seek,self.text_y),self.text,(self.text_color_r,self.text_color_g,self.text_color_b),font=self.text_font)
	def id_load(self):
		self.load_flag=0
		self.save,self.sets,self.draw=self.id_save,self.id_sets,self.id_draw
		[self.code,self.freq,self.flag,self.img_x,self.img_y,self.img_w,self.img_h,self.img_color_r,self.img_color_g,self.img_color_b,self.frame_color_r,self.frame_color_g,self.frame_color_b,self.frame_width,self.text_x,self.text_y,self.text_color_r,self.text_color_g,self.text_color_b,self.text_font,self.psevdonims]=self.data[2:]
		self.img=image('new',(self.img_w,self.img_h))
		self.fonts=[font for font in _appuifw.available_fonts() if font.find(u'60')==-1]
		if self.text_font not in self.fonts:self.text_standart()
		self.text=eval('lambda:'+self.code)
		try:self.text()
		except:self.text=lambda:u'ERROR'
		self.keymap={
		 (0,52):self.text_font_sub,(0,54):self.text_font_add,(0,53):self.text_standart,(0,55):self.frame_width_sub,(0,57):self.frame_width_add,(0,56):self.frame_width_standart,
		 (42,14):self.img_x_sub,(42,15):self.img_x_add,(42,16):self.img_y_sub,(42,17):self.img_y_add,(42,49):self.img_color_r_add,(42,52):self.img_color_r_sub,(42,50):self.img_color_g_add,(42,53):self.img_color_g_sub,(42,51):self.img_color_b_add,(42,54):self.img_color_b_sub,(42,55):self.img_color_r_standart,(42,56):self.img_color_g_standart,(42,57):self.img_color_b_standart,
		 (48,14):self.img_w_sub,(48,15):self.img_w_add,(48,16):self.img_h_sub,(48,17):self.img_h_add,(48,49):self.frame_color_r_add,(48,52):self.frame_color_r_sub,(48,50):self.frame_color_g_add,(48,53):self.frame_color_g_sub,(48,51):self.frame_color_b_add,(48,54):self.frame_color_b_sub,(48,55):self.frame_color_r_standart,(48,56):self.frame_color_g_standart,(48,57):self.frame_color_b_standart,
		 (127,14):self.text_x_sub,(127,15):self.text_x_add,(127,16):self.text_y_sub,(127,17):self.text_y_add,(127,49):self.text_color_r_add,(127,52):self.text_color_r_sub,(127,50):self.text_color_g_add,(127,53):self.text_color_g_sub,(127,51):self.text_color_b_add,(127,54):self.text_color_b_sub,(127,55):self.text_color_r_standart,(127,56):self.text_color_g_standart,(127,57):self.text_color_b_standart
		}
		self.draw()
	def id_save(self):
		file=open(self.path,'w')
		file.write(`[self.type,self.name,self.code,self.freq,self.flag,self.img_x,self.img_y,self.img_w,self.img_h,self.img_color_r,self.img_color_g,self.img_color_b,self.frame_color_r,self.frame_color_g,self.frame_color_b,self.frame_width,self.text_x,self.text_y,self.text_color_r,self.text_color_g,self.text_color_b,self.text_font,self.psevdonims]`)
		file.close()
	def id_sets(self):
		psevdonims=u''
		for index in self.psevdonims.items():psevdonims+=index[1]+u'='+unicode(index[0])+u','
		if len(psevdonims)!=0:psevdonims=psevdonims[:-1]
		form=_appuifw.Form([
		 (ru('Имя'),'text',self.name),
		 (ru('Шрифт'),'combo',(self.fonts,self.fonts.index(self.text_font))),
		 (ru('Поверх'),'combo',([
		  ru('всего'),
		  ru('рабочего стола'),
		  ru('приложений')],self.flag)),
		 (ru('Псевдонимы'),'text',psevdonims)],17)
		form.execute()
		self.name,self.text_font,self.flag=form[0][2],self.fonts[form[1][2][1]],int(form[2][2][1])
		self.psevdonims={}
		if len(form[3][2])!=0:
			for index in form[3][2].split(','):
			    try:self.psevdonims[int(index.split('=')[1])]=index.split('=')[0]
			    except:pass
		self.save()
	def id_draw(self,mode=0):
	    self.img.rectangle((0,0,self.img_w,self.img_h),(self.frame_color_r,self.frame_color_g,self.frame_color_b),fill=(self.img_color_r,self.img_color_g,self.img_color_b),width=self.frame_width)
	    call_id=self.text()
	    self.img.text((self.text_x,self.text_y),self.psevdonims.get(call_id,unicode(call_id)),(self.text_color_r,self.text_color_g,self.text_color_b),font=self.text_font)
	def keymap_pass(self):
	    pass
	def text_font_sub(self):
		index=self.fonts.index(self.text_font)
		if index>0:self.text_font=self.fonts[index-1]
	def text_font_add(self):
		index=self.fonts.index(self.text_font)
		if index<len(self.fonts)-1:self.text_font=self.fonts[index+1]
	def text_standart(self):
		self.text_font=u'LatinBold12'
	def frame_width_sub(self):
		if self.frame_width>1:self.frame_width-=1
	def frame_width_add(self):
		self.frame_width+=1
	def frame_width_standart(self):
		self.frame_width=1
	def img_x_sub(self):
		self.img_x-=1
	def img_x_add(self):
		self.img_x+=1
	def img_y_sub(self):
		self.img_y-=1
	def img_y_add(self):
		self.img_y+=1
	def img_color_r_add(self):
		if self.img_color_r<=247:self.img_color_r+=8
	def img_color_r_sub(self):
		if self.img_color_r>=8:self.img_color_r-=8
	def img_color_g_add(self):
		if self.img_color_g<=247:self.img_color_g+=8
	def img_color_g_sub(self):
		if self.img_color_g>=8:self.img_color_g-=8
	def img_color_b_add(self):
		if self.img_color_b<=247:self.img_color_b+=8
	def img_color_b_sub(self):
		if self.img_color_b>=8:self.img_color_b-=8
	def img_color_r_standart(self):
		self.img_color_r=127
	def img_color_g_standart(self):
		self.img_color_g=127
	def img_color_b_standart(self):
		self.img_color_b=127
	def img_w_sub(self):
		if self.img_w>1:
		    self.img_w-=1
		    self.img=image('new',(self.img_w,self.img_h))
	def img_w_add(self):
		self.img_w+=1
		self.img=image('new',(self.img_w,self.img_h))
	def img_h_sub(self):
		if self.img_h>1:
		    self.img_h-=1
		    self.img=image('new',(self.img_w,self.img_h))
	def img_h_add(self):
		self.img_h+=1
		self.img=image('new',(self.img_w,self.img_h))
	def scr_w_sub(self):
		if self.img_w>1:
		    self.img_w-=1
		    self.img=image('new',(self.img_w,self.img_h))
		    self.scr=image('new',(self.img_w,self.img_h))
	def scr_w_add(self):
		self.img_w+=1
		self.img=image('new',(self.img_w,self.img_h))
		self.scr=image('new',(self.img_w,self.img_h))
	def scr_h_sub(self):
		if self.img_h>1:
		    self.img_h-=1
		    self.img=image('new',(self.img_w,self.img_h))
		    self.scr=image('new',(self.img_w,self.img_h))
	def scr_h_add(self):
		self.img_h+=1
		self.img=image('new',(self.img_w,self.img_h))
		self.scr=image('new',(self.img_w,self.img_h))
	def frame_color_r_add(self):
		if self.frame_color_r<=247:self.frame_color_r+=8
	def frame_color_r_sub(self):
		if self.frame_color_r>=8:self.frame_color_r-=8
	def frame_color_g_add(self):
		if self.frame_color_g<=247:self.frame_color_g+=8
	def frame_color_g_sub(self):
		if self.frame_color_g>=8:self.frame_color_g-=8
	def frame_color_b_add(self):
		if self.frame_color_b<=247:self.frame_color_b+=8
	def frame_color_b_sub(self):
		if self.frame_color_b>=8:self.frame_color_b-=8
	def frame_color_r_standart(self):
		self.frame_color_r=127
	def frame_color_g_standart(self):
		self.frame_color_g=127
	def frame_color_b_standart(self):
		self.frame_color_b=127
	def text_x_sub(self):
		self.text_x-=1
	def text_x_add(self):
		self.text_x+=1
	def text_y_sub(self):
		self.text_y-=1
	def text_y_add(self):
		self.text_y+=1
	def text_color_r_add(self):
		if self.text_color_r<=247:self.text_color_r+=8
	def text_color_r_sub(self):
		if self.text_color_r>=8:self.text_color_r-=8
	def text_color_g_add(self):
		if self.text_color_g<=247:self.text_color_g+=8
	def text_color_g_sub(self):
		if self.text_color_g>=8:self.text_color_g-=8
	def text_color_b_add(self):
		if self.text_color_b<=247:self.text_color_b+=8
	def text_color_b_sub(self):
		if self.text_color_b>=8:self.text_color_b-=8
	def text_color_r_standart(self):
		self.text_color_r=127
	def text_color_g_standart(self):
		self.text_color_g=127
	def text_color_b_standart(self):
		self.text_color_b=127

class main:
	def __init__(self):
		_appuifw.app.screen='large'
		self.text()
		_appuifw.app.body.add(ru('>>> Загрузка настроек.\n'))
		self.phone=[phone for phone in [u'Phone',u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d',u'Telephone'] if phone in appswitch.application_list(0)][0]
		full_name=_appuifw.app.full_name().split('\\')
		self.path=full_name[0]+'\\System\\Apps\\ForeMost\\'#\\nokia\\scripts\\
		self.name=full_name[-1].split('.')[0]
		file=open(self.path+'foremost.set','r')
		sets=eval(file.read())
		file.close()
		[self.auto,self.scr_flag,self.plg_select,self.black_list]=sets[:4]
		self.draw_flag=0
		self.keycode=[0,0]
		self.keymap={(0,16):lambda:self.plg_select_sort(-1),(0,17):lambda:self.plg_select_sort(1),(0,167):self.plg_select_sets}
		_appuifw.app.body.add(ru('>>> Загрузка плагинов:'))
		self.plg_files=[file for file in e32posix.listdir(self.path+'plugins\\') if file[-4:]=='.set']
		self.plg_calls,self.plg_draws=[],[]
		index=0
		while index<len(self.plg_files):
			self.plg_calls.append(plugin(self.path+'plugins\\'+self.plg_files[index]))
			if self.plg_files[index] in sets[4]:
				_appuifw.app.body.add(u'\n>>>  - '+self.plg_calls[-1].name)
				e32.ao_sleep(0.001)
				self.plg_calls[-1].load()
				self.plg_draws.append(index)
			index+=1
		if self.plg_select>=len(self.plg_draws):self.plg_select=0
		_appuifw.app.body.add(ru('\n>>> Готово.\n'))
		_appuifw.app.menu=[
		 (ru('Активация'),self.active),
		 (ru('Настроить'),(
		  (ru('плагины'),self.plg_sets),
		  (ru('программу'),self.sets),
		  (ru('черный список'),self.bl_sets))),
		 (ru('Помощь'),self.help_sets),
		 (ru('Выйти'),self.exit)]
		_appuifw.app.exit_key_handler=self.exit
		if self.scr_flag:self.img=image('new',(176,208))
		else:self.img=image('new',(352,416))
		self.load_flag=1
		#self.lock=e32.Ao_lock()
		if self.auto:self.active()
		#self.lock.wait()
	def text(self):
	    _appuifw.app.body=_appuifw.Text()
	    _appuifw.app.body.color=(0,0,0)
	    _appuifw.app.body.focus=False
	def active(self):
		if self.load_flag:
			self.load_flag=0
			self.canvas=image('canvas',self.draw,self.keys)
			_appuifw.app.body=self.canvas
		if len(self.plg_draws)!=0:
		    _appuifw.app.menu[0]=(ru('Дезактивация'),self.passive)
		    self.draw_flag=1
		    self.back_flag=1
		    while self.draw_flag:
		    	clock=time.clock()
		        app=appswitch.application_list(1)[0]
		        if app==self.phone:self.redraw(2)
		        elif app==self.name:
		        	self.img.clear(16777215)
		        	if self.back_flag:
		        		self.back_flag=0
		        		for plugin in self.plg_draws:self.plg_calls[plugin].back()
		        	for plugin in self.plg_draws:self.plg_calls[plugin].blit(self.img)
		        	self.plg_calls[self.plg_draws[self.plg_select]].select(self.img)
		        	self.canvas.blit(self.img)
		        elif app not in self.black_list:self.redraw(1)
		        else:
		        	self.redraw(3)
		        	while appswitch.application_list(1)[0]==u'screensaver':e32.ao_sleep(0.5)
		        while time.clock()-clock<=0.1:e32.ao_sleep(0.03)
		    self.draw()
	def redraw(self,mode):
		self.back_flag=1
		for plugin in self.plg_draws:self.plg_calls[plugin].fore(mode)
	def passive(self):
		if self.draw_flag:
		    _appuifw.app.menu[0]=(ru('Активация'),self.active)
		    self.draw_flag=0
	def draw(self,rect=0):
		if not self.draw_flag:
			self.img.clear(16777215)
			self.canvas.blit(self.img)
	def keys(self,event):
		if event['type']==3:
		    if event['scancode'] in [0x2a,0x30,0x7f]:self.keycode[0]=event['scancode']
		    else:self.keycode[1]=event['scancode']
		elif event['type']==2:
			if event['scancode'] in [0x2a,0x30,0x7f]:self.keycode[0]=0
		if len(self.plg_draws)>0:self.keymap.get((self.keycode[0],self.keycode[1]),self.plg_select_keys)()
		self.keycode[1]=0
	def save(self):
		file=open(self.path+'foremost.set','w')
		file.write(`[self.auto,self.scr_flag, self.plg_select]+[self.black_list]+[[self.plg_files[index] for index in self.plg_draws]]`)
		file.close()
	def sets(self):
		draw_flag=self.draw_flag
		self.passive()
		form=_appuifw.Form([
		 (ru('Автоактивация'),'combo',([ru('нет'),ru('да')],self.auto)),
		 (ru('Размер экрана'),'combo',([u'352*416',u'176*208'],self.scr_flag))],17)
		form.execute()
		self.auto,self.scr_flag=int(form[0][2][1]),int(form[1][2][1])
		if e32.s60_version_info==(2,8) and self.auto:
			_appuifw.note(ru("Вкл-ть опцию 'Автоакт-ия' на вашем телефоне невозможно."))
			self.auto=0
		if self.scr_flag:self.img=image('new',(176,208))
		else:self.img=image('new',(352,416))
		self.save()
		if draw_flag:self.active()
	def exit(self):
		self.draw_flag=0
		e32.ao_sleep(0.2)
		#self.lock.signal()
		_appuifw.app.set_exit()
	def plg_sets(self):
		self.old_draw_flag=self.draw_flag
		self.passive()
		self.old_body,self.old_menu=_appuifw.app.body,_appuifw.app.menu
		self.plg_listbox=[]
		for index in range(len(self.plg_files)):
			if index in self.plg_draws:flag=u'+'
			else:flag=u'-'
			self.plg_listbox.append(flag+' | '+self.plg_calls[index].name)
		_appuifw.app.body,_appuifw.app.menu=_appuifw.Listbox(self.plg_listbox,self.plg_invert),[(ru('Применить'),self.plg_exit)]
	def plg_invert(self):
		index=_appuifw.app.body.current()
		if self.plg_listbox[index][0]==u'+':
		    self.plg_draws.remove(index)
		    self.plg_listbox[index]=u'-'+self.plg_listbox[index][1:]
		else:
		    if self.plg_calls[index].load_flag:self.plg_calls[index].load()
		    self.plg_draws.append(index)
		    self.plg_listbox[index]=u'+'+self.plg_listbox[index][1:]
		_appuifw.app.body.set_list(self.plg_listbox,index)
	def plg_exit(self):
		self.save()
		self.plg_listbox=[]
		self.plg_select=0
		_appuifw.app.body,_appuifw.app.menu=self.old_body,self.old_menu
		if self.old_draw_flag:self.active()
	def plg_select_sort(self,mode):
		coords=[[self.plg_calls[self.plg_draws[index]].img_y,self.plg_calls[self.plg_draws[index]].img_x,index] for index in range(len(self.plg_draws))]
		coords.sort()
		index_list=[index[2] for index in coords]
		index=index_list.index(self.plg_select)
		if mode==-1 and index>0:self.plg_select=index_list[index-1]
		elif mode==1 and index<len(index_list)-1:self.plg_select=index_list[index+1]
		self.save()
	def plg_select_sets(self):
		self.passive()
		self.plg_calls[self.plg_draws[self.plg_select]].sets()
		self.keycode[1]=0
		self.active()
	def plg_select_keys(self):
	    self.plg_calls[self.plg_draws[self.plg_select]].keys(self.keycode)
	def bl_sets(self):
	    self.old_draw_flag=self.draw_flag
	    self.passive()
	    self.old_body,self.old_menu=_appuifw.app.body,_appuifw.app.menu
	    self.bl_listbox=[]
	    app_list=appswitch.application_list(1)
	    for app in [app for app in self.black_list if app not in app_list]+list(app_list):
	        if app in self.black_list:flag1='+'
	        else:flag1=u'-'
	        if app in app_list:flag2=u'+'
	        else:flag2=u'-'
	        self.bl_listbox.append(flag1+' | '+flag2+' | '+app)
	    _appuifw.app.body,_appuifw.app.menu=_appuifw.Listbox(self.bl_listbox,self.bl_invert),[(ru('Применить'),self.bl_exit)]
	def bl_invert(self):
		index=_appuifw.app.body.current()
		if self.bl_listbox[index][0]=='+':
			self.black_list.remove(self.bl_listbox[index][8:])
			if self.bl_listbox[index][4]=='+':self.bl_listbox[index]='-'+self.bl_listbox[index][1:]
			else:
			    del self.bl_listbox[index]
			    if index==len(self.bl_listbox):index-=1
		else:
			self.black_list.append(self.bl_listbox[index][8:])
			self.bl_listbox[index]='+'+self.bl_listbox[index][1:]
		_appuifw.app.body.set_list(self.bl_listbox,index)
	def bl_exit(self):
		self.save()
		self.bl_listbox=[]
		_appuifw.app.body,_appuifw.app.menu=self.old_body,self.old_menu
		if self.old_draw_flag:self.active()
	def help_sets(self):
	    self.old_draw_flag=self.draw_flag
	    self.passive()
	    self.old_body,self.old_menu=_appuifw.app.body,_appuifw.app.menu
	    _appuifw.app.menu=[
	     (ru('Общие сведения'),lambda:self.help_load('1')),
	     (ru('Настр. плагинов'),(
	      (ru('станд-ые плагины'),lambda:self.help_load('2')),
	      (ru('бегущая строка'),lambda:self.help_load('5')),
	      (ru('CallID,LAC и имена'),lambda:self.help_load('6')),
	      (ru('создание анимаций'),lambda:self.help_load('7')))),
	     (ru('Настр. программы'),lambda:self.help_load('3')),
	     (ru('Черный список'),lambda:self.help_load('4')),
	     (ru('Назад'),self.help_exit)]
	    self.text()
	    self.help_load('1')
	def help_exit(self):
		_appuifw.app.body,_appuifw.app.menu=self.old_body,self.old_menu
		if self.old_draw_flag:self.active()
	def help_load(self,part):
		file=open(self.path+'help\\'+part+'.set','r')
		_appuifw.app.body.set(ru(file.read()))
		_appuifw.app.body.set_pos(0)
		file.close()

main=main()