# Cyberfish 05.2007
# hatchet.py v0.0.4 alfa
# last modified on May 21, 2007
# -*- coding: win-1251 -*-
#
import appuifw
import os
import spath as s
import lite_fm as fm
import math
appuifw.app.body=round=appuifw.Text()
round.focus=False
appuifw.app.title=u"hatchet"
def menu():
  appuifw.app.menu=[(unicode('C��e��� �a���','cp1251'),g.gl1),(unicode("Pa����� �a��","cp1251"),((unicode("�po�e���","cp1251"),lambda:ibyte(1)),(unicode("�a���",'cp1251'),lambda:ibyte(0)))),(unicode("Co�pa�� �a��","cp1251"),fglue),(unicode('O �po�pa��e?','cp1251'),lambda:appuifw.note(u"Hatchet v0.0.4 Thank you for using.\r\nCyberfish 2007","info")),(unicode('B�xo�','cp1251'),quit)]
def quit():appuifw.app.set_exit()
appuifw.app.exit_key_handler=quit
def uni(x):return x.decode('utf-8')
def cp(x):return x.decode('cp1251')
appuifw.app.screen='normal'
round.color=(0,0,200)
def ibyte(select):
  app_path=appuifw.app.full_name()
  file=fm.manager(s.open_path(app_path))
  if file:
    s.save_path(app_path,file)
    f=open(file,'rb')
    fsize=os.path.getsize(file)
    if select==0:
      size=0
      while size<=0 or size>=fsize:
        size=appuifw. query(unicode('Pa��ep � �a��ax:','cp1251'),'number')
      size=float(size)
    elif select==1:
      rate=0
      while rate<=0 or rate>=100/2 or rate==None:
        rate=appuifw.query(unicode('Pa��ep � �po�e��ax:','cp1251'),'number')
      if 0<rate<100:
        size=float(fsize)/100*rate
      if size<1.0:return
    bitsize=fsize/size
    if math.modf(size)[0]>0:
      bitsize+=1
    bit=1
    round.set(unicode(os.path.split(file)[1]+' '+`os.path.getsize(file)`+'�a��\r\n','cp1251'))
    while bit<bitsize+1:
      filename=os.path.splitext(file)[0]+'_'+str(bit)+os.path.splitext(file)[1]
      data=f.read(size)
      open(filename,'wb').write(data)
      bit+=1
      if os.path.getsize(filename)==0:os.remove(filename);break
      round.add(unicode(os.path.split(filename)[1]+' '+`os.path.getsize(filename)`+'�a��'+'\r\n','cp1251'))
    f.close()
    round.add(unicode('�o�o�o.','cp1251'))
def fglue():
  app_path=appuifw.app.full_name()
  path=fm.manager(s.open_path(app_path))
  if path:
    if path[-5:]!='_comp':
      s.save_path(app_path,path)
      transfer=-1
      while transfer==-1 or transfer==None:
        transfer=appuifw.popup_menu([unicode('He �epe�oc���','cp1251'),unicode('�epe�oc���','cp1251')],cp('Ko�e� �a��a'))
      if transfer is 0:tfr=''
      elif transfer is 1:tfr='\r\n'
      fx=os.path.split(path)[1]
      path=os.path.split(path)[0]+'\\'
      round.set(unicode('�y��: \t'+path,'cp1251','replace'))
      for fname in os.listdir(path):
        if fname[-5:]=='_comp':os.unlink(path+fname)
      i=map(uni,os.listdir(path))
      file=path+fx+'_comp'
      open(file,'wb').write('')
      I0=0
      IO=len(i)
      while IO>I0:
        try:
          xfile=path+i[I0]
          round.add(unicode("\r\n"+i[I0].encode('cp1251')+" Ok.\t"+`os.path.getsize(path+i[I0])`+'�a��','cp1251','replace'))
          rfile=open(xfile).read()
          try:
            open(file,'ab').write(rfile+tfr)
          except:break
          I0+=1
        except:break
      round.add(unicode('\r\n'+os.path.split(file)[1]+' Ok.'+`os.path.getsize(file)`+'�a��','cp1251','replace'))
class glue:
  def __init__(self):
     self.fl=[]
     self.debuff=[]
     self.menugl=[(cp('C��e���'),self.gl2),(cp('Y�pa�� �oc�e����'),self.gl0cl),(cp('O��e�a'),self.gl0ca)]
     self.ap=appuifw.app.full_name()
  def akd1(self,x,c):c1=round.color;round.color=c;round.add(unicode('%s\r\n'%(x),'cp1251','replace'));round.color=c1
  def gl0r1(self):
    if self.debuff:self.fl.append(self.debuff.pop(len(self.debuff)-1));self.glbuff()
  def clbuff(self,x):
    if x==1:self.debuff=[]
    elif x==2:self.fl=[]
    else:
        self.fl=[]
        self.debuff=[]
  def gl0ca(self):
    round.clear()
    self.fl=[]
    self.debuff=[]
    menu()
  def glbuff(self):
    round.clear()
    c=1
    for path in self.fl:
       while 1:
         round.add(unicode('%s %s %s �a��.\r\n'%(c,os.path.split(path)[1],os.path.getsize(path)),'cp1251','replace'))
         c+=1
         break
    else:
         for path in self.debuff:self.akd1(os.path.split(path)[1],(255,0,0))#+'\r\n'
    _return=(cp("Bep�y�� (Green)"),self.gl0r1)
    if len(self.debuff)>0: # if self.debuff
      if _return not in self.menugl:self.menugl.insert(1,_return);round.bind(63586,self.gl0r1)
    elif not self.debuff:
       try:self.menugl.remove(_return)
       except:pass
#try/except �o���o ��� gl1
  def gl0cl(self):
    if len(self.fl)==0:
      round.clear()
      self.clbuff(3)
      menu()
    elif len(self.fl)>0:
      self.debuff.append(self.fl.pop(len(self.fl)-1))
      self.glbuff()
  def gl1(self):
    path=1
    c=1
    round.clear()
    while path:
       path=fm.manager(s.open_path(self.ap))
       if path:
          s.save_path(self.ap,path)
          self.fl.append(path)
#          round.add(cp("%s %s %s �a��\r\n"%(c,os.path.split(path)[1],os.path.getsize(path))))
          c+=1
       if len(self.fl)>1:
         round.bind(8,self.gl0cl)
         self.glbuff()
         appuifw.app.menu=self.menugl
  def gl2(self):
    if len(self.fl)>1:
      i=self.fl.pop(0)
      for f in self.fl:
         open(i,'ab').write(open(f,'rb').read())
      else:round.add(unicode("\r\n"*2+"%s %s �a��\r\n"%(os.path.split(i)[1],os.path.getsize(i)),'cp1251','replace'));self.clbuff(3);menu()
g=glue()
menu()
