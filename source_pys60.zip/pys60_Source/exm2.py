###############
from gla_2 import *
###############
appinit()
###############
gla_setmain(100)

x=20
yh=60
yl=yh+30
#A
t1=gla_ltn(10,40)
t2=gla_ltn(31,100)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+10)+gla_lan(t2,x+10,x+10)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+2)+gla_lan(t2,x+2,x+2)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(20,50)
t2=gla_ltn(41,100)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+10)+gla_lan(t2,x+10,x+10)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+18)+gla_lan(t2,x+18,x+18)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(0,30)
t2=gla_ltn(51,100)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+6)+gla_lan(t2,x+6,x+6)
y1=gla_lan(t1,0,75)+gla_lan(t2,75,75)
x2=gla_lan(t1,87,x+14)+gla_lan(t2,x+14,x+14)
y2=gla_lan(t1,207,75)+gla_lan(t2,75,75)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#L
t1=gla_ltn(40,70)
t2=gla_ltn(71,100)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(30,60)
t2=gla_ltn(61,100)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y1=gla_lan(t1,0,yl)+gla_lan(t2,yl,yl)
x2=gla_lan(t1,87,x+38)+gla_lan(t2,x+38,x+38)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#BERT927
t1=gla_ltn(40,80)
t2=gla_ltn(81,100)
gla_text(t1+t2,gla_lan(t1,175,yh+2)+gla_lan(t2,yh+2,yh+2),gla_lan(t1,207,yl+2)+gla_lan(t2,yl+2,yl+2),u'BERT 927',gla_lcn(t1,0,0,0x7f,0xff)+gla_lcn(t2,0,0,0xff,0xff))
###############
while appstate():
    gla_drawmaintest()
###############