#script by _virtual_machine_

import e32,e32posix,time,_appuifw,appswitch

def ru(t):return t.decode('utf-8')
def ur(t):return t.encode('utf-8')

class main:
	def __init__(self):
		#self.lock=e32.Ao_lock()#
		self.path=_appuifw.app.full_name()[0]+':\\System\\Apps\\AppKill\\'#:\\nokia\\scripts\\
		file=open(self.path+'appkill.set','r')
		self.flag_auto,self.flag_mode,self.select=eval(file.read())
		file.close()
		self.app_set(0)
		_appuifw.app.menu=[
		 (ru('Закрыть'),(
		  (ru('сейчас'),self.kill_now),
		  (ru('позже в'),self.kill_in),
		  (ru('позже через'),self.kill_over))),
		 (ru('Список'),(
		  (ru('инвертировать'),self.app_exc),
		  (ru('добавить все'),self.app_on),
		  (ru('очистить'),self.app_off))),
		 (ru('Настройки'),(
		  (ru('скрытые'),self.set_all),
		  (ru('автовыход'),self.set_auto))),
		 (ru('Помощь'),(
		  (ru('о программе'),lambda:self.help_name('about')),
		  (ru('режимы закрытия'),lambda:self.help_name('kills')),
		  (ru('упр-ие списком'),lambda:self.help_name('apps')),
		  (ru('настройки'),lambda:self.help_name('sets')))),
		 (ru('Выход'),_appuifw.app.set_exit)]
		_appuifw.app.exit_key_handler=_appuifw.app.set_exit#self.lock.signal
		#self.lock.wait()#
	def app_set(self,mode=1):
		if mode:index=_appuifw.app.body.current()
		self.apps=[]
		for app in appswitch.application_list(self.flag_mode):
			if app in self.select:txt=u'+ | '
			else:txt=u'- | '
			self.apps.append(txt+app)
		self.apps.insert(0,ru('Приложений: '+str(len(self.apps))).center(21))
		if mode:_appuifw.app.body.set_list(self.apps,index)
		else:
		    _appuifw.app.body=_appuifw.Listbox(self.apps,self.app_exc)
		    _appuifw.app.body.bind(0x35,self.kill_fast)
		file=open(self.path+'appkill.set','w')
		file.write(`[self.flag_auto,self.flag_mode,self.select]`)
		file.close()
	def app_on(self):
		self.select=list(appswitch.application_list(self.flag_mode))
		self.app_set()
	def app_off(self):
		self.select=[]
		self.app_set()
	def app_exc(self):
		index=_appuifw.app.body.current()
		if index!=0:
			app=self.apps[index][4:]
			if app in self.select:self.select.remove(app)
			else:self.select.append(app)
		self.app_set()
	def kill_text(self):
		self.old_body,self.old_menu=_appuifw.app.body,_appuifw.app.menu
		_appuifw.app.body=_appuifw.Text()
		_appuifw.app.body.color=0
		_appuifw.app.body.focus=False
	def kill_fast(self):
		self.flag_auto=1
		self.kill_now()
	def kill_now(self,mode=1):
		if len(self.select)==0:return _appuifw.note(ru('Ничего не выделено.'),'error')
		if mode:self.kill_text()
		else:_appuifw.app.body.set(u'')
		_appuifw.app.body.add(ru('>>> Старт.\n'))
		_appuifw.app.menu=[(ru('Отменить'),self.kill_in_exit)]
		self.flag_timer=0
		for app in self.select:
		    if self.flag_timer:break
		    if app not in appswitch.application_list(self.flag_mode):continue
		    while app in appswitch.application_list(self.flag_mode):
		        appswitch.kill_app(app)
		        e32.ao_sleep(0.8)
		    _appuifw.app.body.add(u'>>> '+app+ru(' убит.\n'))
		_appuifw.app.body.add(ru('>>> Готово.'))
		e32.ao_sleep(0.5)
		if self.flag_auto:_appuifw.app.set_exit()
		else:self.kill_now_exit()
	def kill_in(self):
		if len(self.select)==0:return _appuifw.note(ru('Ничего не выделено.'),'error')
		try:sec=_appuifw.query(ru('Стартовать в:'),'time')-1+1
		except:return
		self.kill_text()
		_appuifw.app.menu=[(ru('Отменить'),self.kill_in_exit)]
		timer=time.strftime('%H%M',time.gmtime(sec))
		timer_txt=time.strftime('%H.%M.%S',time.gmtime(sec))
		self.flag_timer=0
		while timer!=time.strftime('%H%M'):
		    if self.flag_timer:
		    	self.kill_now_exit()
		    	return
		    _appuifw.app.body.set(ru('\nСейчас:  '+time.strftime('%H.%M.%S')+'\n\nСтарт в: '+timer_txt))
		    e32.ao_sleep(5)
		self.kill_now(0)
	def kill_over(self):
		if len(self.select)==0:return _appuifw.note(ru('Ничего не выделено.'),'error')
		try:sec=_appuifw.query(ru('Стартовать через:'),'time')-5
		except:return
		self.kill_text()
		_appuifw.app.menu=[(ru('Отменить'),self.kill_in_exit)]
		self.flag_timer=0
		while sec>=0:
		    if self.flag_timer:
		    	self.kill_now_exit()
		    	return
		    _appuifw.app.body.set(ru('\n\nСтарт через: '+time.strftime('%H.%M.%S',time.gmtime(sec))))
		    sec-=5
		    e32.ao_sleep(5)
		self.kill_now(0)
	def kill_now_exit(self):
		_appuifw.app.body,_appuifw.app.menu=self.old_body,self.old_menu
		self.app_set()
	def kill_in_exit(self):
		self.flag_timer=1
	def set_auto(self):
		flag=_appuifw.query(ru('Выходить после закрытия?\nОК-да,\nОтмена-нет.'),'query')
		if flag:self.flag_auto=1
		else:self.flag_auto=0
		self.app_set()
	def set_all(self):
		flag=_appuifw.query(ru('Показывать скрытые?\nОК-да,\nОтмена-нет.'),'query')
		if flag:self.flag_mode=1
		else:self.flag_mode=0
		self.app_set()
	def help_name(self,name):
		self.kill_text()
		if name=='about':_appuifw.app.body.set(ru('''           О программе.

Название: AppKill 1.10
Автор: _virtual_machine_
Место жительства:
   www.dimonvideo.ru
Возможности программы:
  -закрытие приложений;
  -составление списка;
  -установка таймера.
'''))
		else:
		    file=open(self.path+'helps\\'+name+'.txt','r')
		    _appuifw.app.body.set(ru(file.read()))
		    file.close()
		_appuifw.app.body.set_pos(0)
		_appuifw.app.body.set_pos(170)
		_appuifw.app.menu=[(ru('Назад'),self.kill_now_exit)]

main()