#created by Vital 6630
def ru(x):return x.decode('utf-8')
def ur(x):return x.encode('utf-8')
import appuifw
import os
import e32
import location
import messaging
import sysinfo
from key_codes import *
try:
  import appswitch
  import easydb
  import keypress
  import powlite_fm
except:
  appuifw.note(ru('Установите подборку модулей'),'error')
  os.abort()
fileman = powlite_fm.manager()
def key(k):keypress.simulate_key(k,k)
def bg():
  e32.start_exe('Z:\System\Programs\AppRun.exe','Z:\System\Apps\Phone\Phone.app')
  e32.ao_sleep(1)
d=easydb.EasyDB()
s=easydb.EasyDB()
t=easydb.EasyDB()
load_set=0
mcc,mnc,lac,cellid=location.gsm_location()
name=unicode(mcc)+'_'+unicode(mnc)
path='C:\\System\\Apps\\Phone\\Oplogo\\'+name+'_0.bmp'
app_dir=':\\System\\Apps\\RunPython\\Apps\\'
dir=appuifw.app.full_name()[0]+app_dir+'OpMenu\\'
Plugins=dir+'Plugins\\'
if os.path.exists(Plugins)==0:
  os.mkdir(Plugins)
DB_DIR=Plugins+name+'\\'
if os.path.exists(DB_DIR)==0:
  os.mkdir(DB_DIR)
Settings=dir+'Settings\\'
if os.path.exists(Settings)==0:
  os.mkdir(Settings)
SET=Settings+name+'.cdb'
Logo=dir+'Logo\\'
if os.path.exists(Logo)==0:
  os.mkdir(Logo)
List=dir+'List\\'
if os.path.exists(List)==0:
  os.mkdir(List)
LIST=List+name+'.cdb'
HELP=dir+'Help\\'
loc=1
if sysinfo.signal()==0:
  loc=0
def install_set():
  title=ru('OpMenu')
  nomer=u''
  cod=0
  ver=1
  min=0
  max=0
  pr1='-'
  pr2='-'
  pr3='-'
  sec1=0
  sec2=2
  DB=DB_DIR+title+'.cdb'
  s.Load(SET,create=False)
  s.Add(u'nomer',nomer)
  s.Add(u'cod',cod)
  s.Add(u'ver',ver)
  s.Add(u'min',min)
  s.Add(u'max',max)
  s.Add(u'pr1',pr1)
  s.Add(u'pr2',pr2)
  s.Add(u'pr3',pr3)
  s.Add(u'sec1',sec1)
  s.Add(u'sec2',sec2)
  s.Add(u'DB',DB)
  s.Add(u'title',title)
  s.Save
  d.Load(DB,create=False)
  d.Add(ru('< нет записей >'),u'|')
  d.Save
if os.path.exists(SET)==0 and loc==1:
  install_set()
def change_set():
  global nomer,cod,ver,min,max,pr1,pr2,pr3,sec1,sec2
  try:
    appuifw.app.title=ru('Настройки')
    model1=[ru('123'),ru('Abc')]
    model2=[u'0',u'1',u'2',u'3',u'4',u'5']
    data=[(ru('Формат номера'),'text',unicode(nomer)),(ru('Кол-во знаков в коде пополнения'),'number',int(cod)),(ru('MIN сумма перевода'),'number',int(min)),(ru('MAX сумма перевода'),'number',int(max)),(ru('Вариант ввода номера'),'combo',(model1,int(ver))),(ru('Клавиши в KeyMan'),'text',unicode(pr1)),(ru('Клавиши в  LanguageSwitcher'),'text',unicode(pr2)),(ru('Клавиши в  MultiClipboard'),'text',unicode(pr3)),(ru('Задержка запуска (сек)'),'combo',(model2,int(sec1))),(ru('Задержка MultiClipboard (сек)'),'combo',(model2,int(sec2)))]
    flags=appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced
    form=appuifw.Form(data,flags)
    form.execute()
    nomer=form[0][2]
    cod=int(form[1][2])
    min=int(form[2][2])
    max=int(form[3][2])
    ver=int(str(form[4][2])[-3])
    pr1=form[5][2]
    pr2=form[6][2]
    pr3=form[7][2]
    sec1=int(str(form[8][2])[-3])
    sec2=int(str(form[9][2])[-3])
    s.Load(SET,create=False)
    s.Add(u'nomer',nomer)
    s.Add(u'cod',cod)
    s.Add(u'min',min)
    s.Add(u'max',max)
    s.Add(u'ver',ver)
    s.Add(u'pr1',pr1)
    s.Add(u'pr2',pr2)
    s.Add(u'pr3',pr3)
    s.Add(u'sec1',sec1)
    s.Add(u'sec2',sec2)
    s.Save
    find_app()
    MENU()
  except:
    MENU()
def code():
  global data
  data=appuifw.query(ru('Код пополнения:'),'text')
  if data==None:
    return
  if len(data)!=cod:
    appuifw.note(ru('Количество знаков должно быть ')+unicode(cod),'error')
    code()
def code2():
  global data
  data=appuifw.query(ru('Код:'),'text')
  if data==None:
    return
def numb():
  global i,number
  menu=[ru('Ввести'),ru('Выбрать из списка')]
  i=appuifw.popup_menu(menu,ru('Номер абонента:'))
  if i==None:
    return
  if i==0:
    if ver==0:
      number=appuifw.query(ru('Номер телефона (')+nomer+')','float')
    else:
      number=appuifw.query(ru('Номер телефона (')+nomer+')','text')
    if number==None:
      return
    number=str(number)
    if ver==0:
      number=number[:-2]
    if len(number)!=len(nomer):
      appuifw.note(ru('Номер телефона должен состоять из ')+unicode(len(nomer))+ru('  знаков'),'error')
      numb()
  if i==1:
    appuifw.app.title=ru('Список абонентов')
    t.Load(LIST)
    files=t.GetKeys()
    files.sort()
    index=appuifw.selection_list(files)
    if index==None:
      back()
    number=t.Get(files[index])
def summa():
  global sum
  sum=appuifw.query(ru('Сумма перевода:'),'number')
  if sum==None:
    return
  if sum<min or sum>max:
    appuifw.note(ru('Сумма должна быть в пределах ')+unicode(min)+'-'+unicode(max),'error')
    sum()
  sum=str(sum)
def add_list():
  try:
    name,number=appuifw.multi_query(ru('Имя:'),ru('Номер телефона (')+nomer+')')
  except:
    back()
  if len(number)!=len(nomer):
    appuifw.note(ru('Номер телефона должен состоять из ')+unicode(len(nomer))+ru('  знаков'),'error')
    add()
  else:
    t.Load(LIST,create=False)
    t.Add(name,number)
    t.Save
    appuifw.note(ru("Абонент '")+name+ru("' добавлен"),'conf')
    back()
def view_list():
  appuifw.app.title=ru('Выберите абонента')
  t.Load(LIST)
  files=t.GetKeys()
  files.sort()
  index=appuifw.selection_list(files)
  if index==None:
    back()
  number=t.Get(files[index])
  appuifw.note(ru('Имя: ')+files[index]+ru('\nНомер: ')+number,'info')
  view_list()
def del_list():
  appuifw.app.title=ru('Выберите абонента')
  t.Load(LIST,create=False)
  files=t.GetKeys()
  files.sort()
  index=appuifw.selection_list(files)
  if index==None:
    back()
  if appuifw.query(ru("Удалить '")+files[index]+ru("'?"),"query")==True:
    t.Del(files[index])
    t.Save
    appuifw.note(ru("Абонент '")+files[index]+ru("' удален"),'conf')
  back()
def back():
  appuifw.app.title=title
def phone():
  pro1,pro2,pro3,c,com=0,0,0,[],[]
  c.append('G')
  for a in range(0,len(keys)):
    b=keys[a]
    for aa in range(0,10):
      if b==str(aa):
        com.append(aa+48)
        c.append(aa)
  if pr1!='-':
    for a in range(0,len(pr1)):
      b=pr1[a]
      for a in range(0,len(c)):
        if str(c[a])==str(b):
          pro1=1
          break
  if pr2!='-':
    for a in range(0,len(pr2)):
      b=pr2[a]
      for a in range(0,len(c)):
        if str(c[a])==str(b):
          pro2=1
          break
  if pr3!='-':
    for a in range(0,len(pr3)):
      b=pr3[a]
      for a in range(0,len(c)):
        if str(c[a])==str(b):
          pro3=1
          break
  if pro1!=0:
    appswitch.kill_app(u'KeyMan')
  if pro2!=0:
    appswitch.kill_app(u'Language Switcher') or appswitch.kill_app(u'LangSwitcher') or appswitch.kill_app(u'LanguageSwitcher')
  if pro3!=0:
    e32.start_exe('Z:\System\Programs\AppRun.exe',app3)
    e32.ao_sleep(sec2)
    key(63555)
    key(63554)
    key(63497)
    key(63554)
  bg()
  for a in range(0,len(keys)):
    key(com[a])
  key(63586)
  if pro1!=0:
    e32.ao_sleep(sec1)
    e32.start_exe('Z:\System\Programs\AppRun.exe',app1)
  if pro2!=0:
    e32.ao_sleep(sec1)
    e32.start_exe('Z:\System\Programs\AppRun.exe',app2)
  if pro3!=0:
    e32.start_exe('Z:\System\Programs\AppRun.exe',apd3)
  os.abort()
def ussd():
  pro1,pro2,pro3,c,com=0,0,0,[],[]
  c.append('G')
  for a in range(0,len(keys)):
    b=keys[a]
    for aa in range(0,10):
      if b==str(aa):
        com.append(aa+48)
        c.append(aa)
    if b=='*':
      com.append(42)
      c.append('*')
    if b=='#':
      com.append(35)
      c.append('#')
    if b=='c':
      code()
      if data==None:
        back()
      for a in range(0,cod):
        k=48+int(data[a])
        com.append(k)
        c.append(data[a])
    if b=='k':
      code2()
      if data==None:
        back()
      for a in range(0,len(data)):
        k=48+int(data[a])
        com.append(k)
        c.append(data[a])
    if b=='n':
      numb()
      if i==None or number==None:
        back()
      for a in range(0,len(nomer)):
        k=48+int(number[a])
        com.append(k)
        c.append(number[a])
    if b=='s':
      summa()
      if sum==None:
        back()
      for a in range(0,len(sum)):
        k=48+int(sum[a])
        com.append(k)
        c.append(sum[a])
  if pr1!='-':
    for a in range(0,len(pr1)):
      b=pr1[a]
      for a in range(0,len(c)):
        if str(c[a])==str(b):
          pro1=1
          break
  if pr2!='-':
    for a in range(0,len(pr2)):
      b=pr2[a]
      for a in range(0,len(c)):
        if str(c[a])==str(b):
          pro2=1
          break
  if pr3!='-':
    for a in range(0,len(pr3)):
      b=pr3[a]
      for a in range(0,len(c)):
        if str(c[a])==str(b):
          pro3=1
          break
  if pro1!=0:
    appswitch.kill_app(u'KeyMan')
  if pro2!=0:
    appswitch.kill_app(u'Language Switcher') or appswitch.kill_app(u'LangSwitcher') or appswitch.kill_app(u'LanguageSwitcher')
  if pro3!=0:
    e32.start_exe('Z:\System\Programs\AppRun.exe',app3)
    e32.ao_sleep(sec2)
    key(63555)
    key(63554)
    key(63497)
    key(63554)
  bg()
  for a in range(0,len(com)):
    key(com[a])
    if com[a]==35:
      key(63586)
      if pro1!=0:
        e32.ao_sleep(sec1)
        e32.start_exe('Z:\System\Programs\AppRun.exe',app1)
      if pro2!=0:
        e32.ao_sleep(sec1)
        e32.start_exe('Z:\System\Programs\AppRun.exe',app2)
      if pro3!=0:
        e32.start_exe('Z:\System\Programs\AppRun.exe',apd3)
  os.abort()
def sms():
  text,com=[],[]
  for a in range(0,len(keys)):
    b=keys[a]
    if b=='<' or b=='>':com.append(a)
    if b=='n':
      numb()
      if i==None or number==None:
        return
      text.append(number)
    if b=='s':
      summa()
      if sum==None:
        return
      text.append(sum)
    if b=='c':
      code()
      if data==None:
        return
      text.append(data)
    if b=='k':
      code2()
      if data==None:
        return
      text.append(data)
  a1,a2,a3,a4=com[0]+1,com[1],com[2]+1,com[3]
  sms_text=keys[a1:a2]
  for a in range(0,len(text)):
    sms_text=sms_text+' '+text[a]
  sms_text=str(sms_text)
  num_sms=keys[a3:a4]
  bg()
  messaging.sms_send(num_sms,sms_text)
  os.abort()
def phone_rec():
  appuifw.app.title=ru('Набор номера')
  try:
    name,rec=appuifw.multi_query(ru('Имя:'),ru('Номер телефона:'))
    d.Load(DB,create=False)
    d.Add(name,rec)
    try:
      d.Del(ru('< нет записей >'))
    except:
      pass
    d.Save
    MENU()
  except:
    back()
def ussd_rec():
  try:
    appuifw.app.title=ru('USSD-запрос')
    p2,p3,p4=0,0,0
    y=[u'',u'c',u'k',u'n',u's']
    model=[ru('нет'),ru('код пополнения'),ru('любой код'),ru('номер абонента'),ru('сумма')]
    data=[(ru('Операция'),'text'),(ru('Номер телефона'),'text'),(ru('Выберите пункт'),'combo',(model,int(p2))),(ru('Выберите пункт'),'combo',(model,int(p3))),(ru('Выберите пункт'),'combo',(model,int(p4)))]
    flags=appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced
    form=appuifw.Form(data,flags)
    form.execute()
    name=form[0][2]
    p1=str(form[1][2])
    p2=int(str(form[2][2])[-3])
    p3=int(str(form[3][2])[-3])
    p4=int(str(form[4][2])[-3])
    rec='*'+p1
    if p2>0:
      rec=rec+'*'+y[p2]
    if p3>0:
      rec=rec+'*'+y[p3]
    if p4>0:
      rec=rec+'*'+y[p4]
    rec=rec+'#'
    d.Load(DB,create=False)
    d.Add(name,rec)
    try:
      d.Del(ru('< нет записей >'))
    except:
      pass
    d.Save
    appuifw.note(ru("Запись '")+name+ru("' сохранена"),'conf')
    MENU()
  except:
    MENU()
def sms_rec():
  try:
    appuifw.app.title=ru('СМС-запрос')
    p2,p3,p4=0,0,0
    y=[u'',u'c',u'k',u'n',u's']
    model=[ru('нет'),ru('код пополнения'),ru('любой код'),ru('номер абонента'),ru('сумма')]
    data=[(ru('Операция'),'text'),(ru('Слово'),'text'),(ru('Номер телефона'),'number'),(ru('Выберите пункт'),'combo',(model,int(p2))),(ru('Выберите пункт'),'combo',(model,int(p3))),(ru('Выберите пункт'),'combo',(model,int(p4)))]
    flags=appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced
    form=appuifw.Form(data,flags)
    form.execute()
    name=form[0][2]
    name2=form[1][2]
    p1=str(form[2][2])
    p2=int(str(form[3][2])[-3])
    p3=int(str(form[4][2])[-3])
    p4=int(str(form[5][2])[-3])
    rec='@<'+name2+'><'+p1+'>'
    if p2>0:
      rec=rec+y[p2]
    if p3>0:
      rec=rec+y[p3]
    if p4>0:
      rec=rec+y[p4]
    d.Load(DB,create=False)
    d.Add(name,rec)
    try:
      d.Del(ru('< нет записей >'))
    except:
      pass
    d.Save
    appuifw.note(ru("Запись '")+name+ru("' сохранена"),'conf')
    MENU()
  except:
    MENU()
def ren_rec():
  index=appuifw.app.body.current()
  if spisok[0]==ru('< нет записей >'):
    appuifw.note(ru('Нет записей'),'error')
  else:
    name=appuifw.query(ru('Новое имя:'),'text',spisok[index])
    if name==None or name==spisok[index]:
      return
    else:
      if spisok.count(name)>0:
        appuifw.note(ru('Запись с таким именем существует'),'error')
        ren_rec()
      else:
        d.Load(DB,create=False)
        rec=d.Get(spisok[index])
        d.Add(name,rec)
        d.Del(spisok[index])
        d.Save
        MENU()
def view_rec():
  index=appuifw.app.body.current()
  if spisok[0]==ru('< нет записей >'):
    appuifw.note(ru('Нет записей'),'error')
  else:
    rec=d.Get(spisok[index])
    appuifw.note(ru('')+rec,'info')
def del_rec():
  index=appuifw.app.body.current()
  if spisok[0]==ru('< нет записей >'):
    appuifw.note(ru('Нет записей'),'error')
  else:
    if appuifw.query(ru("Удалить '")+spisok[index]+ru("'?"),"query")==True:
      d.Load(DB,create=False)
      if len(spisok)==1:
        d.Add(ru('< нет записей >'),u'|')
      d.Del(spisok[index])
      d.Save
      MENU()
def add_rec():
  menu=[ru('Набор номера'),ru('USSD-запрос'),ru('СМС-запрос')]
  i=appuifw.popup_menu(menu,ru('ДОБАВИТЬ ЗАПИСЬ:'))
  if i==None:
    return
  if i==0:
    phone_rec()
  if i==1:
    ussd_rec()
  if i==2:
    sms_rec()
def new_db():
  global DB,title
  plugin=appuifw.query(ru('Имя плагина:'),'text')
  if plugin==None:return
  DB=DB_DIR+plugin+'.cdb'
  title=plugin
  s.Load(SET,create=False)
  s.Add(u'title',plugin)
  s.Add(u'DB',DB)
  s.Save
  plugin=easydb.EasyDB()
  plugin.Load(DB,create=False)
  plugin.Add(ru('< нет записей >'),u'|')
  plugin.Save
  MENU()
def ren_db():
  global DB,title
  appuifw.app.title=ru('Выберите плагин')
  files=map(ru,os.listdir(DB_DIR))
  index=appuifw.selection_list(files)
  if index==None:
    back()
  name=appuifw.query(ru('Новое имя:'),'text',files[index][:-4])
  if name==None or files[index]==name:
    back()
  else:
    if files.count(name+'.cdb')>0:
      appuifw.note(ru('Плагин с таким именем существует'),'error')
      ren_db()
    else:
      DB_R1=DB_DIR+files[index]
      DB_R2=DB_DIR+name+'.cdb'
      title=name
      os.rename(ur(DB_R1),ur(DB_R2))
      if DB==DB_R1:
        s.Load(SET,create=False)
        s.Add(u'DB',DB_R2)
        s.Add(u'title',title)
        s.Save()
      appuifw.note(ru('Готово'),'conf')
      MENU()
def del_db():
  global DB
  appuifw.app.title=ru('Выберите плагин')
  files=map(ru,os.listdir(DB_DIR))
  index=appuifw.selection_list(files)
  if index==None:back()
  DB_D=DB_DIR+files[index]
  if DB_D==DB:
    appuifw.note(ru('Невозможно удалить активный плагин'),'error')
    del_db()
  else:
    if appuifw.query(ru("Удалить '")+files[index]+ru("'?"),"query")==True:
      os.remove(ur(DB_D))
      appuifw.note(ru("Плагин '")+files[index]+ru("' удален"),'conf')
      back()
    else:
      del_db()
def sel_db():
  global DB,title
  appuifw.app.title=ru('Выберите плагин')
  files=map(ru,os.listdir(DB_DIR))
  index=appuifw.selection_list(files)
  if index==None:back()
  DB=DB_DIR+files[index]
  title=files[index][:-4]
  s.Load(SET,create=False)
  s.Add(u'title',title)
  s.Add(u'DB',DB)
  s.Save
  MENU()
def plugins():
  menu=[ru('Выбрать'),ru('Новый'),ru('Переименовать'),ru('Удалить')]
  i=appuifw.popup_menu(menu,ru('ПЛАГИНЫ:'))
  if i==None:return
  if i==0:sel_db()
  if i==1:new_db()
  if i==2:ren_db()
  if i==3:del_db()
def records():
  menu=[ru('Добавить (ABC)'),ru('Переименовать (7)'),ru('Просмотр (8)'),ru('Удалить (c)')]
  i=appuifw.popup_menu(menu,ru('ЗАПИСИ В МЕНЮ:'))
  if i==None:return
  if i==0:add_rec()
  if i==1:ren_rec()
  if i==2:view_rec()
  if i==3:del_rec()
def phonebook():
  menu=[ru('Добавить'),ru('Просмотреть'),ru('Удалить')]
  i=appuifw.popup_menu(menu,ru('СПИСОК АБОНЕНТОВ:'))
  if i==None:return
  if i==0:add_list()
  if i==1:view_list()
  if i==2:del_list()
def find_app():
  global pr1,pr2,pr3,app1,app2,app3,apd3
  km=app_dir+'KeyMan\\KeyMan.app'
  ls=app_dir+'LanguageSwitcher\\LanguageSwitcher.app'
  mc=app_dir+'MultiClipboard\\MultiClipboard.app'
  mcd=':\System\Programs\MultiClipboard\MCDaemon.dll'
  km1,km2='C'+km,'E'+km
  ls1,ls2='C'+ls,'E'+ls
  mc1,mc2='C'+mc,'E'+mc
  if pr1!='-':
    if os.path.exists(km1)==1:
      app1=km1+' B'
    elif os.path.exists(km2)==1:
      app1=km2+' B'
    else:
      appuifw.note(ru('Программа KeyMan не найдена'),'error')
  if pr2!='-':
    if os.path.exists(ls1)==1:
      app2=ls1+' B'
    elif os.path.exists(ls2)==1:
      app2=ls2+' B'
    else:
      appuifw.note(ru('Программа LanguageSwitcher не найдена'),'error')
  if pr3!='-':
    if os.path.exists(mc1)==1:
      app3=mc1
      apd3='C'+mcd+' B'
    elif os.path.exists(mc2)==1:
      app3=mc2
      apd3='E'+mcd+' B'
    else:
      appuifw.note(ru('Программа MultiClipboard не найдена'),'error')
def logo():
  menu=[ru('Установить'),ru('Просмотреть'),ru('Удалить')]
  i=appuifw.popup_menu(menu,ru('ЛОГОТИП:'))
  if i==None:return
  if i==0:
    file=fileman.AskUser(Logo,ext=[".bmp"])
    if file==None:return
    e32.file_copy(path,unicode(file))
    appuifw.note(ru('Логотип установлен'),'conf')
  if i==1:
    file=fileman.AskUser(Logo,ext=[".bmp"])
    if file==None:return
    Exe='Z:\System\Apps\ImageViewer\ImageViewer.app'
    ExeRun=ru("\""+Exe+"\" ")
    FileRun=ru("\""+ur(file)+"\"")
    e32.start_exe('Z:\System\Programs\AppRun.exe',ExeRun+FileRun)
    if appuifw.query(ru('Установить этот логотип?'),"query")==True:
      e32.file_copy(path,unicode(file))
      appuifw.note(ru('Логотип установлен'),'conf')
  if i==2:
    if os.path.exists(path)==0:
      appuifw.note(ru('Логотип не обнаружен'),'error')
      return
    if appuifw.query(ru('Удалить?'),"query")==True:
        os.remove(ur(path))
        appuifw.note(ru('Логотип удален'),'conf')
  MENU()
def about():
  appuifw.note(ru('OpMenu by Vital 6630\nICQ: 383822726'),'info')
def about1():
  appuifw.app.screen='full'
  appuifw.app.body=txt=appuifw.Text()
  txt.focus=False
  txt.font=u'LatinBold12'
  txt.color=0xff0000
  txt.style=appuifw.HIGHLIGHT_SHADOW
  txt.set(ru('За помощь в создании программы:'))
  txt.style=0
  txt.color=0x000080
  txt.add(ru('\nAtrant\nICQ: 399976'))
  txt.color=0xff0000
  txt.style=appuifw.HIGHLIGHT_SHADOW
  txt.add(ru('\n\nЗа идеи и помощь в тестировании программы:'))
  txt.style=0
  txt.color=0x000080
  txt.add(ru('\nIgorka\nICQ: 299919876'))
  txt.add(ru('\nOsmak\nICQ: 337876668'))
  txt.add(ru('\nSlavasyrota\nICQ: 424692385'))
  txt.set_pos(0)
  appuifw.app.exit_key_handler=MENU
  appuifw.app.menu=[(ru('Назад'),MENU)]
def help():
  appuifw.app.screen='normal'
  appuifw.app.title=ru('Помощь')
  files=map(ru,os.listdir(HELP))
  index=appuifw.selection_list(files)
  if index==None:MENU()
  file=ur(HELP+files[index])
  f=open(file,'r')
  text=f.read()
  f.close()
  appuifw.app.screen='full'
  appuifw.app.body=txt=appuifw.Text()
  txt.focus=False
  txt.font=u'LatinPlain12'
  txt.color=0x000080
  txt.set(ru(text))
  txt.set_pos(0)
  appuifw.app.exit_key_handler=MENU
  appuifw.app.menu=[(ru('Помощь'),help),(ru('Назад'),MENU)]
def quit():os.abort()
def menu():
  global keys,comand,index
  index=appuifw.app.body.current()
  d.Load(DB)
  keys=d.Get(spisok[index])
  if keys[0]=='|':
    os.abort()
  if keys[0]=='*':
    ussd()
  if keys[0]=='@':
    sms()
  if 0<=int(keys[0])<10:
    phone()
def MENU():
  global nomer,cod,ver,min,max,pr1,pr2,pr3,sec1,sec2,title,spisok,DB,load_set
  if loc==1:
    load_set=load_set+1
    if load_set==1:
      s.Load(SET)
      title=s.Get(u'title')
      nomer=s.Get(u'nomer')
      cod=s.Get(u'cod')
      ver=s.Get(u'ver')
      min=s.Get(u'min')
      max=s.Get(u'max')
      pr1=s.Get(u'pr1')
      pr2=s.Get(u'pr2')
      pr3=s.Get(u'pr3')
      sec1=s.Get(u'sec1')
      sec2=s.Get(u'sec2')
      DB=s.Get(u'DB')
      if pr1==None:
        pr1,pr2,pr3='-','-','-'
        s.Load(SET,create=False)
        s.Add(u'pr1',pr1)
        s.Add(u'pr2',pr2)
        s.Add(u'pr3',pr3)
        s.Save()
      if sec1==None:
        sec1,sec2=0,2
        s.Load(SET,create=False)
        s.Add(u'sec1',sec1)
        s.Add(u'sec2',sec2)
        s.Save()
      if DB==None:
        appuifw.note(ru('Создайте новый плагин.'),'error')
        new_db()
        if DB==None:
          os.abort()
      find_app()
    d.Load(DB)
    spisok=d.GetKeys()
    spisok.sort()
  else:
    title=ru(' ')
  appuifw.app.title=title
  appuifw.app.set_tabs([u''],menu)
  appuifw.app.screen='normal'
  if loc==0:
    appuifw.app.body=appuifw.Listbox([(ru('нет сети'),ru("смотри 'помощь'"))])
  else:
    appuifw.app.body=z=appuifw.Listbox(spisok,menu)
    z.bind(35,plugins)
    z.bind(42,records)
    z.bind(63586,phonebook)
    z.bind(63499,add_rec)
    z.bind(55,ren_rec)
    z.bind(56,view_rec)
    z.bind(8,del_rec)
  appuifw.app.exit_key_handler=quit
  if loc==0:
    appuifw.app.menu=[(ru('Помощь'),help)]
  else:
    appuifw.app.menu=[(ru('Плагины (#)'),plugins),(ru('Записи в меню (*)'),records),(ru('Список абонентов (green)'),phonebook),(ru('Инструменты'),((ru('Настройки'),change_set),(ru('Логотип'),logo),(ru('Помощь'),help),(ru('О программе'),about),(ru('Благодарность'),about1)))]
MENU()
if appuifw.app.full_name().find(u'Python')!=-1:
  lock=e32.Ao_lock()
  os.abort=lock.signal
  lock.wait()
