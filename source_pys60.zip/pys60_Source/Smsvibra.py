import inbox
import appuifw
import vibra
import e32
import thread

vibrate = True
thread_running = False

def stop_alarm():
    global vibrate
    vibrate = False

def vibra_thread():
    global vibrate
    global thread_running
    thread_running = True
    e32.ao_sleep(5)
    try:
        while vibrate:
            vibra.vibrate(100, 100)
            e32.ao_sleep(0.5)
            vibra.vibrate(100, 100)
            e32.ao_sleep(0.5)
            vibra.vibrate(500, 100)
            e32.ao_sleep(1)
    except: pass    
    thread_running = False
    vibrate = True

def m_exit():
    global script_lock 
    script_lock.signal()
    appuifw.app.set_exit()

def process_income_sms(id):
  print u"sms received"
  if thread_running == False:
   try:
     thread.start_new_thread(vibra_thread,())
   except:
     print (u"fuck thread")


script_lock = e32.Ao_lock()

appuifw.app.exit_key_handler=m_exit
appuifw.app.menu = [(u"STOP ALARM", stop_alarm)]
inb_mes = inbox.Inbox()
inb_mes.bind(process_income_sms)
print u"working"
script_lock.wait()
