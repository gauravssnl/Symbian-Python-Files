import sys
class sets:
	__file__="\\".join(sys.argv[0].split("\\")[:-1]+["settings.txt"])
	def __init__(self):
		for name,value in map(lambda line: line.split("="),open(self.__file__,"r").read().split("\n")):
			self.__dict__[name]=eval(value)
	def __setattr__(self,name,value):
		self.__dict__[name]=value
		open(self.__file__,"w").write("\n".join([name+"="+repr(value) for name,value in self.__dict__.items() if name.isupper()]))
sets=sets()