import appuifw
import e32
import keypress
import os
import appswitch
import graphics

def exit():
  appuifw.app.set_exit()

def sleep(seconds):
  e32.ao_sleep(float(seconds))

def sim_key(code1, code2 = 0):
  keypress.simulate_key(code1, code2)
  sleep(0.10000000000000001)

def stopping(key):
  if (key == 63499):
    os.abort()

appuifw.app.exit_key_handler = exit
lastpath = 'c:/lastx.txt'
try:
  f = open(lastpath, 'r')
  initcode = int(f.read())
  f.close()
except:
  initcode = 0
import keycapture
capturer = keycapture.KeyCapturer(stopping)
capturer.forwarding = 1
capturer.keys = [63499]
capturer.start()
appuifw.note(u'Dlya ostanovki nazhmite karandash =)', 'info')
while (initcode < 100000):
  e32.start_exe('X-plore.exe', '', 0)
  sleep(6)
  sim_key(63554)
  z = 0
  while (z < 3):
    z += 1
    sim_key(63554)
    sim_key(63497)
    sim_key(63497)
    sim_key(63554)
    code = str(initcode)
    while (len(code) < 5):
      code = ('0'+code)
    for k in range(len(code)):
      q = int(code[k])
      sim_key((48+q))
    sim_key(63554)
    sim_key(63554)
    img = graphics.screenshot()
    rgb = img.getpixel((202,163))
    if (rgb != [(0,0,0)]):
      f = open('c:/x-key.txt', 'w')
      f.write(str(initcode))
      f.close()
      os.abort()
    initcode += 1
    sim_key(63554)
  appswitch.kill_app(u'X-plore')
  f = open(lastpath, 'w')
  f.write(str((initcode - 2)))
  f.close()
  e32.reset_inactivity()

print u"that's all :-("
exit()
