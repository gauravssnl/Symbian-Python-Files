import appuifw
import math
def ru(x):return x.decode('utf-8')
appuifw.app.body=appuifw.Text(ru('Программа вычислит корни квадратного уравнения вида:\na*x**2+b*x+c=0\n\nНажмите левую софтклавишу\n'))
def count():
 a=appuifw.query(ru('Введите a'),'float')
 b=appuifw.query(ru('Введите b'),'float')
 c=appuifw.query(ru('Введите c'),'float')
 d=((b**2)-(4*a*c))
 if d<0:
  appuifw.note(ru('Нет корней, D<0'),'error')
 else:
  f=math.sqrt(d)
  x1=(-b+f)/(2*a)
  x2=(-b-f)/(2*a)
  def printout(mess):
   appuifw.app.body.add(mess)
  printout(ru('\nРезультат:\n x1=')+str(x1))
  printout(ru('\n x2=')+str(x2)+ru('\n'))
def author():
 appuifw.note(ru('Dimontrans ICQ:412580384\nvan diablo ICQ:380976099\nDimonVideo.ru'))
appuifw.app.menu=[(ru('Вычислить'),count),(ru('О проге...'),author)]
