#by Albert927 
import e32,appuifw,uikludges
a=appuifw
abt=a.Text
an=a.note
ln,cn,ab,al=[],0,0,e32.Ao_lock()
def ag(n=-1):
 global ln,cn,ll,la
 if n==-1:n=ln.pop()
 else:ln.append(cn)
 cn,a.app.screen,a.app.menu,a.app.exit_key_handler,t=n,la[n][0],ll[n],ll[n][-1][1],uikludges.set_right_softkey_text(ll[n][-1][0])
 ar()
def ar():
 global la,cn,ab
 a.app.body=ab=la[cn][1]()
def ae():
 al.signal()
 a.app.set_exit()

import os,time
class E:
 def __init__(s,d,e,f=''):s.d,s.e,s.f,s.l=d,e,f,[]
e=E('e:\\others\\','.txt','fclear')

def daf():
 for i in e.l:
  try:os.remove(i)
  except:
   try:os.rmdir(i)
   except:pass
 an(u'\u0412\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u043e')
 ab.clear()

def scd(d):
 e.l=[]
 scg(d)
 scgl()
 scts()
def scbd():
 e.l=[]
 scg('C:\\')
 scg('E:\\')
 scgl()
 scts()

def scts():
 n=''
 for i in e.l:n+=i+'\r\n'
 try:os.makedirs(e.d)
 except:pass
 f=open(e.d+e.f+e.e,'w')
 f.write(n)
 f.close()
 ab.color=(0,0,0)
 ab.set(unicode(n))
 ab.set_pos(0)

def scg(d):
 e.l.append(d)
 if os.path.isdir(d):
  for i in os.listdir(d):scg(d+'\\'+i)
def scgl():
 n=[]
 for i in e.l:
  if os.path.isfile(i):
   if int(os.stat(i)[6])==0:n.append(i)
 e.l=n

la=[['normal',abt]]
ll=[[(u'\u0421\u043a\u0430\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c',((u'\u043e\u0431\u0430 \u0434\u0438\u0441\u043a\u0430',scbd),(u'\u0434\u0438\u0441\u043a C:',lambda:scd('C:\\')),(u'\u0434\u0438\u0441\u043a E:',lambda:scd('E:\\')))),
     (u'\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0441\u0435',daf),
     (u'\u0412\u044b\u0445\u043e\u0434',ae)]]

ag(0)
al.wait()