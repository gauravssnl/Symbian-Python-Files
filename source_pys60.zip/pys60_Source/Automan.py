#script by _virtual_machine_

def ru(t):return t.decode('utf-8')
def ur(t):return t.encode('utf-8')

import e32,_appuifw
if e32.pys60_version_info[2]<15:
    _appuifw.note(ru("Необходима версия Python не ниже 1.3.15. Пожалуйста обновитесь."),'error')
    _appuifw.app.set_exit()	
import e32posix,sys,time,keypress,appswitch,_inbox,_telephone,_messaging
_inbox=_inbox.Inbox()
_telephone=_telephone.Phone()
_telephone.open()

class script:
	def __init__(self,path):
		self.old_body,self.old_menu=_appuifw.app.body,_appuifw.app.menu
		_appuifw.app.body=_appuifw.Text()
		_appuifw.app.menu=[(ru('Остановить'),self.abort)]
		self.out([ru('Интерпретация...')])
		file=open(path,'r')
		lines=ru(file.read()).splitlines()
		file.close()
		self.flag=1
		self.seek=0
		self.stack=[]
		self.key_map={
		 '0':0x30,'1':0x31,'2':0x32,'3':0x33,'4':0x34,'5':0x35,'6':0x36,'7':0x37,'8':0x38,'9':0x39,'*':0x2a,'#':0x23,'_#':0x7f,
		 'ls':0xf842,'rs':0xf843,'s':0xf845,'abc':0xf80b,'m':0xf852,'c':0x08,'y':0xf862,'n':0xf863,'l':0xf807,'r':0xf808,'u':0xf809,'d':0xf80a,
		 '_ls':0xa4,'_rs':0xa5,'_s':0xa7,'_abc':0x12,'_m':0xb4,'_c':0x01,'_y':0xc4,'_n':0xc5,'_l':0xe,'_r':0xf,'_u':0x10,'_d':0x11,}
		self.txt_map={
		 'a':[1,0x32],'b':[2,0x32],'c':[3,0x32],'d':[1,0x33],'e':[2,0x33],'f':[3,0x33],
		 'g':[1,0x34],'h':[2,0x34],'i':[3,0x34],'j':[1,0x35],'k':[2,0x35],'l':[3,0x35],
		 'm':[1,0x36],'n':[2,0x36],'o':[3,0x36],'p':[1,0x37],'q':[2,0x37],'r':[3,0x37],'s':[4,0x37],
		 't':[1,0x38],'u':[2,0x38],'v':[3,0x38],'w':[1,0x39],'x':[2,0x39],'y':[3,0x39],'z':[4,0x39],
		 ru('а'):[1,0x32],ru('б'):[2,0x32],ru('в'):[3,0x32],ru('г'):[4,0x32],
		 ru('д'):[1,0x33],ru('е'):[2,0x33],ru('ж'):[3,0x33],ru('з'):[4,0x33],
		 ru('и'):[1,0x34],ru('й'):[2,0x34],ru('к'):[3,0x34],ru('л'):[4,0x34],
		 ru('м'):[1,0x35],ru('н'):[2,0x35],ru('о'):[3,0x35],ru('п'):[4,0x35],
		 ru('р'):[1,0x36],ru('с'):[2,0x36],ru('т'):[3,0x36],ru('у'):[4,0x36],
		 ru('ф'):[1,0x37],ru('х'):[2,0x37],ru('ц'):[3,0x37],ru('ч'):[4,0x37],
		 ru('ш'):[1,0x38],ru('щ'):[2,0x38],ru('ъ'):[3,0x38],ru('ы'):[4,0x38],
		 ru('ь'):[1,0x39],ru('э'):[2,0x39],ru('ю'):[3,0x39],ru('я'):[4,0x39],
		 ' ':[1,0x30],'.':[1,0x31],',':[2,0x31],'?':[3,0x31],'!':[4,0x31],'@':[6,0x31],"'":[7,0x31],'-':[8,0x31],'_':[9,0x31],
		 '(':[10,0x31],')':[11,0x31],':':[12,0x31],';':[13,0x31],'/':[15,0x31],'%':[16,0x31],'*':[17,0x31],
		 '#':[18,0x31],'+':[19,0x31],'<':[20,0x31],'=':[21,0x31],'>':[22,0x31],'"':[23,0x31],'$':[24,0x31]}
		self.com_map={
		 'key':self.key,'txt':self.txt,'print':self.out,'clock':self.clock,'timer':self.timer,'sleep':self.sleep,
		 'app.run':self.app_run,'app.fg':self.app_fg,'app.bg':self.app_bg,'app.end':self.app_end,'app.kill':self.app_kill,
		 'os.new':self.os_new,'os.del':self.os_del,'os.copy':self.os_copy,'os.move':self.os_move,'os.rename':self.os_rename,
		 'sms.send':self.sms_send,'sms.del':self.sms_del,
		 'call.dial':self.call_dial,'call.hang':self.call_hang,
		 'def.new':self.def_new,'def.end':self.def_end,'def.call':self.def_call,
		 'for.new':self.for_new,'for.end':self.for_end,'for.sms':self.for_sms,'for.fg':self.for_fg,'for.bg':self.for_bg}
		self.def_map={}
		self.arg_map=[]
		for line in lines:
			if line!='':
			    pos=line.find(' ')
			    self.arg_map.append([self.com_map.get(line[:pos],self.none),line[pos+1:].split(',')])
		self.out([ru('Выполнение...')])
		while self.seek!=len(self.arg_map) and self.flag:
			self.arg_map[self.seek][0](self.arg_map[self.seek][1])
			self.seek+=1
		self.out([ru('Завершено!')])
		_appuifw.app.menu=[(ru('Вернуться'),self.back)]
	def abort(self):
		self.flag=0
	def back(self):
		_appuifw.app.body.focus=False
		_appuifw.app.body,_appuifw.app.menu=self.old_body,self.old_menu
	def none(self,arg):
		pass
	def key(self,arg):
		keypress.simulate_key(self.key_map.get(arg[0],0),self.key_map.get(arg[0],0))
		if len(arg)==2:e32.ao_sleep(float(arg[1]))
	def txt(self,arg):
		text=u''
		for line in arg:text+=u','+line
		old=0
		for simbol in text[1:]:
			code=self.txt_map.get(simbol,[0,0])
			if old==code[1]:e32.ao_sleep(1)
			for index in range(code[0]):keypress.simulate_key_mod(code[1],code[1],2)
			e32.ao_sleep(0.2)
			old=code[1]
	def out(self,arg):
		text=u''
		for line in arg:text+=u','+line
		_appuifw.app.body.add(unicode(time.strftime('%H:%M:%S')+': '+text[1:]+'\n\n'))
	def clock(self,arg):
		e32.set_home_time(time.time()+float(arg[0]))
	def timer(self,arg):
		while arg[0]!=time.strftime('%H:%M'):e32.ao_sleep(1)
	def sleep(self,arg):
		e32.ao_sleep(float(arg[0]))
	def app_run(self,arg):
		 try:
		     e32.start_exe('z:\\system\\programs\\apprun.exe',arg[0])
		     if len(arg)==2:e32.ao_sleep(float(arg[1]))
		 except:pass
	def app_fg(self,arg):
		appswitch.switch_to_fg(arg[0])
		if len(arg)==2:e32.ao_sleep(float(arg[1]))
	def app_bg(self,arg):
		appswitch.switch_to_bg(arg[0])
		if len(arg)==2:e32.ao_sleep(float(arg[1]))
	def app_end(self,arg):
		appswitch.end_app(arg[0])
		if len(arg)==2:e32.ao_sleep(float(arg[1]))
	def app_kill(self,arg):
		appswitch.kill_app(arg[0])
		if len(arg)==2:e32.ao_sleep(float(arg[1]))
	def os_new(self,arg):
		if arg[0].find('.')==-1:
			try:e32posix.mkdir(arg[0])
			except:pass
		else:
			try:
				file=open(arg[0],'a')
				file.close()
			except:pass
	def os_del(self,arg):
		if arg[0].find('.')==-1:
			try:
			    [self.os_del([arg[0]+'\\'+file]) for file in e32posix.listdir(arg[0])]
			    e32posix.rmdir(arg[0])
			except:pass
		else:
			try:e32posix.remove(arg[0])
			except:pass
	def os_copy(self,arg):
		if arg[0].find('.')==-1:
			try:
			    e32posix.mkdir(arg[1])
			    [self.os_copy([arg[0]+'\\'+file,arg[1]+'\\'+file]) for file in e32posix.listdir(arg[0])]
			except:pass
		else:
			try:e32.file_copy(arg[1],arg[0])
			except:pass
	def os_move(self,arg):
		self.os_copy(arg)
		self.os_del(arg)
	def os_rename(self,arg):
		try:e32posix.rename(arg[0],arg[1])
		except:pass
	def sms_send(self,arg):
		try:_messaging.sms_send(arg[0],arg[1])
		except:pass
		if len(arg)==3:e32.ao_sleep(float(arg[2]))
	def sms_del(self,arg):
		for id in _inbox.sms_messages():
			if _inbox.address(id)==arg[0]:_inbox.delete(id)
	def call_dial(self,arg):
		try:
		    _telephone.set_number(arg[0])
		    _telephone.dial()
		except:pass
	def call_hang(self,arg):
		e32.ao_sleep(float(arg[0]))
		try:_telephone.hang_up()
		except:pass
	def def_new(self,arg):
		self.def_map[arg[0]]=self.seek
		while 1:
			self.seek+=1
			if self.arg_map[self.seek][1][0]==arg[0]:break
	def def_end(self,arg):
		self.seek=self.stack.pop()
	def def_call(self,arg):
		self.stack.append(self.seek)
		self.seek=self.def_map[arg[0]]
	def for_new(self,arg):
		self.stack.append(1)
		self.def_map[arg[0]]=self.seek
	def for_end(self,arg):
		if self.stack[-1]==int(arg[1]):
		    self.stack.pop()
		    del self.def_map[arg[0]]
		else:
		    self.stack[-1]+=1
		    self.seek=self.def_map[arg[0]]
	def for_sms(self,arg):
		flag=0
		for id in _inbox.sms_messages():
			if _inbox.address(id)==arg[2]:flag=1
		if self.stack[-1]==int(arg[1]) or flag:
		    self.stack.pop()
		    del self.def_map[arg[0]]
		else:
		    self.stack[-1]+=1
		    self.seek=self.def_map[arg[0]]
	def for_fg(self,arg):
		if self.stack[-1]==int(arg[1]) or arg[2]==appswitch.application_list(0)[0]:
		    self.stack.pop()
		    del self.def_map[arg[0]]
		else:
		    self.stack[-1]+=1
		    self.seek=self.def_map[arg[0]]
	def for_bg(self,arg):
		if self.stack[-1]==int(arg[1]) or arg[2]!=appswitch.application_list(0)[0]:
		    self.stack.pop()
		    del self.def_map[arg[0]]
		else:
		    self.stack[-1]+=1
		    self.seek=self.def_map[arg[0]]

class main:
	def __init__(self):
		#self.lock=e32.Ao_lock()#
		self.path=_appuifw.app.full_name()[0]+':\\System\\Apps\\AutoMan\\'#:\\nokia\\scripts\\
		self.path_files=self.path+'scripts\\'
		self.file_name=''
		_appuifw.app.body=_appuifw.Listbox(self.file_get(),self.file_exc)
		_appuifw.app.body.bind(63499,self.file_new)
		_appuifw.app.body.bind(8,self.file_del)
		_appuifw.app.menu=[
		 (ru('Запустить'),self.file_run),
		 (ru('Скрипт'),(
		  (ru('создать'),self.file_new),
		  (ru('изменить'),self.file_exc),
		  (ru('удалить'),self.file_del))),
		 (ru('Помощь'),(
		  (ru('о программе'),lambda:self.help('about')),
		  (ru('упр-ие скриптами'),lambda:self.help('scripts')),
		  (ru('редакт-ие скриптов'),lambda:self.help('editors')))),
		 (ru('Выход'),_appuifw.app.set_exit)]
		_appuifw.app.exit_key_handler=_appuifw.app.set_exit#self.lock.signal
		#self.lock.wait()#
	def file_get(self):
		self.files=[unicode(file[:-4]) for file in e32posix.listdir(self.path_files) if file[-4:]=='.ams']
		return [ru('Скриптов: '+str(len(self.files))).center(24)]+self.files
	def file_run(self):
		if self.file_name==u'':
		    file_index=_appuifw.app.body.current()
		    if file_index==0:return
		    script(self.path_files+self.files[file_index-1]+'.ams')
		else:script(self.path_full)
	def file_new(self):
		self.file_index=_appuifw.app.body.current()-1
		self.file_name=_appuifw.query(ru('Имя скрипта:'),'text',u'new')
		try:
		    if len(self.file_name)>0:self.editor()
		except:self.file_name=u''
	def file_exc(self):
		self.file_index=_appuifw.app.body.current()-1
		if self.file_index!=-1:
		    self.file_name=self.files[self.file_index]
		    self.editor()
	def file_del(self):
		file_index=_appuifw.app.body.current()-1
		if file_index!=-1:
			e32posix.remove(self.path_files+self.files[file_index]+'.ams')
			_appuifw.app.body.set_list(self.file_get(),file_index+1)
	def editor(self):
		self.old_body,self.old_menu=_appuifw.app.body,_appuifw.app.menu
		self.path_full=self.path_files+self.file_name+'.ams'
		file=open(self.path_full,'a')
		file.close()
		file=open(self.path_full,'r')
		_appuifw.app.body=_appuifw.Text(ru(file.read()))
		file.close()
		_appuifw.app.body.set_pos(0)
		_appuifw.app.menu=[
		 (ru('Запустить'),self.editor_run),
		 (ru('Имя'),self.editor_name),
		 (ru('Помощь'),(
		  (ru('станд-ые команды'),lambda:self.help('coms_stand')),
		  (ru('упр-ие прилож-ми'),lambda:self.help('coms_app')),
		  (ru('файлы и папки'),lambda:self.help('coms_os')),
		  (ru('звонки и смс'),lambda:self.help('coms_call_sms')),
		  (ru('функции'),lambda:self.help('coms_def')),
		  (ru('циклы'),lambda:self.help('coms_for')))),
		 (ru('Назад'),self.editor_exit)]
	def editor_run(self):
		file=open(self.path_full,'w')
		file.write(ur(_appuifw.app.body.get()))
		file.close()
		self.file_run()
	def editor_name(self):
		file_name=_appuifw.query(ru('Имя скрипта:'),'text',self.file_name)
		try:
		    if len(file_name)>0:
		    	self.file_name=file_name
		    	self.path_full=self.path_files+self.file_name+'.ams'
		    	file=open(self.path_full,'a')
		    	file.close()
		except:pass
	def editor_exit(self):
		file=open(self.path_full,'w')
		file.write(ur(_appuifw.app.body.get()))
		file.close()
		self.file_name==u''
		_appuifw.app.body.focus=False
		_appuifw.app.body,_appuifw.app.menu=self.old_body,self.old_menu
		_appuifw.app.body.set_list(self.file_get(),self.file_index+1)
	def help(self,name):
		self.old_2_body,self.old_2_menu=_appuifw.app.body,_appuifw.app.menu
		_appuifw.app.body=_appuifw.Text()
		_appuifw.app.body.color=0
		_appuifw.app.body.focus=False
		file=open(self.path+'helps\\'+name+'.txt','r')
		_appuifw.app.body.set(ru(file.read()))
		file.close()
		_appuifw.app.body.set_pos(0)
		_appuifw.app.body.set_pos(170)
		_appuifw.app.menu=[(ru('Назад'),self.help_exit)]
	def help_exit(self):
		_appuifw.app.body,_appuifw.app.menu=self.old_2_body,self.old_2_menu
main=main()

try:
    file=open(main.path+'autorun.txt','r')
    name=file.read()
    file.close()
    if name!='':script(main.path_files+name+'.ams')
except:pass