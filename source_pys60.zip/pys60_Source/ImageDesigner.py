from graphics import *
import appuifw
import e32
from key_codes import *
import powlite_fm
import wt_ui


class Keyboard(object):
    def __init__(self,onevent=lambda:None):
        self._keyboard_state={}
        self._downs={}
        self._onevent=onevent
    def handle_event(self,event):
        if event['type'] == appuifw.EEventKeyDown:
            code=event['scancode']
            if not self.is_down(code):
                self._downs[code]=self._downs.get(code,0)+1
            self._keyboard_state[code]=1
        elif event['type'] == appuifw.EEventKeyUp:
            self._keyboard_state[event['scancode']]=0
        self._onevent()
    def is_down(self,scancode):
        return self._keyboard_state.get(scancode,0)
    def pressed(self,scancode):
        if self._downs.get(scancode,0):
            self._downs[scancode]-=1
            return True
        return False

######TCURSOR CLASS DECLARATION######
class TCursor:
  def __init__(self, canv, img, x, y, w, h):
    self.x = x
    self.y = y
#    self.s = 1
    self.canv = canv
    self.img = img
    self.wx = x
    self.wy = y
    self.ww = w
    self.wh = h
#    self.col = [0,0,0]
#    self.cold = 0

  def draw(self,imx,imy):

#    if self.cold == 0 :
#      for t in range(0,3):
#        self.col[t]  += 7
#      if self.col[0]>255:
#        self.cold=1
#        for t in range(0,3):
#          self.col[t]  = 255
#    else:
#      for t in range(0,3):
#        self.col[t]  -= 7
#      if self.col[0]<0:
#        self.cold=0 
#        for t in range(0,3):
#          self.col[t]  = 0

    self.canv.rectangle((self.x - 3,self.y-1,self.x + 4,self.y+2),0xffffff)
    self.canv.rectangle((self.x-1,self.y - 3,self.x+2,self.y + 4),0xffffff)

    self.canv.line((self.x - 4,self.y,self.x + 5,self.y),0x000000)
    self.canv.line((self.x,self.y - 4,self.x,self.y + 5),0x000000)

   
  def coord(self,cr = None):
    if cr <> None:
      if cr[0] <> None:
        self.x = cr[0]
      if cr[1] <> None:
        self.y = cr[1]
    else:
      return (self.x, self.y)


  def zone(self,sz = None):
    if sz <> None:
      if sz[0] <> None:
        self.wx = sz[0]
        self.x = sz[0]
      if sz[1] <> None:
        self.wy = sz[1]
        self.y = sz[1]
      if sz[2] <> None:
        self.ww = sz[2]
      if sz[3] <> None:
        self.wh = sz[3]        
    else:
      return (self.wx, self.wy, self.ww, self.wh)


  def move(self,d,s):
    if d == 0:
      if self.x > self.wx:
        self.x -= s
        if self.x < self.wx:
          self.x = self.wx
      else:
        return d
    elif d == 1:
      if self.x < self.wx+self.ww:
        self.x += s
        if self.x > self.wx+self.ww:
          self.x = self.wx+self.ww
      else:
        return d
    elif d == 2:
      if self.y > self.wy:
        self.y -= s
        if self.y < self.wy:
          self.y = self.wy
      else:
        return d          
    elif d == 3:
      if self.y < self.wy+self.wh:
        self.y += s
        if self.y > self.wy+self.wh:
          self.y = self.wy+self.wh
      else:
        #appuifw.note(unicode(self.img.size[1]))
        return d          
    return None



#<1>#
######TIMAGEWINDOW CLASS DECLARATION######
class TImageWindow:
  def __init__(self,img,canv,x,y,w,h):
    self.x = x
    self.y = y
    self.w = w
    self.h = h
    self.imx = 0
    self.imy = 0
    self.blckd = False
    self.hdn = False
    self.img = img
    self.canv = canv
    self.unbuff = None
    self.objx = x
    self.objy = y
    self.objx2 = x
    self.objy2 = y    
    self.obj = 0
#    self.objcolor = 0x000000
    self.drawing = False
    self.foreclr = 0x000000
    self.backclr = 0xffffff
    self.bsize = 1
    self.sbx = 0
    self.sby = 0
    self.sbt = 0
    self.movestep = 1
    self.moving = None
    self.cursor_ptime = 0
    self.curs = TCursor(canv, img, self.x, self.y, self.w, self.h)
    self.keyboard = Keyboard()
    
  def draw(self):
    if self.hdn <> True:
      self.canv.blit(self.img,target=(self.x,self.y),source=(self.imx,self.imy,self.imx+self.w,self.imy+self.h))
      self.curs.draw(self.imx,self.imy)     
    if self.drawing == True: self.draw_object(self.canv)
    if self.drawing == True and self.obj == 1: self.draw_object(self.img)
    if self.obj == 2: self.draw_object(self.canv)
      
  def _backupimage(self):
    self.unbuff.blit(self.img,source=(self.imx,self.imy,self.imx+self.w,self.imy+self.h))         

  def restoreimage(self):
    if self.unbuff <> None: self.img.blit(self.unbuff,target=(self.imx,self.imy,self.imx+self.w,self.imy+self.h))         
    

  def undobuff(self, buff = None):
    if buff <> None:
      self.unbuff = buff
    return self.unbuff

  def forecolor(self,color=None):
    if color <> None:
      self.foreclr = color
    return self.foreclr

  def backcolor(self,color=None):
    if color <> None:
      self.backclr = color
    return self.backclr

  def brushsize(self,size=None):
    if size <> None:
      self.bsize = size
    return self.bsize
    
  def object(self,obj=None):
    if obj <> None:
      self.obj = obj
    return self.obj

  def draw_object(self,canv,dx=0,dy=0,opt=None):
    if self.obj == 0:
      canv.point([self.curs.x+dx,self.curs.y+dy],outline=self.foreclr,width=self.bsize)
    if self.obj == 1:
      canv.point([self.curs.x+dx,self.curs.y+dy],outline=self.foreclr,width=self.bsize)
#      canv.point([self.curs.x+dx,self.curs.y+dy],outline=self.foreclr,width=self.bsize)
#      if self.movestep <> 1:
#        if keyboard.is_down(EScancodeRightArrow):
#          self.img.line([self.curs.x+self.x+self.imx-self.movestep,self.curs.y-self.y+self.imy,self.curs.x+self.x+self.imx,self.curs.y-self.y+self.imy],outline=self.foreclr,width=self.bsize)

      
    elif self.obj == 6:
      w=5
      s=2
      if self.curs.x-self.objx<>0:
        signx = (self.curs.x-self.objx)/abs(self.curs.x-self.objx)
        if signx*(self.sbx+signx*w) > abs(self.curs.x-self.objx):
          self.sbx = 0
          self.sbt = 1
      if self.curs.y-self.objy<>0:
        signy = (self.curs.y-self.objy)/abs(self.curs.y-self.objy)
        if signy*(self.sby+signy*w) > abs(self.curs.y-self.objy):
          self.sby = 0
          self.sbt = 0
      rect(canv,[self.objx+dx,self.objy+dy,self.curs.x+dx,self.curs.y+dy],outline=0x000000,width=1)      
      if self.curs.x-self.objx<>0:      
        if self.sbt == 0:
          
          self.sbx += s*signx
          canv.line([self.objx+dx+self.sbx,self.objy+dy,self.objx+dx+self.sbx+w,self.objy+dy],outline=0xffffff,width=1)
          canv.line([self.curs.x-self.sbx,self.curs.y+dy,self.curs.x-self.sbx+w,self.curs.y+dy],outline=0xffffff,width=1)        
      if self.curs.y-self.objy<>0:    
        if self.sbt == 1:
          self.sby += s*signy
          canv.line([self.curs.x+dx,self.objy+dy+self.sby,self.curs.x+dx,self.objy+dy+self.sby+w],outline=0xffffff,width=1)
          canv.line([self.objx+dx,self.curs.y-self.sby,self.objx+dx,self.curs.y-self.sby+w],outline=0xffffff,width=1)        

    elif self.obj == 2:
      if opt == 0:
        rect(canv,[self.curs.x+dx,self.curs.y+dy,self.curs.x+8+dx,self.curs.y+8+dy],outline=0xffffff,fill=0xffffff,width=1)
      else:
        rect(canv,[self.curs.x+dx,self.curs.y+dy,self.curs.x+8+dx,self.curs.y+8+dy],outline=0x000000,fill=0xffffff,width=1)        
    elif self.obj == 3:
      canv.line([self.objx+dx,self.objy+dy,self.curs.x+dx,self.curs.y+dy],outline=self.foreclr,width=self.bsize)
    elif self.obj == 4:
      rect(canv,[self.objx+dx,self.objy+dy,self.curs.x+dx,self.curs.y+dy],outline=self.foreclr,width=self.bsize)
    elif self.obj == 5:
      ellps(canv,[self.objx+dx,self.objy+dy,self.curs.x+dx,self.curs.y+dy],outline=self.foreclr,width=self.bsize)

  def clipcopy(self):
    w = abs(self.objx-self.curs.x)
    h = abs(self.objy-self.curs.y)
    buff = Image.new((w,h))
    buff.blit(self.img,source=(self.objx-self.x+self.imx,self.objy-self.y+self.imy,self.curs.x-self.x+self.imx,self.curs.y-self.y+self.imy))
    return buff
    
  def clipcut(self):
    self._backupimage()
    buff = self.clipcopy()
    rect(self.img,(self.objx-self.x+self.imx,self.objy-self.y+self.imy,self.curs.x-self.x+self.imx,self.curs.y-self.y+self.imy),outline=self.backclr,fill=self.backclr,width=1)   
    return buff

  def clippaste(self,pastebuff):
    self._backupimage()
    self.img.blit(pastebuff,target=(self.curs.x-self.x+self.imx,self.curs.y-self.y+self.imy))
    return buff

  def clipclear(self):
    self._backupimage()
    rect(self.img,(self.objx-self.x+self.imx,self.objy-self.y+self.imy,self.curs.x-self.x+self.imx,self.curs.y-self.y+self.imy),outline=self.backclr,fill=self.backclr,width=1)

  def param(self, x = None, y = None, w = None, h = None):
    if x <> None:
      self.x = x
    if y <> None:
      self.y = y
    if w <> None:
      self.w = w
    if h <> None:
      self.h = h      
    if x == None and y == None and w == None and h == None:
      return [self.x, self.y, self.w, self.h]

  def image_coord(self, x = None, y = None):
    if x <> None:
      self.imx = x
    if y <> None:
      self.imy = y
    if x == None and y == None:
      return (self.imx, self.imy)

  def coord(self,cr = None):
    if cr <> None:
      if cr[0] <> None:
        self.x = cr[0]
      if cr[1] <> None:
        self.y = cr[1]
      self.curs.zone((self.x,self.y,self.w,self.h))
    else:
      return (self.x, self.y)
  
  def size(self,sz = None):
    if sz <> None:    
      if sz[0] <> None:
        self.w = sz[0]
      if sz[1] <> None:
        self.h = sz[1]
      self.curs.zone((self.x,self.y,self.w,self.h))
    else:   
      return (self.w, self.h)
    

#  def rotateright(self):
#    im = self.img.transpose(ROTATE_270)
#    self.img = Image.new(im.size)
#    self.size((min(im.size[0],self.w),min(im.size[1],self.h)))
#    self.img.blit(im)
  

#  def image_resize(self,sz,asp = 0):
#    self.img = self.img.resize(sz,keepaspect = asp)

  def image_move(self,d,s):
    if d == 0:
      if self.imx > 0:
        self.imx -= s
        if self.imx < 0:
          self.imx = 0
    elif d == 1:
      if self.imx < self.img.size[0]-self.w:
        self.imx += s
        if self.imx > self.img.size[0]-self.w:
          self.imx = self.img.size[0]-self.w  
    elif d == 2:
      if self.imy >0:
        self.imy -= s
        if self.imy < 0:
          self.imy = 0
    elif d == 3:
      if self.imy < self.img.size[1]-self.h:
        self.imy += s
        if self.imy > self.img.size[1]-self.h:
          self.imy = self.img.size[1]-self.h
    return None    

  def cursor_move(self,d,s = 1):
    if s == 0: return
    if self.curs.move(d,s) <> None:
      self.image_move(d,s)

  def hiden(self,hd = None):
    if hd <> None:
      self.hdn = hd
      if self.hdn == True:
        self.blckd = True
      else:
        self.blckd = False
    return self.hdn

  def blocked(self,state=None):
    if state <> None:
      self.blckd = state
    return self.blckd


#<2>#
  def keyboardevent(self):
    if self.blckd <> True:

      t1=8
      t2=40
      t3=100

      if not keyboard.is_down(EScancodeLeftArrow) and not keyboard.is_down(EScancodeRightArrow) and not keyboard.is_down(EScancodeUpArrow) and not keyboard.is_down(EScancodeDownArrow):
        self.movestep = 1
        self.cursor_ptime = 0
        self.moving = False
        
      if keyboard.is_down(EScancodeLeftArrow):
        self.cursor_ptime+=1
        if self.cursor_ptime > t1:
          self.movestep = 1
        if self.cursor_ptime > t2:
          self.movestep = 3
        if self.cursor_ptime > t3:
          self.movestep = 6

        if self.obj == 1 and self.drawing == True:
          self.img.line([self.curs.x+self.x+self.imx+self.movestep,self.curs.y-self.y+self.imy,self.curs.x+self.x+self.imx,self.curs.y-self.y+self.imy],outline=self.foreclr,width=self.bsize)

          
        self.cursor_move(0,self.movestep)
        self.movestep = 0
        self.moving = True
        
      if keyboard.is_down(EScancodeRightArrow):
        self.cursor_ptime+=1
        if self.cursor_ptime > t1:
          self.movestep = 1
        if self.cursor_ptime > t2:
          self.movestep = 3
        if self.cursor_ptime > t3:
          self.movestep = 6


        if self.obj == 1 and self.drawing == True:
          self.img.line([self.curs.x+self.x+self.imx-self.movestep,self.curs.y-self.y+self.imy,self.curs.x+self.x+self.imx,self.curs.y-self.y+self.imy],outline=self.foreclr,width=self.bsize)


        self.cursor_move(1,self.movestep)
        self.movestep = 0
        self.moving = True
        
      if keyboard.is_down(EScancodeUpArrow):
        self.cursor_ptime+=1
        if self.cursor_ptime > t1:
          self.movestep = 1
        if self.cursor_ptime > t2:
          self.movestep = 3
        if self.cursor_ptime > t3:
          self.movestep = 6

        if self.obj == 1 and self.drawing == True:
          self.img.line([self.curs.x+self.x+self.imx,self.curs.y-self.y+self.imy+self.movestep,self.curs.x+self.x+self.imx,self.curs.y-self.y+self.imy],outline=self.foreclr,width=self.bsize)

        
        self.cursor_move(2,self.movestep)
        self.movestep = 0
        self.moving = True
        
      if keyboard.is_down(EScancodeDownArrow):
        self.cursor_ptime+=1
        if self.cursor_ptime > t1:
          self.movestep = 1
        if self.cursor_ptime > t2:
          self.movestep = 3
        if self.cursor_ptime > t3:
          self.movestep = 6

        if self.obj == 1 and self.drawing == True:
          self.img.line([self.curs.x+self.x+self.imx,self.curs.y-self.y+self.imy-self.movestep,self.curs.x+self.x+self.imx,self.curs.y-self.y+self.imy],outline=self.foreclr,width=self.bsize)
          
        self.cursor_move(3,self.movestep)
        self.movestep = 0
        self.moving = True
                
      if keyboard.pressed(EScancodeSelect):
        if self.drawing == False and self.unbuff <> None: self._backupimage()
        if self.obj <> 0 and self.obj <> 7 and self.obj <> 2:
          self.drawing = not self.drawing
          if self.drawing == True:
            #if self.obj == 1:
            self.objx = self.curs.x
            self.objy = self.curs.y
          elif self.drawing == False:
            if self.obj == 6:
              self.objx2 = self.curs.x
              self.objy2 = self.curs.y              
            elif self.obj <> 1:
              self.draw_object(self.img,-self.x+self.imx,-self.y+self.imy)
            
        elif self.obj <> 1:
          self.objx = self.curs.x
          self.objy = self.curs.y
          self.draw_object(self.img,-self.x+self.imx,-self.y+self.imy)
        if self.obj == 7:
          c=self.img.getpixel((self.curs.x-self.x+self.imx,self.curs.y-self.y+self.imy))[0]
          self.forecolor(c)
        if self.obj == 2:
          self.objx = self.curs.x
          self.objy = self.curs.y
          self.draw_object(self.img,-self.x+self.imx,-self.y+self.imy,0)


def brush_size():
  global imwin
  size = appuifw.query(u'Brush Size','number',imwin.brushsize())
  if size <> None:
    imwin.brushsize(size)

def rect(canv,cr,outline=None,fill=None,width=1,pattern=None):
  if cr[0] <> cr[2] and cr[1] <> cr[3]:
    canv.rectangle([min(cr[0],cr[2]),min(cr[1],cr[3]),max(cr[0],cr[2])+1,max(cr[1],cr[3])+1],outline,fill,width)
  else:
    canv.line([cr[0],cr[1],cr[2],cr[3]],outline,width)
    

def ellps(canv,cr,outline=None,fill=None,width=1,pattern=None):
  if cr[0] <> cr[2] and cr[1] <> cr[3]:
    canv.ellipse([min(cr[0],cr[2]),min(cr[1],cr[3]),max(cr[0],cr[2]),max(cr[1],cr[3])],outline,fill,width)
  else:
    canv.line([cr[0],cr[1],cr[2],cr[3]],outline,width)

def about():
  global buff, showabt, keyboard
  if showabt == True:
    if keyboard.is_down(EScancodeSelect):
      switchabout(False)
    buff.rectangle((25,20,153,170),outline=0x000000,fill=0x0000ff,width=1)
    buff.text((40,40),u'Image Designer v0.5')
    y=60
    x=35
    buff.text((x,y),u'writen by werton')
    y+=12
    buff.text((x,y),u'mail: werant@mail.ru')
    y+=16
    buff.text((x,y),u'Thanks:')
    y+=14
    buff.text((x,y),u'Atrant')
    y+=12
    buff.text((x,y),u'for SisBOOM')
    y+=12
    buff.text((x,y),u'and powlite_fm')
    y+=15
    buff.text((x,y),u'_S.M.A.R.T_')
    y+=12
    buff.text((x,y),u'for Two Towers')

def switchabout(state=None):
  global showabt
  if state == None:
    showabt = not showabt
  else:
    showabt = state

def help():
  global buff, showhlp, keyboard
  if showhlp == True:
    if keyboard.is_down(EScancodeSelect):
      switchhelp(False)
    buff.rectangle((25,25,153,165),outline=0x000000,fill=0x0000ff,width=1)
    y=40
    x=35
    buff.text((60,y),u'HELP')
    y+=20
    buff.text((x,y),u'* - tools')
    y+=12
    buff.text((x,y),u'# - color choser')
    y+=12
    buff.text((x,y),u'0 - brush size')
    

def switchhelp(state=None):
  global showhlp
  if state == None:
    showhlp = not showhlp
  else:
    showhlp = state

def tools_set():
  global toolslist, imwin
  imwin.object(toolslist.curitem())

def color_set(state=None):
  global colorgrid, imwin, col
  

  if colorgrid.curitem()[1] == 0 and colorgrid.curitem()[0] == 0:
    s = appuifw.query(u'Fore color(r.g.b)','text',imwin.forecolor())
    if s == None: return
    c = s.split('.')
    try:
      imwin.forecolor((int(c[0]),int(c[1]),int(c[2])))
    except:
      appuifw.note(u'Error: none expected characters!')
  elif colorgrid.curitem()[1] == 0 and colorgrid.curitem()[0] == 2:
    s = appuifw.query(u'Back color(r.g.b)','text',imwin.forecolor())
    if s == None: return
    c = s.split('.')
    try:
      imwin.backcolor((int(c[0]),int(c[1]),int(c[2])))
    except:
      appuifw.note(u'Error: none expected characters!')    
  elif colorgrid.curitem()[1] == 0 and colorgrid.curitem()[0] == 1:
    c = imwin.forecolor()
    imwin.forecolor(imwin.backcolor())
    imwin.backcolor(c)
  elif colorgrid.curitem()[1] == 0 and colorgrid.curitem()[0] == 3:
    imwin.forecolor(0x000000)
    imwin.backcolor(0xffffff)
    
  if colorgrid.curitem()[1] <> 0 or colorgrid.curitem()[0] == 4:
    if state == 0:
      imwin.forecolor(col[colorgrid.curitem()[0]][colorgrid.curitem()[1]])
    elif state == 1:
      imwin.backcolor(col[colorgrid.curitem()[0]][colorgrid.curitem()[1]])



def tools_update():
  global toolslist, keyboard
  if toolslist.blocked() == False:
    if keyboard.pressed(EScancodeSelect):
      tools_hiden(True)
  if colorgrid.blocked() == False:
    if keyboard.pressed(EScancodeSelect):
      color_hiden(True)
      color_set(0)
    if keyboard.pressed(EScancode5):
      color_hiden(True)
      color_set(1)
      
def tools_hiden(state = None):
  global toolslist, toolshiden, imwin
  if state <> None: toolshiden = not state
  if toolshiden == False:
    toolshiden = True
    toolslist.moveto(-24,0,4)
    toolslist.blocked(True)
    imwin.blocked(False)
    tools_set()    
  elif toolshiden == True:
    color_hiden(True)
    toolshiden = False
    toolslist.moveto(0,0,4)
    toolslist.blocked(False)
    imwin.blocked(True)



def color_hiden(state = None):
  global colorgrid, colorhiden, imwin
  if state <> None: colorhiden = not state
  if colorhiden == False:
    colorhiden = True
    colorgrid.moveto(176,0,7)
    colorgrid.blocked(True)
    imwin.blocked(False)
    #color_set()
  elif colorhiden == True:
    tools_hiden(True)
    colorhiden = False
    colorgrid.moveto(94,0,7)
    colorgrid.blocked(False)
    imwin.blocked(True)



def exit():
  global running, scr
  appuifw.app.screen = scr
  appuifw.app.body = None
  running = 0
  appuifw.app.set_exit()



#<3>#
def redraw(rect):
  global imwin, canv, buff, undobuff
  buff.clear(0x999999)
  imwin.draw()
  statusbar()
  help()
  about()
  toolslist.draw(buff)
  colorgrid.draw(buff)
  canv.blit(buff)
  
def event(evt):
  global keyboard, toolslist, colorgrid
  keyboard.handle_event(evt)
  toolslist.control(evt)
  colorgrid.control(evt)
  
def imwindow_center():
  global imwin, workzone  
  if imwin.img.size[0] < workzone[0]:
    x=(workzone[0]-imwin.img.size[0])/2
  if imwin.img.size[1] < workzone[1]:
    y=(workzone[1]-imwin.img.size[1])/2
  imwin.coord((x,y))
  

def imwindow_new(image):
  global imwin, buff, workzone
  x=0
  y=0
  w=workzone[0]
  h=workzone[1]
  if image.size[0] < workzone[0]:
    x=(workzone[0]-image.size[0])/2
    w=image.size[0]
  if image.size[1] < workzone[1]:
    y=(workzone[1]-image.size[1])/2
    h=image.size[1]
  obj = None
  if imwin <> None:
    obj = imwin.obj
  imwin = TImageWindow(image,buff,x,y,w,h)
  imwin.undobuff(Image.new(workzone))
  if obj <> None: imwin.obj = obj
  return imwin

#===============FILE FUNCTIONs==================
#
def file_new(w, h):
  global imwin
  image = Image.new((w,h))  
  imwin = imwindow_new(image)
  return imwin
  
def file_open():
  global imwin, fmanager
  filename = fmanager.AskUser(path='E:\\',ext=['.jpg','.png'])
  if filename == None: return None
  image = Image.open(filename)
  imwin = imwindow_new(image)
  return imwin
  
def file_save():
  global imwin, filename
  if filename[0] == '':
    file_saveas()
  else:
    imwin.img.save(filename[0])

def file_saveas():
  global imwin, filename
  dirname = fmanager.AskUser(path='E:\\',find='dir')
  if dirname == None: return None
  name = appuifw.query(u'Enter File Name','text',u'noname.png')
  if filename == None: return None
  filename[0] = dirname+name
  appuifw.note(u'Saved as: '+unicode(filename[0]))  
  imwin.img.save(filename[0])

def query_file_new():
  w=appuifw.query(u'Width','number',176)
  if w <> None:
    h=appuifw.query(u'Height','number',208)
    if h <> None:
      file_new(w,h)



  
#===============IMAGE FUNCTIONs==================
#
def image_rotate_left():
  global imwin, workzone
  im = imwin.img.transpose(ROTATE_90)
  imwin.img = Image.new(im.size)
  imwin.size((min(im.size[0],workzone[0]),min(im.size[1],workzone[1])))
  imwin.img.blit(im)  
  
def image_rotate_right():
  global imwin, workzone
  im = imwin.img.transpose(ROTATE_270)
  imwin.img = Image.new(im.size)
  imwin.size((min(im.size[0],workzone[0]),min(im.size[1],workzone[1])))
  imwin.img.blit(im)
  
def image_resize(sz,asp):
  global imwin, workzone
  imwin.img = imwin.img.resize(sz,keepaspect = asp)
  imwin.size((min(imwin.img.size[0],workzone[0]),min(imwin.img.size[1],workzone[1])))
  imwindow_center()
  
def image_resize_query():
  width = appuifw.query(u'Width', 'number', imwin.img.size[0])
  if width <> None:
    height = appuifw.query(u'height', 'number', imwin.img.size[1])
    if height <> None:
      asp = appuifw.query(u'Keep aspect?', 'query') 
      if asp == None:
        asp = 0
      else:
        asp = 1
      image_resize((width,height),asp)
      
      
def image_resizecanvas(sz):
  global imwin, workzone
  im = Image.new(sz)
  imwin.size((min(im.size[0],workzone[0]),min(im.size[1],workzone[1])))
  im.blit(imwin.img)
  imwin.img = im
  imwindow_center()
  im = None 

def image_resizecanvas_query():
  width = appuifw.query(u'Width', 'number', imwin.img.size[0])
  if width <> None:
    height = appuifw.query(u'Height', 'number', imwin.img.size[1])
    if height <> None:
      image_resizecanvas((width,height))


#===============EDIT FUNCTIONs==================
#
def undo():
  global imwin
  imwin.restoreimage()

def clip_copy():
  global imwin, clipbuff
  clipbuff = imwin.clipcopy()

def clip_cut():
  global imwin, clipbuff
  clipbuff = imwin.clipcut()

def clip_paste():
  global imwin, clipbuff
  imwin.clippaste(clipbuff)

def clip_clear():
  global imwin, clipbuff
  imwin.clipclear()

def statusbar():
  global buff, imwin, coord_string
  buff.rectangle((3,196,13,206),outline=0,fill=imwin.forecolor())
  buff.rectangle((15,196,25,206),outline=0,fill=imwin.backcolor())
  if imwin.moving == False:
    coord_string = 'x:'+unicode(imwin.curs.x - imwin.x + imwin.imx)+' y:'+unicode(imwin.curs.y - imwin.y + imwin.imy)
  buff.text((30,205),coord_string)



filename = ['','']
workzone = [176, 194]

fmanager=powlite_fm.manager()
keyboard=Keyboard()

buff = Image.new((176,208))

scr = appuifw.app.screen
appuifw.app.screen = 'full'
appuifw.app.body = canv = appuifw.Canvas(redraw_callback = redraw, event_callback = event)
appuifw.app.exit_key_handler = exit


imwin = None
imwin = file_new(176,208)


showhlp = False
showabt = False


icon =[]
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Pencil_24.png'))
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Brush_24.png'))
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Erase_24.png'))
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Line_24.png'))
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Rect_24.png'))
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Ellipse_24.png'))
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Select_24.png'))
icon.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Picker_24.png'))
#System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\Picker.png'))

toolslist = wt_ui.Tlist(0,0,8,icon)
#toolslist = wt_ui.Tgrid(0,0,2,3,[[icon[0],icon[1],icon[2]],[icon[3],icon[4],icon[5]]])
toolslist.rectcolor(0x0000ff)
tools_hiden(True)


col=(
(0,0xffffff,0xff0000,0xffff00,0x00ff00,0x00ffff,0x0000ff,0xff00ff),
(0,0xcccccc,0xcc0000,0xcccc00,0x00cc00,0x00cccc,0x0000cc,0xcc00cc),
(0,0x999999,0x990000,0x999900,0x009900,0x009999,0x000099,0x990099),
(0,0x666666,0x660000,0x666600,0x006600,0x006666,0x000066,0x660066),
(0,0x333333,0x330000,0x333300,0x003300,0x003333,0x000033,0x330033)
)
colors =[]

for t in range(0, 5):
  colors.append(Image.open('E:\\System\\Apps\\RunPython\\Apps\\ImageDesigner\\icon\\colors_'+str(t)+'.png'))

colorgrid = wt_ui.Tgrid(126,0,5,8,colors)
colorgrid.curitem((4,0))
colorgrid.rectcolor(0x0000ff)
color_hiden(True)


canv.bind(EKeyStar, tools_hiden)
canv.bind(EKeyHash, color_hiden)
canv.bind(EKey0, brush_size)
#canv.bind(EKeySelect, tools_hiden(True))

appuifw.app.menu=[
  (u'File', (
    (u'New...',lambda:query_file_new()),
    (u'Open...',lambda:file_open()),
    (u'Save',lambda:file_save()),
    (u'Save as...',lambda:file_saveas())      
)),
  (u'Edit', (
    (u'Undo',lambda:undo()),
    (u'Cut',lambda:clip_cut()),
    (u'Copy',lambda:clip_copy()),      
    (u'Paste',lambda:clip_paste()),
    (u'Clear',lambda:clip_clear()),                      
)),
  (u'Image', (
    (u'Resize',lambda:image_resize_query()),
    (u'Resize canvas',lambda:image_resizecanvas_query()),
    (u'Rotate left',lambda:image_rotate_left()),  
    (u'Rotate right',lambda:image_rotate_right()),        
)),
  (u'Option', (
    (u'Help', switchhelp),  
    (u'About', switchabout),  
)),

#  (u'Test', (
#    (u'Show Tools',appuifw.note(unicode(True))),  
#    (u'Hide Tools',lambda:toolslist.moveto(-24,0,4)),        
#)),
  (u'Exit', exit)
]




running = 1    
while running == 1:
    imwin.keyboardevent()
    tools_update()
    redraw(())
    e32.ao_yield()
    e32.ao_sleep(0.01)


