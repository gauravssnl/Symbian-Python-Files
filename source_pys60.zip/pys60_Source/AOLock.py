#
# AOLock.py
# 
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
# 
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
Active-scheduler-aware lock

This exists mainly just for the purpose of implementing AOQueue.

An AOLock instance wraps an e32.Ao_lock instance but provides the same
interface as the locks returned by thread.allocate_lock().  Only one
thread, which must have an associated active scheduler, is permitted
to invoke acquire() on a lock.

The differences relative to e32.Ao_lock are as follows:

 - The initial state is unlocked instead of locked.  Because these
   locks are only useful for signaling and not mutual exclusion, you
   will generally want to acquire the lock as soon as you create it.

 - AOLock provides acquire() and release() methods instead of wait()
   and signal().  It also provides a locked() method for querying
   the state of the lock.

 - It provides an option for acquiring the lock without blocking if
   it is not available.  This is the hard part.
"""

import e32

class AOLock:
    def __init__(self):
        self._lock = e32.Ao_lock()
        self._lock.signal()
        self._locked = False

    def acquire(self, waitflag=True):
        if waitflag:
            self._lock.wait()
            assert self._locked == False
            self._locked = True
            return True
        else:
            if not self._locked:
                self._lock.wait()
                self._locked = True
                return True
            else:
                return False

    def release(self):
        assert self._locked == True
        # The order of the following two statements is critical.
        self._locked = False
        self._lock.signal()

    def locked(self):
        return self._locked
