# This script lets you create an xml file
# Make sure the page.xhtml file exists on your c: drive.
# Important: you need to have the pyexpat.py library on your phone - that
# inculdes the elementtree library as well. To get the the pyexpat.py
# installed, simply download the pyexpat-series60_v20.sis file from
# http://pdis.hiit.fi/pdis/download/pyexpat/   and install it.
# Through this the pyexpat.py will be installed automatically to the
# correct library folder - and the elementree library as well.
# For documentation on the elementtree module check: http://effbot.org/zone/element-index.htm

import elementtree.ElementTree as ET

# build a tree structure
root = ET.Element("xml")

channel = ET.SubElement(root, "channel")

title = ET.SubElement(channel, "title")
title.text = "BT scan result:"

timestamp = ET.SubElement(channel, "timestamp")
bt_timestamp = "Wed Dec 28 22:24:41 2005"
timestamp.text = bt_timestamp


#show all BT users present                
item = ET.SubElement(channel, "item")
                  
itemtitle = ET.SubElement(item, "title")
itemtitle.text = "Users present:"

userbt = ET.SubElement(item, "user_bt_id")
bt_address = "00:12:62:e0:99:4e"
userbt.text = bt_address

usernn = ET.SubElement(item, "user_nickname")
nickname = "jj"
usernn.text = nickname


# show OBEX services
item = ET.SubElement(channel, "item")
                  
itemtitle = ET.SubElement(item, "title")
itemtitle.text = "OBEX services:"

userbt = ET.SubElement(item, "OBEX_user_bt_id")
bt_address = "00:12:62:e0:99:4e"
userbt.text = bt_address

usernn = ET.SubElement(item, "OBEX_user_nickname")
nickname = "jj"
usernn.text = nickname


# show RFCOMM services
item = ET.SubElement(channel, "item")
                  
itemtitle = ET.SubElement(item, "title")
itemtitle.text = "RFCOMM services:"

userbt = ET.SubElement(item, "OBEX_user_bt_id")
bt_address = "00:12:62:e0:99:4e"
userbt.text = bt_address

usernn = ET.SubElement(item, "OBEX_user_nickname")
nickname = "jj"
usernn.text = nickname
                 


# wrap it in an ElementTree instance, and save as XML
tree = ET.ElementTree(root)
tree.write("c://xml_test01.xml")


""" the resulting xml file looks like this:

- <xml>
-   <channel>
      <title>BT scan result:</title> 
      <timestamp>Wed Dec 28 22:24:41 2005</timestamp> 
-     <item>
        <title>Users present:</title> 
        <user_bt_id>00:12:62:e0:99:4e</user_bt_id> 
        <user_nickname>jj</user_nickname> 
      </item>
-     <item>
        <title>OBEX services:</title> 
        <OBEX_user_bt_id>00:12:62:e0:99:4e</OBEX_user_bt_id> 
        <OBEX_user_nickname>jj</OBEX_user_nickname> 
      </item>
-     <item>
        <title>RFCOMM services:</title> 
        <OBEX_user_bt_id>00:12:62:e0:99:4e</OBEX_user_bt_id> 
        <OBEX_user_nickname>jj</OBEX_user_nickname> 
      </item>
    </channel>
  </xml>

"""  