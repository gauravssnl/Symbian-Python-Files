#скрипт для проиграния музыки
#импортируем необходимые модули
import appuifw,e32,audio
#функция кодирования данных в utf-8 возвращает кодированые данные 
#тоесть для написания руского текста
def ru(x):return x.decode('utf-8')
#начнем, записываем функцию(для меню)
def p1():
#записываем тело в функцию
#задаем путь к мелодии
   s = audio.Sound.open("E:\\1.mid")
#делаем штоб песня играла
   s.play()
#записываем ее для меню
   menu()

def p2():
   s = audio.Sound.open("E:\\2.mid")
   s.play()
   menu()
#не используй никогда '/'этот символ
#задаем правой-софт функцию выхода
def exit_key_handler():
   appuifw.app.set_exit()

def quit():
   appuifw.app.set_exit()
#делаем само меню
appuifw.app.menu = [ru("звук1"),ru("звук2"),ru("выход")]

def menu():
   index=appuifw.popup_menu(l,ru("выберите функции"))
#всегда задавайте popup_menu переменной
#if ето цыкл што значит 'для'. Тоесть для def
   if index == 0:
      p1()
   elif index == 1:
      p2()
   elif index == 2:
      quit()
#задаем название сверху
appuifw.app.title = ru("midi плеер")
#делаем режым экрана нормальный
appuifw.app.screen = "full"
appuifw.app.exit_key_handler = exit_key_handler
menu()
#знак '#' значит што ето комментарий
#тоесть питон игнорирует все што начинаетса с решетки
#криво но думаю понятно