#
# pdis.mgt.subscribe
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Associate collections with metadata records.

Each collection that is to be shared with other repositories
needs to be assigned a key in some metadata collection.  This
assignment is recorded in the local collection __exports__ as
a record of the following form, with the name of the collection
as its key:

    <collection pdis:key="...">
      <metadata_collection>...</metadata_collection>
      <metadata_key>...</metadata_key>
    </collection>

The metadata collection will contain a corresponding record
of the following form:

    <pdis:subscription pdis:key="...">
      <repo>...</repo>
      <collection>...</collection>
    </pdis:subscription>

It is possible for the same metadata key to be associated in this
manner with several local collections.  It is also possible for
several metadata keys (possibly even in the same metadata collection)
to be associated with the same local collection.

We require that the subscription record be present in the metadata
collection before the corresponding entry is created in __exports__.
This is in order to allow the sync management agent to automatically
remove entries from __exports__ when no corresponding subscription
exists.

The metadata collection will normally also contain a record
of the following form, with the same key:

    <pdis:collection pdis:key="...">
      <title>...</title>
      <creator>...</creator>
      <description>...</description>
    </pdis:collection>

Here all properties are optional and follow the Dublin Core.
Repeated properties are generally allowed.  Property names
are written without the Dublin Core namespace qualifier.
"""

import time

from pdis.lib.element import Element, addsubelement
from pdis.versioning.et_metadata import get_key, qualify
from pdis.access.et_repo_access import RepoAccess

class NotFound(Exception):
    pass

class Ambiguous(Exception):
    pass

class AlreadyExists(Exception):
    pass

class InUse(Exception):
    pass

class SubscriptionManager(RepoAccess):
    def __init__(self, *args, **keys):
        RepoAccess.__init__(self, *args, **keys)
        assert self.most_recent_only_default == False

    def create_folder(self, name, quick = False):
        self.subscribe_by_key(name, name, "", quick = quick)

    def publish(self, collection, metadata_collection, props):
        if "title" not in [name for (name, value) in props]:
            props += [("title", collection)]

        metadata = self.create_metadata(metadata_collection, props)
        self.subscribe_by_key(collection, metadata_collection, get_key(metadata))

    def subscribe(self, collection, metadata_collection, props):
        metadata = self.lookup_metadata(metadata_collection, props)
        self.subscribe_by_key(collection, metadata_collection, get_key(metadata))

    def subscribe_by_key(self, collection, metadata_collection, metadata_key,
                         quick = False):
        self.create_collection(collection)
        self._create_subscription(collection, metadata_collection, metadata_key,
                                  quick = quick)
        self._create_export(collection, metadata_collection, metadata_key,
                            quick = quick)

    def _create_subscription(self, collection, metadata_collection, metadata_key,
                             quick = False):
        if not quick:
            subscriptions = self.query(
                metadata_collection,
                make_query("pdis:subscription",
                           repo = self.get_repo_id(),
                           collection = collection),
                key=metadata_key)
            if subscriptions:
                return

        date = "%04d-%02d-%02d" % time.gmtime()[:3]
        subscription = make_record(qualify("subscription"),
                                   repo = self.get_repo_id(),
                                   repo_name = self.get_repo_name(),
                                   date = date,
                                   collection = collection)
        self.create(metadata_collection, subscription, key=metadata_key)

    def _create_export(self, collection, metadata_collection, metadata_key,
                       quick = False):
        if not quick:
            exports = self.query(
                "__exports__",
                make_query("collection",
                           metadata_collection = metadata_collection,
                           metadata_key = metadata_key),
                key=collection)
            if exports:
                return

        export = make_record("collection",
                             metadata_collection = metadata_collection,
                             metadata_key = metadata_key)
        self.create("__exports__", export, key=collection)

    def unsubscribe(self, collection, metadata_collection):
        self.unsubscribe_by_query(
            collection, metadata_collection,
            make_query("collection",
                       metadata_collection = metadata_collection))

    def unsubscribe_by_key(self, collection, metadata_collection, metadata_key):
        self.unsubscribe_by_query(
            collection, metadata_collection,
            make_query("collection",
                       metadata_collection = metadata_collection,
                       metadata_key = metadata_key))

    def unsubscribe_by_query(self, collection, metadata_collection, xpath):
        exports = self.query("__exports__", xpath, key=collection)
        if not exports:
            raise NotFound
        for export in exports:
            key = export.findtext("metadata_key")
            self.kill("__exports__", export)

            subscriptions = self.query(
                metadata_collection,
                make_query("pdis:subscription",
                           repo = self.get_repo_id(),
                           collection = collection),
                key=key)
            for subscription in subscriptions:
                self.kill(metadata_collection, subscription)

    def lookup_metadata(self, metadata_collection, props):
        xpath = make_query("pdis:collection", props)
        results = self.query(metadata_collection, xpath)
        if not results:
            raise NotFound
        if len(results) > 1:
            raise Ambiguous
        return results[0]

    def create_metadata(self, metadata_collection, props):
        xpath = make_query("pdis:collection", props)
        if self.query(metadata_collection, xpath):
            raise Ambiguous

        date = "%04d-%02d-%02d" % time.gmtime()[:3]
        props += [("date", date)]

        metadata = make_record(qualify("collection"), props)
        self.create_and_update_header(metadata_collection, metadata)
        return metadata

    def kill_metadata(self, metadata_collection, props):
        metadata = self.lookup_metadata(metadata_collection, props)
        if self.query(metadata_collection, "/pdis:subscription",
                      key=get_key(metadata)):
            raise InUse
        self.kill(metadata_collection, metadata)

    def modify_metadata(self, metadata_collection, props):
        old = [(k[4:], v) for k, v in props if k.startswith("old_")]
        new = [(k[4:], v) for k, v in props if k.startswith("new_")]
        keep = [(k, v) for k, v in props
                if not k.startswith("old_") and not k.startswith("new_")]
        metadata = self.lookup_metadata(metadata_collection, old + keep)
        update_record(metadata, new, old)
        self.modify_and_update_header(metadata_collection, metadata)
        return metadata

def make_query(tag, props = [], **kwd):
    if kwd:
        props = props + kwd.items()
    xpath = "/%s" % tag
    if props:
        test = " and ".join(['%s = "%s"' % (k, v) for k, v in props])
        xpath += "[%s]" % test
    return xpath

def make_record(tag, props = [], **kwd):
    if kwd:
        props = props + kwd.items()
    record = Element(tag)
    update_record(record, props)
    return record

def update_record(record, new, old = ()):
    for key, value in old:
        for child in record.findall(key):
            if child.text == value:
                record.remove(child)

    new = list(new)
    new.sort()                  # Let's order the tags alphabetically.
    for key, value in new:
        addsubelement(record, key, value)
