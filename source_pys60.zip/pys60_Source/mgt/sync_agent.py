#
# pdis.mgt.sync_agent
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Sync management agent

This agent monitors references from __exports__ to shared collections,
subscriptions to these shared collections, and the current set of
neighboring repositories.  Whenever a new opportunity arises to sync
a local collection with either another local collection or one
subscribed to by a neighboring repository, the agent initiates a sync
dialog accordingly.

In order to enable the user to unsubscribe from a shared collection by
simply removing the local collection, this agent also performs garbage
collection.  It removes subscriptions for nonexistent local
collections, and it removes entries in __exports__ referring to
nonexistent subscriptions.
"""

# The following cases have to be handled.
#
# Collection record present in or added to __exports__:
# 1. Create an _Export instance.
# 2. Find all subscriptions for that metadata collection and key and
#    cache this info in the _Export instance.
# 3. If any subscription is for a nonexistent local collection, delete
#    it and the cached info about it.
# 4. If none of the remaining subscriptions is for the exported local
#    collection, remove the collection record from __exports__, delete
#    the _Export instance, and skip the remaining step.
# 5. Initiate sync dialogs based on the remaining subscriptions and
#    the cached neighbor list.  See below.
#
# Collection record removed from __exports__:
# 1. Delete the corresponding _Export instance if it still exists.
#
# Subscription added:
# 1. If the subscription is for a nonexistent local collection, delete
#    it and skip the following steps.
# 2. Update the cached info for each _Export instance with that
#    metadata collection and key.
# 3. For each such _Export instance, initiate additional sync dialogs
#    based on the new subscription and the cached neighbor list.
#    There are two different cases, depending on whether or not the
#    new subscription is for the exported collection.
#
# Subscription removed:
# 1. For each _Export instance with that metadata collection and key,
#    remove the cached info about this subscription if it is still
#    present.
# 2. If any of those _Export instances no longer has an associated
#    subscription for the exported collection, delete that _Export
#    instance and remove the corresponding collection record from
#    __exports__.
#
# Collection removed:
# 1. Remove collection records from __exports__ that refer to the
#    removed collection as their metadata collection.  Also delete the
#    corresponding _Export instances.
# 2. Delete subscriptions referring to this collection, as well as any
#    cached info about them.
#
# Connection added or removed for a still-connected neighbor:
# 1. Update the cached neighbor list.
# 2. Initiate sync dialogs for this neighbor based on the cached
#    info about subscriptions.
#
# Connection removed such that the neighbor becomes inaccessible:
# 1. Update the cached neighbor list.

# To simplify the procedure for deciding when to establish new sync
# dialogs, we take advantage of the fact that requesting the
# establishment of a sync dialog that already exists has no effect.
# Furthermore, we never bother tearing down existing sync dialogs.
#
# In particular, when a connection is added or removed for an existing
# neighbor such that it remains connected, we simply request all sync
# dialogs anew rather than trying to figure out in advance whether the
# repository's preferred connection has changed.

import time
from Queue import Queue, Empty

from pdis.lib import logging
from pdis.lib.element import copyelement
from pdis.versioning.pdis_metadata import key_from_id
from pdis.versioning.et_metadata import get_id, get_key
from pdis.access.et_repo_access import RepoAccess, Fault

initial_delay = 0.5
repeating_delay = 0

def debug(s): pass

class SyncAgent:
    def __init__(self, address = ("loopback",)):
        """Constructor"""
        self.neighbors = {}             # Map repo ID to count.
        self.exports = {}               # Map full ID to _Export.
        self.metadata_collections = {}  # Map name to live query.

        self.queue = Queue() # Entries have the form (callable, args).

        self.repo = RepoAccess(address,
                               listener = self,
                               agent = True,
                               client_name = "sync agent")
        self.repo.connect(("loopback",))
        self.repo.create_live_query("__exports__", self.update, "/collection")

    def loop(self):
        """Main loop"""
        try:
            while True:
                try:
                    f, args = self.queue.get_nowait()
                    if repeating_delay > 0:
                        time.sleep(repeating_delay)
                except Empty:
                    f, args = self.queue.get()
                    if initial_delay > 0:
                        time.sleep(initial_delay)

                f(*args)
        except:
            logging.log_exception("Sync management agent terminated by exception.")

        self.repo.close()

    #
    # Callbacks
    #

    def connected(self, repo_id, count):
        """Repository callback"""
        self._put("_update_neighbor", repo_id, count)

    def disconnected(self, repo_id, count):
        """Repository callback"""
        self._put("_update_neighbor", repo_id, count)

    def sync_dialog_state_changed(self, info):
        """Repository callback"""
        if info["terminated"] == "no such collection":
            self._put("_remote_collection_removed",
                      info["repo id"],
                      info["local collection"],
                      info["remote collection"])

    def collection_removed(self, collection):
        """Repository callback"""
        self._put("_collection_removed", collection)

    def update(self, added, removed, in_sync):
        """Live query callback for __exports__"""
        for id in removed:
            self._put("_unexport", id)
        for xml in added:
            self._put("_export", xml)

    #
    # Event handlers
    #

    def _update_neighbor(self, repo_id, count):
        debug('Update neighbor: %s, %s' % (repo_id, count))
        if count == 0:
            del self.neighbors[repo_id]
        else:
            self.neighbors[repo_id] = count
            for x in self._get_exports():
                debug('...syncing "%s".' % x.get_collection())
                x.sync(self.repo, [repo_id])

    def _collection_removed(self, collection):
        c = collection
        debug('Collection removed: %s' % c)
        if c in self.metadata_collections:
            debug('...was a metadata collection.')
            del self.metadata_collections[c]
        for x in self._get_exports():
            if x.get_metadata_collection() == c:
                debug('...unexporting "%s".' % x.get_collection())
                self._kill("__exports__", x.xml)
                del self.exports[x.get_id()]
        for x in self._get_exports():
            for s in x.get_subscriptions():
                if s.matches_collection(c, self.repo):
                    m = x.get_metadata_collection()
                    debug('...removing subscription in "%s".' % m)
                    self._kill(m, s.xml)
                    del x.subscriptions[s.get_id()]

    def _export(self, xml):
        x = _Export(xml)
        m = x.get_metadata_collection()
        k = x.get_metadata_key()
        debug('Export "%s" via "%s".' % (x.get_collection(), m))
        if m not in self.metadata_collections:
            debug('...starting live query.')
            listener = _SubscriptionListener(self, m)
            self.metadata_collections[m] = self.repo.create_live_query(
                m, listener.update, "/pdis:subscription")
        for subscription in self._query_subscriptions(m, k):
            s = _Subscription(subscription)
            if s.is_garbage(self.repo):
                debug('...removing subscription for nonexistent collection "%s".'
                      % s.get_collection())
                self._kill(m, subscription)
            else:
                debug('...noting subscription.')
                x.subscriptions[s.get_id()] = s
        if x.is_garbage(self.repo):
            debug('...unexporting since there is no matching subscription.')
            self._kill("__exports__", xml)
        else:
            debug('...syncing "%s".' % x.get_collection())
            self.exports[x.get_id()] = x
            x.sync(self.repo, self._get_neighbors())

    def _unexport(self, id):
        debug('Unexport "%s".' % key_from_id(id))
        if id in self.exports:
            debug('...noted.')
            del self.exports[id]

    def _add_subscription(self, xml, metadata_collection):
        s = _Subscription(xml)
        m = metadata_collection
        k = s.get_metadata_key()
        debug('Add a subscription in "%s".' % m)
        if s.is_garbage(self.repo):
            debug('...was garbage.')
            self._kill(m, xml)
        else:
            for x in self._get_exports():
                if x.matches(m, k):
                    debug('...syncing "%s".' % x.get_collection())
                    x.subscriptions[s.get_id()] = s
                    x.sync(self.repo, self._get_neighbors(), s)

    def _remove_subscription(self, id, metadata_collection):
        m = metadata_collection
        k = key_from_id(id)
        debug('Remove a subscription in "%s".' % m)
        for x in self._get_exports():
            if x.matches(m, k):
                c = x.get_collection()
                if id in x.subscriptions:
                    s = x.subscriptions[id]
                    if s.matches_collection(c, self.repo):
                        debug('...matched export of "%s".' % c)
                    else:
                        debug('...noted for export of "%s".' % c)
                    del x.subscriptions[id]
                if x.is_garbage(self.repo):
                    debug('...unexporting "%s".' % c)
                    self._kill("__exports__", x.xml)
                    del self.exports[x.get_id()]

    def _remote_collection_removed(self, repo_id, c, rc):
        for x in self._get_exports():
            if x.get_collection() == c:
                m = x.get_metadata_collection()
                for s in x.get_subscriptions():
                    if s.get_repo() == repo_id and s.get_collection() == rc:
                        logging.logwrite(
                            'Removing remote subscription by %s in "%s" for "%s".'
                            % (repo_id, m, rc))
                        self._kill(m, s.xml)

    #
    # Other implementation methods
    #

    def _put(self, method, *args):
        self.queue.put((getattr(self, method), args))

    def _get_exports(self):
        return self.exports.values()

    def _get_neighbors(self):
        return self.neighbors.keys()

    def _kill(self, collection, xml):
        try:
            self.repo.kill(collection, xml)
        except Fault:
            # Presumably no such collection.
            pass

    def _query_subscriptions(self, m, k):
        try:
            return self.repo.query(m, "/pdis:subscription", key=k)
        except Fault:
            # Presumably no such collection.
            return []

class _Export:
    def __init__(self, xml):
        self.xml = copyelement(xml)
        self.subscriptions = {}        # Map full ID to _Subscription.

    def get_id(self):
        return get_id(self.xml)

    def get_collection(self):
        return get_key(self.xml)

    def get_metadata_collection(self):
        return self.xml.findtext("metadata_collection")

    def get_metadata_key(self):
        return self.xml.findtext("metadata_key")

    def matches(self, metadata_collection, metadata_key):
        return self.get_metadata_collection() == metadata_collection \
               and self.get_metadata_key() == metadata_key

    def is_garbage(self, repo):
        c = self.get_collection()
        for s in self.get_subscriptions():
            if s.matches_collection(c, repo):
                return False
        return True

    def get_subscriptions(self):
        return self.subscriptions.values()

    def sync(self, repo, neighbors, subscription = None):
        if self.is_garbage(repo):
            return

        if subscription is not None:
            subscriptions = [subscription]
        else:
            subscriptions = self.get_subscriptions()

        subscriptions = [s for s in subscriptions
                         if s.get_repo() in neighbors]

        c = self.get_collection()
        for s in subscriptions:
            if s.matches_collection(c, repo):
                continue

            # XXX As an optimization, we could select one of the two
            # endpoints of each connection somehow.
            rc = s.get_collection()
            repo_id = s.get_repo()
            pipe_id = repo.pick_pipe(repo_id)
            if pipe_id is not None:
                status = repo.start_sync(pipe_id, c, rc)
                debug('Sync "%s" <-> "%s" @ %s: %s' % (c, rc, repo_id, status))

class _Subscription:
    def __init__(self, xml):
        self.xml = copyelement(xml)

    def get_id(self):
        return get_id(self.xml)

    def get_metadata_key(self):
        return get_key(self.xml)

    def get_repo(self):
        return self.xml.findtext("repo")

    def get_collection(self):
        return self.xml.findtext("collection")

    def matches_collection(self, collection, repo):
        return self.is_local(repo) and self.get_collection() == collection

    def is_garbage(self, repo):
        return self.is_local(repo) \
               and not repo.collection_exists(self.get_collection())

    def is_local(self, repo):
        return self.get_repo() == repo.get_repo_id()

class _SubscriptionListener:
    def __init__(self, agent, collection):
        self.agent = agent
        self.collection = collection

    def update(self, added, removed, in_sync):
        for id in removed:
            self.agent._put("_remove_subscription", id, self.collection)
        for xml in added:
            self.agent._put("_add_subscription", xml, self.collection)

if __name__ == "__main__":
    from pdis.lib.best_threading import start_thread

    def debug(s):
        logging.logwrite(s)

    logging.init_logging(logging.EchoLogger())
    agent = SyncAgent(("tcp", "localhost", 35800))
    start_thread(agent.loop)
    while True:
        time.sleep(60)
