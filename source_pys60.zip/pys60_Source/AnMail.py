import appuifw,e32,urllib,urlquote,sysinfo

app_lock=e32.Ao_lock()

def ru(x):return x.decode('utf-8')
def enc(x):return x.encode('utf-8')

def exit():
 app_lock.signal()
 appuifw.app.set_exit()

round=appuifw.Text()
appuifw.app.screen='normal'
round.set(u'               by G.F.Ferre')
appuifw.app.body=round

def sendmail():
 global to,ot,tema,toq,otq,temaq
 to=appuifw.query(ru('Введите адрес получателя'),'text')
 toq=urlquote.quote(to)
 ot=appuifw.query(ru('Введите Ваш(любой) адрес на английском'),'text')
 otq=urlquote.quote(ot)
 tema=appuifw.query(ru('Введите тему письма'),'text')
 temaq=urlquote.quote(tema)
 appuifw.note(ru('Введите текст письма'))
 round.set(ru(''))
 appuifw.app.menu=[(u'Ok',sendok)]
def sendok():
 snd=round.get()
 global sndq
 sndq=urlquote.quote(snd)
 appuifw.app.title=(ru('Предпросмотр'))
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Кому:\n   '+str(to)+'\n\nОт кого:\n   '+str(ot)+'\n\nТема:\n   '+str(tema)+'\n\nТекст:   '+str(snd)))
 txt.set_pos(0)
 txt.set_pos(20)
 appuifw.app.menu=[(ru('Отправить'),mailsnd),(ru('Назад'),backmenu)]
def mailsnd():
 appuifw.app.title=(ru('Отправка'))
 appuifw.app.menu=[(ru('Выход'),exit)]
 go=('http://waptrue.ws/tools/send2.php?method=post&to='+toq+'&from='+otq+'&msg='+sndq+'&sub='+temaq)
 t=urllib.urlopen(go)
 b=t.read()
 print b
 appuifw.note(ru('Ваше письмо для '+str(to)+' отправлено.'),'conf')
 backmenu()
def backmenu():
 appuifw.app.title=u'AnMail'
 appuifw.app.body=round
 round.set(u'               by G.F.Ferre')
 appuifw.app.menu=[(ru('Написать письмо'),sendmail),(ru('О программе'),about),(ru('Выход'),exit)]
def about():
 appuifw.note(u'AnMail v 0.2\nfor DimonVideo.ru')

appuifw.app.menu=[(ru('Написать письмо'),sendmail),(ru('О программе'),about),(ru('Выход'),exit)]
appuifw.app.exit_key_handler=exit
app_lock.wait()