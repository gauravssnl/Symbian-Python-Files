import os
import appuifw
import proshivka
import lite_fm
import e32
import uidcrc
def ru(x):return x.decode('utf-8')
def exit_key_handler():
    appuifw.app.set_exit()

round = appuifw.Text()
appuifw.app.screen='normal'
round.color=0
round.focus=False
round.set(ru('         Pro_UID v.0.05 final'))

def myfunc():
    appuifw.note(ru('Выберите оригинальную иконку'))
    y = lite_fm.manager('e:/others/proshivka',ext='.aif')
    appuifw.note(ru('Иконка выбрана'),'conf')
    appuifw.note(ru('Выберите перебиваемую иконку'))
    z = lite_fm.manager('e:/others/proshivka',ext='.aif')
    appuifw.note(ru('Иконка выбрана'),'conf')
    appuifw.note(ru('Перебивка UID успешно завершена'),'conf')
    appuifw.note(ru('Переименуйте перебитую иконку в оригинал'))
    appuifw.note(ru('И закиньте ее в папку с прогой'))
    proshivka.uid(y, z)
    appuifw.app.body=round

def myfunc1():
    appuifw.note(ru('Выберите аpp-файл стандартной проги'))
    y = lite_fm.manager('z:/system/apps',ext='.app')
    appuifw.note(ru('app-файл выбран'),'conf')
    appuifw.note(ru('Выберите аpp-файл перебиваемой проги'))
    z = lite_fm.manager('e:/system/apps',ext='.app')
    appuifw.note(ru('app-файл выбран'),'conf')
    appuifw.note(ru('Перебивка uid окончена'),'conf')
    appuifw.note(ru('Удалите иконку(aif-файл) перебитой проги'))
    appuifw.note(ru('иначе возникнет системная ошибка'))
    proshivka.uid(y, z)
    appuifw.app.body=round

def myfunc3():
    round.set(ru('        Pro_UID v.0.05 final'))
    appuifw.app.body=round
    appuifw.app.menu=[(ru('Перебивка uid'),((ru('Перебивка uid прог'),myfunc1),(ru('Перебивка uid иконок'),myfunc))),(ru('Подсчет crc'),((ru('Подсчет crc aif'),crcaif),(ru('Подсчет crc app'),crcapp),(ru('Подсчет crc app и aif'),crcappaif))),(ru('Просмотр uid'),((ru('Просмотр uid у aif'),shuidaif),(ru('Просмотр uid у app'),shuidapp))),(ru('Сменить uid'),((ru('Сменить uid у app'),chuidapp),(ru('Сменить uid у aif'),chuidaif))),(ru('Изменить имя'),((ru('В меню'),caption),(ru('В иконке'),renameaif))),(ru('Помощь'),myfunc2),(ru('О программе'),about),(ru('Выход'),exit_key_handler)]

def myfunc2():
    appuifw.app.body=txt=appuifw.Text()
    txt.color=0
    txt.focus=False
    txt.add(ru('Pro_UID v.0.05 final:\n\nИдея и написание:G.F.Ferre\n\nПомощь в написании:\nShrim,_virtual_machine_\n\nИдеи и написание новых функций:canbl4\n\nПомощь в разработке и бета-тест:oddworld\n\nИконка к программе: Focstot\n\n          DimonVideo.ru'))
    txt.set_pos(0)
    txt.set_pos(100)
    appuifw.app.menu=[(ru('О программе'),myfunc2),(ru('Перебивка uid'),((ru('Перебивка uid иконок'),infperaif),(ru('Перебивка uid прог'),infperapp))),(ru('Подсчет crc'),infcrc),(ru('Сменить uid'),infsmuid),(ru('Изменить имя'),((ru('В меню'),namemenu),(ru('В иконке'),infa))),(ru('назад'),myfunc3)]

def infa():
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Переименование на основе редактирования aif-файла.После выбора нужной иконки выйдет окно ввода имени. Учтите, имя должно быть на английским, а количество знаков должно быть как и у исходного имени (короткое имя можно удлинить добавив пробелы в конце и/или начале). Причем, данная функция работает только с теми иконками, в которых имя программы присутствует.Иконка со старым именем будет сохранена в папке программы с расширением *.aif_old. Чтобы вернуть старое имя, либо снова воспользуйтесь данной программой, либо удалите файл *.aif и переименуйте *.aif_old в *.aif'))
 txt.set_pos(0)
 txt.set_pos(150)

def infsmuid():
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Сменить uid:\n\n предназначено для вписывания в файл(aif или app) любого уида.Уид можно посмотреть с помощью функции "Смотреть uid", и вписать его в нужный файл.Уиды задаются из диапазона 0х00000000 до 0хffffffff.При изменении уида этой функцией, в той же папке где и лежал файл, в котором собственно и менялся уид, останется оригинал файла, на всякий случай, с расширением *.old.'))
 txt.set_pos(0)
 txt.set_pos(130)

def namemenu():
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Переименование в меню на основе редактирования caption.rsc-файла.Первое имя будет отображаться в меню под иконкой, второе имя будет в самой программе в верхней части экрана после его запуска.Эти имена можно делать или одинаковыми или разными, язык может быть любой. В некоторых программах второе имя может не изменится и останется таким же, каким было изначально.Ограничение по длине имени - 9 символов.Данная функция основана на создании файла "имяпрограммы_caption.rsc". В тех программах, где такой файл уже есть, старый rsc-файл сохранится в папке программы с расширением *.rsc_old. В случае если понадобится вернуть всё как было, переименуйте файл с расширением *.aif (например, дописав цифру или букву к расширению *.aif_1), удалите файл "имяпрограммы_caption.rsc", старому файлу "_caption.rsc_old" верните прежнее имя (убрав _old) и наконец переименуйте обратно файл иконки в *.aif.'))
 txt.set_pos(0)
 txt.set_pos(150)

def infcrc():
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Подсчет сrс:\n\nПосчитать сrс(контрольную сумму уидов) можно либо у иконки(аif), либо у программы(аpp), для подсчета необходимо ввести три уида, увидеть их можно в программе SmartFileMan, нажав на нужном файле клавишу "5"'))
 txt.set_pos(0)
 txt.set_pos(100)

def infperaif():
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Перебивка uid иконок:\n\nЧтобы перебить uid одной иконки на другую, нужно положить обе(оригинал и перебиваемую) иконки в папку e:/other/proshivka/, потом выбрать данный пункт из меню программы, и первым делом выбрать оригинальную иконку, т.е. ту, uid которой нужен для другой иконки, потом выбираете перебиваемую, и дальше программа сама все сделает.Останется только в ручную переименовать иконку идентично оригиналу, и переместить в папку с нужной программой.Изменить имя иконки в меню можно с помощью:\n"Изменить имя в иконке"\n"Изменить имя в меню"'))
 txt.set_pos(0)
 txt.set_pos(150)

def infperapp():
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Перебивка uid программ:\n\nДанная функция предназначена для замены стандартных приложений смартфона на любые другие(свои), например стандартное приложение "Чат" можно заменить на "Стасю", браузер на "Оперу", и.т.д.Чтобы заменить, нужно сначала выбрать приложение(которое необходимо заменить) с диска Z, после этого нужно выбрать свое приложение(на которое необходимо сменить), далее прога сама все сделает, останется лишь удалить иконку из папки с перебитой прогой'))
 txt.set_pos(0)
 txt.set_pos(150)

def crcaif():
    x = appuifw.query(ru('Введите uid1:'),'text',u'0x00000000')
    y = appuifw.query(ru('Введите uid2:'),'text',u'0x00000000')
    z = appuifw.query(ru('Введите uid3:'),'text',u'0x00000000')
    x,y,z = int(x, 16),int(y, 16),int(z, 16)
    crc=uidcrc.sum(x,y,z)
    res=crc.encode('hex')
    appuifw.note(ru('Успешно посчитано'),'conf')
    round.set(ru('crc aif:')+str(res))
    appuifw.app.menu=[(ru('назад'),myfunc3)]

def crcapp():
    x = appuifw.query(ru('Введите uid1:'),'text',u'0x00000000')
    y = appuifw.query(ru('Введите uid2:'),'text',u'0x00000000')
    z = appuifw.query(ru('Введите uid3:'),'text',u'0x00000000')
    x,y,z = int(x, 16),int(y, 16),int(z, 16)
    crc=uidcrc.sum(x,y,z)
    res=crc.encode('hex')
    appuifw.note(ru('Успешно посчитано'),'conf')
    round.set(ru('crc app:')+str(res))
    appuifw.app.menu=[(ru('назад'),myfunc3)]

def crcappaif():
    appuifw.note(ru('Введите 3 uid"a aif'),'info')
    x = appuifw.query(ru('Введите uid1:'),'text',u'0x00000000')
    y = appuifw.query(ru('Введите uid2:'),'text',u'0x00000000')
    z = appuifw.query(ru('Введите uid3:'),'text',u'0x00000000')
    x,y,z = int(x, 16),int(y, 16),int(z, 16)
    crc2=uidcrc.sum(x,y,z)
    resaif=crc2.encode('hex')
    appuifw.note(ru('Введите 3 uid"а app'),'info')
    a = appuifw.query(ru('Введите uid1:'),'text',u'0x00000000')
    b = appuifw.query(ru('Введите uid2:'),'text',u'0x00000000')
    c = appuifw.query(ru('Введите uid3:'),'text',u'0x00000000')
    a,b,c = int(a, 16),int(b, 16),int(c, 16)
    crc1=uidcrc.sum(a,b,c)
    resapp=crc1.encode('hex')
    appuifw.note(ru('Успешно'),'conf')
    round.set(ru('crc aif:')+str(resaif))
    round.add(ru('\ncrc app:')+str(resapp))
    appuifw.app.menu=[(ru('назад'),myfunc3)]

def about():
    appuifw.note(u'Pro_UID v.0.05 final by G.F.Ferre  for dimonvideo.ru','conf')

def chuidaif():
 appuifw.note(ru('выберете файл'),'info')
 path=lite_fm.manager('e:/',ext='.aif')
 if not path or os.path.isdir(path):
  return
 f=open(path)
 uid1=f.read(4)
 uid2=f.read(4)
 uid3=f.read(4)
 uid4=f.read(4)
 tail=f.read()
 f.close()
 uid_1=str_to_int(uid1)
 uid_2=str_to_int(uid2)
 uid_3=str_to_int(uid3)
 if uid4!=uidcrc.sum(uid_1,uid_2,uid_3):
  appuifw.note(ru('Файл не является пригодным для смены уида'),'error')
  return
 uid=appuifw.query(ru('Введите uid (третий)'),'text',u'0xXXXXXXXX')
 if not uid or len(uid)!=10:
  appuifw.note(ru('Некорректный уид'),'error')
  return
 crc=uidcrc.sum(uid_1,uid_2,long(uid,16))
 uid=str(uid[2:]).decode('hex')
 uid=uid[3:4]+uid[2:3]+uid[1:2]+uid[0:1]
 e32.file_copy(ru(path+'.old'),ru(path))
 f=open(path,'r+')
 f.seek(8)
 f.write(uid+crc) 
 pos=tail.find(uid3)
 if pos>0:
  f.seek(pos,1)
  f.write(uid)
 f.close()
 appuifw.note(ru('Смена уида завершена'),'conf')

def str_to_int(L):
 L = L[3:4]+L[2:3]+L[1:2]+L[0:1]
 L = L.encode('hex')
 L = long(L,16)
 return L

def chuidapp():
 appuifw.note(ru('выберете файл'),'info')
 path=lite_fm.manager('e:/',ext='.app')
 if not path or os.path.isdir(path):
  return
 f=open(path)
 uid1=f.read(4)
 uid2=f.read(4)
 uid3=f.read(4)
 uid4=f.read(4)
 tail=f.read()
 f.close()
 uid_1=str_to_int(uid1)
 uid_2=str_to_int(uid2)
 uid_3=str_to_int(uid3)
 if uid4!=uidcrc.sum(uid_1,uid_2,uid_3):
  appuifw.note(ru('Файл не является пригодным для смены уида'),'error')
  return
 uid=appuifw.query(ru('Введите uid (третий)'),'text',u'0xXXXXXXXX')
 if not uid or len(uid)!=10:
  appuifw.note(ru('Некорректный уид'),'error')
  return
 crc=uidcrc.sum(uid_1,uid_2,long(uid,16))
 uid=str(uid[2:]).decode('hex')
 uid=uid[3:4]+uid[2:3]+uid[1:2]+uid[0:1]
 e32.file_copy(ru(path+'.old'),ru(path))
 f=open(path,'r+')
 f.seek(8)
 f.write(uid+crc) 
 pos=tail.find(uid3)
 if pos>0:
  f.seek(pos,1)
  f.write(uid)
 f.close()
 appuifw.note(ru('Смена уида завершена'),'conf')

def change(L):
 L = L[3:4]+L[2:3]+L[1:2]+L[0:1]
 L = L.encode('hex')
 return L

def shuidaif():
 appuifw.note(ru('Выберите файл, uid которого нужно посмотреть'))
 path=lite_fm.manager('e:/',ext='.aif')
 if not path or os.path.isdir(path):
  return
 f=open(path)
 uid1=f.read(4)
 uid2=f.read(4)
 uid3=f.read(4)
 f.close()
 uidr1=change(uid1)
 uidr2=change(uid2)
 uidr3=change(uid3)
 appuifw.note(ru('Скопируйте с экрана uid'))
 appuifw.note(ru('И введите его в нужный файл'))
 round.set(u'0x'+str(uidr3))
 appuifw.app.menu=[(ru('назад'),myfunc3)]

def shuidapp():
 appuifw.note(ru('Выберите файл, uid которого нужно посмотреть'))
 path=lite_fm.manager('e:/',ext='.app')
 if not path or os.path.isdir(path):
  return
 f=open(path)
 uid1=f.read(4)
 uid2=f.read(4)
 uid3=f.read(4)
 f.close()
 uidr1=change(uid1)
 uidr2=change(uid2)
 uidr3=change(uid3)
 appuifw.note(ru('Скопируйте с экрана uid'))
 appuifw.note(ru('И введите его в нужный файл'))
 round.set(u'0x'+str(uidr3))
 appuifw.app.menu=[(ru('назад'),myfunc3)]

def renameaif():
 appuifw.note(ru('Выберите иконку, имя которой нужно сменить'))
 path=lite_fm.manager('e:\\',ext='.aif')
 name1 = os.path.splitext(os.path.split(path)[1])[0]
 name2=appuifw.query(ru('Введите новое имя:'),'text',unicode(name1))
 try:name2=name2.encode('ascii')
 except:return appuifw.note(ru('Введите имя по-английски'),'error')
 if len(name2)!=len(name1):
  return appuifw.note(ru('Неверная длина'),'error')
 file=open(path,'r')
 old=file.read()
 file.close()
 new=[]
 pos=0
 while pos<len(old)-len(name1):
  if old[pos:pos+len(name1)].lower()==name1.lower():
   new.append(pos)
  pos+=1
 if len(new)==0:
  return appuifw.note(ru('Файл не содержит имени'),'error')
 if not os.path.exists(path+'_old'):
  e32.file_copy(path+'_old',path)
 file=open(path,'r+')
 for pos in new:
  file.seek(pos)
  file.write(name2)
 file.close()
 appuifw.note(ru('Имя изменено'),'conf')

def caption():
 appuifw.note(ru('Выберите иконку для смены имени в меню'))
 path=lite_fm.manager('e:/system/apps/',ext='.aif')
 filename=path
 app_rootname = os.path.splitext(os.path.split(filename)[1])[0]
 n2=appuifw.query(ru('Введите имя для отображения в меню(до 9ти знаков):'),'text')
 if not n2 or len(n2)>=10:
  appuifw.note(ru('Имя не верное!'),'error')
  return
 n1=appuifw.query(ru('Введите имя для отображения в программе(до 9ти знаков):'),'text')
 if not n1 or len(n1)>=10:
  appuifw.note(ru('Имя не верное!'),'error')
  return
 try:os.rename(filename,filename+'temp')
 except:pass
 try:os.rename(filename[:-4]+'_caption.rsc',filename[:-4]+'_caption.rscold')
 except:pass
 appuifw.note(ru('Подождите 10 секунд'))
 round.set(u'...10')
 e32.ao_sleep(1)
 round.add(u'\n...9')
 e32.ao_sleep(1)
 round.add(u'\n...8')
 e32.ao_sleep(1)
 round.add(u'\n...7')
 e32.ao_sleep(1)
 round.add(u'\n...6')
 e32.ao_sleep(1)
 round.add(u'\n...5')
 n1=n1.encode('UTF-16')
 n2=n2.encode('UTF-16')
 ch1=str(n1).encode('hex')[4:]
 e32.ao_sleep(1)
 round.add(u'\n...4')
 ch2=str(n2).encode('hex')[4:]
 xx='0'+str(len(n1[2:])/2)
 e32.ao_sleep(1)
 round.add(u'\n...3')
 yy='0'+str(len(n2[2:])/2)
 if len(xx)==3:
  xx=xx[1:]
 if len(yy)==3:
  yy=yy[1:]
 e32.ao_sleep(1)
 round.add(u'\n...2')
 sh=str(hex(8+(int(xx)+int(yy))*2))[2:]

 temp=sh+'000500'+xx+'ab'+ch1+yy+'ab'+ch2+'0400'+sh+'00'
 temp1=str(temp).decode('hex')
 f=open(path[:-4]+'_caption.rsc','w')
 f.write(temp1)
 f.close()
 e32.ao_sleep(1)
 round.add(u'\n...1')
 try:os.rename(filename+'temp',filename)
 except:pass
 appuifw.note(ru('Выполнено'),'conf')
 round.set(u'         Pro_UID v.0.05 final')
 appuifw.app.body=round

appuifw.app.title = u'  UIDtools'

app_lock=e32.Ao_lock()
appuifw.app.menu=[(ru('Перебивка uid'),((ru('Перебивка uid прог'),myfunc1),(ru('Перебивка uid иконок'),myfunc))),(ru('Подсчет crc'),((ru('Подсчет crc aif'),crcaif),(ru('Подсчет crc app'),crcapp),(ru('Подсчет crc app и aif'),crcappaif))),(ru('Просмотр uid'),((ru('Просмотр uid у aif'),shuidaif),(ru('Просмотр uid у app'),shuidapp))),(ru('Сменить uid'),((ru('Сменить uid у app'),chuidapp),(ru('Сменить uid у aif'),chuidaif))),(ru('Изменить имя'),((ru('В меню'),caption),(ru('В иконке'),renameaif))),(ru('Помощь'),myfunc2),(ru('О программе'),about),(ru('Выход'),exit_key_handler)]

appuifw.app.body=round
appuifw.app.exit_key_handler=exit_key_handler
app_lock.wait()