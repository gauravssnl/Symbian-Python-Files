PORT=9
PATH='E:\\obex'
import os
class OBEX:
  from struct import pack,unpack
  __doc__="""script by Kule.
Python bluetooth obex server
icq: 198540472
mail: pergerk@gmail.com"""
  def __init__(s,sock,dir):
    s.sock,s.dir=sock,dir
    s.Fbuf,s.Flag="",0
    s.download()
  def getpacket(s):
    buf,oper,packS='',ord(s.sock.recv(1)),s.unpack('>H',s.sock.recv(2))[0]-3
    while packS:
       data=s.sock.recv(packS)
       packS-=len(data)
       buf+=data
    return oper,buf
  def getparams(s,buf):
    smt,data=0,{}
    while smt!=len(buf):
      Pop=ord(buf[smt]);smt+=1
      if (Pop&0xc0)==0xc0:
        data[Pop]=s.unpack('>L',buf[smt:smt+4])[0]
        smt+=4
      elif (Pop&0xc0)==0x80:
        data[Pop]=ord(buf[smt])
        smt+=1
      elif (Pop&0xc0)==0x40:
        size=s.unpack('>H',buf[smt:smt+2])[0]-3
        data[Pop]=buf[smt+2:smt+size+2]
        smt+=size+2
      elif (Pop&0xc0)==0x0:
        size=s.unpack('>H',buf[smt:smt+2])[0]-3
        dat=buf[smt+2:smt+size+2]
        data[Pop]=dat.decode('utf-16be')
        smt+=size+2
    return data
  def makefile(s,data):
     if data.has_key(0x1):
       s.Filename=data[0x1].replace('\x00','').encode('utf-8')
       s.F=open(os.path.join(s.dir,s.Filename),'w',2048)
     if data.has_key(0x48):
       if hasattr(s,'F'):
         s.F.write(s.Fbuf+data[0x48])
         s.Fbuf=""
       else:
         s.Fbuf+=data[0x48]
     if data.has_key(0x49):
       if hasattr(s,'F'):
         s.F.write(data[0x49])
         s.F.close()
     if data.has_key(0xc3):
       s.Finfo=open(os.path.join(s.dir,s.Filename+'.info.txt'),'a+',0)
       s.Finfo.write('filename: %s\nsize: %s\n'%(s.Filename,data[0xc3]))
     if data.has_key(0x42):
       s.Finfo.write('mime-type: %s\n'%(data[0x42].replace('\x00','')))
     if data.has_key(0x44):
       s.Finfo.write('file modificate time: %s\n'%(data[0x44]))
     if data.has_key(0xc4):
       s.Finfo.write('file modificate time(unix): %s\n'%(data[0xc4]))
     if data.has_key(0x46):
       s.Finfo.write('service name: %s\n'%(data[0x46]))
     if data.has_key(0x47):
       s.Finfo.write('Opisanie0x47: %s\n'%(data[0x47]))
     if data.has_key(0x4a):
       s.Finfo.write('OBEX app name: %s\n'%(data[0x4a]))
     if data.has_key(0x4b):
       s.Finfo.write('Conn id: %s\n'%(data[0x4b]))
     if data.has_key(0x4c):
       s.Finfo.write('Opisanie0x4C: %s\n'%(data[0x4c]))
     if data.has_key(0x4f):
       s.Finfo.write('OBEX class: %s\n'%(data[0x4f]))
     if data.has_key(0x05):
       s.Finfo.write('Opisanie0x05: %s\n'%(data[0x05]))
     if data.has_key(0xc0):
       s.Finfo.write('All objects: %s\n'%(data[0xc0]))
     if hasattr(s,'Finfo') and s.Flag:
       s.Finfo.write('')
  def download(s):
    while 1:
      op,packet=s.getpacket()
      if op==0x80:
        s.sock.send('\xa0\x00\x07\x10\x00\x10\x00')
      elif op==0x81:
        s.sock.send('\xa0\x00\x03')
        s.sock.close()
        break
      elif op==0x02:
        data=s.getparams(packet)
        s.makefile(data)
        s.sock.send('\xa0\x00\x03')
      elif op==0x82:
        data=s.getparams(packet)
        s.makefile(data)
        s.sock.send('\xa0\x00\x03')
        
import socket,e32,thread
import sys;sys.setdefaultencoding('utf-8')
so=socket.socket(socket.AF_BT,1)
so.bind(('',PORT))
so.listen(5)
socket.bt_advertise_service(u'OBEX Object Push',so,False,socket.OBEX)
print 'started'
while 1:
  s,ad=so.accept()
  print ad
  OBEX(s,PATH)
 # except: 
  # import traceback
  # f=open('c:\\exc.txt','w')
  # traceback.print_exc(file=f)
  # s.close()
