###by _virtual_machine_

TextColor=0xff0000#RGB
FonColor=0x000000#RGB
BorderColor=0xff0000#RGB
TimeRedraw=1#secund
DrawX=113
DrawY=1

import e32,time,fgimage,graphics

img=graphics.Image.new((51,13))
fgi=fgimage.FGImage() 
while 1:
 img.rectangle((0,0,51,13),BorderColor,FonColor)
 img.text((2,11),unicode(time.strftime('%H:%M:%S')),TextColor)
 fgi.set(DrawX,DrawY,img._bitmapapi()) 
 e32.ao_sleep(TimeRedraw)