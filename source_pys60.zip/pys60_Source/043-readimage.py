
f = file('E:\\Images\\picture.jpg', 'r')
img = f.read()
f.close()
