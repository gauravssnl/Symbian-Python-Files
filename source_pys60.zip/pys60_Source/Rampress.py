import appuifw
import e32
import keypress
e32.start_exe('z:\\system\\programs\\apprun.exe','!:\\system\\apps\\appman\\appman.app')
e32.ao_sleep(1)
keypress.simulate_key_mod(63554,0,0)
e32.ao_sleep(0)
keypress.simulate_key_mod(63554,0,0)
e32.ao_sleep(0.3)
keypress.simulate_key_mod(63555,0,0)
e32.ao_sleep(0.2)
keypress.simulate_key_mod(63554,0,0)
e32.ao_sleep(0)
keypress.simulate_key_mod(63497,0,0)
e32.ao_sleep(0)
keypress.simulate_key_mod(63557,0,0)
appuifw.app.set_exit()
