# -*- coding: utf-8 -*-

#
# pdis.todo.todo_item
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.
#
# Authors: Juha Päivärinta <juha.paivarinta@hiit.fi>
#          Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from time import gmtime

from pdis.lib.element import \
     XML, Element, addsubelement, copyelement, equal
from pdis.versioning.et_metadata import get_id

class ToDoItem:
    def __init__(self, data = None):
        if data is None:
            self.data = Element("vtodo")
            addsubelement(self.data, "dtstamp", create_timestamp())
        elif isinstance(data, (str, unicode)):
            self.data = XML(data)
        else:
            self.data = data

    def __eq__(self, other):
        if not isinstance(other, ToDoItem):
            return False
        return equal(self.data, other.data)

    def clone(self):
        return ToDoItem(copyelement(self.data))

    def toxml(self):
        return copyelement(self.data)

    def get_id(self):
        return get_id(self.data)

    def get_summary(self):
        return self.get_field("summary")

    def set_summary(self, value):
        self.set_field("summary", value)

    def get_categories(self):
        result = []
        for child in self.data.findall("categories"):
            for item in child:
                if item.text:
                    result.append(item.text)
        return result

    def set_categories(self, category_list):
        self.remove_field("categories")
        if category_list:
            child = addsubelement(self.data, "categories")
            for category in category_list:
                addsubelement(child, "item", category)

    def get_priority(self):
        return self.get_field("priority", "0")

    def set_priority(self, value):
        self.set_field("priority", str(value))

    def get_status(self):
        return self.get_field("status", "NEEDS-ACTION")

    def set_status(self, value):
        if value == "COMPLETED" and self.get_status() != "COMPLETED":
            self.set_field("completed", create_timestamp())

        if value == "NEEDS-ACTION":
            self.remove_field("status")
        else:
            self.set_field("status", value)

    def get_field(self, name, default = ""):
        value = self.data.findtext(name)
        return value or default

    def set_field(self, name, value):
        self.remove_field(name)
        if value:
            addsubelement(self.data, name, value)

    def remove_field(self, name):
        for child in self.data.findall(name):
            self.data.remove(child)

def create_timestamp():
    # Needs to work in Python 2.2.
    return "%04d%02d%02dT%02d%02d%02dZ" % gmtime()[:6]
