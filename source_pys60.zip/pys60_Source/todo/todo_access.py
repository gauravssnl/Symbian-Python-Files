# -*- coding: utf-8 -*-

#
# pdis.todo.todo_access
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.
#
# Authors: Juha Päivärinta <juha.paivarinta@hiit.fi>
#          Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from pdis.access.et_repo_access import RepoAccess
from pdis.access.collection_monitor import CollectionMonitor
from pdis.todo.todo_item import ToDoItem

class ToDoAccess:
    def __init__(self, address, name = "todo"):
        self.address = address
        self.name = name
        self.repo = RepoAccess(address, client_name = "todo")
        self.collection = self.repo.open_collection(name, only_if_exists = False)
        self.monitor = None

    def listen(self, callback):
        assert not self.monitor
        self.monitor = CollectionMonitor(self.repo, self.name, "/vtodo",
                                         callback = callback)

    def close(self):
        self.repo.close()

    def snapshot(self):
        if self.monitor:
            data = self.monitor.query()
        else:
            data = self.collection.query("/vtodo")

        data = map(ToDoItem, data)
        data.sort(compare_todo_items)
        return data

    def create_and_update_header(self, item):
        self.collection.create_and_update_header(item.data)

    def modify_and_update_header(self, item):
        self.collection.modify_and_update_header(item.data)

    def create(self, item):
        self.collection.create(item.data)

    def modify(self, item):
        self.collection.modify(item.data)

    def kill(self, item):
        self.collection.kill(item.data)

    def store_type(self):
        self.collection.store_type("todo")

    def clear_type(self):
        self.collection.clear_type("todo")

def compare_todo_items(a, b):
    return (cmp(a.get_priority(), b.get_priority())
            or cmp(a.get_categories(), b.get_categories())
            or cmp(a.get_summary(), b.get_summary()))
