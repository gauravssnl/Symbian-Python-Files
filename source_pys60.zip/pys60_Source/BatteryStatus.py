import appuifw, e32, audio

def ru(x):return x.decode('utf-8')

try:
  import sysagent, miso
except:
  appuifw.note(ru('Ошибка загрузки сторонних модулей'),'error')
  
if os.path.exists("E:\\Python\\BatAlert.aac")==1:
  pass
else:
  appuifw.note(ru('Файл звука не найден!'),'error')
  os.abort()

print u'----------'

snd=audio.Sound.open("E:\\Python\\BatAlert.aac")

def alert():
  try:
     print u'Alert!...'
     snd.play()
     try:
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
     except:
       pass
     e32.ao_sleep(10)
  except:
      appuifw.note(ru('Ошибка! Файл не найден!'),'error')

def main_f():
  running=1
  while running:
    bat=sysagent.charger_status()
    if bat==0:
       pass
    if bat==1:
       alert()
       running=0
    e32.ao_sleep(1)

appuifw.note(ru('Активировано'),'conf')
print u'Running...'
main_f()

appuifw.app.screen='normal'
appuifw.app.title = u'BatteryStatus'

app_lock = e32.Ao_lock()
app_lock.wait()