import appuifw
import os
import e32
import zlib
import time

def ru(x):
    return x.decode('utf-8')
def ur(x):
    return x.encode('utf-8')

def anote(mess):
    appuifw.note(mess, 'info')

def aerror(mess):
    appuifw.note(mess, 'error')


def HasExtension(s):
    for i in range((len(s) - 1), -1, -1):
        if (s[i] == '\\'):
            return False
        elif (s[i] == '.'):
            return True

    return False



def GetLang(id):
    if (id == 0):
        return u'Test'
    if (id == 1):
        return u'EN'
    if (id == 2):
        return u'FR'
    if (id == 3):
        return u'GE'
    if (id == 4):
        return u'SP'
    if (id == 5):
        return u'IT'
    if (id == 6):
        return u'SW'
    if (id == 7):
        return u'DA'
    if (id == 8):
        return u'NO'
    if (id == 9):
        return u'FI'
    if (id == 10):
        return u'AM'
    if (id == 11):
        return u'SF'
    if (id == 12):
        return u'SG'
    if (id == 13):
        return u'PO'
    if (id == 14):
        return u'TU'
    if (id == 15):
        return u'IC'
    if (id == 16):
        return u'RU'
    if (id == 17):
        return u'HU'
    if (id == 18):
        return u'DU'
    if (id == 19):
        return u'BL'
    if (id == 20):
        return u'AU'
    if (id == 21):
        return u'BG'
    if (id == 22):
        return u'AS'
    if (id == 23):
        return u'NZ'
    if (id == 24):
        return u'IF'
    if (id == 25):
        return u'CS'
    if (id == 26):
        return u'SK'
    if (id == 27):
        return u'PL'
    if (id == 28):
        return u'SL'
    if (id == 29):
        return u'TC'
    if (id == 30):
        return u'HK'
    if (id == 31):
        return u'ZH'
    if (id == 32):
        return u'JA'
    if (id == 33):
        return u'TH'
    if (id == 34):
        return u'AF'
    if (id == 35):
        return u'SQ'
    if (id == 36):
        return u'AH'
    if (id == 37):
        return u'AR'
    if (id == 38):
        return u'HY'
    if (id == 39):
        return u'TL'
    if (id == 40):
        return u'BE'
    if (id == 41):
        return u'BN'
    if (id == 42):
        return u'BulG'
    if (id == 43):
        return u'MY'
    if (id == 44):
        return u'CA'
    if (id == 45):
        return u'HR'
    if (id == 46):
        return u'CE'
    if (id == 47):
        return u'IE'
    if (id == 48):
        return u'SouthAF'
    if (id == 49):
        return u'ET'
    if (id == 50):
        return u'FA'
    if (id == 51):
        return u'CF'
    if (id == 52):
        return u'GD'
    if (id == 53):
        return u'KA'
    if (id == 54):
        return u'EL'
    if (id == 55):
        return u'CG'
    if (id == 56):
        return u'GU'
    if (id == 57):
        return u'HE'
    if (id == 58):
        return u'HI'
    if (id == 59):
        return u'IN'
    if (id == 60):
        return u'GA'
    if (id == 61):
        return u'SZ'
    if (id == 62):
        return u'KN'
    if (id == 63):
        return u'KK'
    if (id == 64):
        return u'KM'
    if (id == 65):
        return u'KO'
    if (id == 66):
        return u'LO'
    if (id == 67):
        return u'LV'
    if (id == 68):
        return u'LT'
    if (id == 69):
        return u'MK'
    if (id == 70):
        return u'MS'
    if (id == 71):
        return u'ML'
    if (id == 72):
        return u'MR'
    if (id == 73):
        return u'MO'
    if (id == 74):
        return u'MN'
    if (id == 75):
        return u'NN'
    if (id == 76):
        return u'BP'
    if (id == 77):
        return u'PA'
    if (id == 78):
        return u'RO'
    if (id == 79):
        return u'SR'
    if (id == 80):
        return u'SI'
    if (id == 81):
        return u'SO'
    if (id == 82):
        return u'OS'
    if (id == 83):
        return u'LS'
    if (id == 84):
        return u'SH'
    if (id == 85):
        return u'FS'
    if (id == 87):
        return u'TA'
    if (id == 88):
        return u'TE'
    if (id == 89):
        return u'BO'
    if (id == 90):
        return u'TI'
    if (id == 91):
        return u'CT'
    if (id == 92):
        return u'TK'
    if (id == 93):
        return u'UK'
    if (id == 94):
        return u'UR'
    if (id == 96):
        return u'VI'
    if (id == 97):
        return u'CY'
    if (id == 98):
        return u'ZU'


class BinaryReader:
    __module__ = __name__

    def Open(self, filename):
        try:
            self.File = open(filename, 'rb')
            return True
        except:
            aerror((u"Can't access file " + filename))
            return False



    def Read16(self):
        tmp = self.File.read(2)
        res = ((ord(tmp[1]) * 256) + ord(tmp[0]))
        return res



    def Read32(self):
        tmp = self.File.read(4)
        res = ((((ord(tmp[3]) * 16777216) + (ord(tmp[2]) * 65536)) + (ord(tmp[1]) * 256)) + ord(tmp[0]))
        return res



    def ReadString(self, size):
        tmp = self.File.read(size)
        return tmp



    def Seek(self, location, SeekOrigin = 0):
        self.File.seek(location, SeekOrigin)



    def GetPosition(self):
        return self.File.tell()



    def Close(self):
        self.File.close()



class SisHeader:
    __module__ = __name__

    def __init__(self):
        self.NumberOfFiles = 0
        self.Options = 0
        self.NumberOfLanguages = 0
        self.LanguagesPointer = 0
        self.FilesPointer = 0
        self.Compressed = True
        self.LangCodes = []



    def ReadHeader(self, br):
        br.Seek(18)
        self.NumberOfLanguages = br.Read16()
        br.Seek(20)
        self.NumberOfFiles = br.Read16()
        br.Seek(36)
        self.Options = br.Read16()
        br.Seek(48)
        self.LanguagesPointer = br.Read32()
        br.Seek(52)
        self.FilesPointer = br.Read32()
        self.ReadLangCodes(br)



    def ReadLangCodes(self, br):
        br.Seek(self.LanguagesPointer)
        for i in range(self.NumberOfLanguages):
            langcode = br.Read16()
            self.LangCodes.append(GetLang(langcode))




class SisFileRecord:
    __module__ = __name__

    def __init__(self):
        self.FileRecordType = 0
        self.FileType = 0
        self.FileDetails = 0
        self.SourceNameLength = 0
        self.SourceNamePointer = 0
        self.DestinationNameLength = True
        self.DestinationNamePointer = 0
        self.Multilanguage = False



    def CheckIllegalChars(self, s):
        invalidchars = u'*:;'
        for ch in invalidchars:
            if ((s.find(ch) != -1) and (self.FileType == 4)):
                return False
            return True




    def ScanRecord(self, br, sh, basedirFolder):
        StartFileRecordPos = br.GetPosition()
        FileRecordType = br.Read32()
        if ((FileRecordType == 1) or (FileRecordType == 0)):
            if (FileRecordType == 1):
                self.Multilanguage = True
            elif (FileRecordType == 0):
                self.Multilanguage = False
            self.FileType = br.Read32()
            self.FileDetails = br.Read32()
            self.SourceNameLength = br.Read32()
            self.SourceNamePointer = br.Read32()
            self.DestinationNameLength = br.Read32()
            self.DestinationNamePointer = br.Read32()
            tmppos = br.GetPosition()
            br.Seek(self.DestinationNamePointer)
            name = br.ReadString(self.DestinationNameLength)
            name = name.replace('\x00', '')
            name = name.replace(':\\', '\\')
            br.Seek(tmppos)
            iterations = -1
            if (self.FileType == 0):
                iterations = 1
            elif (self.FileType == 1):
                tmptime = time.localtime()
                name = (('info_' + time.strftime(u'%H%M%S')) + '.txt')
                e32.ao_sleep(1)
                iterations = 1
            elif (self.FileType == 2):
                tmptime = time.localtime()
                name = (('SIScomponent_' + tmptime.strftime(u'%H%M%S')) + '.sis')
                e32.ao_sleep(1)
                iterations = 1
            elif (self.FileType == 3):
                iterations = 1
            elif (self.FileType == 4):
                iterations = 1
            elif (self.FileType == 5):
                iterations = 1
            else:
                aerror(u'Unknown FileType')
            if self.Multilanguage:
                iterations = sh.NumberOfLanguages
            print name
            e32.ao_yield()
            if (iterations > 0):
                names = []
                flengths = []
                pointers = []
                for i in range(iterations):
                    s = os.path.split(name)[1]
                    tmpname = ''
                    if (iterations == 1):
                        tmpname = (basedirFolder + name)
                    else:
                        tmpname = (((((basedirFolder + os.path.split(name)[0]) + '_') + sh.LangCodes[i]) + '\\') + s)
                    names.append(tmpname)
                    flengths.append(br.Read32())

                for i in range(iterations):
                    pointers.append(br.Read32())

                for i in range(iterations):
                    if ((not HasExtension(names[i])) and (FileType == 4)):
                        try:
                            os.makedirs(names[i])
                        except:
                            pass
                        continue
                    try:
                        os.makedirs(os.path.split(names[i])[0])
                    except:
                        pass
                    if self.CheckIllegalChars(names[i]):
                        bw = open(names[i], 'w+')
                        br.Seek(pointers[i])
                        file = br.ReadString(flengths[i])
                        if sh.Compressed:
                            file = zlib.decompress(file)
                        bw.write(file)
                        bw.close()

                br.Seek((((StartFileRecordPos + 32) + (12 * iterations)) + 4))
        elif (FileRecordType == 2):
            NumberOfOptions = br.Read32()
            br.Seek(StartFileRecordPos)
            br.Seek(((8 + ((8 * NumberOfOptions) * sh.NumberOfLanguages)) + 16))
        elif ((FileRecordType == 3) or (FileRecordType == 4)):
            SizeOfConditionalExpression = br.Read32()
            br.Seek(SizeOfConditionalExpression)
        elif ((FileRecordType == 5) or (FileRecordType == 6)):
            pass
        else:
            aerror(u'Unknown FileRecordType')


if (not os.path.exists('e:\\sisunpack\\')):
    os.makedirs('e:\\sisunpack\\')


basedir = 'e:\\sisunpack\\'

def extension(x):
    return (os.path.splitext(x)[1].lower() == '.sis')


appuifw.body = None
appuifw.body = appuifw.Text()
appuifw.body.clear()
print ru('Начинаю распаковку!')
filelist = filter(extension, os.listdir(basedir))
for file in filelist:
    br = BinaryReader()
    br.Open((basedir + file))
    sh = SisHeader()
    sh.ReadHeader(br)
    sfr = SisFileRecord()
    tmpbase = ((basedir + os.path.split(file)[1]) + '_unpack\\')
    os.mkdir(tmpbase)
    tw = open((tmpbase + 'ComponentNamesList.txt'), 'w+')
    br.Seek(64)
    comppoint = br.Read32()
    br.Seek(comppoint)
    NameLengths = []
    for k in range(sh.NumberOfLanguages):
        NameLengths.append(br.Read32())

    NamePointers = []
    for k in range(sh.NumberOfLanguages):
        NamePointers.append(br.Read32())

    for k in range(sh.NumberOfLanguages):
        br.Seek(NamePointers[k])
        component = br.ReadString(NameLengths[k])
        component = component.replace('\x00', '')
        tw.write((((sh.LangCodes[k] + ': ') + component) + '\n'))

    tw.close()
    br.Seek(22)
    NumberOfRequisites = br.Read16()
    br.Seek(56)
    RequisitesPointer = br.Read32()
    br.Seek(RequisitesPointer)
    tw = open((tmpbase + 'RequisitesList.txt'), 'w+')
    for i in range(NumberOfRequisites):
        UID = br.Read32()
        tw.write((('UID:\t' + str(UID)) + '\n'))
        MajorVersion = br.Read16()
        tw.write((('Major version:\t' + str(MajorVersion)) + '\n'))
        MinorVersion = br.Read16()
        tw.write((('Minor version:\t' + str(MinorVersion)) + '\n'))
        Variant = br.Read32()
        tw.write((('Variant:\t' + str(Variant)) + '\n'))
        RequisiteNameLengths = []
        for k in range(sh.NumberOfLanguages):
            RequisiteNameLengths.append(br.Read32())

        RequisiteNamePointers = []
        for k in range(sh.NumberOfLanguages):
            RequisiteNamePointers.append(br.Read32())

        tmppos = br.GetPosition()
        for k in range(sh.NumberOfLanguages):
            br.Seek(RequisiteNamePointers[k])
            req = br.ReadString(RequisiteNameLengths[k])
            req = req.replace('\x00', '')
            tw.write((((sh.LangCodes[k] + ':\t') + req) + '\n'))

        br.Seek(tmppos)
        tw.write('=================================================================')

    tw.close()
    br.Seek(30)
    NumberOfCapabilities = br.Read16()
    br.Seek(72)
    CapabilitiesPointer = br.Read32()
    br.Seek(CapabilitiesPointer)
    tw = open((tmpbase + 'CapabilitiesList.txt'), 'w+')
    CapabilityKeys = []
    for k in range(NumberOfCapabilities):
        CapabilityKeys.Add(br.ReadUInt32())

    CapabilityValues = []
    for k in range(NumberOfCapabilities):
        CapabilityValues.append(br.Read32())

    for k in range(NumberOfCapabilities):
        tw.WriteLine((((((('Key #' + str(k)) + ': ') + str(CapabilityKeys[k])) + '\tValue: ') + str(CapabilityValues[k])) + '\n'))

    tw.close()
    br.Seek(60)
    CertificatesPointer = br.Read32()
    br.Seek(CertificatesPointer)
    tw = open((tmpbase + 'CertificatesList.txt'), 'w+')
    us = br.Read16()
    tw.write((('Year: ' + str(us)) + '\n'))
    us = br.Read16()
    tw.write((('Month: ' + str(us)) + '\n'))
    us = br.Read16()
    tw.write((('Day: ' + str(us)) + '\n'))
    us = br.Read16()
    tw.write((('Hour: ' + str(us)) + '\n'))
    us = br.Read16()
    tw.write((('Minute: ' + str(us)) + '\n'))
    us = br.Read16()
    tw.write((('Second: ' + str(us)) + '\n'))
    us = br.Read16()
    tw.write((('Number of certificates: ' + str(us)) + '\n'))
    tw.close()
    br.Seek(sh.FilesPointer)
    print (('Unpacking ' + file) + '...')
    e32.ao_yield()
    for i in range(sh.NumberOfFiles):
        sfr.ScanRecord(br, sh, tmpbase)

    print ru('Готово!')
    br.Close()

