#tager
#a.tetis@mail.ru

import appuifw,e32,os,audio
import location,powlite_fm
import uikludges
from appswitch import*
def ru(x):return  x.decode('utf-8')
def ur(x):return  x.encode('utf-8')

if not os.path.exists('e:\\system\\apps\\gsm_ps\\cell'):os.makedirs('e:\\system\\apps\\gsm_ps\\cell')

sleep=e32.ao_sleep
run = 'z:\\system\\programs\\apprun.exe'
exe = e32.start_exe
ppz=ur(u'e:\\system\\apps\\gsm_ps\\cell\\')

da = appuifw.Icon(u"Z:\\system\\data\\avkon.mbm",218,218)
appuifw.app.screen='normal'

i=1

def new_call():
  if r1==1:
    appuifw.note(ru('Остановите сканирование'),'info')
    return
  mesto=appuifw.query(ru('Введите название:'),'text')
  if mesto=='':run_call()
  save(mesto)
  
def save(mesto):
  f=open(ur(u'e:\\system\\apps\\gsm_ps\\cell\\')+ur(mesto),'a+')
  for a in range(0,len(cells_sav)):
     f.write(str(cells_sav[a])+ur('\n'))
  appuifw.note(ru('Сохранено: '+ur(mesto)+str(cells_sav)),'info')  
  f.close()
  runn_call()
def delete1():
  if r1==1:
    appuifw.note(ru('Остановите сканирование'),'info')
    return
#  global lines  
  index=appuifw.app.body.current()
  appuifw.note(ru(str(index)),'info')

def delete():
  if r1==1:
    appuifw.note(ru('Остановите сканирование'),'info')
    return
#  global lines  
  index=appuifw.app.body.current()
  ind=index*2
  f=open(ur(u'e:\\system\\apps\\gsm_ps\\run'),'r')
  linesx=f.readlines()
  f.close()
  del linesx[ind+1]
  del linesx[ind]
  f=open(ur(u'e:\\system\\apps\\gsm_ps\\run'),'w+')
  for a in range(0,len(linesx)):
     f.write(linesx[a])
  f.close()
  run_call()

def run_call():
  global cells_sav,i,r,lines
  linesx=[]
  try:
     f=open(ur(u'e:\\system\\apps\\gsm_ps\\run'),'r')
     lines=f.readlines()
     f.close()
  except:lines=[]
  
  if len(lines)<1:
     linesx=[((ru('      Нет данных'),ru('')))]
  else:
     for c in range(0,len(lines),2):
       linesx.append((ru(lines[c])[:-1],ru(lines[c+1])[:-1]))
  appuifw.app.body=appuifw.Listbox(linesx,delete)
  
  cells_sav=cells_d=cells=[]
  while r:
    cell=location.gsm_location()[3]
    if cell in cells or cell==0:pass
    else:cells.append(cell)
    if len(cells_d)<len(cells):cells_sav=cells
    else:cells_sav=cells_d
    if i < 50 :i+=1
    if i == 50:
      appuifw.app.title=ru(str(cell))
      i=1
      cells_d=cells
      cells=[]
    zerkalo()
    sleep(0.5)

def edit_call():
   global r,r1
   if r1==1:
     appuifw.note(ru('Остановите сканирование'),'info')
     return
   r,r1=0,1
   dobaw()
   
def dobaw():
  global cells_sav,r1
#  cells_sav=[]
  skan=ru('Сканирую.....')
  list()
  f=open(ur(u'e:\\system\\apps\\gsm_ps\\cell\\'+edit_call),'r')
  lines=f.readlines()
  f.close()
  cells_sav=lines
  while r1:
   for a in range(0,len(skan)):
    appuifw.app.title=skan[:a]
    cell=location.gsm_location()[3]
    if (str(cell)+'\n') in cells_sav or cell==0:pass
    else:
      cells_sav.append(str(cell)+'\n')
      f=open(ur(u'e:\\system\\apps\\gsm_ps\\cell\\')+ur(edit_call),'a+')
      f.write(str(cell)+ur('\n'))
      f.close()
      appuifw.app.title=(ru('Добавлено ')+(str(cell)))
      appuifw.note(ru('Добавлено ')+(str(cell)),'info',1)
    sleep(0.4)

def stop_A():
  global A
  A.stop()

def stop():
  menu()
  run_call()

def list():
   global edit_call
   dir_m=[]
   dir=os.listdir(ur(u'e:\\system\\apps\\gsm_ps\\cell\\'))
   for a in range(0,len(dir)):
       dir_m.append(ru(dir[a]))
   ind = appuifw.selection_list(dir_m, search_field=1)
   try:
     edit_call=dir_m[ind]
   except:stop()

def renam():
   if r1==1:
     appuifw.note(ru('Остановите сканирование'),'info')
     return
   list()
   new=appuifw.query(ru('Введите название:'),'text',edit_call)
   if new=='':menu()
   os.renames((ppz+ur(edit_call)),(ppz+ur(new)))
   appuifw.note(ru('Переименовано на '+ur(new)),'info')
  
def runn():
  if r1==1:
    appuifw.note(ru('Остановите сканирование'),'info')
    return
  fileman=powlite_fm.manager()
  try:
    pp=ur(fileman.AskUser('e:\\',ext=['.amr','.wav','.mp3','.app']))
  except:return
  appuifw.app.title=ru('Выберите место запуска:')
  list()
  f=open(ur(u'e:\\system\\apps\\gsm_ps\\run'),'a+')
  f.write(ur(edit_call)+ur('\n')+pp+ur('\n'))
  f.close()
  run_call()
  
def zerkalo():
   global titl,A
   dir=os.listdir(ur(u'e:\\system\\apps\\gsm_ps\\cell\\'))
   for a in range(0,len(dir)):
     ccell=location.gsm_location()[3]
     f=open(ur(u'e:\\system\\apps\\gsm_ps\\cell\\')+dir[a],'r')
     liness=f.readlines()
     f.close()
     if (str(ccell)+'\n') in liness:
       titl=dir[a]
       appuifw.app.title=ru(titl)
       for b in range(0,len(lines),2):
         try:
           if titl==lines[b][:-1]:
             try:
                 A=audio.Sound.open(lines[b+1])
                 A.play()
             except:
                 exe(run,lines[b+1])
             del lines[b+1]
             del lines[b]
         except:pass    

def menu():
  global r,r1
  r,r1=1,0
  appuifw.app.menu=[(ru('Навигация'),((ru('Сохранить место'),new_call),(ru('Дополнить'),edit_call),(ru('Остановить'),stop),(ru('Переименовать'),renam))),(ru('Файлы'),((ru('Запуск'),runn),(ru('Удаление'),delete))),(ru('Выход'),((ru('Выход'),exit),(ru('Свернуть'),sw)))]
  run_call()
def sw():
  switch_to_bg(ru('gsm_ps'))
  
def exit():os.abort()

uikludges.set_right_softkey_text(ru('Стоп'))
appuifw.app.exit_key_handler = stop_A

menu()
#lock = e32.Ao_lock()
#appuifw.app.exit_key_handler = lock.signal
#lock.wait()
