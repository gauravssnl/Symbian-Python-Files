#created by Vital 6630
def ru(x):return x.decode('utf-8')
def ur(x):return x.encode('utf-8')
import appuifw
import e32
appuifw.app.screen='full'
appuifw.app.body=t=appuifw.Text()
t.focus=False
t.font=u'Alb17b'
t.color=0x004060
t.set(ru('\n'*4+'\tG S M T r a c k'))
t.font=u'LatinPlain12'
t.add(ru('\n'*9+'\t\tзагрузка...'))
e32.ao_sleep(0.5)
import os
import camera
import location
import time
import audio
import _sysinfo
import error
from graphics import*
try:
  from appswitch import*
  from fgimage import FGImage
  import easydb
  import powlite_fm
  import uikludges
except:
  appuifw.note(ru('Установите подборку модулей'),'error')
  os.abort()
length,strength=100,100
class misoVibraFake(object):
  def vibrate(self,length,strength):
    e32.ao_sleep(length/float(1000))
if e32.s60_version_info==(2,6) or e32.s60_version_info==(2,8):
  try:
    import miso
  except:
    appuifw.note(ru('Установите подборку модулей'),'error')
    os.abort()
else:
  miso = misoVibraFake()

fileman=powlite_fm.manager()
uikludges.set_right_softkey_text(ru('В трей'))
timer=e32.Ao_timer()
time_start=time.time()
try:
  if _sysinfo.signal_bars()!=0:
    mcc,mnc,lac,cellid=location.gsm_location()
  else:
    mcc,mnc,lac,cellid=0,0,0,0
except:
  mcc,mnc,lac,cellid=0,0,0,0
name=unicode(mcc)+', '+unicode(mnc)+', '+unicode(lac)+', '+unicode(cellid)
name2=u'LAC: '+unicode(lac)+u'  CellId: '+unicode(cellid)
title=unicode(lac)+' '+unicode(cellid)
s=easydb.EasyDB()
app_dir=':\\System\\Apps\\'
dir=appuifw.app.full_name()[0]+':\\System\\Apps\\GSMTrack\\'
PHOTO=dir+'Photo\\'
if os.path.exists(ur(PHOTO))==0:
  os.mkdir(ur(PHOTO))
Data=dir+'Data\\'
HELP=dir+'Help\\'
SET=dir+'Settings.cdb'
log_file='c:\\gsmtrack.log'
if os.path.exists(log_file)==0:
  f=open(ur(log_file),'w')
  f.close()
read,sel=0,0
sota=ru('не установлена')
point=ru('вышка неизвестна')
L0=[u'Albi12',u'Albi13',u'Alp13',u'Alpi12',u'Alpi13',u'LatinBold12',u'LatinBold13',u'LatinPlain12']
L1=[0x000000,0xffffff,0xff0000,0xff8000,0xffff00,0x008000,0x0000ff,0x000080,0xff00ff]
s.Load(SET)
alarm_time=s.Get(u'alarm_time')
close=s.Get(u'close')
col=s.Get(u'col')
col2=s.Get(u'col2')
col3=s.Get(u'col3')
col4=s.Get(u'col4')
col5=s.Get(u'col5')
DATA=s.Get(u'DATA')
fonts=s.Get(u'fonts')
fonts2=s.Get(u'fonts2')
fonts3=s.Get(u'fonts3')
line1=s.Get(u'line1')
line2=s.Get(u'line2')
log=s.Get(u'log')
pht=s.Get(u'pht')
ph_dir=s.Get(u'ph_dir')
run=s.Get(u'run')
sound_path=s.Get(u'sound_path')
x=s.Get(u'x')
x2=s.Get(u'x2')
y=s.Get(u'y')
y2=s.Get(u'y2')
zvuk=s.Get(u'zvuk')
run_old=run
if alarm_time==0:atime=0
if alarm_time==1:atime=15
if alarm_time==2:atime=30
if alarm_time==3:atime=60
try:
  if os.path.exists(DATA)==0:
    DATA=ur(appuifw.app.full_name()[0])+DATA[1:]
except:pass
DATA=ur(DATA)
PHOTO=ur(dir+'Photo\\')+DATA[29:]
try:
  miso.vibrate(30,30)
  e32.ao_sleep(0.2)
  miso.vibrate(30,30)
except:pass
def set():
  menu=[ru('общие'),ru('строка вышки'),ru('строка сигнала')]
  i=appuifw.popup_menu(menu,ru('-= НАСТРОЙКИ =-'))
  if i==None:return
  if i==0:set0()
  if i==1:set1()
  if i==2:set2()
def set0():
  global alarm_time,atimel,close,log,zvuk
  appuifw.app.title=ru('Настройки:\nобщие')
  zvuk_old=zvuk
  model0=[ru('бесконечно'),ru('15 сек'),ru('30 сек'),ru('60 сек')]
  model1=[ru('нет'),ru('да')]
  model2=[ru('нет'),ru('вышки из списка'),ru('все вышки')]
  try:
    data=[(ru('громкость сигнала (0-10)'),'number',int(zvuk)),(ru('прод-ть тревоги'),'combo',(model0,int(alarm_time))),(ru('закрывать программу'),'combo',(model1,int(close))),(ru('вести журнал'),'combo',(model2,int(log)))]
    flags=appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced
    form=appuifw.Form(data,flags)
    form.execute()
    zvuk=int(form[0][2])
    alarm_time=int(str(form[1][2])[-3])
    close=int(str(form[2][2])[-3])
    log=int(str(form[3][2])[-3])
    if alarm_time==0:atime=0
    if alarm_time==1:atime=15
    if alarm_time==2:atime=30
    if alarm_time==3:atime=60
    if zvuk>10:
      zvuk=zvuk_old
      appuifw.note(ru('Неверно задана громкость!'),'error')
      set0()
    s.Load(SET,create=False)
    s.Add(u'zvuk',zvuk)
    s.Add(u'alarm_time',alarm_time)
    s.Add(u'close',close)
    s.Add(u'log',log)
    s.Save
    appuifw.note(ru('Настройки сохранены'),'conf')
    MENU()
  except:pass
def set1():
  global col,fonts,line1,run,run_old,x,y
  appuifw.app.title=ru('Настройки:\nстрока вышки')
  col_old,x_old,y_old,=col,x,y
  model0=[ru('только вышку'),ru('вышку и сигнал')]
  model1=[ru('выкл.'),ru('вкл.')]
  model2=[u'Albi12',u'Albi13',u'Alp13',u'Alpi12',u'Alpi13',u'LatinBold12',u'LatinBold13',u'LatinPlain12']
  try:
    data=[(ru('показывать'),'combo',(model0,int(line1))),(ru('бегущая строка'),'combo',(model1,int(run_old))),(ru('позиция X (0-176)'),'number',int(x)),(ru('позиция Y (0-')+unicode(y2-12)+'...'+unicode(y2+12)+u'-208)','number',int(y)),(ru('цвет (ffffff)'),'text',unicode(col)),(ru('шрифт'),'combo',(model2,int(fonts)))]
    flags=appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced
    form=appuifw.Form(data,flags)
    form.execute()
    line1=int(str(form[0][2])[-3])
    run=int(str(form[1][2])[-3])
    x=int(form[2][2])
    y=int(form[3][2])
    col=str(form[4][2])
    fonts=int(str(form[5][2])[-3])
    if x>176:
      x=x_old
      appuifw.note(ru('Неверно задана позиция X!'),'error')
      set1()
    if y>208:
      y=y_old
      appuifw.note(ru('Неверно задана позиция Y!'),'error')
      set1()
    if y2-12<y<y2+12:
      y=y_old
      appuifw.note(ru('Строка перекрывает строку сигнала!'),'error')
      set1()
    try:
      if len(col)!=6:
        col=col_old
        appuifw.note(ru('Не может быть числом цвета'),'error')
        set1()
        return
      else:a=int(col[2:],16)
    except:
      col=col_old
      appuifw.note(ru('В числе цвета встречаются посторонние символы'),'error')
      set1()
      return
    s.Load(SET,create=False)
    s.Add(u'line1',line1)
    s.Add(u'run',run)
    s.Add(u'x',x)
    s.Add(u'y',y)
    s.Add(u'col',col)
    s.Add(u'fonts',fonts)
    s.Save
    run_old=run
    appuifw.note(ru('Настройки сохранены'),'conf')
    MENU()
  except:pass
def set2():
  global col2,fonts2,line2,x2,y2
  appuifw.app.title=ru('Настройки:\nстрока сигнала')
  col2_old,x2_old,y2_old,=col2,x2,y2
  model0=[ru('ничего'),ru('% и dBm'),ru('только %'),ru('только dBm')]
  model1=[u'Albi12',u'Albi13',u'Alp13',u'Alpi12',u'Alpi13',u'LatinBold12',u'LatinBold13',u'LatinPlain12']
  try:
    data=[(ru('показывать'),'combo',(model0,int(line2))),(ru('позиция X (0-176)'),'number',int(x2)),(ru('позиция Y (0-')+unicode(y-12)+'...'+unicode(y+12)+u'-208)','number',int(y2)),(ru('цвет (ffffff)'),'text',unicode(col2)),(ru('шрифт'),'combo',(model1,int(fonts2)))]
    flags=appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced
    form=appuifw.Form(data,flags)
    form.execute()
    line2=int(str(form[0][2])[-3])
    x2=int(form[1][2])
    y2=int(form[2][2])
    col2=str(form[3][2])
    fonts2=int(str(form[4][2])[-3])
    if x2>176:
      x2=x2_old
      appuifw.note(ru('Неверно задана позиция X!'),'error')
      set2()
    if y2>208:
      y2=y2_old
      appuifw.note(ru('Неверно задана позиция Y!'),'error')
      set2()
    if y-12<y2<y+12:
      y2=y2_old
      appuifw.note(ru('Строка перекрывает строку вышек!'),'error')
      set1()
    try:
      if len(col2)!=6:
        col2=col2_old
        appuifw.note(ru('Не может быть числом цвета'),'error')
        set2()
        return
      else:a=int(col2[2:],16)
    except:
      col2=col2_old
      appuifw.note(ru('В числе цвета встречаются посторонние символы'),'error')
      set2()
      return
    s.Load(SET,create=False)
    s.Add(u'line2',line2)
    s.Add(u'x2',x2)
    s.Add(u'y2',y2)
    s.Add(u'col2',col2)
    s.Add(u'fonts2',fonts2)
    s.Save
    appuifw.note(ru('Настройки сохранены'),'conf')
    MENU()
  except:pass
def set3():
  global col3,col4,col5,fonts3,pht,ph_dir
  col3_old,col4_old,col5_old,=col3,col4,col5
  appuifw.app.title=ru('Настройки:\nфото')
  model0=[ru('нет'),ru('да')]
  model1=[ru('вышкам'),ru('наборам')]
  model2=[u'Albi12',u'Albi13',u'Alp13',u'Alpi12',u'Alpi13',u'LatinBold12',u'LatinBold13',u'LatinPlain12']
  try:
    data=[(ru('показывать фото'),'combo',(model0,int(pht))),(ru('привязать к...'),'combo',(model1,int(ph_dir))),(ru('цвет фона (ffffff)'),'text',unicode(col3)),(ru('цвет окантовки (ffffff)'),'text',unicode(col4)),(ru('цвет шрифта (ffffff)'),'text',unicode(col5)),(ru('шрифт'),'combo',(model2,int(fonts3)))]
    flags=appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced
    form=appuifw.Form(data,flags)
    form.execute()
    pht=int(str(form[0][2])[-3])
    ph_dir=int(str(form[1][2])[-3])
    col3=str(form[2][2])
    col4=str(form[3][2])
    col5=str(form[4][2])
    fonts3=int(str(form[5][2])[-3])
    try:
      if len(col3)!=6:
        col3=col3_old
        appuifw.note(ru('-= ФОН =-\nНе может быть числом цвета'),'error')
        set3()
        return
      else:a=int(col3[2:],16)
    except:
      col3=col3_old
      appuifw.note(ru('-= ФОН =-\nВ числе цвета фона встречаются посторонние символы'),'error')
      set3()
      return
    try:
      if len(col4)!=6:
        col4=col4_old
        appuifw.note(ru('-= ОКАНТОВКА =-\nНе может быть числом цвета'),'error')
        set3()
        return
      else:a=int(col4[2:],16)
    except:
      col4=col4_old
      appuifw.note(ru('-= ОКАНТОВКА =-\nВ числе цвета встречаются посторонние символы'),'error')
      set3()
      return
    try:
      if len(col5)!=6:
        col5=col5_old
        appuifw.note(ru('-= ШРИФТ =-\nНе может быть числом цвета'),'error')
        set3()
        return
      else:a=int(col5[2:],16)
    except:
      col5=col5_old
      appuifw.note(ru('-= ШРИФТ =-\nВ числе цвета встречаются посторонние символы'),'error')
      set3()
      return
    s.Load(SET,create=False)
    s.Add(u'pht',pht)
    s.Add(u'ph_dir',ph_dir)
    s.Add(u'col3',col3)
    s.Add(u'col4',col4)
    s.Add(u'col5',col5)
    s.Add(u'fonts3',fonts3)
    s.Save
    appuifw.note(ru('Настройки сохранены'),'conf')
    MENU2()
  except:pass
def bg():
  e32.start_exe('Z:\System\Programs\AppRun.exe','Z:\System\Apps\Phone\Phone.app')
  e32.ao_sleep(1)
  ekran()
def new():
  if k==1:
    appuifw.note(ru('Набор с таким кодом существует!'),'error')
    return
  appuifw.app.title=ru('Новый набор')
  file=appuifw.query(ru('Имя:'),'text',ru('Имя'))
  if file==None:return
  if os.path.exists(DATA+ur(file))==1:
    if appuifw.query(ru('Набор существует. Перезаписать?'), 'query')==None:return
  f=open(DATA+ur(file),'w')
  f.write(str(name)+u'\n')
  f.close()
  if os.path.exists(PHOTO+ur(file))==0:
    fold=PHOTO+ur(file)
    os.mkdir(fold)
  MENU()
def update():
  if k==1:
    appuifw.note(ru('Набор с таким кодом существует!'),'error')
    return
  appuifw.app.title=ru('Дописать в...')
  files=map(ru,os.listdir(DATA))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  f=open(DATA+ur(files[index]),'a')
  f.write(str(name)+u'\n')
  f.close()
  MENU()
def rename():
  global file,read
  appuifw.app.title=ru('Выберите файл')
  files=map(ru,os.listdir(DATA))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  read=1
  appuifw.app.title=ru('Переименовать')
  appuifw.app.exit_key_handler=back
  file=appuifw.query(ru('Новое имя:'),"text",files[index])
  if file==None:return
  file_old=ru(DATA)+files[index]
  fold0_old=ru(PHOTO)+files[index]
  if os.path.exists(DATA+ur(file))==1:
    if appuifw.query(ru('Набор существует. Перезаписать?'), 'query')==None:return
  os.rename(ur(file_old),DATA+ur(file))
  os.rename(ur(fold0_old),PHOTO+ur(file))
  appuifw.note(ru('Набор переименован'),'conf')
  back()
def edit():
  global file,read
  appuifw.app.title=ru('Выберите файл')
  files=map(ru,os.listdir(DATA))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  read=1
  appuifw.app.title=ru('Редактор')
  appuifw.app.exit_key_handler=back
  uikludges.set_right_softkey_text(ru('Отмена'))
  appuifw.app.body=t=appuifw.Text()
  appuifw.app.menu=[(ru('Сохранить'),save),(ru('Отмена'),back)]
  t.focus=True
  t.color=0x000080
  t.font=u'LatinBold12'
  file=DATA+ur(files[index])
  appuifw.app.body.set(u"")
  f=open(file,'r')
  appuifw.app.body.set(ru(f.read()))
  f.close()
  t.set_pos(0)
def save():
  f=open(file,'w')
  f.write(ur(appuifw.app.body.get()).replace(chr(0xe2)+chr(0x80)+chr(0xa9),"\n"))
  f.close()
  appuifw.note(ru('Сохранено'),'conf')
  back()
def delete():
  appuifw.app.title=ru('Выберите файл')
  files=map(ru,os.listdir(DATA))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  if appuifw.query(ru('Удалить ')+files[index]+'?','query')==True:
    os.remove(DATA+ur(files[index]))
    fold=PHOTO+ur(files[index]+'\\')
    del_dir_all(fold)
    os.rmdir(fold)
    appuifw.note(ru('Набор удален'),'conf')
    MENU()
def back_photo():
  try:
    camera.stop_finder()
    MENU2()
    return
  except:pass
def back():
  global read
  read=0
  appuifw.app.screen='normal'
  uikludges.set_right_softkey_text(ru('В трей'))
  MENU()
def shoot():
  global canvas
  if point0==name2 and ph_dir==1:
    appuifw.note(ru('Невозможно присвоить фото.\nВышке не присвоено имя.'),'error')
  else:
    appuifw.app.body=canvas=appuifw.Canvas()
    uikludges.set_right_softkey_text(ru('Отмена'))
    appuifw.app.exit_key_handler=back_photo
    camera.start_finder(viewfinder)
    canvas.bind(63557,photo)
def viewfinder(img):
  appuifw.app.exit_key_handler=back_photo
  canvas.blit(img)
def photo():
  try:
    camera.stop_finder()
    image=camera.take_photo(size=(160,120))
    w,h=canvas.size
    canvas.blit(image,target=(0,0,w,0.75*w),scale=1)
    if ph_dir==0:
      n=name
    else:
      n=point0
    file=ru(PHOTO)+point0+'\\'+n+'.jpg'
    image.save(file)
    MENU2()
  except:
    camera.stop_finder()
def sel_photo():
  global file,n,sel
  appuifw.app.title=ru('Выберите файл')
  files=map(ru,os.listdir(PHOTO+ur(point0)))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  n=files[index]
  file=ru(PHOTO)+point0+'\\'+n
  sel=1
  MENU2()
def del_photo():
  if os.path.exists(ur(file))==1:
    if appuifw.query(ru('Удалить фото?'),'query')==True:
      os.remove(ur(file))
      appuifw.note(ru('Фото удалено'),'conf')
      MENU2()
def active():
  global sota,vibrate
  if sota==ru('не установлена'):
    appuifw.app.title=ru('Выберите файл')
    files=map(ru,os.listdir(DATA))
    index=appuifw.selection_list(choices=files,search_field=1)
    if index==None:return
    sota=files[index]
  else:
    try:
      z.stop()
    except:pass
    vibrate=0
    sota=ru('не установлена')
    if close==1 and atime!=0:quit()
  MENU()
def active_on():
  global sota,vibrate
  appuifw.app.title=ru('Выберите файл')
  files=map(ru,os.listdir(DATA))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  sota=files[index]
  MENU()
def active_off():
  global sota,vibrate
  try:
    z.stop()
  except:pass
  vibrate=0
  sota=ru('не установлена')
  MENU()
def new_dir():
  global DATA,PHOTO
  appuifw.app.title=ru('Создать папку')
  name_dir=appuifw.query(ru('Имя папки:'),'text')
  if name_dir==None:return
  if os.path.exists(DATA[:29]+ur(name_dir))==0:
    fold=DATA[:29]+ur(name_dir)
    os.mkdir(fold)
    fold0=PHOTO[:30]+ur(name_dir)
    os.mkdir(fold0)
    DATA=fold+'\\'
    PHOTO=fold0+'\\'
    file_name=ru('Пропала сеть')
    rec=u'0, 0, 0, 0'
    f=open(DATA+ur(file_name),'w')
    f.write(str(rec)+u'\n')
    f.close()
    s.Load(SET,create=False)
    s.Add(u'DATA',DATA)
    s.Save
    appuifw.note(ru('Папка создана'),'conf')
    back()
  else:
    appuifw.note(ru('Папка с таким именем существует!'),'error')
    new_dir()
def sel_dir():
  global DATA,PHOTO
  appuifw.app.title=ru('Выберите папку')
  files=map(ru,os.listdir(Data))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  DATA=DATA[:29]+ur(files[index]+'\\')
  PHOTO=PHOTO[:30]+ur(files[index]+'\\')
  if os.path.exists(PHOTO)==0:
    os.mkdir(PHOTO)
  s.Load(SET,create=False)
  s.Add(u'DATA',DATA)
  s.Save
  back()
def ren_dir():
  global DATA,PHOTO
  appuifw.app.title=ru('Выберите папку')
  files=map(ru,os.listdir(DATA[:29]))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  appuifw.app.title=ru('Переименовать папку')
  appuifw.app.exit_key_handler=back
  name_dir=appuifw.query(ru('Новое имя:'),"text",files[index])
  if name_dir==None:return
  fold_old=ru(DATA[:29])+files[index]
  fold0_old=ru(PHOTO[:30])+files[index]
  if os.path.exists(DATA[:29]+ur(name_dir))==0:
    os.rename(ur(fold_old),DATA[:29]+ur(name_dir))
    os.rename(ur(fold0_old),PHOTO[:30]+ur(name_dir))
    if DATA==DATA[:29]+ur(files[index])+'\\':
      DATA=DATA[:29]+ur(name_dir)+'\\'
      PHOTO=PHOTO[:30]+ur(name_dir)+'\\'
      s.Load(SET,create=False)
      s.Add(u'DATA',DATA)
      s.Save
    appuifw.note(ru('Папка переименована'),'conf')
    back()
  else:
    appuifw.note(ru('Папка с таким именем существует!'),'error')
    ren_dir()
def del_dir_all(path):
  for name in os.listdir(path):
    e32.ao_sleep(0.001)
    new=path+'\\'+name
    if os.path.isdir(new):
      del_dir_all(new)
      try:os.rmdir(new)
      except:pass
    else:
      try:os.remove(new)
      except:pass
def del_dir():
  global fold
  appuifw.app.title=ru('Выберите папку')
  files=map(ru,os.listdir(DATA[:29]))
  index=appuifw.selection_list(choices=files,search_field=1)
  if index==None:return
  appuifw.app.title=ru('Удалить папку')
  fold=DATA[:29]+ur(files[index])
  if fold==DATA:
    appuifw.note(ru('Невозможно удалить активную папку!'),'error')
    return
  if appuifw.query(ru('Удалить ')+files[index]+'?',"query")==True:
    del_dir_all(fold)
    os.rmdir(fold)
    fold=PHOTO[:30]+ur(files[index])
    del_dir_all(fold)
    os.rmdir(fold)
    appuifw.note(ru('Папка удалена'),'conf')
    back()
def alarm():
  global atime,s,vibrate
  vibrate=1
  if atime!=0:
    timer=e32.Ao_timer()
    timer.after(atime,active)
  if zvuk>0:
    try:
      z=audio.Sound.open(sound_path)
      z.set_volume(zvuk)
      z.play(audio.KMdaRepeatForever)
    except:pass
  running=1
  try:
    while vibrate==1:
      miso.vibrate(10,100)
      e32.ao_sleep(0.5)
  except:pass
  running=0
def signal_new():
  global name,name2,name_new,title,signal
  try:
    signal=_sysinfo.signal_bars()
    dbm=_sysinfo.signal_dbm()
    mcc,mnc,lac,cellid=location.gsm_location()
    if signal==0:
      mcc,mnc,lac,cellid=0,0,0,0
  except:
    mcc,mnc,lac,cellid=0,0,0,0
  name_new=unicode(mcc)+', '+unicode(mnc)+', '+unicode(lac)+', '+unicode(cellid)
  title=unicode(lac)+' '+unicode(cellid)
  name2=u'LAC: '+unicode(lac)+u'  CellId: '+unicode(cellid)
  if line2==1:
    signal=ru('Сигнал: ')+unicode(signal)+'% - '+unicode(dbm)+u' dBm'
  if line2==2:
    signal='-= '+unicode(signal)+' =-'
  if line2==3:
    signal='-= '+unicode(dbm)+u' dBm =-'
  if name_new!=name:
    name=name_new
    e32.ao_sleep(0.001)
    MENU()
def ekran():
  global k,name,p,point,fg,fg2,fg3,j
  try:
    scr,fg,fg2,fg3='',FGImage(),FGImage(),FGImage()
    while application_list(1)[0] in [u'Phone',u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d',u'Telephone']:
      if pht==1:
        try:
          if not scr:
            scr3=screenshot()
            rcs3=Image.new((176,120))
          if ph_dir==0:
            file=ru(PHOTO)+point0+'\\'+name+'.jpg'
          else:
            file=ru(PHOTO)+point0+'\\'+point+'.jpg'
          scr3=Image.open(file)
          rcs3.blit(scr3,target=(1,1),source=((2,2),(176,176)))
          scr3.blit(rcs3)
          fg3.set(8,56,scr3._bitmapapi())
        except:fg3.unset()
      if not scr:
        scr=screenshot()
        scr2=screenshot()
        rcs=Image.new((176,12))
        rcs2=Image.new((176,12))
        rcs.blit(scr,target=(0,0),source=((0,y),(176,y+12)))
        rcs2.blit(scr2,target=(0,0),source=((0,y2),(176,y2+12)))
      scr=Image.new((176,12))
      scr2=Image.new((176,12))
      scr.blit(rcs)
      scr2.blit(rcs2)
      r=int('0x'+col[:2],16)
      g=int('0x'+col[2:4],16)
      b=int('0x'+col[-2:],16)
      r2=int('0x'+col2[:2],16)
      g2=int('0x'+col2[2:4],16)
      b2=int('0x'+col2[-2:],16)
      if line1==0:p=point
      else:p=point+'  '+signal
      if run==0:
        scr.text((x,10),p,fill=(r,g,b),font=L0[fonts])
      else:
        scr.text((x,10),p[j:],fill=(r,g,b),font=L0[fonts])
        j=j+1
        if j>=len(p):j=0
        e32.ao_sleep(0.2)
      fg.set(0,y,scr._bitmapapi())
      if line2!=0 and line1==0:
        scr2.text((x2,10),signal,fill=(r2,g2,b2),font=L0[fonts2])
        fg2.set(0,y2,scr2._bitmapapi())
      signal_new()
      e32.ao_sleep(0.001)
      e32.ao_yield()
    while 1:
      if application_list(1)[0] in [u'Phone',u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d',u'Telephone']:
        ekran()
      fg.unset()
      fg2.unset()
      fg3.unset()
      appuifw.app.title=unicode(time.strftime('%H:%M:%S',time.localtime(time.time()-time_start)))+'\n'+title
      signal_new()
      e32.ao_sleep(0.001)
      e32.ao_yield()
  except:pass
def sel_sound():
  global sound_path
  path=fileman.AskUser("E:\\Sounds\\",ext=[".mp3"])
  if path==None:return
  sound_path=path
  s.Load(SET,create=False)
  s.Add(u'sound_path',sound_path)
  s.Save
  appuifw.note(ru('Настройки сохранены'),'conf')
def log_read():
  menu=[ru('просмотр'),ru('редактировать'),ru('удалить')]
  i=appuifw.popup_menu(menu,ru('-= ЖУРНАЛ =-'))
  if i==None:return
  if i==0:view_log()
  if i==1:edit_log()
  if i==2:del_log()
def view_log():
  global read
  read=1
  appuifw.app.screen='large'
  appuifw.app.exit_key_handler=back
  uikludges.set_right_softkey_text(ru('Отмена'))
  appuifw.app.body=t=appuifw.Text()
  appuifw.app.menu=[(ru('Редактировать'),edit_log),(ru('Отмена'),back)]
  t.focus=False
  t.color=0x555555
  t.font=u'LatinBold12'
  appuifw.app.body.set(u"")
  f=open(ur(log_file),'r')
  appuifw.app.body.set(ru(f.read()))
  f.close()
  t.set_pos(0)
def edit_log():
  global file,read
  read=1
  appuifw.app.screen='large'
  appuifw.app.exit_key_handler=back
  uikludges.set_right_softkey_text(ru('Отмена'))
  appuifw.app.body=t=appuifw.Text()
  appuifw.app.menu=[(ru('Сохранить'),save),(ru('Очистить экран'),clear),(ru('Отмена'),back)]
  t.focus=True
  t.color=0x000080
  t.font=u'LatinBold12'
  appuifw.app.body.set(u"")
  file=ur(log_file)
  f=open(file,'r')
  appuifw.app.body.set(ru(f.read()))
  f.close()
  t.set_pos(0)
def clear():
  appuifw.app.body.set(u'')
def del_log():
  if appuifw.query(ru('Удалить журнал?'),'query')==True:
    os.remove(ur(log_file))
    f=open(ur(log_file),'w')
    f.close()
    appuifw.note(ru('Журнал удален'),'conf')
def help():
  global read
  read=1
  appuifw.app.screen='normal'
  appuifw.app.title=ru('Помощь')
  files=map(ru,os.listdir(HELP))
  i=appuifw.selection_list(files)
  if i==None:
    MENU()
    return
  file=ur(HELP+files[i])
  f=open(file,'r')
  text=f.read()
  f.close()
  appuifw.app.screen='full'
  appuifw.app.body=t=appuifw.Text()
  t.focus=False
  t.font=u'LatinPlain12'
  t.color=0x444444
  t.set(ru(text))
  t.set_pos(0)
  appuifw.app.exit_key_handler=back
  appuifw.app.menu=[(ru('Помощь'),help),(ru('Назад'),back)]
def about():
  appuifw.note(ru('GSMTrack\nавтор Vital 6630\nICQ: 383822726'),'info')
  appuifw.note(ru('В программе используются фрагменты кода программ:'),'info')
  appuifw.note(ru('GSMLocation 2.5\nавтор Atrant\nICQ: 399976'),'info')
  appuifw.note(ru('Sclero\nавтор Shrim\nICQ: 225220777'),'info')
def quit():os.abort()
def MENU2():
  global canvas,file,sel,n
  r3=int('0x'+col3[:2],16)
  g3=int('0x'+col3[2:4],16)
  b3=int('0x'+col3[-2:],16)
  r4=int('0x'+col4[:2],16)
  g4=int('0x'+col4[2:4],16)
  b4=int('0x'+col4[-2:],16)
  r5=int('0x'+col5[:2],16)
  g5=int('0x'+col5[2:4],16)
  b5=int('0x'+col5[-2:],16)
  img=Image.new((176,144))
  img.clear((r3,g3,b3))
  if ph_dir==0 and sel==0:
    n=name
  if ph_dir==1 and sel==0:
    n=point0
  if sel==0:
    file=ru(PHOTO)+point0+'\\'+n+'.jpg'
  else:
    sel=0
    n=n[:-4]
  try:img2=Image.open(file)
  except:pass
  img.text((7,13),(n),(r5,g5,b5),font=L0[fonts3])
  img.rectangle((0,0,176,144),(r4,g4,b4))
  img.rectangle((7,16,169,138),(r4,g4,b4))
  def handle_redraw(rect):
    canvas.blit(img)
    try:canvas.blit(img2,target=(8,17,168,137),scale=1)
    except:pass
  canvas=appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)
  appuifw.app.body=canvas
  appuifw.app.exit_key_handler=bg
  uikludges.set_right_softkey_text(ru('В трей'))
  appuifw.app.menu=[(ru('Фото'),((ru('сделать (5)'),shoot),(ru('выбрать'),sel_photo),(ru('удалить (с)'),del_photo))),(ru('Настройки'),set3),(ru('Выйти'),quit)]
  canvas.bind(53,shoot)
  canvas.bind(8,del_photo)
  e32.ao_yield()
def menu():
  index=appuifw.app.body.current()
  if index==0:
    if sota==ru('не установлена'):
      menu=[ru('установить')]
    else:
      menu=[ru('сбросить')]
    i=appuifw.popup_menu(menu,u'')
    if i==None:return
    active()
  if index==1:
    if k==0:
      menu=[ru('новый набор'),ru('добавить в набор')]
      i=appuifw.popup_menu(menu,u'')
      if i==None:return
      if i==0:new()
      if i==1:update()
    elif k==1:pass
    else:
      menu=[ru('добавить в набор')]
      i=appuifw.popup_menu(menu,u'')
      if i==None:return
      update()
def handle_tab(index):
  global lb
  if index==0:MENU()
  if index==1:MENU2()
def MENU():
  global k,name,point,point0,j,run,run_old
  if read==1:return
  k=0
  files=map(ru,os.listdir(DATA))
  for a in range(0,len(files)):
    f=open(DATA+ur(files[a]),'r')
    for b in range(0,100):
      n=f.read()
      if n.find(name)>=0:
        k=1
        point_new=files[a]
        break
    if k==0:
      point=name2
      j,run,point0=0,0,point
      rec=u'-'
    else:
      point=point_new
      j,run,point0=0,run_old,point
      if os.path.exists(PHOTO+ur(point))==0:
        fold=PHOTO+ur(point)
        os.mkdir(fold)
      if run==1:
        point=' '*40+point
      else:
        if point[:40]==' '*40:
          point=point0
    f.close()
  if sota==point0:
    if atime==0:
      appswitch.switch_to_fg(u'GSMTrack')
    appuifw.app.title=ru('ТРЕВОГА')
    appuifw.app.menu=[(ru('СТОП'),active)]
    fg.unset()
    fg2.unset()
    fg3.unset()
    alarm()
  tm=unicode(time.strftime('%d-%m-%Y %H:%M:%S'))
  if log==1 and rec!=u'-':
    f=open(ur(log_file),'a')
    f.write(tm+'\n')
    f.write(ur(point0)+'\n')
    f.write(name+'\n\n')
    f.close()
  if log==2:
    f=open(ur(log_file),'a')
    f.write(tm+'\n')
    f.write(ur(point0)+'\n')
    f.write(name+'\n\n')
    f.close()
  appuifw.app.body=appuifw.Listbox([(ru('Активная вышка:'),sota),(ru('Текущая вышка:'),point0)],menu)
  appuifw.app.set_tabs([ru('Меню'),ru('Фото')],handle_tab)
  appuifw.app.exit_key_handler=bg
  appuifw.app.screen='normal'
  appuifw.app.menu=[(ru('Активная вышка'),((ru('установить'),active_on),(ru('сбросить'),active_off))),(ru('Текущая вышка'),((ru('новый набор'),new),(ru('дописать в набор'),update))),(ru('Наборы вышек'),((ru('переименовать'),rename),(ru('редактировать'),edit),(ru('удалить'),delete))),(ru('Папки с наборами'),((ru('выбрать'),sel_dir),(ru('создать новую'),new_dir),(ru('переименовать'),ren_dir),(ru('удалить'),del_dir))),(ru('Инструменты'),((ru('настройки'),set),(ru('выбрать звук. файл'),sel_sound),(ru('журнал'),log_read),(ru('помощь'),help),(ru('о программе'),about))),(ru('Выйти'),quit)]
handle_tab(0)
ekran()
lock=e32.Ao_lock()
lock.wait()
