###############
from gla_2 import *
###############
appinit()
###############
gla_setmain(760)

x=20
yh=60
yl=yh+30
#F
#параметры времени выражаем в переменных t1 t2
t1=gla_ltn(10,40)
t2=gla_ltn(31,100)
#параметры цвета выражаем в переменной с
c=gla_lcn(t1,0x99,0x25,0x25,0x99)+gla_lcn(t2,0x25,0xff,0x99,0xff)
# параметры толщены выражае в переменной w
w=gla_lan(t1,7,3)+gla_lan(t2,3,2)
#задаем координату х1 и у1
x1=gla_lan(t1,100,x)+gla_lan(t2,x,x)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
#задаем координату х2 и у2
x2=gla_lan(t1,87,x+2)+gla_lan(t2,x,x)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
#теперь все переменные выкладываем на линию
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#параметры времени выражаем в переменных t1 t2
t1=gla_ltn(20,50)
t2=gla_ltn(41,100)
#
c=gla_lcn(t1,0x7f,0x25,0x25,0x99)+gla_lcn(t2,0x25,0xff,0x99,0xff)
#
w=gla_lan(t1,7,3)+gla_lan(t2,3,2)
#
x1=gla_lan(t1,90,x+10)+gla_lan(t2,x+15,x+15)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
#
x2=gla_lan(t1,87,x-4)+gla_lan(t2,x-4,x-4)
y2=gla_lan(t1,207,yh+3)+gla_lan(t2,yh+3,yh+3)
#
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#
t1=gla_ltn(0,30)
t2=gla_ltn(51,100)
#
c=gla_lcn(t1,0x7f,0x25,0x25,0x99)+gla_lcn(t2,0x25,0xff,0x99,0xff)
#
w=gla_lan(t1,7,3)+gla_lan(t2,3,2)
#
x1=gla_lan(t1,87,x-3)+gla_lan(t2,x-3,x-3)
y1=gla_lan(t1,0,75)+gla_lan(t2,75,75)
#
x2=gla_lan(t1,87,x+14)+gla_lan(t2,x+14,x+14)
y2=gla_lan(t1,207,75)+gla_lan(t2,75,75)
#
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#fantom forever
t1=gla_ltn(20,60)
t2=gla_ltn(61,100)
gla_text(t1+t2,gla_lan(t1,175,yh-20)+gla_lan(t2,yh-20,yh-20),gla_lan(t1,207,yl+2)+gla_lan(t2,yl+2,yl+2),u'ANTOM-FOREVER',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))

#A
t1=gla_ltn(110,140)
t2=gla_ltn(131,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+10)+gla_lan(t2,x+10,x+10)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+2)+gla_lan(t2,x+2,x+2)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(120,150)
t2=gla_ltn(141,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+10)+gla_lan(t2,x+10,x+10)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+18)+gla_lan(t2,x+18,x+18)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(101,130)
t2=gla_ltn(151,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+6)+gla_lan(t2,x+6,x+6)
y1=gla_lan(t1,0,75)+gla_lan(t2,75,75)
x2=gla_lan(t1,87,x+14)+gla_lan(t2,x+14,x+14)
y2=gla_lan(t1,207,75)+gla_lan(t2,75,75)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#L
t1=gla_ltn(140,170)
t2=gla_ltn(171,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(130,160)
t2=gla_ltn(161,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y1=gla_lan(t1,0,yl)+gla_lan(t2,yl,yl)
x2=gla_lan(t1,87,x+38)+gla_lan(t2,x+38,x+38)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#BERT927
t1=gla_ltn(140,180)
t2=gla_ltn(181,200)
gla_text(t1+t2,gla_lan(t1,175,yh+2)+gla_lan(t2,yh+2,yh+2),gla_lan(t1,207,yl+2)+gla_lan(t2,yl+2,yl+2),u'BERT 927',gla_lcn(t1,0,0,0x7f,0xff)+gla_lcn(t2,0,0,0xff,0xff))

#представляет 
t1=gla_ltn(201,230)
t2=gla_ltn(231,250)
gla_text(t1+t2,gla_lan(t1,yh+2,yh+2)+gla_lan(t2,yh+2,yh+2),gla_lan(t1,yl+2,yl+2)+gla_lan(t2,yl+2,yl+2),u'\u043f\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043b\u044f\u0435\u0442',gla_lcn(t1,0,0x55,0,0xff)+gla_lcn(t2,0x56,0,0xff,0))

#воом
t1=gla_ltn(251,280)
t2=gla_ltn(281,300)
gla_text(t1+t2,gla_lan(t1,yh-12,yh-12)+gla_lan(t2,yh-12,yh-12),gla_lan(t1,yl+2,yl+2)+gla_lan(t2,yl+2,yl+2),u'BOOM',gla_lcn(t1,0,0xff,)+gla_lcn(t2,0xff,0))

#фон
t1=gla_ltn(300,350)
t2=gla_ltn(351,380)
t3=gla_ltn(381,400)
t4=gla_ltn(401,500)
gla_fon(t1+t2+t3+t4,gla_lcn(t1,0,0x95,0,0x095,0,0x55)+gla_lcn(t2,0x95,0x95,0x095,0x95,0x55,0xff)+gla_lcn(t3,0x95,0x95,0x095,0x95,0xff,0xff)+gla_lcn(t4,0x95,0x95,0x095,0x95,0xff,0xff))

#
t1=gla_ltn(300,320)
t2=gla_ltn(321,340)
t3=gla_ltn(341,360)
t4=gla_ltn(361,380)
t5=gla_ltn(381,400)
t6=gla_ltn(401,410)
t7=gla_ltn(411,425)
t8=gla_ltn(426,450)
t9=gla_ltn(451,550)

#параметры цвета 
c=gla_lcn(t1,0x25,0x25,0x25,0x25)+gla_lcn(t2,0x25,0x35,0x25,0x35)+gla_lcn(t3,0x35,0x15,0x35,0x25)+gla_lcn(t4,0x15,0x10,0x25,0x20)+gla_lcn(t5,0x15,0x10,0x25,0x20)+gla_lcn(t6,0x15,0x10,0x25,0x20)+gla_lcn(t7,0x15,0x10,0x25,0x20)+gla_lcn(t8,0x15,0x10,0x25,0x20)+gla_lcn(t9,0x15,0x10,0x25,0x20)

c1=gla_lcn(t9,0xdd,0x95,0x25,0x25)

w=gla_lan(t1,5,5)+gla_lan(t2,5,0)+gla_lan(t3,0,5)+gla_lan(t4,5,15)+gla_lan(t5,15,5)+gla_lan(t6,5,3)+gla_lan(t7,3,5)+gla_lan(t8,5,35)+gla_lan(t9,35,35)

w1=gla_lan(t9,35,35)

#задаем координату х1 и у1
x1=gla_lan(t1,100,x)+gla_lan(t2,x,x)+gla_lan(t3,x,200)+gla_lan(t4,200,50)+gla_lan(t5,50,x+50)+gla_lan(t6,x+50,60)+gla_lan(t7,60,x+80)+gla_lan(t8,x+50,85)+gla_lan(t9,85,85)

x1a=gla_lan(t9,85,85)

y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh+30)+gla_lan(t3,yh+30,yh-20)+gla_lan(t4,yh-20,yh+45)+gla_lan(t5,yh-20,yh+45)+gla_lan(t6,yh-20,yh+45)+gla_lan(t7,yh-20,yh+45)+gla_lan(t8,yh-20,yh+45)+gla_lan(t9,yh+45,yh+95)

y1a=gla_lan(t9,yh+45,yh+95)
#задаем координату х2 и у2
x2=gla_lan(t9,85,85)
y2=gla_lan(t9,yh+45,yh+45)
#теперь все переменные выкладываем на линию
gla_line(t9,x1a,y1a,x2,y2,c1,w1)

gla_point(t1+t2+t3+t4+t5+t6+t7+t8+t9,x1,y1,c,w)

#trescheny

w=gla_lan(t9,1,1)

c=gla_lcn(t9,0xff,0xff,0xff,0xff,0xff,0xff)
c1=gla_lcn(t9,0x45,0x45,0x45,0x45,0x55,0x55)
#1
x1=gla_lan(t9,85,85)
y1=gla_lan(t9,105,105)
#2
x1v=gla_lan(t9,75,75)
y1v=gla_lan(t9,25,25)
#3
x1n=gla_lan(t9,95,95)
y1n=gla_lan(t9,125,125)
#4
x1np=gla_lan(t9,100,100)
y1np=gla_lan(t9,115,115)
#5
x2=gla_lan(t9,40,40)
y2=gla_lan(t9,165,165)
#6
x2p=gla_lan(t9,140,140)
y2p=gla_lan(t9,45,45)

#
gla_line(t9,x1,y1,x2,y2,c1,w)
gla_line(t9,x1,y1,x2p,y2p,c1,w)
gla_line(t9,x1,y1,x1v,y1v,c1,w)
gla_line(t9,x1,y1,x1np,y1np,c1,w)
gla_line(t9,x1,y1,x1n,y1n,c1,w)


#
#1
x1=gla_lan(t9,90,90)
y1=gla_lan(t9,115,115)
#2
x2=gla_lan(t9,110,110)
y2=gla_lan(t9,135,135)
#3
x3=gla_lan(t9,100,100)
y3=gla_lan(t9,125,125)
#4
x4=gla_lan(t9,110,110)
y4=gla_lan(t9,95,95)
#5
x5=gla_lan(t9,150,150)
y5=gla_lan(t9,110,110)

#
gla_line(t9,x1,y1,x2,y2,c1,w)
gla_line(t9,x3,y3,x4,y4,c1,w)
gla_line(t9,x4,y4,x5,y5,c1,w)

#
#1
x1=gla_lan(t9,74,74)
y1=gla_lan(t9,100,100)
#2
x2=gla_lan(t9,30,30)
y2=gla_lan(t9,35,35)
#3
x3=gla_lan(t9,60,60)
y3=gla_lan(t9,125,125)
#4
x4=gla_lan(t9,79,79)
y4=gla_lan(t9,109,109)
#5
x5=gla_lan(t9,50,50)
y5=gla_lan(t9,110,110)

#
gla_line(t9,x1,y1,x2,y2,c1,w)
gla_line(t9,x3,y3,x4,y4,c1,w)
gla_line(t9,x4,y4,x5,y5,c1,w)

#titry
#ПРОДОЛЖЕНИЕ СЛЕДУЕТ
t1=gla_ltn(540,580)
t2=gla_ltn(581,620)
gla_text(t1+t2,gla_lan(t1,24,24)+gla_lan(t2,24,24),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'\u041f\u0420\u041e\u0414\u041e\u041b\u0416\u0415\u041d\u0418\u0415 \u0421\u041b\u0415\u0414\u0423\u0415\u0422',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))


#ХУДОЖНИК:
t1=gla_ltn(560,600)
t2=gla_ltn(601,640)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'\u0425\u0423\u0414\u041e\u0416\u041d\u0418\u041a',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))


# FANTOM-FOREVER
t1=gla_ltn(580,620)
t2=gla_ltn(621,660)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'FANTOM-FOREVER',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))



#ПРОГРАММИСТ
t1=gla_ltn(600,640)
t2=gla_ltn(641,680)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'\u041f\u0420\u041e\u0413\u0420\u0410\u041c\u041c\u0418\u0421\u0422',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))



#ALBERT 927
t1=gla_ltn(620,660)
t2=gla_ltn(661,700)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'ALBERT 927',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))


###############
while appstate():
    gla_drawmaintest()
###############
handle_redraw(())
e32.ao_yield()