import appuifw,e32,urllib,urlquote,os
from rusos import *
def ru(x):return x.decode('utf-8')

app_lock=e32.Ao_lock()

round=appuifw.Text()
appuifw.app.screen='normal'
round.set(u'                  CallBacker')
appuifw.app.body=round

def exit():
 app_lock.signal()
 appuifw.app.set_exit()


HelPath='e:\\system\\apps\\CallBacker\\help.hlp'
MyNumb='e:\\system\\apps\\CallBacker\\my_number\\my.nmb'
BookPath='e:\\system\\apps\\CallBacker\\numbers\\'


if os.path.exists(HelPath):
 HelPath='e:\\system\\apps\\CallBacker\\help.hlp'
 BookPath='e:\\system\\apps\\CallBacker\\numbers\\'
else:
 HelPath='c:\\system\\apps\\CallBacker\\help.hlp'
 BookPath='c:\\system\\apps\\CallBacker\\numbers\\'

if not os.path.exists(MyNumb):
 mn=appuifw.query(ru('Введите Ваш номер телефона(без 7)'),'text')
 if mn == None:
  appuifw.note(ru('Ошибка, необходимо ввести свой номер'),'error')
  exit()
 else:
  f=open(MyNumb,'w')
  f.write(mn)
  f.close()
  f=open(MyNumb,'r')
  r=f.read()
  f.close()
  ynmb=str(r)
  ynmbq=urlquote.quote(ynmb)
  appuifw.note(ru('Номер успешно сохранен'),'conf')
else:
 f=open(MyNumb,'r')
 r=f.read()
 f.close()
 ynmb=str(r)
 ynmbq=urlquote.quote(ynmb)


def call():
 sn=appuifw.query(ru('Введите номер собеседника(без 7ки):'),'text')
 if sn == None:
  appuifw.note(ru('Отменено'))
  return
 snq=urlquote.quote(sn)
 if appuifw.query(ru('Послать запрос на callback?'),'query') == True:
  appuifw.note(ru('Выберите точку доступа'))
  urllib.urlopen('http://freeofcharge.ru/cgi-bin/light.py?n1='+ynmbq+'&n2='+snq)
  appuifw.note(ru('Запрос на callback отправлен.Ждите входящего звонка'),'conf')
 else:
  appuifw.note(ru('Вы отменили запрос'),'error')
  round.set(u'                  CallBacker')
def about():
 appuifw.note(u'CallBacker v.0.02\nby G.F.Ferre\nfor DimonVideo.ru')
def help():
 f=open(HelPath,'r')
 r=f.read()
 f.close()
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru(r))
 txt.set_pos(0)
 txt.set_pos(220)
 appuifw.app.menu=[(ru('Назад'),backmenu)]
def backmenu():
 appuifw.app.body=round
 round.set(u'                  CallBacker')
 appuifw.app.menu=[(ru('Звонок'),call),(ru('Записная книжка'),((ru('Смотреть'),book),(ru('Добавить'),add_book),(ru('Удалить'),book_del))),(ru('Мой номер'),((ru('Смотреть'),mynumb_show),(ru('Изменить'),mynumb_set))),(ru('Помощь'),help),(ru('О программе'),about),(ru('Выход'),exit)]
##########################
def book():
 appuifw.note(ru('Выберите собеседника из телефонной книги'))
 o=os.listdir(BookPath)
 m=mask(o)
 i=appuifw.selection_list(m)
 if i == None:
  appuifw.note(ru('Отменено'))
  return
 if appuifw.query(ru('Послать запрос на callback?'),'query') == True:
  snmbq=urlquote.quote(o[i])
  urllib.urlopen('http://freeofcharge.ru/cgi-bin/light.py?n1='+ynmbq+'&n2='+snmbq)
  appuifw.note(ru('Запрос отправлен.Ждите входящего звонка'),'conf')
 else:
  appuifw.note(ru('Вы отменили запрос'))
#########
def mynumb_set():
 f=open(MyNumb,'r')
 r=f.read()
 f.close()
 newnumb=appuifw.query(ru('Текущий: '+r+'\nВведите новый номер(без 7):'),'text')
 if newnumb == None:
  appuifw.note(ru('Отменено'),'conf')
  return
 else:
  f=open(MyNumb,'w')
  f.write(newnumb)
  f.close()
  f=open(MyNumb,'r')
  r=f.read()
  f.close()
  ynmb=str(r)
  global ynmbq
  ynmbq=urlquote.quote(ynmb)
  appuifw.note(ru('Смена номера успешно завершена!'),'conf')
##########
def mynumb_show():
 f=open(MyNumb,'r')
 r=f.read()
 f.close()
 appuifw.note(ru('Ваш номер: '+str(r)))
def add_book():
 global nc
 nc=appuifw.query(ru('Введите номер контакта(без 7)'),'text')
 if nc == None:
  appuifw.note(ru('Номер не введен'),'error')
  return
 nnm=appuifw.query(ru('Введите имя контакта'),'text')
 if nnm == None:
  appuifw.note(ru('Имя не введено'),'error')
  return
 f=open(BookPath+nnm,'w')
 f.write(nc)
 f.close()
 appuifw.note(ru('Контакт создан'),'conf')
def book_del():
 appuifw.note(ru('Выберите номер для удаления'))
 o=os.listdir(BookPath)
 m=mask(o)
 i=appuifw.selection_list(m)
 if i == None:
  appuifw.note(ru('Отменено'))
  return
 if appuifw.query(ru('Удалить '+o[i]+'?'),'query') == True:
  os.remove(BookPath+o[i])
  appuifw.note(ru('Контакт удален'),'conf')
 else:
  appuifw.note(ru('Отменено'))
  return

appuifw.app.menu=[(ru('Звонок'),call),(ru('Записная книжка'),((ru('Смотреть'),book),(ru('Добавить'),add_book),(ru('Удалить'),book_del))),(ru('Мой номер'),((ru('Смотреть'),mynumb_show),(ru('Изменить'),mynumb_set))),(ru('Помощь'),help),(ru('О программе'),about),(ru('Выход'),exit)]
appuifw.app.exit_key_handler=exit
app_lock.wait()