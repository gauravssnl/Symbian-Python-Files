###############
from gla_2 import *
###############
appinit()
###############
gla_setmain(150)
mt=gla_ltn(0,150)
mt1=gla_ltn(0,75)
mt2=gla_ltn(76,150)
mc=gla_lcn(mt1,0x00,0xff)+gla_lcn(mt2,0xff,0x00)
gla_fon(mt,mc)
mx=gla_lan(mt1,0,175)
mx+=gla_lan(mt2,175,0)
my=gla_lan(mt1,0,207)
my+=gla_lan(mt2,0,207)
mc=gla_lcn(mt1,0,0,0,0,0xff,0)
mc+=gla_lcn(mt2,0,0,0,0xff)
mw=gla_lan(mt1,1,20)
mw+=gla_lan(mt2,20,1)
gla_point(mt,mx,my,mc,mw)
###############
while appstate():
    gla_drawmaintest()
###############