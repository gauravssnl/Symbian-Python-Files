import sys
class ConsoleOutput(object):
  def __init__(s, path):
    s.path = path
    s.f = open(s.path,"w+")
    s.f.close()

  def write(s,string):
    s.f = open(s.path,"a+")
    s.f.write(string)
    s.f.close()

sys.stderr = ConsoleOutput("D:\\err")
sys.stdout = ConsoleOutput("D:\\out")



from appswitch import switch_to_bg 
from keypress import simulate_key 
from os import abort
from e32 import ao_sleep

switch_to_bg(u'Emoff')
#ao_sleep(0.1)
simulate_key(63556,63556)
ao_sleep(0.3)
simulate_key(63497,63497)
abort()


