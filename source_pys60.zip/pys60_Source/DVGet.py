#corrected version check by Guria (gurianov@gmail.com)
import os,e32,time,socket,appuifw,local

class data :
	def __init__(self):
		#self.path_sets=appuifw.app.full_name()[0]+':\\nokia\\scripts\\DVGet.set'
		self.path_sets=appuifw.app.full_name()[0]+':\\System\\Apps\\DVGet\\DVGet.set'
		self.stack=[]
		self.timer_stop=''
		file=open(self.path_sets,'r')
		self.language,self.flag_autodel,self.down_apid,self.down_savedir,self.down_urls=eval(file.read())
		file.close()
		if self.language==0:
			languages=[unicode(lang) for lang in local.data.keys()]
			index=appuifw.popup_menu(languages,u'Language:')
			if index>=0:
				self.language=languages[index]
				self.save()
			else:appuifw.app.set_exit()
		self.lang()
		if e32.pys60_version_info<(1,3,18):
			appuifw.note(self._update,'error')
			appuifw.app.set_exit()
	def lang(self):
		self._update,self._start,self._start_now,self._start_in,self._start_over,self._list,self._list_new,self._list_edit,self._list_del,self._sets,self._set_autodel,self._set_apid,self._set_savedir,self._help,self._exit,self._urls,self._full,self._txt_autodel,self._txt_savedir,self._txt_savedir_bad,self._help_about,self._help_list,self._help_down,self._help_sets,self._help_back,self._down_next,self._down_stop,self._mess_stop,self._mess_404,self._mess_416,self._mess_down,self._mess_unknown,self._timer_in,self._timer_in_end,self._timer_over,self._timer_over_end,self._timer_cancel,self._timer_txt_now,self._timer_txt_in,self._timer_txt_over,self._unknown,self._kb_sec,self._file,self._size,self._progress,self._download,self._speed,self._language=[txt.decode('utf-8') for txt in local.data[self.language][:-1]]
	def save(self):
		file=open(self.path_sets,'w')
		file.write(`[self.language,self.flag_autodel,self.down_apid,self.down_savedir,self.down_urls]`)
		file.close()

data=data()

def set_language():
	languages=[unicode(lang) for lang in local.data.keys()]
	index=appuifw.popup_menu(languages,u'Language:')
	if index>=0:
		data.language=languages[index]
		data.lang()
		data.save()
		main()
def set_autodel():
	flag=appuifw.query(data._txt_autodel,'query')
	if flag:data.flag_autodel=1
	else:data.flag_autodel=0
	data.save()
def set_apid():
	data.down_apid=socket.select_access_point()
	data.save()
def set_savedir():
	path=appuifw.query(data._txt_savedir,'text',data.down_savedir)
	try:
		len(path)
		try:
			os.stat(path)
			data.down_savedir=path
		except:
			try:
				os.mkdir(path)
				data.down_savedir=path
			except:
				data.down_savedir=u'e:\\download\\'
				appuifw.note(data._txt_savedir_bad,'error')
	except:pass
	data.save()

def body_text():
	data.stack.append([appuifw.app.body,appuifw.app.menu])
	appuifw.app.body=appuifw.Text()
	appuifw.app.body.color=0
def body_exit():
	appuifw.app.body.focus=False
	appuifw.app.body,appuifw.app.menu=data.stack.pop()

def help_main():
	body_text()
	appuifw.app.body.focus=False
	appuifw.app.menu=[
		(data._help_about,lambda:help_part('about')),
		(data._help_list,lambda:help_part('lists')),
		(data._help_down,lambda:help_part('down')),
		(data._help_sets,lambda:help_part('sets')),
		(data._help_back,body_exit)]
	help_part('about')
def help_part(part):
	appuifw.app.body.set(local.data[data.language][-1][part].decode('utf-8'))
	appuifw.app.body.set_pos(0),appuifw.app.body.set_pos(170)

def list_get(mode=1):
	if mode:index=appuifw.app.body.current()
	files=[u'  '+unicode(index+1)+u') '+data.down_urls[index].split('/')[-1] for index in range(len(data.down_urls))]
	files.insert(0,data._urls+unicode(len(files)))
	if mode:appuifw.app.body.set_list(files,index)
	else:
		appuifw.app.body=appuifw.Listbox(files,list_edit)
		appuifw.app.body.bind(0xf80b,list_new)
		appuifw.app.body.bind(0x35,start_now)
		appuifw.app.body.bind(0x8,list_del)
def list_new():
	body_text()
	appuifw.app.menu=[(data._full,list_new_exit)]
def list_new_exit():
	url=appuifw.app.body.get()
	if len(url)>7:
		data.down_urls.append(url)
		data.save()
	body_exit()
	list_get()
def list_edit():
	data.index=appuifw.app.body.current()
	if data.index==0:return
	body_text()
	appuifw.app.body.set(data.down_urls[data.index-1])
	appuifw.app.menu=[(data._full,list_edit_exit)]
def list_edit_exit():
	url=appuifw.app.body.get()
	if len(url)>7:
		data.down_urls[data.index-1]=url
		data.save()
	body_exit()
	list_get()
def list_del():
	index=appuifw.app.body.current()
	if index==0:return
	del data.down_urls[index-1]
	data.save()
	list_get()

def start_now(mode=1):
	urls_len=len(data.down_urls)
	if urls_len==0:return
	if data.down_apid==None:set_apid()
	if data.down_apid==None:return
	socket.set_default_access_point(socket.access_point(data.down_apid))
	if mode:
		body_text()
		appuifw.app.body.focus=False
	appuifw.app.menu=[
		(data._down_next,down_next),
		(data._down_stop,down_stop)]
	data.old_seek,data.old_time=0,0
	data.index=u''
	data.flag_stop=0
	for url in [url for url in data.down_urls]:
		if urls_len>1:data.index=u' ('+unicode(data.down_urls.index(url)+1)+u'/'+unicode(urls_len)+u')'
		data.filename=url.split('/')[-1]
		data.flag_next=0
		appuifw.note(down_start(url))
		if data.flag_stop:break
		if data.flag_autodel:
			data.down_urls.remove(url)
			data.save()
	body_exit()
	list_get()
	data.timer_stop=''
def start_in():
	urls_len=len(data.down_urls)
	if urls_len==0:return
	try:
		sec=appuifw.query(data._timer_in,'time')-1+1
		sec_end=appuifw.query(data._timer_in_end,'time')-1+1
	except:return
	body_text()
	appuifw.app.body.focus=False
	appuifw.app.menu=[(data._timer_cancel,start_exit)]
	timer=time.strftime('%H%M',time.gmtime(sec))
	timer_txt=unicode('\n\n'+data._timer_txt_in+time.strftime('%H.%M.%S',time.gmtime(sec)))
	data.flag_timer=0
	while timer!=time.strftime('%H%M'):
		if data.flag_timer:return body_exit()
		appuifw.app.body.set(data._timer_txt_now+unicode(time.strftime('%H.%M.%S'))+timer_txt)
		e32.ao_sleep(1)
	data.timer_stop=time.strftime('%H%M',time.gmtime(sec_end))
	start_now(0)
def start_over():
	urls_len=len(data.down_urls)
	if urls_len==0:return
	try:
		sec=appuifw.query(data._timer_over,'time')-1
		sec_end=appuifw.query(data._timer_over_end,'time')-1
	except:return
	body_text()
	appuifw.app.body.focus=False
	appuifw.app.menu=[(data._timer_cancel,start_exit)]
	data.flag_timer=0
	while sec>=0:
		if data.flag_timer:return body_exit()
		appuifw.app.body.set(data._timer_txt_over+unicode(time.strftime('%H.%M.%S',time.gmtime(sec))))
		sec-=1
		e32.ao_sleep(1)
	data.timer_stop=time.strftime('%H%M',time.gmtime(sec+sec_end))
	start_now(0)
def start_exit():
	data.flag_timer=1

def down_start(url):
	temp=url.split('//')[1].split('/')
	host=temp[0]
	path=''
	for part in temp[1:]:path+='/'+part
	try:os.stat(data.down_savedir)
	except:os.mkdir(data.down_savedir)
	name=data.down_savedir+temp[-1]
	try:seek=os.stat(name)[6]
	except:seek=0
	size=0
	down_call(size,seek)
	try:
		while 1:
			try:
				conn=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
				if data.flag_stop or data.flag_next:
					conn.close()
					return data._mess_stop
				conn.connect((host,80))
				conn.send('GET  '+path+' HTTP/1.1\r\nHost: '+host+'\r\nAccept-Encoding: identity\r\nRange: bytes='+str(seek)+'-\r\nUser-agent: DVGet\r\n\r\n')
				info=conn.recv(512)
				e32.ao_sleep(0.1)
			except:continue
			if info[:32].find('404')>=0 or info[:32].find('400')>=0 or info[:32].find('302')>=0:
				conn.close()
				return data._mess_404
			elif info[:32].find('416')>=0:
				conn.close()
				return data._mess_416
			for part in info.split('\r\n'):
				if part[:16]=='Content-Length: ':
					size=int(part[16:])+seek
					break
			else:size=-1
			info=info[info.find('\r\n\r\n')+4:]
			while 1:
				seek+=len(info)
				down_call(size,seek)
				file=open(name,'a')
				file.write(info)
				file.close()
				if data.flag_stop or data.flag_next:
					conn.close()
					return data._mess_stop
				if seek==size or (info=='' and size==-1):
					conn.close()
					return data._mess_down
				try:info=conn.recv(8192)
				except:break
	except:return data._mess_unknown
def down_call(size,seek):
	if size==0:size=pr=speed=data._unknown
	else:
		pr=unicode((seek*100)/size)+u'%'
		speed=unicode(round((seek-data.old_seek)/(1024*(time.clock()-data.old_time)),2))+data._kb_sec
		data.old_seek,data.old_time=seek,time.clock()
	appuifw.app.body.set(data._file+data.index+u': '+data.filename+u'\n\n'+data._size+unicode(size)+u'\n\n'+data._download+unicode(seek)+u'\n\n'+data._progress+pr+u'\n\n'+data._speed+speed)
	if data.timer_stop==time.strftime('%H%M'):data.flag_stop=1
def down_next():
	data.flag_next=1
def down_stop():
	data.flag_stop=1

def main():
	appuifw.app.menu=[
		(data._start,(
			(data._start_now,start_now),
			(data._start_in,start_in),
			(data._start_over,start_over))),
			(data._list,(
			(data._list_new,list_new),
			(data._list_edit,list_edit),
			(data._list_del,list_del))),
		(data._sets,(
			(data._set_autodel,set_autodel),
			(data._set_apid,set_apid),
			(data._set_savedir,set_savedir),
			(data._language,set_language))),
		(data._help,help_main),
		(data._exit,appuifw.app.set_exit)]
	list_get(0)

main()

#lock=e32.Ao_lock()
#appuifw.app.exit_key_handler=lock.signal
#lock.wait()