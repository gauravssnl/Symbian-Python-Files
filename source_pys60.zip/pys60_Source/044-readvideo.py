
f = file('E:\\Videos\\200703\\video.mp4','r')
myvideo = f.read()
f.close()
