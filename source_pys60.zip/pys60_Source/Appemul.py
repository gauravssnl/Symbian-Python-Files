###Seldon86

import os,e32,appuifw,keypress,appswitch
aa=appuifw.app

def ru(t):return t.decode('utf-8')
def ur(t):return t.encode('utf-8')

def start():
 PATH='e:/others/appemul/'
 if os.path.isdir(PATH)==0:
  app.out('Ошибка: папки '+PATH+' не существует.')
  return

 LISTFILE=[]
 for i in os.listdir(PATH):
  if os.path.isfile(PATH+i):
   if os.path.splitext(PATH+i)[1]=='.txt':LISTFILE.append(ru(i[:-4]))
 if len(LISTFILE)!=0:NAME=PATH+ur(LISTFILE[appuifw.selection_list(LISTFILE)])+'.txt'
 else:
  app.out('Ошибка: папка '+PATH+' пуста.')
  return

 try:FILE=open(NAME,'r',4098)
 except:
  app.out('Ошибка: скрипт '+NAME+' не найден.')
  return

 TEGS=FILE.read().splitlines()
 FILE.close()
 app.out('Выполнение скрипта.')

 NUMBER,STEP,REPEAT=0,0,1
 for i in TEGS:
  TEG=i.split('=')
  if TEG[0]=='!L':
   STEP,REPEAT=1,int(TEG[1])
   break
 
 while NUMBER<REPEAT:
  for i in TEGS:
   TEG=i.split('=')
   TEGNAME,TEGARGUMENT=TEG
   if TEGNAME=='!A':appswitch.switch_to_fg(unicode(TEGARGUMENT))
   elif TEGNAME=='!S':e32.ao_sleep(float(TEGARGUMENT))
   elif TEGNAME=='!K':
    KEYS=TEGARGUMENT.split(',')
    if len(KEYS)==1:keypress.simulate_key(int(KEYS[0]),int(KEYS[0]))
    if len(KEYS)==2:keypress.simulate_key(int(KEYS[0]),int(KEYS[1]))
    if len(KEYS)==3:keypress.simulate_key(int(KEYS[0]),int(KEYS[1]),int(KEYS[2]))
  NUMBER+=STEP

 appswitch.switch_to_fg(u'AppEmul')
 app.out('Выполнение скрипта завершено.')

class Exit:
 def __init__(s):s.AOLOCK=e32.Ao_lock()
 def wait(s):s.AOLOCK.wait()
 def call(s):
  s.AOLOCK.signal()
  aa.set_exit()
exit=Exit()

class App:
 def __init__(s):
  aa.screen,aa.exit_key_handler='normal',exit.call
  aa.menu=[
  (ru('Запустить скрипт'),start),
  (ru('Выход'),exit.call)]
  aa.body=appuifw.Text()
  aa.body.color=(0,0,0)
  s.out('Программа готова к работе.')
 def out(s,t):
  aa.body.set(ru(t))
  aa.body.set_pos(0)
  aa.body.focus=False
  e32.ao_sleep(0.001)
 def get(s):return aa.body.get()
app=App()

exit.wait()