#
# System Agent return values for sysagent.pyd !
#

ESACallNone = 0
ESACallVoice = 1
ESACallFax = 2
ESACallData = 3
ESACallAlerting = 4
ESACallRinging = 5
ESACallAlternating = 6
ESACallDialling = 7
ESACallAnswering = 8
ESACallDisconnecting = 9

ESABatteryAlmostEmpty = 0
ESABatteryLow = 1
ESABatteryFull = 2

ESAPhoneOff = 0
ESAPhoneOn = 1

ESASimOk = 0
ESASimNotPresent = 1
ESASimRejected = 2

ESANetworkAvailable = 0 
ESANetworkUnAvailable = 1

ESANetworkStrengthNone = 0
ESANetworkStrengthLow = 1
ESANetworkStrengthMedium = 2
ESANetworkStrengthHigh = 3
ESANetworkStrengthUnknown = 4

ESAChargerConnected = 0 
EESAChargerDisconnected = 1
ESAChargerNotCharging = 2

ESADataPortIdle = 0 
ESADataPortBusy	= 1

ESAInboxEmpty = 0
ESADocumentsInInbox = 1

ESAOutboxEmpty = 0
ESADocumentsInOutbox = 1

ESAAm = 0 
ESAPm = 1

ESAIrLoaded	= 0	        ## IRDA Irlap layer loaded
ESAIrDiscoveredPeer = 1 ## Discovery begin
ESAIrLostPeer = 2		    ## Discovery end
ESAIrConnected = 3		  ## IRDA Irlap layer connected
ESAIrBlocked = 4		    ## IRDA Irlap layer blocked
ESAIrDisConnected = 5	  ## IRDA Irlap layer disconnected
ESAIrUnloaded = 6		    ## IRDA Irlap layer unloaded
