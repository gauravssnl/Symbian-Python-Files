import appuifw
import audio
import sys

def op():
   sys.setdefaultencoding('utf-8')
op()

text = appuifw.query(u"Text",'text')
try:
  audio.say(text)
except:
  print u'error\n\r'
 

