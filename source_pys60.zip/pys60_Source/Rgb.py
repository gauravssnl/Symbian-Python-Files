# Grishberg
# функции для преобразования hls в rgb
# я нашей этот алгоритм в нете, написанный на паскале, вот посидел и переделал под питон.
# пользуйтесь наздоровье!
# Grishberg@rambler.ru

import appuifw
from appuifw import *
from graphics import *
import e32


def max(a1,a2,a3):
 if a2>a3:
  if a2>a1:
   return a2
  else: return a1
 else:
  if a3>a1:
   return a3
  else: return a1

def min(a1,a2,a3):
 if a2<a3:
  if a2<a1:
   return a2
  else: return a1
 else:
  if a3<a1:
   return a3
  else: return a1

def huetorgb(n1,n2,hue):
  if hue < 0: hue = hue+240
  if (hue > 240): hue=hue -240
  if (hue < 40):
#    print ( n1 + (((n2-n1)*hue+20.)/40.) )
    return ( n1 + (((n2-n1)*hue+20.)/40.) )
  else:
    if (hue < (120.)): return float(n2)
    else: 
      if hue < 160: 
        return ( n1 + (((n2-n1)*(160.-hue)+20)/40.))
      else: 
        return  n1

def hlstorgb(h,l,s):
  if (s == 0):
    b=round( (l*255)/240 )
    r=b
    g=b
  else:
    if (l <= 120):
      Magic2 = (l*(240. + s) + 120)/240.
    else: Magic2 = l + s - ((l*s) + (120.))/240
    Magic1 = 2.*l-Magic2
    r = round( (huetorgb(Magic1,Magic2,h+80)*255 + 120.)/240 )
    g = round( (huetorgb(Magic1,Magic2,h)*255 + 120) / 240 )
    b = round( (huetorgb(Magic1,Magic2,h-80)*255 + 120)/240 )
  if r<0: r=0 
  if r>255: r=255
  if g<0: g=0
  if g>255:  g=255
  if b<0: b=0
  if b>255: b=255
  return int(r),int(g),int(b)
