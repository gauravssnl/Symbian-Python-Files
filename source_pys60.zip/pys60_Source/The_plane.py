###############
from gla_2 import *
###############
appinit()
###############
gla_setmain(700)

x=20
yh=60
yl=yh+30
#F
#параметры времени выражаем в переменных t1 t2
t1=gla_ltn(10,40)
t2=gla_ltn(31,100)
#параметры цвета выражаем в переменной с
c=gla_lcn(t1,0x99,0x25,0x25,0x99)+gla_lcn(t2,0x25,0xff,0x99,0xff)
# параметры толщены выражае в переменной w
w=gla_lan(t1,7,3)+gla_lan(t2,3,2)
#задаем координату х1 и у1
x1=gla_lan(t1,100,x)+gla_lan(t2,x,x)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
#задаем координату х2 и у2
x2=gla_lan(t1,87,x+2)+gla_lan(t2,x,x)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
#теперь все переменные выкладываем на линию
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#параметры времени выражаем в переменных t1 t2
t1=gla_ltn(20,50)
t2=gla_ltn(41,100)
#
c=gla_lcn(t1,0x7f,0x25,0x25,0x99)+gla_lcn(t2,0x25,0xff,0x99,0xff)
#
w=gla_lan(t1,7,3)+gla_lan(t2,3,2)
#
x1=gla_lan(t1,90,x+10)+gla_lan(t2,x+15,x+15)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
#
x2=gla_lan(t1,87,x-4)+gla_lan(t2,x-4,x-4)
y2=gla_lan(t1,207,yh+3)+gla_lan(t2,yh+3,yh+3)
#
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#
t1=gla_ltn(0,30)
t2=gla_ltn(51,100)
#
c=gla_lcn(t1,0x7f,0x25,0x25,0x99)+gla_lcn(t2,0x25,0xff,0x99,0xff)
#
w=gla_lan(t1,7,3)+gla_lan(t2,3,2)
#
x1=gla_lan(t1,87,x-3)+gla_lan(t2,x-3,x-3)
y1=gla_lan(t1,0,75)+gla_lan(t2,75,75)
#
x2=gla_lan(t1,87,x+14)+gla_lan(t2,x+14,x+14)
y2=gla_lan(t1,207,75)+gla_lan(t2,75,75)
#
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#fantom forever
t1=gla_ltn(20,60)
t2=gla_ltn(61,100)
gla_text(t1+t2,gla_lan(t1,175,yh-20)+gla_lan(t2,yh-20,yh-20),gla_lan(t1,207,yl+2)+gla_lan(t2,yl+2,yl+2),u'ANTOM-FOREVER',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))

#A
t1=gla_ltn(110,140)
t2=gla_ltn(131,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+10)+gla_lan(t2,x+10,x+10)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+2)+gla_lan(t2,x+2,x+2)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(120,150)
t2=gla_ltn(141,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+10)+gla_lan(t2,x+10,x+10)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+18)+gla_lan(t2,x+18,x+18)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(101,130)
t2=gla_ltn(151,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+6)+gla_lan(t2,x+6,x+6)
y1=gla_lan(t1,0,75)+gla_lan(t2,75,75)
x2=gla_lan(t1,87,x+14)+gla_lan(t2,x+14,x+14)
y2=gla_lan(t1,207,75)+gla_lan(t2,75,75)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#L
t1=gla_ltn(140,170)
t2=gla_ltn(171,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y1=gla_lan(t1,0,yh)+gla_lan(t2,yh,yh)
x2=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

t1=gla_ltn(130,160)
t2=gla_ltn(161,200)
c=gla_lcn(t1,0x7f,0xff)+gla_lcn(t2,0xff,0xff)
w=gla_lan(t1,5,2)+gla_lan(t2,2,2)
x1=gla_lan(t1,87,x+22)+gla_lan(t2,x+22,x+22)
y1=gla_lan(t1,0,yl)+gla_lan(t2,yl,yl)
x2=gla_lan(t1,87,x+38)+gla_lan(t2,x+38,x+38)
y2=gla_lan(t1,207,yl)+gla_lan(t2,yl,yl)
gla_line(t1+t2,x1,y1,x2,y2,c,w)

#BERT927
t1=gla_ltn(140,180)
t2=gla_ltn(181,200)
gla_text(t1+t2,gla_lan(t1,175,yh+2)+gla_lan(t2,yh+2,yh+2),gla_lan(t1,207,yl+2)+gla_lan(t2,yl+2,yl+2),u'BERT 927',gla_lcn(t1,0,0,0x7f,0xff)+gla_lcn(t2,0,0,0xff,0xff))

#представляет 
t1=gla_ltn(201,230)
t2=gla_ltn(231,250)
gla_text(t1+t2,gla_lan(t1,yh+2,yh+2)+gla_lan(t2,yh+2,yh+2),gla_lan(t1,yl+2,yl+2)+gla_lan(t2,yl+2,yl+2),u'\u043f\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043b\u044f\u0435\u0442',gla_lcn(t1,0,0x55,0,0xff)+gla_lcn(t2,0x56,0,0xff,0))

#the plane
t1=gla_ltn(251,280)
t2=gla_ltn(281,300)
gla_text(t1+t2,gla_lan(t1,yh-12,yh-12)+gla_lan(t2,yh-12,yh-12),gla_lan(t1,yl+2,yl+2)+gla_lan(t2,yl+2,yl+2),u'THE PLANE',gla_lcn(t1,0,0xff,)+gla_lcn(t2,0xff,0))

#peizazh
t1=gla_ltn(300,550)
x=0
y=208
#
c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

#1

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-90,y-90)

gla_line(t1,x1,y1,x1,y2,c,w)
#2
t1=gla_ltn(330,580)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x,x+174)
y2=gla_lan(t1,y-80,y-80)

gla_line(t1,x1,y1,x1,y2,c,w)
#3
t1=gla_ltn(360,610)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x,x+174)
y2=gla_lan(t1,y-70,y-70)

gla_line(t1,x1,y1,x1,y2,c,w)
#4
t1=gla_ltn(390,640)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x,x+174)
y2=gla_lan(t1,y-75,y-75)

gla_line(t1,x1,y1,x1,y2,c,w)
#5
t1=gla_ltn(420,670)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x,x+174)
y2=gla_lan(t1,y-85,y-85)

gla_line(t1,x1,y1,x1,y2,c,w)
#6
t1=gla_ltn(450,700)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x,x+174)
y2=gla_lan(t1,y-90,y-90)

gla_line(t1,x1,y1,x1,y2,c,w)
#7
t1=gla_ltn(300,520)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x+30,x+174)
y2=gla_lan(t1,y-85,y-85)

gla_line(t1,x1,y1,x1,y2,c,w)
#8
t1=gla_ltn(300,490)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x+60,x+174)
y2=gla_lan(t1,y-75,y-75)

gla_line(t1,x1,y1,x1,y2,c,w)
#9
t1=gla_ltn(300,460)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x+90,x+174)
y2=gla_lan(t1,y-70,y-70)

gla_line(t1,x1,y1,x1,y2,c,w)
#10
t1=gla_ltn(300,430)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x+120,x+174)
y2=gla_lan(t1,y-65,y-65)

gla_line(t1,x1,y1,x1,y2,c,w)
#11
t1=gla_ltn(300,400)

c=gla_lcn(t1,0x30,0x30,0x95,0x095,0x55,0x55)
#
w=gla_lan(t1,30,30)

y1=gla_lan(t1,y,y)
x1=gla_lan(t1,x+150,x+174)
y2=gla_lan(t1,y-80,y-80)

gla_line(t1,x1,y1,x1,y2,c,w)
#
#

#фон izmena tsveta
t1=gla_ltn(300,350)
t2=gla_ltn(351,380)
t3=gla_ltn(381,400)
t4=gla_ltn(401,530)
gla_fon(t1+t2+t3+t4,gla_lcn(t1,0,0x95,0,0x095,0,0x55)+gla_lcn(t2,0x95,0x95,0x095,0x95,0x55,0xff)+gla_lcn(t3,0x95,0x95,0x095,0x95,0xff,0xff)+gla_lcn(t4,0x95,0x95,0x095,0x95,0xff,0xff))

#2 ryad
t1=gla_ltn(300,425)
x=0
y=208
#
c=gla_lcn(t1,0x20,0x20,0x65,0x065,0x25,0x25)
#
w=gla_lan(t1,50,50)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-60,y-60)

gla_line(t1,x1,y1,x1,y2,c,w)
#2
t1=gla_ltn(330,455)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-50,y-50)

gla_line(t1,x1,y1,x1,y2,c,w)
#3
t1=gla_ltn(360,485)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-55,y-55)

gla_line(t1,x1,y1,x1,y2,c,w)
#4
t1=gla_ltn(390,515)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-45,y-45)

gla_line(t1,x1,y1,x1,y2,c,w)
#5
t1=gla_ltn(420,545)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-60,y-60)

gla_line(t1,x1,y1,x1,y2,c,w)
#6
t1=gla_ltn(425,550)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-60,y-60)

gla_line(t1,x1,y1,x1,y2,c,w)
#7
t1=gla_ltn(450,575)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-50,y-50)

gla_line(t1,x1,y1,x1,y2,c,w)
#8
t1=gla_ltn(475,600)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-55,y-55)

gla_line(t1,x1,y1,x1,y2,c,w)
#9
t1=gla_ltn(500,625)

x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-45,y-45)

gla_line(t1,x1,y1,x1,y2,c,w)

###
#бомба
###1
t1=gla_ltn(387,450)
x=0
y=0
#
c=gla_lcn(t1,0x10,0x10,0x15,0x15,0x15,0x15)
#
w=gla_lan(t1,4,9)

#1
x1=gla_lan(t1,x+154,x+69)
y1=gla_lan(t1,y,y+190)
gla_point(t1,x1,y1,c,w)

#vzryv

t1=gla_ltn(450,480)

c=gla_lcn(t1,0x99,0xff,0x55,0xf5,0x15,0x15)

w=gla_lan(t1,10,140)

x1=gla_lan(t1,x+69,x+72)
y1=gla_lan(t1,y+190,y+190)
gla_point(t1,x1,y1,c,w)

#2

t1=gla_ltn(457,487)

c=gla_lcn(t1,0x99,0xff,0x55,0xf5,0x15,0x15)

w=gla_lan(t1,10,140)

x1=gla_lan(t1,x+74,x+79)
y1=gla_lan(t1,y+190,y+190)
gla_point(t1,x1,y1,c,w)

#4

t1=gla_ltn(464,494)

c=gla_lcn(t1,0x99,0xff,0x55,0xf5,0x15,0x15)

w=gla_lan(t1,10,140)

x1=gla_lan(t1,x+79,x+84)
y1=gla_lan(t1,y+190,y+190)
gla_point(t1,x1,y1,c,w)



#5

t1=gla_ltn(494,524)

c=gla_lcn(t1,0xff,0x99,0xf5,0x55,0x15,0x15)

w=gla_lan(t1,140,0)

x1=gla_lan(t1,x+84,x+99)
y1=gla_lan(t1,y+190,y+190)
gla_point(t1,x1,y1,c,w)

###

#perednij plan
#3
t1=gla_ltn(300,425)
x=0
y=208

c=gla_lcn(t1,0x20,0x20,0x65,0x065,0x25,0x25)

w=gla_lan(t1,50,50)


x1=gla_lan(t1,x+50,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-55,y-55)

gla_line(t1,x1,y1,x1,y2,c,w)
#4
t1=gla_ltn(300,400)

x1=gla_lan(t1,x+100,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-45,y-45)

gla_line(t1,x1,y1,x1,y2,c,w)
#5
t1=gla_ltn(300,375)

x1=gla_lan(t1,x+140,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-60,y-60)

gla_line(t1,x1,y1,x1,y2,c,w)
#6
t1=gla_ltn(300,350)

x1=gla_lan(t1,x+160,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-60,y-60)

gla_line(t1,x1,y1,x1,y2,c,w)

###

###1
t1=gla_ltn(487,550)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-30,y-30)
gla_line(t1,x1,y1,x1,y2,c,w)


###

###2
t1=gla_ltn(412,486)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
#2
y2=gla_lan(t1,y-30,y-30)
gla_line(t1,x1,y1,x1,y2,c,w)

###

###2
t1=gla_ltn(360,411)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
#2
y2=gla_lan(t1,y-30,y-30)
gla_line(t1,x1,y1,x1,y2,c,w)

###

###2
t1=gla_ltn(300,359)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
#2
y2=gla_lan(t1,y-30,y-30)

gla_line(t1,x1,y1,x1,y2,c,w)

###

###1
t1=gla_ltn(487,550)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
y2=gla_lan(t1,y-30,y-30)
gla_line(t1,x1,y1,x1,y2,c,w)


###

###2
t1=gla_ltn(442,516)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
#2
y2=gla_lan(t1,y-30,y-30)
gla_line(t1,x1,y1,x1,y2,c,w)

###

###2
t1=gla_ltn(390,441)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
#2
y2=gla_lan(t1,y-30,y-30)
gla_line(t1,x1,y1,x1,y2,c,w)

###

###2
t1=gla_ltn(330,389)
x=0
y=208
#
c=gla_lcn(t1,0x10,0x10,0x50,0x050,0x15,0x15)
#
w=gla_lan(t1,80,80)

#1
x1=gla_lan(t1,x,x+174)
y1=gla_lan(t1,y,y)
#2
y2=gla_lan(t1,y-30,y-30)

gla_line(t1,x1,y1,x1,y2,c,w)

#titry
#ПРОДОЛЖЕНИЕ СЛЕДУЕТ
t1=gla_ltn(540,580)
t2=gla_ltn(581,620)
gla_text(t1+t2,gla_lan(t1,24,24)+gla_lan(t2,24,24),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'\u041f\u0420\u041e\u0414\u041e\u041b\u0416\u0415\u041d\u0418\u0415 \u0421\u041b\u0415\u0414\u0423\u0415\u0422',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))


#ХУДОЖНИК:
t1=gla_ltn(560,600)
t2=gla_ltn(601,640)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'\u0425\u0423\u0414\u041e\u0416\u041d\u0418\u041a',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))


# FANTOM-FOREVER
t1=gla_ltn(580,620)
t2=gla_ltn(621,660)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'FANTOM-FOREVER',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))



#ПРОГРАММИСТ
t1=gla_ltn(600,640)
t2=gla_ltn(641,680)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'\u041f\u0420\u041e\u0413\u0420\u0410\u041c\u041c\u0418\u0421\u0422',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))



#ALBERT 927
t1=gla_ltn(620,660)
t2=gla_ltn(661,700)
gla_text(t1+t2,gla_lan(t1,30,30)+gla_lan(t2,30,30),gla_lan(t1,1,104)+gla_lan(t2,104,208),u'ALBERT 927',gla_lcn(t1,0x55,0,0,0x99)+gla_lcn(t2,0,0,0x99,0xff))


###############
while appstate():
    gla_drawmaintest()
###############
handle_redraw(())
e32.ao_yield()