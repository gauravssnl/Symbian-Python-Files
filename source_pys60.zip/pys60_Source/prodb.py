import sys
class set:
 def __init__(self,name="settings.txt",save=1,load=1):
  self.__dict__["__file__"],self.__dict__["__flag__"]="\\".join(sys.argv[0].split("\\")[:-1])+"\\"+name,save
  if load:self.load()
 def __setattr__(self,name,value):
  self.__dict__[name]=value
  if self.__flag__:self.save()
 def load(self):
  map(lambda line:self.__dict__.__setitem__(line.split("=")[0],eval(line.split("=")[1])),file(self.__file__,"r").read().splitlines())
 def save(self):
  file(self.__file__,"w").write("\n".join([name+"="+repr(value) for name,value in self.__dict__.items() if name.isupper()]))