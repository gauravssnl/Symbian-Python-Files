
a = ["user%d" % x for x in range(10)]
