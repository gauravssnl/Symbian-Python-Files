import appuifw,TopWindow,e32
def ru(x):return x.decode('utf-8')
screen=TopWindow.TopWindow()
screen.size=(181,208)
screen.position=(-215,-210)
screen.shadow = 105
def sstart():
 screen.show()
 appuifw.app.menu=[(ru('Выключить'),sstop)]
def sstop():
 screen.hide()
 appuifw.app.menu=[(ru('Включить'),sstart)]
appuifw.app.body=t=appuifw.Text()
t.focus=False
t.color=0xff0000
t.set(ru('\n'*8+'    shadow от '))
t.color=255
t.style=(appuifw.STYLE_BOLD|appuifw.STYLE_UNDERLINE|appuifw.STYLE_ITALIC)
t.add(u'dimontyay')
t.style=0
t.add(u'   \n')
i=0
while i<8:
 t.delete(0,1)
 i+=1
 e32.ao_yield()
t.color=0
t.style=0
t.font=u'Alpi12'
f=0
while f<21:
 f+=1
 t.set_pos(26)
 t.add(ru('    Затемнение экрана')[21-f])
 e32.ao_yield()
appuifw.app.menu=[(ru('Включить'),sstart)]

