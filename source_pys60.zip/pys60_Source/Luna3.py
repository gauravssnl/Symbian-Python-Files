# Grishberg
# функции для преобразования rgb в hls
# я нашей этот алгоритм в нете, написанный на паскале, вот посидел и переделал под питон.
# пользуйтесь наздоровье!
# Grishberg@rambler.ru

import appuifw
from appuifw import *
from graphics import *
import e32
#from d3d import *

import math
h2=208/2
w2=176/2

def proj(x,y,z):
  a=125.5
  b=50
  global h2
  global w2
  z=z+b
  xx=x/(z/a+1)+w2
  yy=-(y)/(z/a+1)+h2
  return int(xx),int(yy)

def roty(x,y,z,x0,y0,z0,ang):
  xx=x*math.cos(ang)-z*math.sin(ang)+x0
  zz=x*math.sin(ang)+z*math.cos(ang)+z0
  return xx,y,zz

def rotx(x,y,z,x0,y0,z0,ang):
  yy=y*math.cos(ang)-z*math.sin(ang)+y0
  zz=y*math.sin(ang)+z*math.cos(ang)+z0
  return x,yy,zz

def rotz(x,y,z,x0,y0,z0,ang):
  xx=x*math.cos(ang)-y*math.sin(ang)+x0
  yy=x*math.sin(ang)+y*math.cos(ang)+y0
  return xx,yy,z

r_var=1
def quit():
    global r_var
    r_var=0

appuifw.app.screen='full'
img=Image.new((176,208))
def handle_redraw(rect):
    canvas.blit(img)

r_var=1
canvas=appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)
appuifw.app.body=canvas
app.exit_key_handler=quit
img.clear(0x00000)
a=0
while r_var:
    a=a+0.1
    if a>6.28:
     a=0
    img.clear(0x090535)
    x1,y1,z1=roty(50,50,50,0,0,0,a)
    x2,y2,z2=roty(50,-50,50,0,0,0,a)
    x3,y3,z3=roty(50,50,-50,0,0,0,a)
    x4,y4,z4=roty(50,-50,-50,0,0,0,a)
    x5,y5,z5=roty(-50,50,50,0,0,0,a)
    x6,y6,z6=roty(-50,-50,50,0,0,0,a)
    x7,y7,z7=roty(-50,50,-50,0,0,0,a)
    x8,y8,z8=roty(-50,-50,-50,0,0,0,a)
    a1,b1=proj(x1,y1,z1)
    a2,b2=proj(x2,y2,z2)
    a3,b3=proj(x3,y3,z3)
    a4,b4=proj(x4,y4,z4)
    a5,b5=proj(x5,y5,z5)
    a6,b6=proj(x6,y6,z6)
    a7,b7=proj(x7,y7,z7)
    a8,b8=proj(x8,y8,z8)
    img.line((100,140,100,206),(50,150,6),width=7)
    img.line((100,165,100,206),(50,130,6),width=7)
    img.line((100,170,100,206),(50,120,6),width=7)
    img.line((100,175,100,206),(50,110,6),width=7)
    img.line((100,180,100,206),(50,100,6),width=7)
    img.line((100,185,100,206),(50,90,6),width=7)
    img.line((100,190,100,206),(50,80,6),width=7)
    img.line((100,195,100,206),(50,70,6),width=7)
    img.line((100,200,100,206),(50,60,6),width=7)
    img.point((100,140,),(250,250,6),width=35)
    img.point((100,140,),(250,250,60),width=25)
    img.point((100,140,),(250,250,80),width=22)
    img.point((100,140,),(250,250,100),width=19)
    img.point((100,140,),(250,250,120),width=15)
    img.point((100,140,),(250,250,160),width=10)
    img.point((100,140,),(250,250,206),width=7)
    img.point((25,40,),(200,200,240),width=45)
    img.point((32,40,),0x090535,width=33)
    img.point((a4+10,a8+40),(250,250,6),width=5)
    img.point((a7+20,a7+50),(250,a2,6),width=5)
    img.point((a1+20,a6+60),(250,a3,6),width=5)
    img.point((a2+20,a6+50),(250,a4,6),width=5)
    img.point((b7+10,a6+40),(250,a5,6),width=5)
    img.point((b4+10,a8+40),(250,a6,6),width=5)
    img.point((b7+20,a7+50),(250,a7,6),width=5)
    img.point((b1+20,a6+60),(250,a8,6),width=5)
    img.point((b2+20,a6+50),(250,b1,6),width=5)
    img.point((b7+10,a6+40),(250,b2,6),width=5)
    img.point((b3,b4,),(250,b3,6),width=4)
    img.point((a4+10,b8+40),(250,250,6),width=5)
    img.point((a7+20,b7+50),(250,250,6),width=5)
    img.point((a1+20,b6+60),(250,250,6),width=5)
    img.point((a2+20,b6+50),(250,250,6),width=5)
    img.point((b7+10,b6+40),(250,250,6),width=5)
    img.point((b4+10,b8+40),(250,250,6),width=5)
    img.point((b7+20,b7+50),(250,250,6),width=5)
    img.point((b1+20,b6+60),(250,250,6),width=5)
    img.point((b2+20,b6+50),(250,250,6),width=5)
    img.point((b7+10,b6+40),(250,250,6),width=5)
    img.text((b4-10,b4-10),u'FANTOM',(166,166,66))
    handle_redraw(())
    e32.ao_yield()
 