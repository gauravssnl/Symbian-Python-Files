#
# pdis.lib.hex_id
#
# Copyright 2003-2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

'''
Probabilistically unique identifiers
'''

def _get_random_bytes(n):
    """
    Return a string of random bytes.

    This function raises IOError if /dev/random is not available.
    """
    f = file("/dev/random", "r")
    try:
        return f.read(n)
    finally:
        f.close()

def _get_good_seed():
    """
    Return a random 256-bit long integer.

    This function raises IOError if /dev/random is not available.
    """
    result = 0
    for c in _get_random_bytes(32):
        result = 256 * result + ord(c)
    return result

try:
    import random
except ImportError:
    import whrandom
    _choice = whrandom.choice
else:
    try:
        _choice = random.Random(_get_good_seed()).choice
    except IOError:
        _choice = random.choice

_hex = "0123456789abcdef"
_hexpairs = [x + y for x in _hex for y in _hex]

def create_id(length = 16):
    '''Create a random string of hex digits.'''
    # Generating two digits at a time is almost twice as fast.
    n = int((length + 1) / 2)
    s = "".join([_choice(_hexpairs) for i in range(n)])
    return s[:length]
