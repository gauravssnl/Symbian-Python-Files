#
# pdis.lib.element
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

'''
Facade for the ElementTree module

This module provides a customized interface to the ElementTree module.
It exports the following standard functions and classes:

 * Element()
 * SubElement()
 * iselement()
 * TreeBuilder
 * XML() - tweaked to accept unicode strings.
 * tostring() - default encoding changed to UTF-8.

It also introduces the following additional functions:

 * equal() - structural equality.

 * copyelement() - shallow copy.

 * addsubelement() - alternative to SubElement().  This is more
   convenient for adding child elements with textual content.

 * toprettystring() - like tostring() but with extra newlines
   and indentation.
'''

from copy import deepcopy

from elementtree import ElementTree as _ET0

try:
    import cElementTree as _ET
except ImportError:
    _ET = _ET0

Element = _ET.Element
SubElement = _ET.SubElement
iselement = _ET.iselement
TreeBuilder = _ET.TreeBuilder

def augment_namespace_map(prefix, uri):
    _ET0._namespace_map[uri] = prefix

def XML(text):
    """
    Create a tree representation (an Element) for some textual XML.

    The argument can be either an octet string (probably UTF-8 encoded)
    or a unicode string.
    """
    if isinstance(text, unicode):
        text = text.encode("utf-8")
    return _ET.XML(text)

def tostring(element, encoding = "utf-8"):
    """
    Return the textual representation of the element.

    The encoding defaults to UTF-8, in contrast to the prevailing
    US-ASCII default in the ElementTree module.
    """
    return _ET.tostring(element, encoding)

def toprettystring(element, encoding="utf-8"):
    """
    Return a nicely formatted textual representation of the element.

    The encoding defaults to UTF-8, in contrast to the prevailing
    US-ASCII default in the ElementTree module.
    """
    def prettify(node, indent, increment):
        if len(node) > 0:
            child_indent = indent + increment
            if node.text is None:
                node.text = '\n' + child_indent * ' '
            for child in node:
                prettify(child, child_indent, increment)
                if child.tail is None:
                    child.tail = '\n' + child_indent * ' '
            node[-1].tail = '\n' + indent * ' ' # Tweak last child.

    scratch = deepcopy(element)
    prettify(scratch, 0, 2)
    return tostring(scratch, encoding)

def addsubelement(parent, tag, text=None, **attrib):
    """
    Create an element instance and append it to an existing element.

    Returns the new subelement.

    This differs from SubElement() in that the optional third argument
    is the text content rather than an attribute dictionary.
    """
    assert text is None or isinstance(text, (str, unicode))
    child = parent.makeelement(tag, attrib)
    child.text = text
    parent.append(child)
    return child

def copyelement(element):
    """
    Copy the top-level node and its attribute dictionary.
    """
    result = element.makeelement(element.tag, element.attrib)
    result.text = element.text
    result.tail = element.tail
    result[:] = element[:]
    return result

def equal(x, y):
    """
    Structural equality predicate for element trees.
    """
    if not iselement(x) or not iselement(y):
        return x == y
    if x.tag != y.tag or x.text != y.text or x.tail != y.tail \
           or x.attrib != y.attrib or len(x) != len(y):
        return False
    for i in range(len(x)):
        if not equal(x[i], y[i]):
            return False
    return True
