#
# pdis.lib.PQueue
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

'''
Queue with two priority levels
'''

from Queue import Queue, Empty, Full

class PQueue(Queue):
    def _init(self, maxsize):
        self.maxsize = maxsize
        self.queue1 = []
        self.queue2 = []

    def put(self, item, *args, **keys):
        # urgent = keys.pop("urgent", False)
        urgent = False
        if "urgent" in keys:
            urgent = keys["urgent"]
            del keys["urgent"]

        Queue.put(self, (item, urgent), *args, **keys)

    def put_nowait(self, item, urgent=False):
        return self.put(item, block=False, urgent=urgent)

    def _qsize(self):
        return len(self.queue1) + len(self.queue2)

    def _empty(self):
        return not (self.queue1 or self.queue2)

    def _full(self):
        return self.maxsize > 0 and self._qsize() == self.maxsize

    def _put(self, (item, urgent)):
        if urgent:
            self.queue1.append(item)
        else:
            self.queue2.append(item)

    def _get(self):
        if self.queue1:
            return self.queue1.pop(0)
        else:
            return self.queue2.pop(0)
