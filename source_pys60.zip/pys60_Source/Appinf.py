from appuifw import *
import powlite_fm as fm
import struct
import os

def doOut4(caption):
 x=caption+"="+hex(struct.unpack('l',d.read(4))[0])
 print x
 l.write(x+'\n')
def doOut4s(caption):
 x=caption+"="+hex(struct.unpack("<i",d.read(4))[0])
 print x
 l.write(x+'\n')

def doOut(caption,value):
 x=caption+"="+hex(struct.unpack("<l",value)[0])
 print x
 l.write(x+'\n')

m=fm.manager()
path=m.AskUser()
#path='c:/python.app'
d=open(path,'r')
l=open('c:\\'+os.path.split(path)[1]+'.log','w')
l.write("the header of file: "+path+'\n')
for i in range(1,4):doOut4("uid"+str(i))
doOut4('uid_crc')
doOut4('signature(always="EPOC")')
doOut4('Cpu')
doOut4('CheckSumCode')
doOut4('CheckSumData')
print 'version=100'
l.write('version=100'+'\n')
d.read(2)#version major
d.read(2)#version minor
o=d.read(8)
o='time='+hex(struct.unpack("Q",o)[0])
print o
l.write(o+'\n')
doOut4('Flags')
doOut4s('CodeSize')
doOut4s('DataSize')
doOut4s('HeapSizeMin')
doOut4s('HeapSizeMax')
doOut4s('StackSize')
doOut4s('BssSize')
doOut4('EntryPoint')
doOut4('CodeBase')
doOut4s('DllRefTableCount')
doOut4('ExportDirOffset')
doOut4s('ExportDirCount')
doOut4s('TextSize')
doOut4('CodeOffset')
doOut4('DataOffset')
doOut4('ImportOffset')
doOut4('CodeRelocOffset')
doOut4('DataRelocOffset')
doOut4('Unknown')
doOut4('ProccesPriority')
l.close()
d.close()