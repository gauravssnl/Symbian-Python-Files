#SYMBIAN_UID=0x03747304
#by Albert927  
#
import os,time,zipfile
def scd(d):
 global il
 f,r=fn(),[]
 scg(d+':\\',r)
 scs(f+'_'+d+'_all',r)
 ok()
 sml(4)
def scd2():
 global il
 f,r=fn(),[]
 scg('C:\\',r)
 scg('E:\\',r)
 scs(f+'_all',r)
 ok()
 sml(4)
def scc():
 global il
 if sil():return
 if il[2][-8:-4]!='_all': return an(u'\u041d\u0443\u0436\u0435\u043d *_all')
 f,r1,r2,d=fn(),scl(il[2]),[],il[2][-9]
 if d=='C' or d=='E':
  scg(d+':\\',r2)
  d='_'+d
 else:
  d=''
  scg('C:\\',r2)
  scg('E:\\',r2)
 rd,rn=[],[]
 for i in r1:
  if i not in r2:rd.append(i)
 for i in r2:
  if i not in r1:
   rn.append(i)
 scs(f+d+'_del',scf(rd))
 scs(f+d+'_new',scf(rn))
 ok()
 sml(4)
def sci():
 global il
 if sil():return
 f=open(il[2])
 an(u'\u0424\u0430\u0439\u043b\u043e\u0432: '+unicode(str(len(f.read().split('\r\n'))-1)))
 f.close()
def scg(d,r):
 r.append(d)
 if os.path.isdir(d):
  for i in os.listdir(d):scg(d+'\\'+i,r)
def scs(f,r):
 global il
 f=open(il[0]+f+il[1],'w')
 for i in r:f.write(i+'\r\n')
 f.close()
def scl(d):
 s=open(il[2])
 r=s.read().split('\r\n')[:-1]
 s.close()
 return r
def fn():return at(u'\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0438\u043c\u044f \u0444\u0430\u0439\u043b\u0430',unicode(time.strftime('%m%d%H%M%S')))
def scsr():
 global il
 if sil():return
 if il[2][-8:-4]!='_new': return an(u'\u041d\u0443\u0436\u0435\u043d *_new')
 f,r,ud,zd=il[2].split('\\')[-1][:-3],scl(il[2]),'E:\\\\system\\uninstall\\','E:\\zipman\\'
 if not os.path.isdir(ud):os.mkdir(ud)
 if not os.path.isdir(zd):os.mkdir(zd)
 s=open(ud+f+'sr','w')
 s.write('i=Delete '+f+'zip\r\n')
 for i in r:s.write('d='+i+'\r\n')
 s.close()
 r.append(ud+f+'sr')
 z=zipfile.ZipFile(zd+f+'zip','w',zipfile.ZIP_DEFLATED)
 for i in r:
  try:z.write(i,i[4:])
  except:pass
 z.close()
 ok()
def scf(r):
 i,n=0,[]
 for i in r:
  if i.find('system\\scaner')==-1:n.append(i)
 return n
#
import gla3
def glar():
 global il
 if sil():return
 cs(1)
 gla3.draw(gla3.load(il[2][:-4]))
 as('normal')
 cl()
def glai():
 global il
 if sil():return
 an(unicode(gla3.load(il[2][:-4]).i))
#
def srl(p):
 f,i,t=open(p),u'\u0418\u043d\u0444\u044b \u043d\u0435\u0442',[]
 for j in f.read().splitlines():
  n,a=j.split('=')
  if a[0]=='!':a=p[0]+a[1:]
  if n=='d':t.append(a)
  if n=='i':i=a
 f.close()
 return i,t
def srr():
 global il
 if sil():return
 i,t=srl(il[2])
 for j in t:dp(j)
 adm(il[2])
def sri():
 global il
 if sil():return
 i,t=srl(il[2])
 f=open(il[2])
 an(unicode(i+'.\n'+u'\u041e\u0431\u044c\u0435\u043a\u0442\u043e\u0432 \u0434\u043b\u044f \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u044f: '+str(len(f.read().split('\r\n'))-1)))
 f.close()
#
import appuifw
def an(a,i='info'):appuifw.note(a,i)
def aq(a):return appuifw.query(a,'query')
def at(a,i=''):return str(appuifw.query(a,'text',i))
def as(a):appuifw.app.screen=a
def ok():an(u'\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u043e')
def er():an(u'\u041e\u0448\u0438\u0431\u043a\u0430','error')

def ad(f):
 global il
 if sil():return
 adm(il[f])
def ar(f=1):
 global il
 if sil():return
 if f:f=il[2]
 f=open(f)
 cs(1)
 appuifw.app.body.color=(0,0,0)
 appuifw.app.body.set(unicode(f.read()))
 appuifw.app.body.set_pos(0)
 appuifw.app.body.focus=False
 f.close()

def adm(f):
 if dp(f):return er()
 ok()
 sfl()
def sil():
 global il,fl
 if appuifw.app.body.current()==0:return 1
 il[2]=il[0]+fl[appuifw.app.body.current()]+il[1]
 return not aq(u'\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c?')
def sfl():
 global il,fl
 fl=[il[0]]
 if not os.path.isdir(il[0]):os.mkdir(il[0])
 for i in os.listdir(il[0]):
  if i.lower().endswith(il[1]):fl.append(i[:-len(il[1])])
 appuifw.app.body=appuifw.Listbox(map(unicode,fl),nf)
 appuifw.app.body.bind(8,lambda:ad(2))
#
def nf():pass
def cs(n):
 global i,c
 c.append(i)
 sml(n)
def cl():
 global c
 sml(c.pop())
import uikludges
def sml(n):
 global i,ml,el,il
 i,appuifw.app.menu,appuifw.app.exit_key_handler=n,ml[n],ml[n][-1][1]
 uikludges.set_right_softkey_text(ml[n][-1][0])
 if n>=2:il=el[n-2]
 if n==0:appuifw.app.body=appuifw.Canvas()
 elif n==1:appuifw.app.body=appuifw.Text()
 else:sfl()
def dp(p):
 if os.path.isfile(p):
  try:os.remove(p)
  except:return 1
 if os.path.isdir(p):
  for i in os.listdir(p):dp(p+'\\'+i)
  try:os.rmdir(p)
  except:return 1
#
import e32
al=e32.Ao_lock()
def exit():
 al.signal()
 appuifw.app.set_exit()

c=[]
i=il=fl=0
mli=u'\u0421\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0438\u043d\u0444\u0443'
mlo=[(u'\u041f\u0440\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u0442\u044c',ar),(u'\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0444\u0430\u0439\u043b',lambda:ad(2)),(u'\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0441\u0435 \u0444\u0430\u0439\u043b\u044b',lambda:ad(0)),(u'\u041d\u0430\u0437\u0430\u0434',cl)]
ml= [[(u'\u0421\u043a\u0430\u043d\u0435\u0440 \u0434\u0438\u0441\u043a\u043e\u0432',lambda:cs(4)),(u'SR \u0430\u0440\u0445\u0438\u0432\u044b',lambda:cs(2)),(u'GLA \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u0438',lambda:cs(3)),(u'\u0412\u044b\u0439\u0442\u0438',exit)]]
ml+=[[(mlo[-1])]]
ml+=[[(u'\u0423\u0434\u0430\u043b\u0438\u0442\u044c sr \u0430\u0440\u0445\u0438\u0432',srr),(mli,sri)]+mlo]
ml+=[[(u'\u0412\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0441\u0442\u0438',glar),(mli,glai)]+mlo]
ml+=[[(u'\u0421\u043a\u0430\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0434\u0438\u0441\u043a',((u'C: \u0438 E:',scd2),(u'C:',lambda:scd('C')),(u'E:',lambda:scd('E')))),(u'\u041f\u043e\u0432\u0442\u043e\u0440\u043d\u043e\u0435 \u0441\u043a\u0430\u043d-\u0438\u0435',scc),(u'\u0421\u043e\u0437\u0434\u0430\u0442\u044c sr.zip',scsr),(mli,sci)]+mlo]
el= [['e:\\system\\uninstall\\','.sr','']]
el+=[['e:\\system\\animations\\','.gla','']]
el+=[['e:\\system\\scaner\\','.txt','']]

sml(0)
al.wait()