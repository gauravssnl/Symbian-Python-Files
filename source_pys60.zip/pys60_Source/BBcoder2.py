###########################
# Автор: AHgpyxA
# 02.08.2007
###########################
version = '2.15'
standaloneapp = True

import appuifw as ui
from graphics import Image
import e32
import os
import sys

import keycapture
import clipboard as cb
import uitricks
from key_tricks import EAknSoftkeyExit,EAknSoftkeyOptions

def ru(x): return x.decode('utf-8')
def ur(x): return x.encode('utf-8')
def anote(mess,style='info'):
  ui.note(mess,style)
def printline(mess,clear=False,col=0x0,newline=False):
  if newline: mess=mess+'\n'
  ui.app.body.color=col
  if clear: ui.app.body.set((mess))
  else: ui.app.body.add((mess))

app_path=ru(os.path.split(sys.argv[0])[0]+"\\")
app_path=app_path.lower()
if (app_path.find('tower')>-1) or (app_path.find('python\\')>-1):
  standaloneapp=False
############################
#########  SettingS ##########
settings={
'Color_Tags':1,
'Color_Tag1':u'0000FF',
'Color_Tag2':u'FF0000'
}
#--------------------------------
def settings_view():
  global settings
  data=[
(ru('цветные теги'),'combo',([ru('нет'),ru('да')],settings['Color_Tags'])),
(ru('цвет откр. тега'),'text',(settings['Color_Tag1'])),
(ru('цвет закр. тега'),'text',(settings['Color_Tag2']))
]
  flags = ui.FFormEditModeOnly+ui.FFormDoubleSpaced
  f = ui.Form(data, flags)
  f.save_hook=settings_edit
  f.execute()
#--------------------------------
def settings_edit(x):
  settings['Color_Tags']=int(x[0][2][1])
  try:
    int(x[1][2],16)
    settings['Color_Tag1']=unicode(x[1][2])
    int(x[1][2],16)
    settings['Color_Tag2']=unicode(x[2][2])
  except:
    anote(ru('Недопустимые символы в цвете!'),'error')
    return False
  settings_save()
  anote(ru('Чтобы изменения вступили в силу - сделайте "просмотр"'),'conf')
#--------------------------------
def settings_save():
  global settings
  f=open(app_path+'options.dat','wt')
  f.write(repr(settings))
  f.close()
#--------------------------------
def settings_load():
  global settings
  if os.path.exists(app_path+'options.dat'):
    f=open(app_path+'options.dat','rt')
    settings=eval(f.read())
    f.close()
#########  SettingS ##########
############################

_key_pen = 0

def _keys(key):
  global _key_pen
  if key==63499:
    _key_pen += 1
  else:
    # не изменять, так надо!!!
    if key==63586:
      ui.app.body.add(u'\n')
    elif key==EAknSoftkeyOptions:
      _key_pen=0
    elif key==EAknSoftkeyExit:
      _key_pen=0
    elif key==8 and _key_pen>=2:
      #clear_scr()
      pass
    # не изменять, так надо!!!
    _key_pen=0

############################
###########  SmileS ##########
n_smile=1
old_t=''
old_p=0
old_m=[]
old_e=None
smiles_canvas=None
smiles_path=app_path
smiles_img=Image.open(smiles_path+'smiles.gif')
smiles={
 1:u':smile:',
 2:u':wink:',
 3:u':sad:',
 4:u':angry:',
 5:u':wassat:',
 6:u':crying:',
 7:u':laughing:',
 8:u':tongue:',
}
#--------------------------------
def smiles_select():
  global smiles_canvas
  global old_t,old_p,old_m,old_e
  old_t=ui.app.body.get()
  old_p=ui.app.body.get_pos()
  uitricks.set_text(ru('Назад'),EAknSoftkeyExit) 
  old_e=ui.app.exit_key_handler
  ui.app.exit_key_handler=lambda:smiles_exit(0)
  old_m=ui.app.menu
  ui.app.menu=[(ru('выбор'),lambda:smiles_exit(1)),(ru('назад'),lambda:smiles_exit(0))]
  smiles_canvas=ui.Canvas(smiles_draw,smiles_keys)
  ui.app.body=smiles_canvas
  smiles_draw(u'')
#--------------------------------
def smiles_exit(x):
  global old_t,old_p,old_m,old_e
  ui.app.body=ui.Text()
  printline('',True)
  highlight_tags(settings['Color_Tags'],(settings['Color_Tag1']),(settings['Color_Tag2']))
  ui.app.body.set_pos(old_p)
  ui.app.menu=old_m
  ui.app.exit_key_handler=old_e
  uitricks.set_text(ru('Выход'),EAknSoftkeyExit) 
  if x>0:
    global n_smile  
    printline(smiles[n_smile])
#--------------------------------
def smiles_draw(x):
  global smiles_canvas,n_smiles
  smiles_canvas.clear(0xFFFFFF)
  smiles_canvas.blit(smiles_img,(0,-30))
  smiles_canvas.text((5,20),ru('Выберите смайлик'),0x0)
  smiles_canvas.rectangle(((n_smile-1)*19,55,n_smile*19,60),0x0,0x00ff00)
  #smiles_canvas.rectangle(((n_smile-1)*18,30,n_smile*18,60),0x0)
#--------------------------------
def smiles_keys(key):
  global smiles_canvas
  global current_smile,n_smile
  if key['keycode']==63495:
    if n_smile>1: n_smile-=1
  elif key['keycode']==63496:
    if n_smile<8: n_smile+=1
  elif key['keycode']==63557:
    smiles_exit(1)
  smiles_draw(u'')
###########  SmileS ##########
############################

def highlight_tags(mode=False,col1=0x0000BB,col2=0x990000):
  global old_t

  if not mode:
    printline(old_t,True,0x0)
    return
  try: col1=int(col1,16)
  except: col1=0x0000BB
  try: col2=int(col2,16)
  except: col2=0x990000
  all_tags={}
  tags = 'B','I','U','S',  'LEFT','CENTER','RIGHT',  'COLOR','HIDE','URL','IMG','CODE','QUOTE'
  t = old_t.split(u'[')
  for i in range(len(t)):
    if i==0:
      printline(t[i],True,0x0)
      continue
    x=t[i].split(u']')
    if len(x)>1:
      tag1=x[0].upper()
      tag2=tag1.split(u'/')
      try:tag2=tag2[1]
      except:tag2=tag2[0]
      tag1=tag1.split(u'=')
      tag1=tag1[0]
      if (tag1 in tags):
        printline('[%s]'%x[0],False,col1)
        for k in range(len(x)-1):
          printline(x[k+1],False,0x0)
      elif (tag2 in tags):
        printline('[%s]'%x[0],False,col2)
        for k in range(len(x)-1):
          printline(x[k+1],False,0x0)
      else:
        printline('[%s]'%x[0],False,0x0)
        for k in range(len(x)-1):
          printline(x[k+1],False,0x0)

def preview():
  ##preview
  capturer.stop()
  ui.app.exit_key_handler=GoBack
  uitricks.set_text(ru('Назад'),EAknSoftkeyExit) 
  try: ui.app.body.focus=False
  except: pass
  ui.app.menu=[(ru('назад'),GoBack)]

  global old_t,old_p
  old_t=t=ui.app.body.get()
  old_p=ui.app.body.get_pos()
  printline(u'',1,0x0,0)

  bgstyle = 0
  bg_old = 0
  hidden = 0

  t = t.split(u'[')
  for i in range(len(t)):
    x=t[i].split(u']')
    if i==0:
      style=0
      clr=0x0
      ui.app.body.style=style
      printline(x[0])
    else:
      tag = (x[0])
      try:
        text=x[1]
        for i in range(len(x)-2):
          text=text+']'+x[i+2]
      except:
        text = ru('')
      if tag.upper()=='B':
        if _and(dec2bin(style),dec2bin(1))==dec2bin(0):
          style=style+1
      elif tag.upper()=='/B':
        if _and(dec2bin(style),dec2bin(1))==dec2bin(1):
          style=style-1
      elif tag.upper()=='U':
        if _and(dec2bin(style),dec2bin(2))==dec2bin(0):
          style=style+2
      elif tag.upper()=='/U':
        if _and(dec2bin(style),dec2bin(2))==dec2bin(2):
          style=style-2
      elif tag.upper()=='I':
        if _and(dec2bin(style),dec2bin(4))==dec2bin(0):
          style=style+4
      elif tag.upper()=='/I':
        if _and(dec2bin(style),dec2bin(4))==dec2bin(4):
          style=style-4
      elif tag.upper()=='S':
        if _and(dec2bin(style),dec2bin(8))==dec2bin(0):
          style=style+8
      elif tag.upper()=='/S':
        if _and(dec2bin(style),dec2bin(8))==dec2bin(8):
          style=style-8
      elif tag.upper()=='HIDE':
        #bg_old=bgstyle
        #bgstyle=ui.HIGHLIGHT_SHADOW
        text=ru(':скрытый текст:')
        hidden=1
      elif tag.upper()=='/HIDE':
        #bgstyle=bg_old
        hidden=0
        pass
      elif tag.upper().find('QUOTE') != -1:
        if tag.upper()=='/QUOTE':
          if bgstyle==ui.HIGHLIGHT_STANDARD:
            bgstyle=0
        else:
          q=tag.split('=')
          try:
            q=q[1]
            text=q+ru(' сказал:\n')+text
          except: pass
          if bgstyle==0:
            bgstyle=ui.HIGHLIGHT_STANDARD
      elif tag.upper()=='CODE':
        #if bgstyle==0:
          #bgstyle=ui.HIGHLIGHT_ROUNDED
        pass
      elif tag.upper()=='/CODE':
        pass
        #if bgstyle==ui.HIGHLIGHT_ROUNDED:
          #bgstyle=0
      elif tag.upper().find('COLOR') != -1:
        if tag.upper()=='/COLOR':
          clr=0x0
        else:
          try:
            clr=tag.split('=')
            clr=tag.split('#')
            clr=int('0x'+clr[1],16)
          except:
            clr=0xfeed00
            anote(ru('Похоже, где-то указан неверный цвет'),'error')
            anote(ru('Это место при просмотре выделено желтым'),'error')
      elif tag.upper()=='IMG':
        clr=0xff0000
        text=ru(':IMG:')
      elif tag.upper()=='/IMG':
        clr=0x0
      elif tag.upper().find('URL') != -1:
        if tag.upper()=='/URL':
          clr=0x0
          if _and(dec2bin(style),dec2bin(2))==dec2bin(2):
            if u2 == 1: style=style-2
        else:
          if _and(dec2bin(style),dec2bin(2))==dec2bin(0):
            style=style+2
            u2 = 1
          else:
            u2 = 0
          clr=0xff
      elif tag=='':
        text='[]'+text

      elif len(x)<2:
      #elif text=='':
        text='['+tag
      else:
        text='['+tag+']'+text

      ui.app.body.style=style+bgstyle
      if hidden==0:
        printline((text),0,clr)
  ui.app.body.set_pos(0)
  
############################
######## Close Tags ##########
def close_tags():
  global old_t,old_p,old_m,old_e
  old_t=ui.app.body.get()
  old_p=ui.app.body.get_pos()
  uitricks.set_text(ru('Назад'),EAknSoftkeyExit) 
  old_e=ui.app.exit_key_handler
  ui.app.exit_key_handler=close_exit
  old_m=ui.app.menu
  ui.app.menu=[(ru('закр. незакрытые'),lambda:close_view(1)),(ru('назад'),close_exit)]
  close_view(0)
#--------------------------------
def close_view(mode=0):
  global old_t
  t = old_t
  highlight_tags(settings['Color_Tags'],(settings['Color_Tag1']),(settings['Color_Tag2']))
  all_tags={}
  tags = 'B','I','U','S',  'LEFT','CENTER','RIGHT',  'COLOR','HIDE','URL','IMG','CODE','QUOTE'
  t = t.split(u'[')
  for i in range(len(t)):
    if i==0: continue
    x=t[i].split(u']')
    if len(x)>1:
      tag1=x[0].upper()
      tag2=tag1.split(u'/')
      try:tag2=tag2[1]
      except:tag2=tag2[0]
      tag1=tag1.split(u'=')
      tag1=tag1[0]
      if (tag1 in tags):
        #anote(tag1)
        try: all_tags[tag1] += 1
        except: all_tags[tag1] = 1
      elif (tag2 in tags):
        #anote(tag2,'error')
        try: all_tags[tag2] -= 1
        except: all_tags[tag2] = -1
  if mode==0:
    _open=_closed=''
    for i in all_tags:
      if all_tags[i]==0: continue
      elif all_tags[i]>0:
        _open += '%s\t\t | %i\t\n'%(i,all_tags[i])
      elif all_tags[i]<0:
        _closed += '%s\t\t | %i\t\n'%(i,-all_tags[i])
    ui.app.body.set_pos(len(old_t))
    if _open != '':
      printline(ru('\nнезакрытые: \n тег\t\t | кол-во'),False,0x990000,True)
      printline('%s'%_open,False,0xff0000,False)
    if _closed != '':
      printline(ru('\nнеоткрытые: \n тег\t\t | кол-во'),False,0x990000,True)
      printline('%s'%_closed,False,0xff0000,False)
    if _open+_closed=='':
      printline(ru('\nПохоже, что все теги в порядке :)'),False,0x99,True)
    try: ui.app.body.focus=False
    except: pass
  else:
    #закрыть все незакрытые
    for i in all_tags:
      if all_tags[i]==0: continue
      elif all_tags[i]>0:
        for j in range(all_tags[i]):
          old_t += '[/%s]'%i
    printline(ru('\nПохоже, что все теги в порядке :)'),False,0x99,True)
    ui.app.menu=[(ru('назад'),close_exit)]
    close_view(0)
#--------------------------------
def close_exit():
  global old_t,old_p,old_m,old_e
  ui.app.body=ui.Text()
  printline(u'',True)
  highlight_tags(settings['Color_Tags'],(settings['Color_Tag1']),(settings['Color_Tag2']))
  ui.app.body.set_pos(old_p)
  ui.app.menu=old_m
  ui.app.exit_key_handler=old_e
  uitricks.set_text(ru('Выход'),EAknSoftkeyExit) 
######## Close Tags ##########
############################

def clear_scr():
  if ui.query(ru('Удалить весь текст?'),'query')==1:
    ui.app.body.clear()

def copy():
  text = ui.app.body.get()
  if cb.Set(text):
    anote(ru('Скопировано в буфер обмена'),'conf')
    return True
  else:
    anote(ru('Не удалось!'),'error')
    anote(ru('Придется вручную :)'),'error')
    return False

def popup_menu():
  global menu2
  result = ui.popup_menu(menu2,u'select')
  ui.note(unicode(result))
  
def set_menu():
  pass
  ui.app.menu = [
    (ru('просмотр'),preview),
    (ru('действия'),
      (
      (ru('просмотр'),preview),
      (ru('скопир. в буфер'),copy),
      (ru('очистить экран'),clear_scr),
      (ru('незакрытые теги'),close_tags)
      )
    ),
    (ru('текст'),
      (
      (ru('жирный'),ins_bold),
      (ru('курсив'),ins_italic),
      (ru('подчеркнутый'),ins_underline),
      (ru('зачеркнутый'),ins_strike),
      (ru('цветной'),ins_color)
      )
    ),
    (ru('выравнивание'),
      (
      (ru('влево'),ins_left),
      (ru('по центру'),ins_center),
      (ru('вправо'),ins_right)
      )
    ),
    (ru('объекты'),
      (
      (ru('ссылка'),ins_url),
      (ru('ссылка на польз.'),ins_user),
      (ru('смайлик'),ins_smile),
      (ru('рисунок'),ins_image),
      (ru('цитата'),ins_quote),
      (ru('код'),ins_code),
      (ru('скрытый текст'),ins_hide)
      )
    ),
    (ru('настройки'),settings_view),
    (ru('инфо'),
      (
      (ru('о проге...'),about),
      (ru('помощь'),help)
      )
    ),
    (ru('выход'),Exit)
  ]  

def Exit():
  settings_save()
  if ui.query(ru('Выход?'),'query')==None:
    return
  if ui.query(ru('Скопировать в буфер?'),'query')!=None:
    if not copy():
      return False
  global capturer,old_tit,old_scr
  ui.app.title,ui.app.screen=old_tit,old_scr
  capturer.keys=[]
  capturer.stop()
  ui.app.exit_key_handler = None
  global script_lock
  script_lock.signal()
  if standaloneapp:
    ui.app.set_exit()
def GoBack():
  capturer.start()
  global old_t,old_p
  uitricks.set_text(ru('Выход'),EAknSoftkeyExit) 
  ui.app.exit_key_handler = Exit
  ui.app.body.style=0
  printline('',True)
  highlight_tags(settings['Color_Tags'],(settings['Color_Tag1']),(settings['Color_Tag2']))
  ui.app.body.set_pos(old_p)
  ui.app.body.focus=True
  set_menu()
def switch(fg):
  global capturer
  if fg: capturer.start()
  else: capturer.stop()

############################
####### Insert Tags ##########
def ins_quote():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  menu3.insert(0,ru('два тега с ником'))
  menu3.insert(2,ru('нач. тег с ником'))
  res=ui.popup_menu(menu3,ru('Цитата'))
  if res==0:
    nick = ui.query(ru('Ник'),'text')
    if nick==None: return False
    ui.app.body.add(u'[QUOTE="%s"][/QUOTE]'%nick)
    ui.app.body.set_pos(ui.app.body.get_pos()-8)
  elif res==1:
    ui.app.body.add(u'[QUOTE][/QUOTE]')
    ui.app.body.set_pos(ui.app.body.get_pos()-8)
  if res==2:
    nick = ui.query(ru('Ник'),'text')
    if nick==None: return False
    ui.app.body.add(u'[QUOTE="%s"]'%nick)
  if res==3:
    ui.app.body.add(u'[QUOTE]')
  if res==4:
    ui.app.body.add(u'[/QUOTE]')
#--------------------------------
def ins_code():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Код'))
  if res==0:
    ui.app.body.add(u'[CODE][/CODE]')
    ui.app.body.set_pos(ui.app.body.get_pos()-7)
  elif res==1:
    ui.app.body.add(u'[CODE]')
  if res==2:
    ui.app.body.add(u'[/CODE]')
#--------------------------------
def ins_hide():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Скрытый текст'))
  if res==0:
    ui.app.body.add(u'[HIDE][/HIDE]')
    ui.app.body.set_pos(ui.app.body.get_pos()-7)
  elif res==1:
    ui.app.body.add(u'[HIDE]')
  if res==2:
    ui.app.body.add(u'[/HIDE]')
#--------------------------------
def ins_left():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Выр. влево'))
  if res==0:
    ui.app.body.add(u'[LEFT][/LEFT]')
    ui.app.body.set_pos(ui.app.body.get_pos()-7)
  elif res==1:
    ui.app.body.add(u'[LEFT]')
  if res==2:
    ui.app.body.add(u'[/LEFT]')
#--------------------------------
def ins_center():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Выр. по центру'))
  if res==0:
    ui.app.body.add(u'[CENTER][/CENTER]')
    ui.app.body.set_pos(ui.app.body.get_pos()-9)
  elif res==1:
    ui.app.body.add(u'[CENTER]')
  if res==2:
    ui.app.body.add(u'[/CENTER]')
#--------------------------------
def ins_right():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Выр. вправо'))
  if res==0:
    ui.app.body.add(u'[RIGHT][/RIGHT]')
    ui.app.body.set_pos(ui.app.body.get_pos()-8)
  elif res==1:
    ui.app.body.add(u'[RIGHT]')
  if res==2:
    ui.app.body.add(u'[/RIGHT]')
#--------------------------------
def ins_bold():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Жирный'))
  if res==0:
    ui.app.body.add(ru('[B][/B]'))
    ui.app.body.set_pos(ui.app.body.get_pos()-4)
  elif res==1:
    ui.app.body.add(ru('[B]'))
  if res==2:
    ui.app.body.add(ru('[/B]'))
#--------------------------------
def ins_italic():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Курсив'))
  if res==0:
    ui.app.body.add(ru('[I][/I]'))
    ui.app.body.set_pos(ui.app.body.get_pos()-4)
  elif res==1:
    ui.app.body.add(ru('[I]'))
  if res==2:
    ui.app.body.add(ru('[/I]'))
#--------------------------------
def ins_underline():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Подчеркнутый'))
  if res==0:
    ui.app.body.add(ru('[U][/U]'))
    ui.app.body.set_pos(ui.app.body.get_pos()-4)
  elif res==1:
    ui.app.body.add(ru('[U]'))
  if res==2:
    ui.app.body.add(ru('[/U]'))
#--------------------------------
def ins_strike():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Зачеркнутый'))
  if res==0:
    ui.app.body.add(ru('[S][/S]'))
    ui.app.body.set_pos(ui.app.body.get_pos()-4)
  elif res==1:
    ui.app.body.add(ru('[S]'))
  if res==2:
    ui.app.body.add(ru('[/S]'))
#--------------------------------
def ins_user():
  nick = ui.query(ru('Ник'),'text',ru('nick'))
  if nick==None: return False
  ui.app.body.add(u'[URL=http://dimonvideo.ru/smart/user/%s/]%s[/URL]'%(nick,nick))
#--------------------------------
def ins_url():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Ссылка'))
  if res==0:
    url = ui.query(ru('Адрес ссылки'),'text',ru('http://'))
    if url==None: return False
    ui.app.body.add(u'[URL=%s][/URL]'%url)
    ui.app.body.set_pos(ui.app.body.get_pos()-6)
  elif res==1:
    url = ui.query(ru('Адрес ссылки'),'text',ru('http://'))
    if url==None: return False
    ui.app.body.add(u'[URL=%s]'%url)
  if res==2:
    ui.app.body.add(u'[/URL]')
#--------------------------------
def get_color():
  color=[ru('красный'),ru('зеленый'),ru('синий'),ru('другой...')]
  color=ui.popup_menu(color,ru('Выбор цвета'))
  if color==0:
    color='FF0000'
  elif color==1:
    color='00FF00'
  elif color==2:
    color='0000FF'
  elif color==3:
    color=ui.query(ru('Введите код цвета (hex)'),'text',ru('FF0000'))
    if color==None: return None
  elif color==None: return None
  color='#'+color
  return color
#--------------------------------
def ins_color():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Выделение цветом'))
  if res==0:
    color = get_color()
    if color==None: return
    ui.app.body.add(u'[COLOR=%s][/COLOR]'%color)
    ui.app.body.set_pos(ui.app.body.get_pos()-8)
  elif res==1:
    color = get_color()
    if color==None: return
    ui.app.body.add(u'[COLOR=%s]'%color)
  elif res==2:
    ui.app.body.add(u'[/COLOR]')
#--------------------------------
def ins_image():
  global menu2
  menu3 = []
  for i in range(len(menu2)):
    menu3.append(menu2[i])
  res=ui.popup_menu(menu3,ru('Рисунок'))
  if res==0:
    img=ui.query(ru('Введите адрес рисунка'),'text',ru('http://'))
    if img==None: return
    ui.app.body.add(u'[IMG]%s[/IMG]'%img)
  elif res==1:
    ui.app.body.add(u'[IMG]')
  elif res==2:
    ui.app.body.add(u'[/IMG]')
#--------------------------------
def ins_smile():
  smiles_select()
####### Insert Tags ##########
############################

def dec2bin(x,max=8):
  # перевод в двоичную
  s = ''
  while x > 0:
    s = str(int(x%2)) + s
    x = int(x/2)
  for i in range(max-len(s)):
    s = '0' + s
  return s
def _and(x,y):
  # логическая операция И
  z = ''
  for i in range(len(x)):
    if (x[i] == '1') and (y[i] == '1'):
      z = z + '1'
    else:
      z = z + '0'
  return z

def about():
  anote(ru('BBcoder %s\n'%version))
  anote(ru('Правка сообщений с BB кодами.'))
  anote(ru('Автор: AHgpyxA\n\nDimonVideo.Ru'))

def help():
  ui.app.exit_key_handler=GoBack
  uitricks.set_text(ru('Назад'),EAknSoftkeyExit) 
  try: ui.app.body.focus=False
  except: pass
  ui.app.menu=[(ru('назад'),GoBack)]

  global old_t,old_p
  old_t=t=ui.app.body.get()
  old_p=ui.app.body.get_pos()
  ui.app.body.style=ui.STYLE_BOLD
  printline(ru('Назначение'),1,0x009900,1)
  ui.app.body.style=0
  printline(ru('Редактирование сообщений, содержащих ВВ-коды'),0,0x0,1)
  ui.app.body.style=ui.STYLE_BOLD
  printline(ru('Возможности'),0,0x009900,1)
  ui.app.body.style=0
  printline(ru(' 1. Предпросмотр\n 2. Подсветка тегов\n 3. Автозакрытие тегов\n 4. Смайлики\n 5. Копирование результата в буфер'),0,0x0,1)
  ui.app.body.style=ui.STYLE_BOLD
  printline(ru('Описание меню'),0,0x009900,1)
  ui.app.body.style=0
  printline(ru(' 1. Просмотр\n 2. Текст - вставка тегов оформления текста: жирный, курсив, подчеркнутый, зачеркнутый, цветной\n 3. Объекты - смайлик, рисунок, ссылка, цитата, скрытый текст, код\n 4. Выравнивание\n 5. Действия - просмотр, копирование в буфер, закрытие тегов, очистка экрана\n 6. Настройки'),0,0x0,1)
  ui.app.body.style=ui.STYLE_BOLD
  printline(ru('Разное'),0,0x009900,1)
  ui.app.body.style=0
  printline(ru('Автор: AHgpyxA\nСпециально для пользователей сайта '),0,0x0,0)
  ui.app.body.style=ui.STYLE_UNDERLINE
  printline(ru('DimonVideo.ru'),0,0xff,1)
  ui.app.body.style=0
  ui.app.body.set_pos(0)
############################
############ Main ###########
settings_load()
title=ru('BBcoder2 v%s'%version)
old_tit,old_scr=ui.app.title,ui.app.screen
ui.app.title=title
ui.app.screen='normal'
ui.app.body = ui.Text()

old_t = ru('')
highlight_tags(settings['Color_Tags'],(settings['Color_Tag1']),(settings['Color_Tag2']))

script_lock = e32.Ao_lock()
ui.app.exit_key_handler = Exit
uitricks.set_text(ru('Выход'),EAknSoftkeyExit) 

menu2 = [ru('два тега'),ru('нач. тег'),ru('кон. тег')]

set_menu()

capturer = keycapture.KeyCapturer(_keys)
capturer.forwarding=1
capturer.keys = 8,63586,63557,63499,63530,
48,49,50,51,52,53,54,55,56,57,
63495,63496,63497,63498

capturer.start()
ui.app.focus = switch

if not standaloneapp:
  script_lock.wait()
