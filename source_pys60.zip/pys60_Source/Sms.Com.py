import appuifw,contacts,sys,urllib,e32
_tele2=['902','904','908','950','951']
_MTS=['910','916','917']
_beeline=['903','905','906','909','960','961','962']
_MTSpb=['911','912']
_MTSivan=['910','915']
#_MTSvelnov=['911']
#_MTSbash=['917']
#_MTStatar=['917']
#_MTSvolga=['917','918','919']
#_MTSlife=['913']
#_MTSural=['912','914']
#_MTSmore=['914']
#_MTSsmol=['910','915','919']
#_MTScuba=['918']
#_MTSudm=['912','919']
#_MTSyak=['912','919']
#_MTSrost=['918']
#_MTSekb=['912']
#_MTSnewsib=['913']
#_MTSperm=['912']
#_MTSstavr=['918','919']
#_MTSPekom=['910','915','919']
#_Baikal=['901','902','908','950']
#_NTC902=['902']
#_NTC=['904','908','951']
#_ETC=['902','908','950']
#_NSS=['902','904','908','950','951']
#_AKOC=['902','951']
#_Motiv=['902','904','908','950']
#_Tatincom=['843','855','904','950','951']
#_BashCELL=['90425']
#_EPMAK=['902','904']
#_UTELchel=['902','904','908']
#_UTELtum=['902','904','908']
#_ALINE=['9023']
#_SMARTS=['902','904','908']
#_SMARTSyar=['902','904','908']
#_SMARTSpen=['902','908']
#_SMARTSvolga=['902','908']
#_UKRAINE=['380']
#_KievStar=['67','96','97','98']
#_beelineUkrain=['68']
#_UMS=['50','66','95','99']
#_GoldTel=['39']
#_MTSbelrus=['2']
#_VELCOM=['29']
#_Tele2lat=['371']
#_LMT=['371']
#_k_mobile=['333']
#_kcell=['701']
sys.setdefaultencoding('utf-8')
def ru(x):return x.decode('utf-8')
def enc(x):return x.encode('koi8-r')
def enc_win(x):return x.encode('windows-1251')
def ainfo(x):appuifw.note(ru(x))
def probel(x):
  a=x.split(' ')
  x=''
  for i in range(len(a)):
   x=x+a[i]+'%20'
  return x[:len(x)-3]
def scanner():
 global list,endlist,codelist2,newlist
 base=contacts.open()
 conts=[]
 codelist=[]
 codelist2=_tele2+_MTS+_beeline+_MTSpb
 map(unicode,codelist2)
 for codes in codelist2:codelist+=[u'+7'+codes]+[u'8'+codes]
 list=[]
 for tempcode in codelist:conts+=base.find(tempcode)
 conts.sort()
 for tempcode in conts:
  mobiles=tempcode.find(u'mobile_number')
  for tmobile in mobiles:
   if tmobile.value[-10:-7] in codelist2:list+=[tempcode]
 endlist=[]
 oldlist=[]
 for names in list:
  try:surname=names.find(u'last_name')[0].value
  except:surname=u''
  try:name=names.find(u'first_name')[0].value
  except:name=u''
  if surname==u'':
   if name==u'':fullname=ru('(без имени)')
   else:fullname=name
  else:fullname=surname+u' '+name
  oldlist+=[(fullname,names)]
 oldlist.sort()
 newlist=[]
 pc=1
 for same in oldlist:
  try:
   if same[0]<>oldlist[pc][0]:newlist+=[(same)]
   pc+=1
  except:newlist+=[(same)]
 for surnames in newlist:
  endlist+=[surnames[0]]
 sendsms()
def sendsms():
 global kod,numb,endlist
 endlist1=[ru('Ввести номер'),ru('Автор Дима')]+endlist
 endlist=endlist1
 index=appuifw.selection_list(endlist,search_field=1)
 if index==None:return
 if index==0:reciever='+'+str(appuifw.query(ru('Введите номер в между народном формате (с +)'),'float'))[:-2]
 elif index==1:reciever='+79043341916'
 else:
  mob=newlist[index-2][1]
  mobnumbers=mob.find(u'mobile_number')
  mobils=[]
  mobilka=[]
  for phone in mobnumbers:
   mobils+=[phone.value]

  for tmobile in mobils:
   if tmobile[-10:-7] in codelist2:mobilka+=[tmobile]
  mobnumbers=mobilka
  if len(mobnumbers)>1:
   mobchoice=appuifw.selection_list(mobnumbers)
  else:mobchoice=0
  if mobchoice==None:return
  reciever=str((mobnumbers[mobchoice]))
 kod=str(reciever[-10:-7])
 numb=str(reciever[-7:])
 vvod()

def vvod():
  global round
  appuifw.app.title=(ru('Ввод текста сообщения'))
  appuifw.app.screen='normal'
  appuifw.app.body=round=appuifw.Text()
  appuifw.app.menu=[(u'Ok',sendok),(ru('Назад'),sendsms)]


def sendok():
 global snd,sndq,txt
 snd=round.get()
 appuifw.app.title=(ru('Просмотр сообщения'))
 appuifw.app.body=txt=appuifw.Text()
 txt.color=255
 txt.focus=False
 txt.add(ru('Номер:\n  '))
 txt.color=0xff0000
 txt.add('+'+unicode(str(7))+unicode(kod)+unicode(numb))
 txt.color=255
 txt.add(ru('\n\nТекст сообщения:\n  '))
 txt.color=0xff0000
 txt.add(snd+'\n\n')
 len_snd=len(snd)
 if len_snd<160:
  txt.color=0x0000ff
  txt.add(ru('Осталось ')+unicode(str(160-len_snd))+ru(' символов'))
 if len_snd>160:
  txt.color=0xff0000
  txt.add(ru('Вы ввели на ')+unicode(str(len_snd-160))+ru(' символов больше'))
 if len_snd==160:
  txt.color=0x0000ff
  txt.add(ru('Вы ввели максимальное число символов'))
 appuifw.app.menu=[(ru('Отправить'),sendmes),(ru('Назад'),vvod)]
def sendtele2():
 urllib.urlretrieve('http://www.rocc.ru/cgi-bin/sms33.cgi?Send_Message&Prefix=7'+kod+'&phone='+numb+'&message='+enc(probel(snd)),url_f)
def sendMTS():
 appuifw.note(u'MTS')
 urllib.urlretrieve('http://www.tver.mts.ru/cgi-bin/cgi.exe?function=sms_send&To=7'+kod+numb+'&Msg='+enc_win(probel(snd))+'&Hour=23&Min=59&Day=31&Mon=12&Year=2008', url_f)
def sendbeeline():
 urllib.urlopen('http://www.beeonline.ru/servlet/send/sms/?prf=7'+kod+'&phone='+numb+'&message='+enc_win(probel(snd))+'&number_sms=number_sms_send&termtype=G&translit=off&x=5&y=4')
 txt.add(u'\nsent')
def sendMTSpb():
 ainfo('МТС Питер')
 urllib.urlretrieve('http://spb.mts.ru/smssend.htm?Msg='+enc_win(probel(snd))+'&To=7'+kod+numb+'&count=156&SMSHour=23&SMSMinute=58&SMSDay=31&SMSMonth=12&SMSYear=2008', url_f)
def sendMTSivan():
 ainfo('МТС Иваново')
 urllib.urlretrieve('http://www.ivanovo.mts.ru/cgi-bin/cgi.exe?function=sms_send&MMObjectType=0&MMObjectID=&To=7'+kod+numb+'&Msg='+enc_win(probel(snd))+'&count=160&Hour=23&Min=59&Day=31&Mon=12&Year=2008&Lang=2', url_f)

def sendmes():
 if kod in _tele2:sendtele2()
 elif kod in _MTS:sendMTS()
 elif kod in _beeline:sendbeeline()
 elif kod in _MTSpb:sendMTSpb()
 elif kod in _MTSivan:sendMTSivan()
 ainfo('Отправлено')
url_f='c:\\retrieve.html'
appuifw.app.menu=[(ru('Написать смс'),scanner)]
