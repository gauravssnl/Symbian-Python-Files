import os, e32, appuifw, time, socket, lite_fm
import minidb
appuifw.app.screen='full'
def ru(x): return x.decode('utf-8')
appuifw.app.body=t=appuifw.Text()
timer=e32.Ao_timer()
t.focus=False
text=appuifw.app.body.add
inf=u'\u0418\u0437\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043f\u0440\u0438\u043d\u044f\u0442\u044b \u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u044b'
sec=1
if e32.s60_version_info[0]==3:
  ver=1
  dir='c:/System/Data/'
  path="c:/System/Apps/Time_correct/tc_setting.dat"
  sound_path='c:/Data/Sounds/Digital/'
else:
  ver=0
  dir=appuifw.app.full_name()[0]+':\\System\\Apps\\RunPython\\Apps\\TimeCORRECT\\'
  path=dir+'tc_setting.dat'
  sound_path='E:/Sounds/'
  
shapka=(u'  < TIME CORRECT version 0.9 >\n           < by Vim1978 >\n')
def writes(str):
  global path
  f=open(path,"w")
  f.write(str)
  f.close()
def reads(str):
  f=open(path,"rb")
  read=f.readlines()
  ppp=read[str]
  f.close()
  return ppp
p1=reads(0)
p2=reads(1)
p3=reads(2)
p4=reads(3)
p5=reads(4)
p6=reads(5)
p7=reads(6)
p8=reads(7)
p9=reads(8)
if int(p9)==0:
  stm=(u'\u0423\u0441\u0442.')
else:
  stm=(u'\u041e\u0442\u043a\u043b.')
z=int(p6)
if z==0:
  z1=(u'\u041e\u0442\u043a\u043b\u044e\u0447\u0435\u043d')
else:
  z1=(u'\u0412\u043a\u043b\u044e\u0447\u0435\u043d')
from audio import *
f=ru(p4[:-1])
try:
  s=Sound.open(f)
except:
  pass
def tim():
  if sec==1:
    tmH=int(time.strftime('%H'))
    tmM=int(time.strftime('%M'))
    tmS=int(time.strftime('%S'))
    if tm1==tmH and tm2==tmM and tmS==0:
      sinchronize_t()
    if tmS==0:
      start()
    timer.after(1)
    timer.after(0,tim)
def start():
  global tm1,tm2
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  if int(p9)==0:
    smt1=(u' \u043d\u0435')
  else:
    smt1=(u'')
  tm1=int(int(p7)/3600)
  tm2=int((int(p7)%3600)/60)
  if tm2<10:
    tm02='0'+str(tm2)
  else:
    tm02=tm2
  tm=str(tm1)+':'+str(tm02)
  z=int(p6)
  f=ru(p4[:-1])
  if z==0:
    z1=(u'\u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d')
  else:
    z1=(u'\u0432\u043a\u043b\u044e\u0447\u0435\u043d')
  dtA=time.strftime('%d.%m.%Y')
  tmA=time.strftime('%H:%M')
  t.color=0x660000
  t.set(shapka)
  t.color=0x000080
  text(u'\n  \u0422\u0415\u041a\u0423\u0429\u0418\u0415 \u041d\u0410\u0421\u0422\u0420\u041e\u0419\u041a\u0418:\n')
  t.color=0x666666
  text(u'\u0427\u0430\u0441\u043e\u0432\u043e\u0439 \u043f\u043e\u044f\u0441: '+p1+u'\u0421\u0435\u0440\u0432\u0435\u0440: '+p3+u'\u0412\u0440\u0435\u043c\u044f \u0430\u0432\u0442\u043e\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f: '+tm+u'\n\u041b\u0435\u0442\u043d\u0435\u0435 \u0432\u0440\u0435\u043c\u044f'+smt1+u' \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e'+u'\n\u041a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0430: '+(p5[:len(p5)-3])+(u' \u043c\u0438\u043d.')+u'\n\u0422\u0435\u043a\u0443\u0449\u0430\u044f \u0434\u0430\u0442\u0430: '+dtA+u'\n\u0422\u0435\u043a\u0443\u0449\u0435\u0435 \u0432\u0440\u0435\u043c\u044f: '+tmA+u'\n\u0417\u0432\u0443\u043a \u043e\u043f\u043e\u0432\u0435\u0449\u0435\u043d\u0438\u044f: '+z1+'\n'+f)
  t.color=0x336600
  text(u'\n\n\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u043f\u0440\u0430\u0432\u0443\u044e \u0441\u043e\u0444\u0442-\u043a\u043b\u0430\u0432\u0438\u0448\u0443, \u0447\u0442\u043e\u0431\u044b \u0437\u0430\u043f\u0443\u0441\u0442\u0438\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0432 \u0444\u043e\u043d\u043e\u0432\u043e\u043c \u0440\u0435\u0436\u0438\u043c\u0435')  
  t.set_pos(0)
  tim()
### begin sinchronize_t ###
def sinchronize_t():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  appuifw.app.menu = [(u'\u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u044c',sinchronize_t),(u'\u041d\u0430\u0437\u0430\u0434', back)]
  t.color=0x660000
  t.set(shapka)
  dtA=time.strftime('%d.%m.%Y')
  tmA=time.strftime('%H:%M:%S')
  port = 13
  aa=reads(0)
  bb=reads(1)
  cc=reads(2)
  chp=aa[:len(aa)-1]
  gmt=int(bb)
  gmt=gmt
  host=cc[:len(cc)-1]
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  if int(p9)==0:
    smt1=(u' \u043d\u0435')
  else:
    smt1=(u'')
  if int(p9)==1:
    gmt=gmt+2
  else:
    gmt=gmt+1
  calib=p5[:len(p5)-3]
  t.color=0x993300
  text(u'\n\u041f\u0410\u0420\u0410\u041c\u0415\u0422\u0420\u042b \u0421\u0418\u041d\u0425\u0420\u041e\u041d\u0418\u0417\u0410\u0426\u0418\u0418:')
  t.color=0x000080
  text(u'\n\u0422\u0435\u043a\u0443\u0449\u0430\u044f \u0434\u0430\u0442\u0430: '+dtA+u'\n\u0422\u0435\u043a\u0443\u0449\u0435\u0435 \u0432\u0440\u0435\u043c\u044f: '+tmA+u'\n\u0427\u0430\u0441\u043e\u0432\u043e\u0439 \u043f\u043e\u044f\u0441: '+chp+u'\n\u041b\u0435\u0442\u043d\u0435\u0435 \u0432\u0440\u0435\u043c\u044f'+smt1+u' \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e'+u'\n\u0421\u0435\u0440\u0432\u0435\u0440: '+host+u'\n\u041a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0430:  '+(p5[:len(p5)-3])+u' \u043c\u0438\u043d.'+u'\n')
  try:
    socket.set_default_access_point(socket.access_point(int(p8)))
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((host,port))
  except:
    appuifw.note(u'\u0421\u0435\u0440\u0432\u0435\u0440 \u043d\u0435 \u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d !\n\u041f\u043e\u043c\u0435\u043d\u044f\u0439\u0442\u0435 \u0441\u0435\u0440\u0432\u0435\u0440.','error')
    sock.close()
    back()
  nist = sock.recv(1024)
  last_time = time.mktime(time.gmtime())
  sock.close()
  p6=reads(5)
  zvuk=int(p6)
  if zvuk == 1:
    s.play()
  else:
    s.stop()
  e32.set_home_time(time.mktime((int('20'+nist[7:9]),int(nist[10:12]),int(nist[13:15]),int(nist[16:18])+gmt,(int(nist[19:21])+int(p5[:len(p5)-3])),int(nist[22:24])+(float(nist[31:nist.index('U')-1].strip())/1000),0,0,0)))
  delta = last_time - time.mktime((int('20'+nist[7:9]),int(nist[10:12]),int(nist[13:15]),int(nist[16:18]),int(nist[19:21]),int(nist[22:24]),0,0,0))
  curr_time = time.gmtime(time.time())
  tmB=time.strftime('%H:%M:%S')
  dtB=time.strftime('%d.%m.%Y')
  t.color=0x993300
  text(u'\n\u0420\u0415\u0417\u0423\u041b\u042c\u0422\u0410\u0422\u042b \u0421\u0418\u041d\u0425\u0420\u041e\u041d\u0418\u0417\u0410\u0426\u0418\u0418:')
  t.color=0x000080
  text(u'\n\u0414\u0430\u0442\u0430:  '+dtB+u'\n\u0412\u0440\u0435\u043c\u044f:  '+tmB+u'\n\u0421\u043a\u043e\u0440\u0440\u0435\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043e:  '+str(delta)+u' \u0441\u0435\u043a.'+u'\n\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0441\u0435\u0442\u0438:  '+nist[31:36]+u' \u043c\u0441.\n')
  appuifw.note(u'TimeCorrect \u0421\u0438\u043d\u0445\u0440\u043d\u0438\u0437\u0430\u0446\u0438\u044f \u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0430','info',1)
  timer=e32.Ao_timer()
  timer.after(30)
  back()
### begin chas. poyas ### 
def chasovoj_poyas():
  global p1,sec
  sec=0
  appuifw.app.exit_key_handler=back
  appuifw.app.menu = [(u'\u0414\u0440\u0443\u0433\u043e\u0439 \u043f\u043e\u044f\u0441',chasovoj_poyas),(u'\u041d\u0430\u0437\u0430\u0434', back)]
  t.color=0x660000
  t.set(shapka)
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  poyas=[u'UTC-12', u'UTC-11', u'UTC-10', u'UTC-09', u'UTC-08', u'UTC-07', u'UTC-06', u'UTC-05', u'UTC-04', u'UTC-03', u'UTC-02', u'UTC-01', u'UTC+00', u'UTC+01', u'UTC+02', u'UTC+03', u'UTC+04', u'UTC+05', u'UTC+06', u'UTC+07', u'UTC+08', u'UTC+09', u'UTC+10', u'UTC+11', u'UTC+12']
  chp=appuifw.popup_menu(poyas,u'\u0427\u0430\u0441\u043e\u0432\u043e\u0439 \u043f\u043e\u044f\u0441:')
  if chp == None:
    back()
  else:
    po=chp
  if chp==po:
    chp=poyas[chp]
    ppo=chp[len(chp)-3:]
  t.color=0xff0000
  text(u'\n  \u0412\u044b \u0432\u044b\u0431\u0440\u0430\u043b\u0438 \u0447\u0430\u0441\u043e\u0432\u043e\u0439 \u043f\u043e\u044f\u0441: '+chp)
  t.color=0x660033
  text(u'\n\n  \u0420\u0430\u0437\u043d\u0438\u0446\u0430 \u0441 \u0423\u043d\u0438\u0432\u0435\u0440\u0441\u0430\u043b\u044c\u043d\u044b\u043c \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u043c \u0432\u0440\u0435\u043c\u0435\u043d\u0435\u043c \u0432 \u0447\u0430\u0441\u0430\u0445 \u0441\u043e\u0441\u0442\u0430\u0432\u043b\u044f\u0435\u0442 '+ppo+'\n')
  writes(str(chp)+'\n'+str(ppo)+'\n'+p3+p4+p5+p6+p7+p8+p9)
  appuifw.note(inf,'conf')
### begin server_sinh ###
def server_sinh():
  global p3,sec
  sec=0
  appuifw.app.exit_key_handler=back
  appuifw.app.menu = [(u'\u0414\u0440\u0443\u0433\u043e\u0439 \u0441\u0435\u0440\u0432\u0435\u0440',server_sinh),(u'\u041d\u0430\u0437\u0430\u0434', back)]
  t.color=0x660000
  t.set(shapka)
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  server=[u'time.nist.gov', u'time-a.nist.gov', u'time-b.nist.gov', u'nist1.datum.com', u'nist1-ny.glassey.com']
  srv=appuifw.popup_menu(server,u'\u0421\u0435\u0440\u0432\u0435\u0440 \u0441\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u0438:')
  if srv == None:
    back()
  else:
    ss=srv
  if srv==ss:
    srv=server[srv]
  t.color=0xff0000
  text(u'\n  \u0412\u044b \u0432\u044b\u0431\u0440\u0430\u043b\u0438 \u0441\u0435\u0440\u0432\u0435\u0440 \u0441\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u0438:\n\n  '+srv+u'\n')
  writes(p1+p2+str(srv)+'\n'+p4+p5+p6+p7+p8+p9)
  appuifw.note(inf,'conf')
### tochka_dostupa ###
def tochka_dostupa():
  global p8,sec
  sec=0
  appuifw.app.exit_key_handler=back
  appuifw.app.screen='normal'
  apo=socket.select_access_point()
  if apo!=None:
    p8=apo
    writes(p1+p2+p3+p4+p5+p6+p7+str(p8)+'\n'+p9)
    appuifw.note(inf,'conf')
  appuifw.app.screen='full'
### interval_sinh ###
def interval_sinh():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  appuifw.app.menu=[(u'\u0412\u0440\u0435\u043c\u044f \u0430\u0432\u0442\u043e\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f',interval_sinh),(u'\u041d\u0430\u0437\u0430\u0434',back)]
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  tm=appuifw.query(u'','time',float(p7))
  if tm==None:
    back()
  tm=int(tm)
  writes(p1+p2+p3+p4+p5+p6+str(tm)+'\n'+p8+p9)
  p7=int(reads(6))
  tm1=int(p7/3600)
  tm2=int((p7%3600)/60)
  if tm2<10:
    tm2='0'+str(tm2)
  tm=str(tm1)+':'+str(tm2)
  t.color=0x660000
  t.set(shapka)
  t.color=0xff0000
  text(u'\n  \u0412\u044b \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u043b\u0438 \u0432\u0440\u0435\u043c\u044f \u0430\u0432\u0442\u043e\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f: '+tm)
  appuifw.note(inf,'conf')
### begin summer_tm ###
def summer_tm():
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  sum=int(p9)
  leto=(u'\u041b\u0435\u0442\u043d\u0435\u0435 \u0432\u0440\u0435\u043c\u044f')
  if sum == 0:
    st=appuifw.query((u'\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c\n'+leto+'?'),'query')
    if st == None:
      sst=0
      appuifw.note(leto+u'\n\u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e!','error')
      start()
    else:
      sst=1
      appuifw.note(leto+u'\n\u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e!','conf')
  if sum == 1:
    st=appuifw.query((u'\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c\n'+leto+'?'),'query')
    if st == None:
      sst=1
      appuifw.note(leto+u'\n\u043d\u0435 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u043e!','error')
      start()
    else:
      sst=0
      appuifw.note(leto+u'\n\u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u043e','conf')
  writes(p1+p2+p3+p4+p5+p6+p7+p8+str(sst)+'\n')
  start()
### begin calibr_t ###
def calibr_t():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  appuifw.app.menu=[(u'\u0412\u0432\u0435\u0441\u0442\u0438 \u043a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0443',calibr_tt),(u'\u041d\u0430\u0437\u0430\u0434',back)]
  t.color=0x660000
  t.set(shapka)
  t.color=0x666666
  text(u'\n  \u0424\u0443\u043d\u043a\u0446\u0438\u044f \u043a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0438 \u0432\u0440\u0435\u043c\u0435\u043d\u0438 \u0434\u043b\u044f \u0432\u0432\u0435\u0434\u0435\u043d\u0438\u044f \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u0435\u043c \u043f\u0440\u0438\u043d\u0443\u0434\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0433\u043e "\u043e\u0442\u0441\u0442\u0430\u0432\u0430\u043d\u0438\u044f" \u0438\u043b\u0438 "\u0437\u0430\u0431\u0435\u0433\u0430\u043d\u0438\u044f" \u0447\u0430\u0441\u043e\u0432 \u0441\u043c\u0430\u0440\u0442\u0430 \u043d\u0430 \u043d\u0435\u043e\u0431\u0445\u043e\u0434\u0438\u043c\u043e\u0435 \u0435\u043c\u0443 \u0432\u0440\u0435\u043c\u044f.\n\n')
  t.color=0xff0080
  text(u'  \u0412 \u041d \u0418 \u041c \u0410 \u041d \u0418 \u0415 !\n\n')
  t.color=0x666666
  text(u'  \u041f\u0440\u0438 \u0432\u0432\u043e\u0434\u0435 \u0432\u0440\u0435\u043c\u0435\u043d\u0438 \u043a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0438 \u043d\u0430\n"+/-N" \u043c\u0438\u043d\u0443\u0442, \u043f\u0440\u0438 \u0441\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u0438 \u0432\u0440\u0435\u043c\u0435\u043d\u0438, \u0447\u0430\u0441\u044b \u0430\u0432\u0442\u043e\u043c\u0430\u0441\u0438\u0447\u0435\u0441\u043a\u0438 \u0431\u0443\u0434\u0443\u0442 \u043f\u0435\u0440\u0435\u0432\u0435\u0434\u0435\u043d\u044b \u043d\u0430 \u044d\u0442\u043e \u0432\u0440\u0435\u043c\u044f.')
  p5=reads(4)
  t.color=0x000080
  text(u'\n\n  \u0412\u0432\u0435\u0434\u0435\u043d\u0430 \u043a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0430:  '+(p5[:len(p5)-3])+(u' \u043c\u0438\u043d.'))
def calibr_tt():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  ct=appuifw.query(u'\u0412\u0432\u0435\u0441\u0442\u0438 \u043a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0443\n\u0414\u043b\u044f \u043e\u0442\u043c\u0435\u043d\u044b "0"','float')
  if ct==None or ct==0:
    writes(p1+p2+p3+p4+str(ct)+'\n'+p6+p7+p8+p9)
    ct=0
    appuifw.note(u'\u041a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0430\n\u043e\u0442\u043c\u0435\u043d\u0435\u043d\u0430','conf')
    calibr_t()
  else:
    writes(p1+p2+p3+p4+str(ct)+'\n'+p6+p7+p8+p9)
    appuifw.note(inf,'conf')
    calibr_t()
### begin ef_fect1 ###
def ef_fect():
  appuifw.app.exit_key_handler=back
  appuifw.app.menu = [(u'\u0414\u0440\u0443\u0433\u043e\u0439 \u0437\u0432\u0443\u043a',ef_fect),(u'\u041d\u0430\u0437\u0430\u0434', back)]
  t.color=0x660000
  t.set(shapka)
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  muz=lite_fm.manager(sound_path,ext='.mp3')
  if muz==None:
    muz=p4[:len(p4)-1]
  try:
    writes(p1+p2+p3+muz+'\n'+p5+p6+p7+p8+p9)
    appuifw.note(inf,'conf')
  except:
    appuifw.note(u'\u041d\u0435\u043f\u0440\u0430\u0432\u0438\u043b\u044c\u043d\u044b\u0439 \u0444\u0430\u0439\u043b!','error')
    effect()
    t.color=0x660000
    t.set(shapka)
    t.color=0xff0000
  text(u'\n  \u0412\u044b \u0432\u044b\u0431\u0440\u0430\u043b\u0438 \u0437\u0432\u0443\u043a \u043e\u043f\u043e\u0432\u0435\u0449\u0435\u043d\u0438\u044f:\n\n  '+ru(muz)+u'\n')
###   begin zvuk_off   ###
def zvuk_off():
  p1=reads(0)
  p2=reads(1)
  p3=reads(2)
  p4=reads(3)
  p5=reads(4)
  p6=reads(5)
  p7=reads(6)
  p8=reads(7)
  p9=reads(8)
  zvuk=int(p6)
  if zvuk == 0:
    zv=appuifw.query((u'\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0437\u0432\u0443\u043a \u043e\u043f\u043e\u0432\u0435\u0449\u0435\u043d\u0438\u044f'),'query')
    if zv == None:
      zzv=0
      appuifw.note(u'\u0417\u0432\u0443\u043a \u043d\u0435 \u0432\u043a\u043b\u044e\u0447\u0435\u043d','error')
      start()
    else:
      zzv=1
      appuifw.note(u'\u0417\u0432\u0443\u043a \u0432\u043a\u043b\u044e\u0447\u0435\u043d','conf')
  if zvuk == 1:
    zv=appuifw.query((u'\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0437\u0432\u0443\u043a \u043e\u043f\u043e\u0432\u0435\u0449\u0435\u043d\u0438\u044f'),'query')
    if zv == None:
      zzv=1
      appuifw.note(u'\u0417\u0432\u0443\u043a \u043d\u0435 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d','error')
      start()
    else:
      zzv=0
      appuifw.note(u'\u0417\u0432\u0443\u043a \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d','conf')
  writes(p1+p2+p3+p4+p5+str(zzv)+'\n'+p7+p8+p9)
  start()
###   begin infopr   ###
def infopr():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  t.color=0x008080
  t.set(u'\n   \u041f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0430 \u0434\u043b\u044f \u043a\u043e\u0440\u0440\u0435\u043a\u0442\u0438\u0440\u043e\u0432\u043a\u0438 \u0432\u0440\u0435\u043c\u0435\u043d\u0438 \u043d\u0430 \u0412\u0430\u0448\u0435\u043c \u0441\u043c\u0430\u0440\u0442\u0444\u043e\u043d\u0435 \u0441 \u0423\u043d\u0438\u0432\u0435\u0440\u0441\u0430\u043b\u044c\u043d\u044b\u043c \u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0438\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u043c \u0412\u0440\u0435\u043c\u0435\u043d\u0435\u043c UTC (Coordinated Universal Time) \u043f\u0440\u0438 \u043f\u043e\u043c\u043e\u0449\u0438 \u0441\u043f\u0435\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0445 \u0441\u0435\u0440\u0432\u0435\u0440\u043e\u0432 \u0441\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u0438 \u0432\u0440\u0435\u043c\u0435\u043d\u0438.')
  appuifw.app.menu = [(u'\u041e \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0435',infopr),
(u'\u041e \u0447\u0430\u0441\u043e\u0432\u044b\u0445 \u043f\u043e\u044f\u0441\u0430\u0445',infochp),(u'\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e \u043f\u043e\u044f\u0441\u0435',info_poyas),
(u'\u0421\u043f\u0430\u0441\u0438\u0431\u043e !',thanks),(u'\u041d\u0430\u0437\u0430\u0434', back)]
### begin infochp ### 
def infochp():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  t.color=0x008080
  t.set(u'\n  \u0427\u0430\u0441\u043e\u0432\u044b\u0435 \u043f\u043e\u044f\u0441\u0430 \u0432\u043e\u043a\u0440\u0443\u0433 \u0437\u0435\u043c\u043d\u043e\u0433\u043e \u0448\u0430\u0440\u0430 \u0432\u044b\u0440\u0430\u0436\u0430\u044e\u0442\u0441\u044f, \u043a\u0430\u043a \u043f\u043e\u043b\u043e\u0436\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0438 \u043e\u0442\u0440\u0438\u0446\u0430\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0441\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u043e\u0442 \u0055\u0054\u0043. \u0055\u0054\u0043 - \u044d\u0442\u043e \u043d\u0430\u0441\u043b\u0435\u0434\u0438\u0435 \u0432\u0440\u0435\u043c\u0435\u043d\u0438 \u043f\u043e \u0413\u0440\u0438\u043d\u0432\u0438\u0447\u0443 (\u0047\u004d\u0054), \u0438\u043d\u043e\u0433\u0434\u0430 \u0442\u0430\u043a\u0436\u0435 \u043e\u0448\u0438\u0431\u043e\u0447\u043d\u043e \u0438\u043c\u0435\u043d\u0443\u0435\u043c\u043e\u0435 \u0047\u004d\u0054. \u041d\u043e\u0432\u043e\u0435 \u0438\u043c\u044f \u0431\u044b\u043b\u043e \u0432\u0432\u0435\u0434\u0435\u043d\u043e, \u0447\u0442\u043e\u0431\u044b \u0438\u0437\u0431\u0430\u0432\u0438\u0442\u044c\u0441\u044f \u043e\u0442 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0451\u043d\u043d\u043e\u0433\u043e \u043c\u0435\u0441\u0442\u0430 \u043d\u0430 \u0417\u0435\u043c\u043b\u0435 \u0432 \u041c\u0435\u0436\u0434\u0443\u043d\u0430\u0440\u043e\u0434\u043d\u043e\u043c \u0441\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u0435. \u0055\u0054\u0043 \u0431\u0430\u0437\u0438\u0440\u0443\u0435\u0442\u0441\u044f \u043d\u0430 \u0430\u0442\u043e\u043c\u043d\u043e\u043c \u043e\u0442\u0441\u0447\u0451\u0442\u0435 \u0432\u0440\u0435\u043c\u0435\u043d\u0438, \u0430 \u043d\u0435 \u043d\u0430 \u0432\u0440\u0435\u043c\u0435\u043d\u0438 \u0432 \u0441\u0430\u043c\u043e\u043c \u0413\u0440\u0438\u043d\u0432\u0438\u0447\u0435. \u0421\u043b\u0435\u0434\u0443\u0435\u0442 \u043e\u0431\u0440\u0430\u0442\u0438\u0442\u044c \u0432\u043d\u0438\u043c\u0430\u043d\u0438\u0435 \u043d\u0430 \u0442\u043e, \u0447\u0442\u043e \u0432\u0440\u0435\u043c\u044f \u043f\u043e \u0055\u0054\u0043 \u043d\u0435 \u043f\u0435\u0440\u0435\u0432\u043e\u0434\u0438\u0442\u0441\u044f \u043b\u0435\u0442\u043e\u043c \u0438 \u0437\u0438\u043c\u043e\u0439. \u041f\u043e\u044d\u0442\u043e\u043c\u0443, \u0434\u043b\u044f \u0442\u0435\u0445 \u043c\u0435\u0441\u0442, \u0433\u0434\u0435 \u0435\u0441\u0442\u044c \u043f\u0435\u0440\u0435\u0432\u043e\u0434 \u043d\u0430 \u043b\u0435\u0442\u043d\u0435\u0435 \u0432\u0440\u0435\u043c\u044f, \u0441\u043c\u0435\u0449\u0435\u043d\u0438\u0435 \u043e\u0442\u043d\u043e\u0441\u0438\u0442\u0435\u043b\u044c\u043d\u043e \u0055\u0054\u0043 \u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f.')
  appuifw.app.menu = [(u'\u041e \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0435',infopr),
(u'\u041e \u0447\u0430\u0441\u043e\u0432\u044b\u0445 \u043f\u043e\u044f\u0441\u0430\u0445',infochp),(u'\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e \u043f\u043e\u044f\u0441\u0435',info_poyas),
(u'\u0421\u043f\u0430\u0441\u0438\u0431\u043e !',thanks),(u'\u041d\u0430\u0437\u0430\u0434', back)]
### begin thanks ###
def thanks():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  t.color=0x008080
  t.set(u'\n \u0421\u041f\u0410\u0421\u0418\u0411\u041e \u0423\u0427\u0410\u0421\u0422\u041d\u0418\u041a\u0410\u041c \u0421\u0410\u0419\u0422\u0410\n')
  t.color=0x006600
  text(u'\n    <<< Dimon VIDEO >>>\n\n')
  t.color=0x3300ff
  text(u' - Smart4n & Arok')
  t.color=0x008080
  text(u' - \u0437\u0430 \u043f\u043e\u043c\u043e\u0449\u044c \u0438 \u043a\u043e\u043d\u0441\u0443\u043b\u044c\u0442\u0430\u0446\u0438\u044e \u043f\u0440\u0438 \u0441\u043e\u0437\u0434\u0430\u043d\u0438\u0438 \u044d\u0442\u043e\u0439 \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u044b\n')
  t.color=0x3300ff
  text(u' - Acid Sonic')
  t.color=0x008080
  text(u' - \u0437\u0430 \u0441\u043e\u0437\u0434\u0430\u043d\u0438\u0435 \u043a\u0440\u0430\u0441\u0438\u0432\u043e\u0439 \u0438 \u043f\u0435\u0440\u0432\u043e\u043a\u043b\u0430\u0441\u0441\u043d\u043e\u0439 \u0438\u043a\u043e\u043d\u043a\u0438')
  t.color=0x3300ff
  text(u' - Acid Sonic')
  t.color=0x008080
  text(u'\n \u042d\u0442\u0430 \u0432\u0435\u0440\u0441\u0438\u044f \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u044b \u043d\u0430\u043f\u0438\u0441\u0430\u043d\u0430 \u0441\u043e\u0432\u043c\u0435\u0441\u0442\u043d\u043e')
  t.color=0x3300ff
  text(u'\nVim1978 & Vital 6630')
  t.color=0x008080
  text(u'\n \u041d\u0435 \u0437\u0430\u0431\u044b\u0432\u0430\u0439\u0442\u0435 \u0431\u043b\u0430\u0433\u043e\u0434\u0430\u0440\u0438\u0442\u044a \u0430\u0432\u0442\u043e\u0440\u043e\u0432 \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u044b. \u041f\u043e\u0441\u0435\u0442\u0438\u0442\u0435:')
  t.color=0x3300ff
  text(u'\n    www.dimonvideo.ru')
  appuifw.app.menu = [(u'\u041e \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0435',infopr),
(u'\u041e \u0447\u0430\u0441\u043e\u0432\u044b\u0445 \u043f\u043e\u044f\u0441\u0430\u0445',infochp),(u'\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e \u043f\u043e\u044f\u0441\u0435',info_poyas),
(u'\u0421\u043f\u0430\u0441\u0438\u0431\u043e !',thanks),(u'Dimon Video',dimon),(u'Vim1978',vim),(u'Vital 6630',vital),(u'\u041d\u0430\u0437\u0430\u0434', back)]
###
def info_poyas():
  global sec
  sec=0
  appuifw.app.exit_key_handler=back
  appuifw.app.menu = [(u'\u041e \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0435',infopr),(u'\u041e \u0447\u0430\u0441\u043e\u0432\u044b\u0445 \u043f\u043e\u044f\u0441\u0430\u0445',infochp),(u'\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e \u043f\u043e\u044f\u0441\u0435',info_poyas),(u'\u0421\u043f\u0430\u0441\u0438\u0431\u043e !',thanks),(u'\u041d\u0430\u0437\u0430\u0434', back)]
  t.set(u'\u0427\u0430\u0441\u043e\u0432\u043e\u0439 \u043f\u043e\u044f\u0441 \u0432\u0432\u043e\u0434\u0438\u0442\u0435 \u0432 \u0444\u043e\u0440\u043c\u0430\u0442\u0435: UTC+/-XX \u0431\u0435\u0437 \u043f\u0440\u043e\u0431\u0435\u043b\u043e\u0432.\n\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: UTC-12; UTC+00; UTC+03 \u0438 \u0442\u0430\u043a \u0434\u0430\u043b\u0435\u0435...')
  data=appuifw.query(u'\u041a\u0430\u043a\u043e\u0439 \u0447\u0430\u0441\u043e\u0432\u043e\u0439 \u043f\u043e\u044f\u0441 \u0412\u0430\u0441 \u0438\u043d\u0442\u0435\u0440\u0435\u0441\u0443\u0435\u0442?','text',ru('UTC+00'))
  minidb.Open('tc_data',dir,update=0)
  rezult=minidb.Read(data)
  t.set(u'\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e \u0447\u0430\u0441\u043e\u0432\u043e\u043c \u043f\u043e\u044f\u0441\u0435\n'+rezult)
######
def vim():
  if appuifw.query(u'\u041f\u0435\u0440\u0435\u0439\u0442\u0438 \u043f\u043e \u0441\u0441\u044b\u043b\u043a\u0435 \u043d\u0430 \u0441\u0442\u0440\u0430\u043d\u0438\u0447\u043a\u0443 Vim1978 ?', "query") == 1:
    appuifw.Content_handler().open_standalone(dir+'Vim1978.html')
######
def vital():
  if appuifw.query(u'\u041f\u0435\u0440\u0435\u0439\u0442\u0438 \u043f\u043e \u0441\u0441\u044b\u043b\u043a\u0435 \u043d\u0430 \u0441\u0442\u0440\u0430\u043d\u0438\u0447\u043a\u0443 Vital 6630 ?', "query") == 1:
    appuifw.Content_handler().open_standalone(dir+'Vital6630.html')
######
def dimon():
  if appuifw.query(u'\u041f\u0435\u0440\u0435\u0439\u0442\u0438 \u043f\u043e \u0441\u0441\u044b\u043b\u043a\u0435 \u043d\u0430 \u0441\u0430\u0439\u0442\nDimon Video ?', "query") == 1:
    appuifw.Content_handler().open_standalone(dir+'Dimon.html')
### begin back ###
def back():
  global sec
  sec=1
  appuifw.app.exit_key_handler=squit
  menu()
  start()
### begin quit ###
def quit():
 if appuifw.query(u'\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0431\u0443\u0434\u0435\u0442 \u0437\u0430\u043a\u0440\u044b\u0442\u043e. \u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c ?', "query") == 1:
  os.abort()
### begin main menu ###
def menu():
  appuifw.app.title=u'TimeCORRECT'
  appuifw.app.menu = [(u'\u0421\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u044f', sinchronize_t),
(u'\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438',
((u'\u0427\u0430\u0441\u043e\u0432\u043e\u0439 \u043f\u043e\u044f\u0441', chasovoj_poyas),
(u'\u0421\u0435\u0440\u0432\u0435\u0440 \u0441\u0438\u043d\u0445\u0440\u043e\u043d\u0438\u0437\u0430\u0446\u0438\u0438',server_sinh),(u'\u0422\u043e\u0447\u043a\u0430 \u0434\u043e\u0441\u0442\u0443\u043f\u0430',tochka_dostupa),(u'\u0412\u0440\u0435\u043c\u044f \u0430\u0432\u0442\u043e\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f',interval_sinh),(u'\u041b\u0435\u0442\u043d\u0435\u0435 \u0432\u0440\u0435\u043c\u044f: \u0432\u043a\u043b./\u043e\u0442\u043a\u043b.',summer_tm),(u'\u0412\u0432\u0435\u0441\u0442\u0438 \u043a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0443',calibr_t),(u'\u0417\u0432\u0443\u043a \u043e\u043f\u043e\u0432\u0435\u0449\u0435\u043d\u0438\u044f', ef_fect),(u'\u0417\u0432\u0443\u043a \u0432\u043a\u043b./\u043e\u0442\u043a\u043b.',zvuk_off))),
(u'\u0421\u043f\u0440\u0430\u0432\u043a\u0430',
((u'\u041e \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0435',infopr),
(u'\u041e \u0447\u0430\u0441\u043e\u0432\u044b\u0445 \u043f\u043e\u044f\u0441\u0430\u0445',infochp),(u'\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e \u043f\u043e\u044f\u0441\u0435',info_poyas),
(u'\u0421\u043f\u0430\u0441\u0438\u0431\u043e !',thanks))),
(u'\u0412\u044b\u0445\u043e\u0434', quit)]
menu()
start()

### end main menu ###
def squit():
  if ver==0:
    e32.start_exe('Z:\System\Programs\AppRun.exe','Z:\System\Apps\Phone\Phone.app')
  else:
    e32.start_exe('Phone.exe','',1)

appuifw.app.exit_key_handler = squit
if ver==0:
  if appuifw.app.full_name().find(u'Python')!=-1:
    lock=e32.Ao_lock()
    os.abort=lock.signal
    lock.wait()
else:
  lock=e32.Ao_lock()
  lock.wait()
