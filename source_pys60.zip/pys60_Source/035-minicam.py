
import camera
photo = camera.take_photo()
photo.save("E:\\Images\\minicam.jpg")
