
f = file('E:\\Sounds\\Digital\\boo.wav', 'r')
mysound = f.read()
f.close()
