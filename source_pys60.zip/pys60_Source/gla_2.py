#GLA_2 by Albert927
###############
import appuifw
import e32
import time
import math
from graphics import *
###############
class timer_15:
    def __init__(self):
        self.state=0
        self.tik_old=self.tik_new=float(time.clock())

    def test(self):
        self.state=0
        self.tik_new=time.clock()
        if self.tik_new-self.tik_old>=0.055555:
            self.tik_old=self.tik_new
            self.state=1

class fps:
    def __init__(self):
        self.number=0
        self.text=u''
        self.tik_old=self.tik_new=float(time.clock())

    def test(self):
        self.tik_new=time.clock()
        self.number+=1
        if self.tik_new-self.tik_old>=1:
            self.tik_old=self.tik_new
            self.text=unicode(str(self.number))
            self.number=0
###############
main=[[[0,1]]]
main_offset=0
still=timer_15()
fps=fps()

state=1
img=0
canvas=0
###############
def gla_ltn(t1=0,t2=0):
    dt=[]
    for ti in range(t1,t2+1): dt.append(ti)
    return dt    

def gla_lan(t,a1=0,a2=0):
    dl=[]
    a1=ai=float(a1)
    a2=float(a2)
    delta=float(abs(a2-a1)/(len(t)))
    for ti in range(0,len(t)):
        dl.append(int(round(ai)))
        if a1<a2: ai+=delta
        if a1>a2: ai-=delta
    return dl

def gla_lcn(t,a1=0,a2=0,a3=0,a4=0,a5=0,a6=0):
    dc=[]
    dr=gla_lan(t,a1,a2)
    dg=gla_lan(t,a3,a4)
    db=gla_lan(t,a5,a6)
    for ti in range(0,len(t)): dc.append(dr[ti]*256*256+dg[ti]*256+db[ti])
    return dc

def gla_chg(t,d,a):
    nd=[]
    for ti in range(0,len(t)): nd.append(d[ti]+a)
    return nd
###############
def gla_fon(t,c):
    global main
    for ti in range(0,len(t)): main[t[ti]][0][1]=c[ti]

def gla_8p(f,t,x1,y1,x2,y2,c=0,w=0):
    global main
    for ti in range(0,len(t)):
        main[t[ti]].append([f])
        tt=len(main[t[ti]])-1
        main[t[ti]][tt].append(x1[ti])
        main[t[ti]][tt].append(y1[ti])
        if f==2:main[t[ti]][tt].append(x2[ti])
        if f==6:main[t[ti]][tt].append(x2)
        if f==2 or f==6:main[t[ti]][tt].append(y2[ti])
        if f==3 or f==4 or f==5:
            main[t[ti]][tt].append(x2[ti])
            main[t[ti]][tt].append(y2[ti])
            main[t[ti]][tt].append(c[ti])
            main[t[ti]][tt].append(w[ti])

def gla_point(t,x,y,c,w):
    gla_8p(2,t,x,y,c,w)

def gla_line(t,x1,y1,x2,y2,c,w):
    gla_8p(3,t,x1,y1,x2,y2,c,w)

def gla_ellipse(t,x1,y1,x2,y2,c,w):
    gla_8p(4,t,x1,y1,x2,y2,c,w)

def gla_rectangle(t,x1,y1,x2,y2,c,w):
    gla_8p(5,t,x1,y1,x2,y2,c,w)

def gla_text(t,x,y,s,c):
    gla_8p(6,t,x,y,s,c)
###############
def gla_setmain(length):
    global main
    for index in range(0,length): main.append([[1,0]])

def gla_drawmain():
    global still
    global main
    global main_offset
    still.test()
    if still.state:
        main_offset+=1
        if main_offset==len(main)-1: main_offset=0
        for index in main[main_offset]: gla_treat(index)
        canvas.blit(img)
    e32.ao_yield()

def gla_drawmaintest():
    global still
    global fps
    global main
    global main_offset
    fps.test()
    still.test()
    if still.state:
        main_offset+=1
        if main_offset==len(main)-1: main_offset=0
        for index in main[main_offset]: gla_treat(index)
        img.text((0,9),fps.text,0xffffff)
        canvas.blit(img)
    e32.ao_yield()
###############
def gla_treat(arg):
    global img
    if arg[0]==1: img.clear(arg[1])
    elif arg[0]==2: img.point((arg[1],arg[2]),arg[3],width=arg[4])
    elif arg[0]==3: img.line((arg[1],arg[2],arg[3],arg[4]),arg[5],width=arg[6])
    elif arg[0]==4: img.ellipse((arg[1],arg[2],arg[3],arg[4]),arg[5],width=arg[6])
    elif arg[0]==5: img.rectangle((arg[1],arg[2],arg[3],arg[4]),arg[5],width=arg[6])
    elif arg[0]==6: img.text((arg[1],arg[2]),arg[3],arg[4])
###############
def exit():
    global state
    state=0
    appuifw.app.set_exit()

def appinit():
    global img
    global canvas
    appuifw.app.exit_key_handler=exit
    appuifw.app.screen='full'
    appuifw.app.body=canvas=appuifw.Canvas(event_callback=None,redraw_callback=None)
    img=Image.new(canvas.size)

def appstate():
    global state
    return state