# -*- coding: utf-8 -*-

#
# pdis_todo.py
# 
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
# 
# Authors: Juha Päivärinta <juha.paivarinta@hiit.fi>
#          Tapio Tallgren <tapio.tallgren@nokia.com>
#          Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import e32
import appuifw
import key_codes

from pdis.lib.logging import *
from pdis.socket.transport_registry import close_all_managers

pretty_status_strings = [u"Needs action", u"Completed", u"In process", u"Cancelled"]
standard_status_strings = ["NEEDS-ACTION", "COMPLETED", "IN-PROCESS", "CANCELLED"]
status_chars = u" X!-"

def get_status_index(item):
    try:
        return standard_status_strings.index(item.get_status())
    except ValueError:
        return 0

def format(item):
    # Format the item as a short unicode string.
    return u"[%s] %s" % (status_chars[get_status_index(item)],
                         item.get_summary())

def join_categories(category_list):
    return ", ".join(category_list)

def split_categories(category_string):
    list = [name.strip() for name in category_string.split(",")]
    return [name for name in list if name]

def save_state():
    return (appuifw.app.title,
            appuifw.app.body,
            appuifw.app.menu,
            appuifw.app.exit_key_handler)

def restore_state(state):
    (appuifw.app.title,
     appuifw.app.body,
     appuifw.app.menu,
     appuifw.app.exit_key_handler) = state

class ToDoApp:
    def __init__(self, title):
        self.dirty = False
        self.lock = e32.Ao_lock()

        self.saved_state = save_state()

        appuifw.app.title = title

        self.exit_flag = False
        appuifw.app.exit_key_handler = self.abort

        self.data = []
        appuifw.app.body = appuifw.Listbox([u"Loading..."], self.handle_view)
        appuifw.app.body.bind(key_codes.EKeyBackspace, self.handle_delete)

        self.menu_new = (u"New", self.handle_new)
        self.menu_view = (u"View/Edit", self.handle_view)
        self.menu_toggle = (u"Toggle Status", self.handle_toggle)
        self.menu_delete = (u"Delete", self.handle_delete)
        appuifw.app.menu = [] # First call to refresh() will fill in the menu.

    def connect(self, address, collection_name):
        from pdis.todo.todo_access import ToDoAccess

        self.db = ToDoAccess(address, collection_name)
        self.db.listen(self.notify) # Set up callback for change notifications.

    def loop(self):
        try:
            self.lock.wait()
            while not self.exit_flag:
                self.refresh()
                self.lock.wait()
        finally:
            self.db.close()

    def close(self):
        restore_state(self.saved_state)

    def abort(self):
        # Exit-key handler.
        self.exit_flag = True
        self.lock.signal()

    def notify(self):
        # Handler for database change notifications.
        self.dirty = True
        self.lock.signal()

    def refresh(self):
        if not self.dirty:
            return
        self.dirty = False

        # Note selected item.
        current_item = self.get_current_item()

        # Get updated data.
        self.data = self.db.snapshot()

        if not self.data:
            content = [u"(Empty)"]
        else:
            content = [format(item) for item in self.data]

        if current_item in self.data:
            # Update the displayed data, retaining the previous selection.
            index = self.data.index(current_item)
            appuifw.app.body.set_list(content, index)
        else:
            # Previously selected item is no longer present, so allow
            # the selection to be reset.
            appuifw.app.body.set_list(content)

        if not self.data:
            appuifw.app.menu = [self.menu_new]
        else:
            appuifw.app.menu = [self.menu_new,
                                self.menu_view,
                                self.menu_toggle,
                                self.menu_delete]

    def handle_new(self):
        from pdis.todo.todo_item import ToDoItem

        text = appuifw.query(u"Enter text:", "text")
        if text:
            new_item = ToDoItem()
            new_item.set_summary(text)
            self.db.store_type()
            self.db.create(new_item)

    def handle_toggle(self):
        item = self.get_current_item()
        if item is not None:
            status_index = get_status_index(item)
            if status_index == 0:
                status_index = 1
            else:
                status_index = 0

            modified_item = item.clone()
            modified_item.set_status(standard_status_strings[status_index])
            self.db.modify(modified_item)

    def handle_delete(self):
        item = self.get_current_item()
        if item is not None:
            if appuifw.query(u'Delete "%s"?' % item.get_summary(), "query"):
                if len(self.data) == 1:
                    self.db.clear_type()
                self.db.kill(item)

    def handle_view(self):
        item = self.get_current_item()
        if item is None:
            return
        item = item.clone()

        summary = unicode(item.get_summary())
        status_index = get_status_index(item)
        categories = unicode(join_categories(item.get_categories()))

        content = [(u"Summary", "text", summary),
                   (u"Status", "combo", (pretty_status_strings, status_index)),
                   (u"Categories", "text", categories)]

        f = appuifw.Form(content, appuifw.FFormDoubleSpaced)
        f.save_hook = lambda content: self._save(item, content)
        f.execute()

    def _save(self, item, content):
        [(label, type, summary),
         (label, type, (choices, status_index)),
         (label, type, categories)] = content

        summary = summary.strip()
        if not summary:
            appuifw.note(u"Summary field required.", "error")
            return False

        item.set_summary(summary)
        item.set_status(standard_status_strings[status_index])
        item.set_categories(split_categories(categories))

        self.db.modify_and_update_header(item)
        return True

    def get_current_item(self):
        # Return currently selected item, or None if the list is empty.
        if not self.data:
            return None
        current = appuifw.app.body.current()
        return self.data[current]

def main(collection = "todo", address = ("tcp", "localhost", 35800)):
    app = ToDoApp(u"To Do: %s" % collection)
    try:
        e32.ao_yield()
        app.connect(address, collection)
        app.loop()
    finally:
        app.close()

if __name__ == "__main__":
    from pdis.access.pdis_url import parse_pdis_url

    init_logging(FileLogger("todo.txt"))

    try:
        url = u"pdis://localhost/todo"
        while True:
            url = appuifw.query(u"Enter URL of to-do list:", "text", url)
            if url is None:
                break

            address, name = parse_pdis_url(url)
            if not name:
                appuifw.note(u"Incomplete URL.", "error")
                continue

            main(name, address)
            break
    except:
        log_exception()
        appuifw.note(u"Fatal error.", "error")

    close_all_managers()
