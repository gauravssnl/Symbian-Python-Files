# Copyright (c) 2006 Jurgen Scheible
# read location id

import appuifw
import e32
import location


def main_menu_setup():
    appuifw.app.menu = [(u"get location", gsm_location)]


def gsm_location() :
    (mcc, mnc, lac, cellid) = location.gsm_location()
    
    print u"MCC: " + unicode(mcc)
    print u"MNC: " + unicode(mnc)
    print u"LAC: " + unicode(lac)
    print u"Cell id: " + unicode(cellid)


def exit_key_handler():
    global script_lock
    script_lock.signal()
    appuifw.app.set_exit()
    

script_lock = e32.Ao_lock()

appuifw.app.title = u"Get cell-id"

#appuifw.app.body = appuifw.Text(u"Press Options button below ...")

main_menu_setup()
appuifw.app.exit_key_handler = exit_key_handler
script_lock.wait()


 

