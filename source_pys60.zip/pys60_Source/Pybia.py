#by Shrim
class Game:
 def __init__(s):
  import appuifw,graphics,e32,mbm
  s.A,s.G,s.E=appuifw,graphics.Image,e32
  s.A.app.body=s.body=s.A.Canvas(event_callback=s.callback)
  s.A.app.screen='full'
  s.body.text((70,110),u'loading...')
  s.E.ao_yield()
  mbmpath=str(s.A.app.full_name())[:-3]+'mbm'
  s.fon=mbm.image(mbmpath,0)
  green=mbm.image(mbmpath,1)
  s.male=mbm.image(mbmpath,2)
  s.male_m=mbm.image(mbmpath,3)
  s.ekran=s.G.new(s.fon.size)
  s.trava=s.G.new((160,160))
  for x in range(0,160,20):
   for y in range(0,160,20):s.trava.blit(green,target=(x,y),source=((0,0),green.size))
  s.aktiv=0
  s.pole=[0,0]
  s.chel=[120,[0,0,0,0]]
  s.draw('down')
 def callback(s,event):
  if not s.aktiv:
   if event['keycode']==50 or event['keycode']==63497:s.draw('up')
   elif event['keycode']==52 or event['keycode']==63495:s.draw('left')
   elif event['keycode']==54 or event['keycode']==63496:s.draw('right')
   elif event['keycode']==56 or event['keycode']==63498:s.draw('down')
 def draw(s,arg):
  s.aktiv+=1
  if arg=='up':
   if s.pole[1]>0:s.pole[1]-=5
   else:s.pole[1]=20
   if s.aktiv==1:
    if s.chel[1][0]:s.chel[0],s.chel[1][0]=20,0
    else:s.chel[0],s.chel[1][0]=40,1
   else:s.chel[0]=0
  elif arg=='left':
   if s.pole[0]>0:s.pole[0]-=5
   else:s.pole[0]=20
   if s.aktiv==1:
    if s.chel[1][1]:s.chel[0],s.chel[1][1]=200,0
    else:s.chel[0],s.chel[1][1]=220,1
   else:s.chel[0]=180
  elif arg=='right':
   if s.pole[0]<20:s.pole[0]+=5
   else:s.pole[0]=0
   if s.aktiv==1:
    if s.chel[1][2]:s.chel[0],s.chel[1][2]=80,0
    else:s.chel[0],s.chel[1][2]=100,1
   else:s.chel[0]=60
  elif arg=='down':
   if s.pole[1]<20:s.pole[1]+=5
   else:s.pole[1]=0
   if s.aktiv==1:
    if s.chel[1][3]:s.chel[0],s.chel[1][3]=140,0
    else:s.chel[0],s.chel[1][3]=160,1
   else:s.chel[0]=120
  s.ekran.blit(s.fon)
  s.ekran.blit(s.trava,target=(2,2),source=(s.pole,(140+s.pole[0],140+s.pole[1])))
  s.ekran.blit(s.male,target=(62,62),source=((s.chel[0],0),(s.chel[0]+20,20)),mask=s.male_m)
  s.body.blit(s.ekran)
  if s.aktiv==1:s.E.ao_sleep(0.2),s.draw(arg)
  else:s.E.ao_sleep(0.1);s.aktiv=0
Game()
