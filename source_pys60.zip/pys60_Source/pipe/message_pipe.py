#
# pdis.pipe.message_pipe
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Bidirectional message pipe over TCP or other byte stream

A message pipe is a bidirectional communication session supporting
one-way messages and pipelined request-response message exchanges.
More precisely, a MessagePipe instance is an endpoint of such a
communication session.

This implementation is based on a bidirectional byte stream in the
form of the interface defined by pdis.socket.blocking_socket.  It has
specifically been designed to allow compatibility with a future
implementation based instead on BEEP.

A session carries reliable message streams bidirectionally.  Messages
are of four types: one-way messages, requests, replies and error
replies.  However, because one-way messages and requests both map
into MSG messages in BEEP, we do the same here and require that the
application protocol define how to distinguish between one-way
messages and request messages.

Also for compatibility with BEEP, we require that replies be
transmitted in the same order as the corresponding requests.

The contents of each message is zero or more octet strings.

Each message pipe endpoint utilizes two internal threads, one for
inbound messages and the other for outbound messages.  The inbound-side
thread informs the application of arriving messages directly via a
callback interface.  The outbound-side thread processes messages from
an outbound queue, where outbound one-way messages are deposited
by invocations of send() and outbound requests are deposited by
invocations of call().  These invocations can be intermixed and
made concurrently from multiple threads.

Because the inbound-side thread is used both for delivering callbacks
(receive and shutdown) and for processing replies, the callback
handler should be non-blocking.  Moreover, invoking call() on the same
message pipe from the handler will result in a deadlock.  (In the case
of a startup callback, the inbound-side thread is not yet running, and
thus call() would fail to return because the reply is not processed.)
"""

import time
from Queue import Queue

try:
    from UIQueue import UIQueue
except ImportError:
    from Queue import Queue as UIQueue

from pdis.lib import logging
from pdis.lib.compat import sum
from pdis.lib.best_threading import *
from pdis.lib.priority import set_thread_priority
from pdis.socket.safe_socket import SafeSocket
from pdis.socket.buffered_stream import BufferedStream
from pdis.socket.transport_registry import connect, listen
from pdis.pipe.message_pipe_exceptions import *

use_ui_queue = False

class _MessagePipeInfo:
    """
    Blackboard for information attached to a message pipe.

    Each message pipe has an instance of this class in pipe.info.
    """
    def __init__(self, initiator):
        self.initiator = initiator
        self.packets_in = 0
        self.packets_out = 0
        self.bytes_in = 0
        self.bytes_out = 0
        self.start_timestamp = self.last_timestamp = time.time()

class _MessagePipe:
    """
    Endpoint of a bidirectional communication session

    Message pipes are normally created by instantiating a MessagePipeServer
    at one peer and then invoking connect_client() at the other peer.
    A session can be closed by invoking the close() method of either
    endpoint.

    The call() method conducts a request-reply exchange, while send()
    sends off a one-way message and reply() sends the reply for a
    request-reply exchange.

    Startup, message handler (receive), and shutdown callbacks can be
    specified with the"startup", "receive", and "shutdown" keyword
    arguments, respectively, when instantiating a MessagePipeServer
    or calling connect_client().  These must be callables with the
    following signatures:

        startup(message_pipe, **keyword_args)
        receive(message_pipe, message_number, *payload)
        shutdown(message_pipe)

    The startup callback is invoked from the MessagePipeServer thread
    or the connect_client() call before the message pipe's internal
    inbound-side thread is started.  The receive callback is invoked
    by the message pipe's inbound-side thread whenever a one-way
    message is received.  It must call reply() (or cause it to be
    called) if and only if the message was sent by invoking call().
    The shutdown callback is invoked by the inbound-side thread
    after the connection has been deactivated.

    Callback handlers are permitted to make calls to send() and to
    close() (with no timeout).  They must not invoke call() on the
    same message pipe.

    A handler object can be specified using the "target" keyword,
    in which case the three callbacks are set to target.startup,
    target.receive, and target.shutdown.

    The callbacks are stored as the instance variables "startup_callback",
    "receive_callback", and "shutdown_callback".  It is possible for
    the startup callback to set up the receive and shutdown callbacks.
    """

    _count = 0

    def __init__(self, stream, initiator, target=None,
                 startup=None, receive=None, shutdown=None,
                 **keys):
        """
        Initialize a communication session.

        The first argument must be a BufferedStream, which will
        subsequently be managed by the message pipe.

        The iniator argument is a boolean indicating whether this is
        the initiating endpoint.

        Startup, receive, and shutdown callbacks can be specified with
        individual keyword arguments, or all three can be mapped to
        methods of a handler object by specifying the"target" keyword
        argument.

        Any other keyword arguments are passed along to the startup
        callback.
        """
        self.info = _MessagePipeInfo(initiator)

        self._stream = stream
        self._keys = keys

        self.receive_callback = receive
        self.startup_callback = startup
        self.shutdown_callback = shutdown
        if target is not None:
            if not self.receive_callback:
                self.receive_callback = target.receive
            if not self.startup_callback:
                self.startup_callback = target.startup
            if not self.shutdown_callback:
                self.shutdown_callback = target.shutdown

        self._closed = False
        self._last_msgno = 0
        self._call_queue = Queue()
        self._outbound_queue = Queue()

        self._desired_priority = 0
        self._inbound_priority = None
        self._outbound_priority = None

        self._mutex = allocate_lock()
        self._mutex.acquire()
        try:
            self.__class__._count += 1
            self.id = self.__class__._count
        finally:
            self._mutex.release()

        self._connected = False

    def connect(self):
        assert not self._connected
        self._connected = True

        if self.startup_callback:
            try:
                self.startup_callback(self, **self._keys)
            except:
                self._closed = True
                self._stream.close()
                raise

        self.outbound_thread = start_thread(
            target = self._outbound_loop,
            name = "outbound-message-pipe-thread-%d" % self.id)

        self.inbound_thread = start_thread(
            target = self._inbound_loop,
            name = "inbound-message-pipe-thread-%d" % self.id)

    def get_priority(self):
        return self._desired_priority

    def set_priority(self, priority):
        self._desired_priority = priority

    def is_closed(self):
        """
        Determine if the message pipe has been closed.
        """
        return self._closed

    def close(self, timeout=0):
        """
        Close the communication session.

        Calling close() will close the message pipe at both ends.  It
        can be called more than once.

        This closes the message pipe abruptly.  A best-effort attempt
        is made to send buffered outbound messages, but buffered
        inbound messages will not be received.

        If a nonzero timeout is specified, close() will block until
        the message pipe has been completely shut down, or until the
        specified number of seconds has expired.  Do not specify a
        timeout when calling close() from a callback, since the
        shutdown will not complete while the inbound-side thread
        is blocked.
        """
        self._close()
        if timeout > 0:
            self._wait(timeout)

    def _close(self):
        self._mutex.acquire()
        try:
            if self._closed:
                return
            self._closed = True

            # Release the outbound thread and any calling threads.
            # The inbound thread will exit when it reads end-of-file.
            self._outbound_queue.put(None)
            while not self._call_queue.empty():
                msgno, response_queue = self._call_queue.get()
                response_queue.put(None)
        finally:
            self._mutex.release()

    def _wait(self, timeout):
        # The following is derived from code in Queue.py in Python 2.3.4.
        delay = 0.0005               # 500 us -> initial delay of 1 ms
        endtime = time.time() + timeout
        while self.outbound_thread or self.inbound_thread:
            remaining = endtime - time.time()
            if remaining <= 0:
                break
            delay = min(delay * 2, remaining, .05)
            time.sleep(delay)

        if self.outbound_thread:
            logging.logwrite("Message pipe outbound thread failed to exit"
                             " within %s seconds." % timeout)
        if self.inbound_thread:
            logging.logwrite("Message pipe inbound thread failed to exit"
                             " within %s seconds." % timeout)

    def call(self, *payload):
        """
        Send a request to our peer and wait for a response.

        This queues the message for transmission, waits for a
        response, which must contain one octet string, and returns
        this string.  A SessionClosed exception is raised if the
        message pipe has been closed.
        """
        return self.call_returning_list(*payload)[0]

    def call_returning_list(self, *payload):
        """
        Send a request to our peer and wait for a response.

        This queues the message for transmission, waits for a
        response, and returns the response payload -- a list of octet
        strings.  A SessionClosed exception is raised if the message
        pipe has been closed.
        """
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            msgno = self._next_msgno()
            if use_ui_queue:
                response_queue = UIQueue(1)
            else:
                response_queue = Queue(1)

            self._call_queue.put((msgno, response_queue))
            self._send("MSG", msgno, payload)
        finally:
            self._mutex.release()

        result = response_queue.get()
        if self._closed:
            raise SessionClosed

        response_type, response_payload = result
        if response_type == "ERR":
            raise Fault(*response_payload)
        else:
            assert response_type == "RPY"
            return response_payload

    def send(self, *payload):
        """
        Send a one-way message to our peer.

        This queues the message for transmission and then returns
        immediately with the message number as the return value.
        A SessionClosed exception is raised if the message pipe has
        been closed.
        """
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            msgno = self._next_msgno()
            self._send("MSG", msgno, payload)
            return msgno
        finally:
            self._mutex.release()

    def reply(self, msgno, *payload):
        """
        Send a reply to our peer.

        This queues the message for transmission and then returns
        immediately.  A SessionClosed exception is raised if the
        message pipe has been closed.
        """
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            self._send("RPY", msgno, payload)
        finally:
            self._mutex.release()

    def fault(self, msgno, code, message):
        """
        Send an error reply to our peer.

        This queues the message for transmission and then returns
        immediately.  A SessionClosed exception is raised if the
        message pipe has been closed.
        """
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            self._send("ERR", msgno, [str(code), message])
        finally:
            self._mutex.release()

    def _next_msgno(self):
        self._last_msgno += 1
        return self._last_msgno

    def _send(self, type, msgno, payload):
        for s in payload:
            if not isinstance(s, str):
                raise TypeError, "Expected string."
        self._outbound_queue.put((type, msgno, payload))

    def _receive(self, type, msgno, payload):
        if type == "MSG":
            try:
                if self.receive_callback:
                    self.receive_callback(self, msgno, *payload)
            except Fault, e:
                # This is for the convenience of synchronous handlers.
                # Asynchronous handlers will have to call fault() themselves.
                # Note that this will result in a protocol error on the client
                # side if the client is not expecting a reply.
                self.fault(msgno, e.code, e.message)
        elif type == "RPY" or type == "ERR":
            if self._call_queue.empty():
                raise ProtocolError
            expected_msgno, response_queue = self._call_queue.get()
            if msgno != expected_msgno:
                raise ProtocolError
            response_queue.put((type, payload))
        else:
            raise ProtocolError

    def _outbound_loop(self):
        try:
            self.__outbound_loop()
        except:
            logging.log_exception("Exception in outbound message pipe thread.")

        self.outbound_thread = None

    def __outbound_loop(self):
        try:
            while True:
                if self._outbound_priority != self._desired_priority:
                    self._outbound_priority = self._desired_priority
                    set_thread_priority(self._outbound_priority)

                data = self._outbound_queue.get()
                if data is None:
                    break

                type, msgno, payload = data
                profile = "".join([" %d" % len(s) for s in payload])
                header = "%s %d%s\r\n" % (type, msgno, profile)
                self._write(header)
                for part in payload:
                    self._write(part)
                self._write("END\r\n")
                self._stream.flush()
                self.info.packets_out += 1
                self.info.last_timestamp = time.time()
        finally:
            self._close()
            try:
                self._stream.close()
            except:
                # E.g., socket error 107: Transport endpoint is not connected.
                logging.log_exception("Got exception on connection close.")

    def _write(self, data):
        self._stream.write(data)
        self.info.bytes_out += len(data)

    def _inbound_loop(self):
        try:
            self.__inbound_loop()
        except:
            logging.log_exception("Exception in inbound message pipe thread.")

        self.inbound_thread = None

    def __inbound_loop(self):
        try:
            while True:
                if self._inbound_priority != self._desired_priority:
                    self._inbound_priority = self._desired_priority
                    set_thread_priority(self._inbound_priority)

                # Read header.
                header = self._stream.readline()
                if not header:
                    return

                # Parse header.
                if not header.endswith("\r\n"):
                    raise ProtocolError
                header = header[:-2]
                fields = header.split(" ")
                if len(fields) < 2:
                    raise ProtocolError
                type = fields.pop(0)
                for field in fields:
                    if not field.isdigit():
                        raise ProtocolError
                msgno = int(fields.pop(0))
                profile = map(int, fields)

                # Read payload.
                payload = []
                for length in profile:
                    s = self._stream.read(length)
                    if len(s) < length:
                        return
                    payload.append(s)

                # Read trailer.
                trailer = self._stream.read(5)
                if len(trailer) < 5:
                    return
                if trailer != "END\r\n":
                    raise ProtocolError

                self.info.packets_in += 1
                self.info.bytes_in += len(header) + sum(profile) + 7

                # Dispatch inbound message.
                if not self._closed:
                    self._receive(type, msgno, payload)

                self.info.last_timestamp = time.time()
        finally:
            self._close()
            if self.shutdown_callback:
                self.shutdown_callback(self)

class MessagePipeServer:
    """
    Message pipe server

    A message pipe server listens for incoming connections using
    an internal thread and instantiates a message pipe for each
    connection it accepts.
    """
    def __init__(self, address, wrapper=None, **keys):
        """
        Initialize and start a message pipe server.

        The server address should be of the form (transport, params...),
        and more particularly, ("tcp", host, port) for TCP.  The host
        will most typically be the empty string, signifying that
        connections should be accepted from all interfaces.

        Any keyword arguments will be passed along when the message
        pipe is initialized.
        """
        self.address = address
        self.wrapper = wrapper
        self.keyword_arguments = keys
        self.server = listen(address)
        self.thread = start_thread(
            target = self._loop,
            name = "message-pipe-server-thread")

    def close(self, timeout=0):
        """
        Shut down the message pipe server.

        Whether this also closes the message pipes created by this
        server is undefined and will be determined by the implementation.

        If a nonzero timeout is specified, close() will block until
        the message pipe server has shut down, or until the specified
        number of seconds has expired.
        """
        self.server.close()
        if timeout > 0:
            self._wait(timeout)

    def _wait(self, timeout):
        # The following is derived from code in Queue.py in Python 2.3.4.
        delay = 0.0005               # 500 us -> initial delay of 1 ms
        endtime = time.time() + timeout
        while self.thread:
            remaining = endtime - time.time()
            if remaining <= 0:
                break
            delay = min(delay * 2, remaining, .05)
            time.sleep(delay)

        if self.thread:
            logging.logwrite("Message pipe server thread failed to exit"
                             " within %s seconds." % timeout)

    def _loop(self):
        try:
            while True:
                endpoint = self.server.accept()
                logging.logwrite("Accepting connection on %s." % repr(self.address))
                stream = BufferedStream(SafeSocket(endpoint))
                # The message pipe we create here will be referenced
                # by its own internal threads, so it will stick around.
                pipe = _MessagePipe(stream, False, **self.keyword_arguments)
                if self.wrapper is not None:
                    pipe = self.wrapper(pipe)
                pipe.connect()
        except ServerTerminated:
            logging.logwrite("Message pipe server exiting.")
        except:
            logging.log_exception("Exception in message pipe server thread.")

        self.thread = None

def connect_client(address, wrapper=None, **keys):
    """
    Return a new message pipe connected to a listening server.

    The address to connect to should be of the form (trasport, params...).
    For TCP, that would be ("tcp", host, port).

    Any keyword arguments will be passed along when the message pipe
    is initialized.

    The message pipe's startup callback will have been called by the
    time this method returns.
    """
    endpoint = connect(address)
    stream = BufferedStream(SafeSocket(endpoint))
    pipe = _MessagePipe(stream, True, **keys)
    if wrapper is not None:
        pipe = wrapper(pipe)
    pipe.connect()
    return pipe
