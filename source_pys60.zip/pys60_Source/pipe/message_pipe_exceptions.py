#
# pdis.pipe.message_pipe_exceptions
#
# Copyright 2003-2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from pdis.socket.socket_exceptions import *

class MessagePipeError(SocketError):
    """
    Base class for all message-pipe-related exceptions.
    """
    pass

class ProtocolError(MessagePipeError):
    """
    Exception indicating that a fatal protocol error has occurred.

    This is mainly used internally within the message pipe implementation,
    but a handler function can also raise a ProtocolError to signal an
    unrecoverable error in the communication session, which is thereupon
    immediately closed.
    """
    pass

class Fault(MessagePipeError):
    """
    Server-side exception to be returned to the invoker of call().

    Note that no mechanism is implemented for returning an exception to an
    invoker of send().

    The following reply codes from the BEEP specification (RFC 3080) might
    serve as some level of guideline, although the actual reply codes will
    depend on the application:
        421     service not available
        450     requested action not taken (e.g., lock already in use)
        451     requested action aborted (e.g., local error in processing)
        454     temporary authentication failure
        500     general syntax error (e.g., poorly-formed XML)
        501     syntax error in parameters (e.g., non-valid XML)
        504     parameter not implemented
        530     authentication required
        534     authentication mechanism (e.g., too weak, sequence exhausted, etc.)
        535     authentication failure
        537     action not authorized for user
        538     authentication mechanism requires encryption
        550     requested action not taken (e.g., no requested profiles are acceptable)
        553     parameter invalid
        554     transaction failed (e.g., policy violation)
    """
    def __init__(self, code, message):
        MessagePipeError.__init__(self)
        self.code = str(code)
        self.message = message

    def __repr__(self):
        return "<Fault %s: %s>" % (self.code, repr(self.message))

    __str__ = __repr__
