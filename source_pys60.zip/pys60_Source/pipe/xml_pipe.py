#
# pdis.pipe.xml_pipe
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Message pipe with XML-RPC-style marshalling and unmarshalling

A message pipe is a bidirectional communication session supporting
one-way messages and pipelined request-response message exchanges.
See pdis.pipe.message_pipe for more information.

Regarding unicode:

Unicode strings (type "unicode") are marshalled as utf-8, and octet
strings (type "str") are assumed to be encoded in utf-8 (if they
include characters outside 7-bit ascii).  Strings including only
characters within 7-bit ascii are unmarshalled as octet strings,
while all others are unmarshalled as unicode strings.

Although strings received from an XML pipe are thus never utf-8-encoded,
this cannot be relied upon if utf-8-encoded strings may be passed in,
because the alternative loopback pipe implementation passes them
through as-is.

The usual convention is to allow any string to be represented as a
unicode string, and to require it for strings including characters
outside of 7-bit ascii.  However, if a string represents an XML document,
we generally allow it to be represented as either a unicode string or a
utf-8-encoded octet string.
"""

try:
    from xmlrpclib import dumps, loads
except ImportError:
    from pdis.pipe.xmlrpc_marshal import dumps, loads

from pdis.pipe.message_pipe_exceptions import *
from pdis.pipe import message_pipe

class _XMLPipe:
    """
    Message pipe with XML-RPC-style marshalling and unmarshalling

    This provides call(), send() and reply() methods that support
    marshalling of typed parameters and results as in XML-RPC.  The
    call2(), send2() and reply2() methods provide an alternative
    interface enabling adding binary attachments to messages.

    A receive callback handler must have the following signature:

        receive(message_pipe, message_number,
                method_name, parameter_list, *attachments)

    Otherwise this interface is as in pdis.pipe.message_pipe.
    """
    def __init__(self, pipe):
        self.pipe = pipe
        self.info = pipe.info

        self.startup_callback = pipe.startup_callback
        self.receive_callback = pipe.receive_callback
        self.shutdown_callback = pipe.shutdown_callback

        pipe.startup_callback = self._startup
        pipe.receive_callback = self._receive
        pipe.shutdown_callback = self._shutdown

    def connect(self):
        self.pipe.connect()

    def get_priority(self):
        return self.pipe.get_priority()

    def set_priority(self, priority):
        self.pipe.set_priority(priority)

    def is_closed(self):
        return self.pipe.is_closed()

    def close(self, timeout=0):
        self.pipe.close(timeout)

    def call(self, method, *params):
        """
        Send a request to our peer and wait for a reply.

        The value passed back in the reply is returned.
        """
        xml = dumps(tuple(params), methodname=method)
        returned_xml = self.pipe.call(xml)
        ((result,), nothing) = loads(returned_xml)
        return result

    def send(self, method, *params):
        """
        Send a one-way message to our peer.
        """
        xml = dumps(tuple(params), methodname=method)
        return self.pipe.send(xml)

    def reply(self, msgno, result):
        """
        Send a reply to our peer.
        """
        xml = dumps((result,), methodresponse=1)
        self.pipe.reply(msgno, xml)

    def fault(self, msgno, code, message):
        """
        Send an error reply to our peer.
        """
        self.pipe.fault(msgno, code, message)

    def call2(self, method, params, *attachments):
        """
        Send a request to our peer and wait for a reply.

        This alternate form of call() enables including binary
        attachments in the request and reply messages.  The return
        value is a list whose first element is the value included in
        the reply and whose remaining elements are any attachments
        also included in the reply.
        """
        xml = dumps(tuple(params), methodname=method)
        result_list = self.pipe.call_returning_list(xml, *attachments)
        ((result,), nothing) = loads(result_list[0])
        result_list[0] = result
        return result_list

    def send2(self, method, params, *attachments):
        """
        Send a one-way message to our peer.

        This alternate form of send() enables including binary
        attachments in the message.
        """
        xml = dumps(tuple(params), methodname=method)
        return self.pipe.send(xml, *attachments)

    def reply2(self, msgno, result, *attachments):
        """
        Send a reply to our peer.

        This alternate form of reply() enables including binary
        attachments in the message.
        """
        xml = dumps((result,), methodresponse=1)
        self.pipe.reply(msgno, xml, *attachments)

    def _startup(self, pipe, **keys):
        if self.startup_callback:
            self.startup_callback(self, **keys)

    def _receive(self, pipe, msgno, xml, *attachments):
        (params, method) = loads(xml)
        if self.receive_callback:
            self.receive_callback(self, msgno, method, params, *attachments)

    def _shutdown(self, pipe):
        if self.shutdown_callback:
            self.shutdown_callback(self)

def PipeServer(address, **keys):
    """
    Start and return a new message pipe server.
    """
    return message_pipe.MessagePipeServer(
        address, wrapper=_XMLPipe, **keys)

def connect_client(address, **keys):
    """
    Return a new message pipe connected to a listening server.
    """
    return message_pipe.connect_client(
        address, wrapper=_XMLPipe, **keys)
