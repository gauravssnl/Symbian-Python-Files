#
# pdis.pipe.loopback_pipe
#
# Copyright 2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Simple message pipe implementation for intraprocess communication

This interface is compatible with pdis.pipe.xml_pipe (not
pdis.pipe.message_pipe).
"""

import time
from Queue import Queue

from pdis.lib import logging
from pdis.lib.best_threading import *
from pdis.lib.priority import set_thread_priority
from pdis.pipe.message_pipe_exceptions import *

class _LoopbackPipeInfo:
    """
    Blackboard for information attached to a message pipe.

    Each message pipe has an instance of this class in pipe.info.
    """
    def __init__(self, initiator):
        self.initiator = initiator
        self.packets_in = 0
        self.packets_out = 0
        self.bytes_in = 0               # Not used.
        self.bytes_out = 0              # Not used.
        self.start_timestamp = self.last_timestamp = time.time()

class _LoopbackPipe:

    _count = 0

    def __init__(self, outbound, inbound, initiator, target=None,
                 startup=None, receive=None, shutdown=None,
                 **keys):
        self._outbound = outbound
        self._inbound = inbound

        self.info = _LoopbackPipeInfo(initiator)
        self._keys = keys

        self.receive_callback = receive
        self.startup_callback = startup
        self.shutdown_callback = shutdown
        if target is not None:
            if not self.receive_callback:
                self.receive_callback = target.receive
            if not self.startup_callback:
                self.startup_callback = target.startup
            if not self.shutdown_callback:
                self.shutdown_callback = target.shutdown

        self._closed = False
        self._last_msgno = 0
        self._call_queue = Queue()

        self._desired_priority = 0
        self._inbound_priority = None

        self._mutex = allocate_lock()
        self._mutex.acquire()
        try:
            self.__class__._count += 1
            self.id = self.__class__._count
        finally:
            self._mutex.release()

        self._connected = False

    def connect(self):
        assert not self._connected
        self._connected = True

        if self.startup_callback:
            try:
                self.startup_callback(self, **self._keys)
            except:
                self._closed = True
                raise

        self.inbound_thread = start_thread(
            target = self._inbound_loop,
            name = "inbound-message-pipe-thread-%d" % self.id)

    def get_priority(self):
        return self._desired_priority

    def set_priority(self, priority):
        self._desired_priority = priority

    def is_closed(self):
        """
        Determine if the message pipe has been closed.
        """
        return self._closed

    def close(self, timeout=0):
        """
        Close the communication session.

        Calling close() will close the message pipe at both ends.  It
        can be called more than once.

        This closes the message pipe abruptly.  A best-effort attempt
        is made to send buffered outbound messages, but buffered
        inbound messages will not be received.

        If a nonzero timeout is specified, close() will block until
        the message pipe has been completely shut down, or until the
        specified number of seconds has expired.  Do not specify a
        timeout when calling close() from a callback, since the
        shutdown will not complete while the inbound-side thread
        is blocked.
        """
        self._close()
        if timeout > 0:
            self._wait(timeout)

    def _close(self):
        self._mutex.acquire()
        try:
            if self._closed:
                return
            self._closed = True

            # Send an end-of-file and release any calling threads.
            # The inbound thread will exit when it reads end-of-file.
            self._send_eof()
            while not self._call_queue.empty():
                msgno, response_queue = self._call_queue.get()
                response_queue.put(None)
        finally:
            self._mutex.release()

    def _wait(self, timeout):
        # The following is derived from code in Queue.py in Python 2.3.4.
        delay = 0.0005               # 500 us -> initial delay of 1 ms
        endtime = time.time() + timeout
        while self.inbound_thread:
            remaining = endtime - time.time()
            if remaining <= 0:
                break
            delay = min(delay * 2, remaining, .05)
            time.sleep(delay)

        if self.inbound_thread:
            logging.logwrite("Loopback pipe inbound thread failed to exit"
                             " within %s seconds." % timeout)

    def call(self, method, *params):
        """
        Send a request to our peer and wait for a reply.

        The value passed back in the reply is returned.
        """
        return self.call2(method, params)[0]

    def send(self, method, *params):
        """
        Send a one-way message to our peer.
        """
        return self.send2(method, params)

    def reply(self, msgno, result):
        """
        Send a reply to our peer.
        """
        self.reply2(msgno, result)

    def fault(self, msgno, code, message):
        """
        Send an error reply to our peer.

        This queues the message for transmission and then returns
        immediately.  A SessionClosed exception is raised if the
        message pipe has been closed.
        """
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            self._send("ERR", msgno, [str(code), message])
        finally:
            self._mutex.release()

    def call2(self, method, params, *attachments):
        """
        Send a request to our peer and wait for a reply.

        This alternate form of call() enables including binary
        attachments in the request and reply messages.  The return
        value is a list whose first element is the value included in
        the reply and whose remaining elements are any attachments
        also included in the reply.
        """
        return self._call_returning_list((method, params), *attachments)

    def send2(self, method, params, *attachments):
        """
        Send a one-way message to our peer.

        This alternate form of send() enables including binary
        attachments in the message.
        """
        payload = [(method, params)] + list(attachments)
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            msgno = self._next_msgno()
            self._send("MSG", msgno, payload)
            return msgno
        finally:
            self._mutex.release()

    def reply2(self, msgno, result, *attachments):
        """
        Send a reply to our peer.

        This alternate form of reply() enables including binary
        attachments in the message.
        """
        payload = [result] + list(attachments)
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            self._send("RPY", msgno, payload)
        finally:
            self._mutex.release()

    def _call_returning_list(self, *payload):
        self._mutex.acquire()
        try:
            if self._closed:
                raise SessionClosed
            msgno = self._next_msgno()
            response_queue = Queue(1)

            self._call_queue.put((msgno, response_queue))
            self._send("MSG", msgno, payload)
        finally:
            self._mutex.release()

        result = response_queue.get()
        if self._closed:
            raise SessionClosed

        response_type, response_payload = result
        if response_type == "ERR":
            raise Fault(*response_payload)
        else:
            assert response_type == "RPY"
            return list(response_payload) # Convert from tuple.

    def _next_msgno(self):
        self._last_msgno += 1
        return self._last_msgno

    def _send(self, type, msgno, payload):
        self._outbound.put((type, msgno, payload))
        self.info.packets_out += 1
        self.info.last_timestamp = time.time()

    def _send_eof(self):
        self._outbound.put(None)

    def _receive(self, type, msgno, payload):
        if type == "MSG":
            try:
                if self.receive_callback:
                    method, params = payload[0]
                    attachments = payload[1:]
                    self.receive_callback(self, msgno, method, params, *attachments)
            except Fault, e:
                # This is for the convenience of synchronous handlers.
                # Asynchronous handlers will have to call fault() themselves.
                # Note that this will result in a protocol error on the client
                # side if the client is not expecting a reply.
                self.fault(msgno, e.code, e.message)
        elif type == "RPY" or type == "ERR":
            if self._call_queue.empty():
                raise ProtocolError
            expected_msgno, response_queue = self._call_queue.get()
            if msgno != expected_msgno:
                raise ProtocolError
            response_queue.put((type, payload))
        else:
            raise ProtocolError

    def _inbound_loop(self):
        try:
            self.__inbound_loop()
        except:
            logging.log_exception("Exception in inbound loopback pipe thread.")

        self.inbound_thread = None

    def __inbound_loop(self):
        try:
            while True:
                if self._inbound_priority != self._desired_priority:
                    self._inbound_priority = self._desired_priority
                    set_thread_priority(self._inbound_priority)

                message = self._inbound.get()
                if not message:
                    return

                self.info.packets_in += 1

                if not self._closed:
                    self._receive(*message)

                self.info.last_timestamp = time.time()
        finally:
            self._close()
            if self.shutdown_callback:
                self.shutdown_callback(self)

servers = {}

class PipeServer:
    """
    Loopback message pipe server

    A message pipe server listens for incoming connections using
    an internal thread and instantiates a message pipe for each
    connection it accepts.
    """
    def __init__(self, address, **keys):
        """
        Initialize and start a loopback message pipe server.

        The server address should be a tuple of the form

            ("loopback", [server_name])

        where the server name defaults to "default".

        Any keyword arguments will be passed along when the message
        pipe is initialized.
        """
        self.address = address
        self.keyword_arguments = keys

        self.terminated = False
        self.queue = Queue()

        name = _parse_address(address)
        servers[name] = self

        self.thread = start_thread(
            target = self._loop,
            name = "loopback-pipe-server-thread")

    def close(self, timeout=0):
        """
        Shut down the message pipe server.

        In this implementation, this does not also close the message
        pipes created by this server.

        If a nonzero timeout is specified, close() will block until
        the message pipe server has shut down, or until the specified
        number of seconds has expired.
        """
        if not self.terminated:
            self.terminated = True
            self.queue.put(None)     # Cause accept() to fall through.

        if timeout > 0:
            self._wait(timeout)

    def _wait(self, timeout):
        # The following is derived from code in Queue.py in Python 2.3.4.
        delay = 0.0005               # 500 us -> initial delay of 1 ms
        endtime = time.time() + timeout
        while self.thread:
            remaining = endtime - time.time()
            if remaining <= 0:
                break
            delay = min(delay * 2, remaining, .05)
            time.sleep(delay)

        if self.thread:
            logging.logwrite("Loopback pipe server thread failed to exit"
                             " within %s seconds." % timeout)

    def _loop(self):
        try:
            while True:
                if self.terminated:
                    raise ServerTerminated
                connection = self.queue.get()
                if self.terminated:
                    raise ServerTerminated
                logging.logwrite("Accepting connection on %s." % repr(self.address))

                # The message pipe we create here will be referenced
                # by its own internal thread, so it will stick around.
                pipe = _LoopbackPipe(connection[1], connection[0],
                                     False, **self.keyword_arguments)
                pipe.connect()
        except ServerTerminated:
            logging.logwrite("Loopback pipe server exiting.")
        except:
            logging.log_exception("Exception in loopback pipe server thread.")

        self.thread = None

def connect_client(address, **keys):
    """
    Return a new loopback message pipe connected to a listening server.

    The address to connect to should be a tuple of the form

        ("loopback", [server_name])

    where the server name defaults to"default".

    Any keyword arguments will be passed along when the message pipe
    is initialized.

    The message pipe's startup callback will have been called by the
    time this method returns.
    """
    name = _parse_address(address)
    server = servers[name]
    connection = (Queue(), Queue())
    server.queue.put(connection)
    pipe = _LoopbackPipe(connection[0], connection[1], True, **keys)
    pipe.connect()
    return pipe

def _parse_address(address):
    if address[0] != "loopback":
        raise ValueError, "Bad address: %s" % repr(address)

    if len(address) < 2:
        return "default"
    else:
        return address[1]
