#KeyTalker_v1.20 by Газетдинов Альберт,G.F.Ferre,Great_dr.Karkar

import os,e32,sys,appuifw

RU=lambda text:text.decode('utf-8')

INF=lambda mess:appuifw.note(RU(mess),"info",1)
ERR=lambda mess:appuifw.note(RU(mess),"error",1)

def internet(name):
	appuifw.Content_handler().open_standalone(sys.argv[0][0]+u':\\system\\apps\\KeyTalker\\'+name)

def screen(menu=[],body=None,stack=[]):
	if menu and body:
		stack.append((appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.body))
		appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.body=menu,menu[-1][1],body
	else:
		appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.body=stack.pop()

class sets:
	def __init__(self):
		self.path=sys.argv[0][0]+':\\system\\apps\\KeyTalker\\KeyTalker.set'
		self.keys=[]
		try:
			for line in open(self.path,'rb').read().split('\n'):
				key,value=line.split('=')
				setattr(self,key,eval(value))
				self.keys.append(key)
		except:
			ERR('Ошибка при загрузки настроек')
			os.abort()
	def save(self):
		open(self.path,'wb').write('\n'.join([key+'='+repr(getattr(self,key)) for key in self.keys]))
sets=sets()

class error:
	flag=0
	def write(self,text):
		if self.flag:
			appuifw.app.body.add(RU(text))
		else:
			self.flag=1
			mess='Произошла ошибка в программе KeyTalker v1.20'
			ERR(mess)
			screen([
				(RU('Выйти'),os.abort)],
				appuifw.Text(RU(mess)+u'.\n'+RU('Отправьте нижеследующий текст разработчикам.\n')))
			appuifw.app.body.color=(255,0,0)
sys.stderr=error()

try:
	import appswitch
except:
	ERR('Отсутсвует модуль appswitch')
	os.abort()

import audio,keycapture

sets.STANDBY=""
for app in appswitch.application_list(1):
	for name in (u"Phone",u"Telephone",RU('Телефон'),"Standby",RU('Реж. ожид.'),RU('Режим ожид.'),RU('Реж. ожидания'),RU('Режим ожидания')):
		if app==name:
			sets.STANDBY=name
if not sets.STANDBY:
	ERR("Программа не поддерживает ваш телефон")
	os.abort()

try:
	sets.WAVES=[audio.Sound.open(unicode(sys.argv[0][0]+":\\system\\apps\\KeyTalker\\sounds\\"+str(index)+".wav")) for index in range(10)]
except:
	ERR("Ошибка при загрузки звуковых файлов")
	os.abort()

def callback(key):
	if appswitch.application_list(1)[0]==sets.STANDBY:
		try:
			sets.WAVES[key-0x30].set_volume(sets.VOLUME)
			sets.WAVES[key-0x30].play()
		except:
			pass

def settings():
	form=appuifw.Form([
		(RU('Громкость'),"combo",([unicode(index) for index in range(sets.WAVES[0].max_volume()+1)],sets.VOLUME))],
		appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced)
	form.execute()
	sets.VOLUME=int(form[0][2][1])
	sets.save()

capture=keycapture.KeyCapturer(callback)
capture.keys=(0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39)
capture.forwarding=1
capture.start()

screen([
	(RU('Настройки'),settings),
	(RU('О программе'),lambda:screen([
		(RU('www.mobi.ru'),lambda:internet('wwwmobi.html')),
		(RU('wap.mobimag.ru'),lambda:internet('wapmobi.html')),
		(RU('Назад'),screen)],
		appuifw.Text(RU('Название:\n	KeyTalker v1.20\nРазработчики:\n	Газетдинов Альберт\n	G.F.Ferre\n	Great_dr.Karkar\nКоординаты:\n	www.mobi.ru\n	wap.mobimag.ru\n	tarlovka@rambler.ru')))),
	(RU('Выйти'),lambda:appuifw.query(RU('Выйти из программы?'),'query') and os.abort())],
	appuifw.Text(RU('	Программа озвучивает голосом нажатие цифровых клавиш при наборе номера. Для выполнения этой функции программа должна быть постоянно запущена. В настройках можно изменить громкость звука.')))

if sys.argv[0].lower().find('\\python\\')!=-1:
	appuifw.app.title=u'KeyTalker'
	lock=e32.Ao_lock()
	os.abort=lock.signal
	lock.wait()