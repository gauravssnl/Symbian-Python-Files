#script by Madjel
#e-mail: madjel@mail.ru
#icq: 239954573
import appuifw
import e32

def ru(x): return x.decode('utf-8')

#добавляем заголовок программы
appuifw.app.title=(ru('ТЕСТ№1'))

#функция о производителе, выводит всплывающее сообщение
def about():
    appuifw.note(ru('Сделал madjel icq: 239954573'))
    menu()

#функция о сути теста, выводится как текст в отдельном окне
def abouttest():
  t.color=0x0000ff
  t.set(ru(' Вашему вниманию представляется тест, определяющий тип личности человека. Тест взят из одного популярного журнала. Состоит тест из 30 вопросов, на которые необходимо отвечать либо "Да", либо "Нет". P.S. Автор не несет ответственности за полученные результаты :) '))
  appuifw.app.menu = [(ru('Назад'),menu)]

Menu = [ru('Начать'),ru('Информация о Тесте'),ru('Об авторе'),ru('Выход')]

#функция меню, вызывает меню
def menu():
    x = appuifw.selection_list(Menu)
    if x == 0: vop1()
    elif x == 1: abouttest()
    elif x == 2: about()
    elif x == 3: exit()

#функции, которые выводят 30 вопросов теста
def vop1():
  t.color=0x3333ff
  t.set(ru('1. Легко ли Вы привыкаете к новой обстановке?'))
  appuifw.app.menu = [(ru('Да'),da1), (ru('Нет'),net1)]
def vop2():
  t.color=0x3333ff
  t.set(ru('2. Любите ли Вы модно одеваться?'))
  appuifw.app.menu = [(ru("Да"),da2), (ru('Нет'),net2)]
def vop3():
  t.color=0x3333ff
  t.set(ru('3. Любите ли вы шумное общество?'))
  appuifw.app.menu = [(ru("Да"),da3), (ru('Нет'),net3)]
def vop4():
  t.color=0x3333ff
  t.set(ru('4. С большой ли охотой посещаете рестораны?'))
  appuifw.app.menu = [(ru("Да"),da4), (ru('Нет'),net4)]
def vop5():
  t.color=0x3333ff
  t.set(ru('5. Рассказываете ли Вы друзьям о своих отношениях с женщинами?'))
  appuifw.app.menu = [(ru("Да"),da5), (ru('Нет'),net5)]
def vop6():
  t.color=0x3333ff
  t.set(ru('6. Хотели бы Вы занимать руководящий пост?'))
  appuifw.app.menu = [(ru("Да"),da6), (ru('Нет'),net6)]
def vop7():
  t.color=0x3333ff
  t.set(ru('7. Считаете ли Вы, что за деньги можно купить почти всё, что угодно?'))
  appuifw.app.menu = [(ru("Да"),da7), (ru('Нет'),net7)]
def vop8():
  t.color=0x3333ff
  t.set(ru('8. Считаете ли Вы себя человеком энергичным?'))
  appuifw.app.menu = [(ru("Да"),da8), (ru('Нет'),net8)]
def vop9():
  t.color=0x3333ff
  t.set(ru('9. Нравится ли Вам работа по дому?'))
  appuifw.app.menu = [(ru("Да"),da9), (ru('Нет'),net9)]
def vop10():
  t.color=0x3333ff
  t.set(ru('10. Считаете ли Вы, что, прежде всего, следует обеспечить себя, а потом уже думать обо всем остальном?'))
  appuifw.app.menu = [(ru("Да"),da10), (ru('Нет'),net10)]
def vop11():
  t.color=0x3333ff
  t.set(ru('11. Легко ли Вы рискуете?'))
  appuifw.app.menu = [(ru("Да"),da11), (ru('Нет'),net11)]
def vop12():
  t.color=0x3333ff
  t.set(ru('12. Сможете ли Вы ударить женщину?'))
  appuifw.app.menu = [(ru("Да"),da12), (ru('Нет'),net12)]
def vop13():
  t.color=0x3333ff
  t.set(ru('13. Легко ли Вы идёте на выяснение отношений?'))
  appuifw.app.menu = [(ru("Да"),da13), (ru('Нет'),net13)]
def vop14():
  t.color=0x3333ff
  t.set(ru('14. Вам очень нравится спорт?'))
  appuifw.app.menu = [(ru("Да"),da14), (ru('Нет'),net14)]
def vop15():
  t.color=0x3333ff
  t.set(ru('15. Могли бы вы убить человека, если бы не опасались наказания?'))
  appuifw.app.menu = [(ru("Да"),da15), (ru('Нет'),net15)]
def vop16():
  t.color=0x3333ff
  t.set(ru('16. Считаете ли вы, что для женщин внешность - главное?'))
  appuifw.app.menu = [(ru("Да"),da16), (ru('Нет'),net16)]
def vop17():
  t.color=0x3333ff
  t.set(ru('17. Сможете ли Вы встречаться с женщиной,которая Вам не нравится?'))
  appuifw.app.menu = [(ru("Да"),da17), (ru('Нет'),net17)]
def vop18():
  t.color=0x3333ff
  t.set(ru('18. Пользуетесь ли Вы успехом у женщин?'))
  appuifw.app.menu = [(ru("Да"),da18), (ru('Нет'),net18)]
def vop19():
  t.color=0x3333ff
  t.set(ru('19. Часто ли Вы говорите комплименты женщинам?'))
  appuifw.app.menu = [(ru("Да"),da19), (ru('Нет'),net19)]
def vop20():
  t.color=0x3333ff
  t.set(ru('20. Считаете ли Вы, что за любовь надо платить?'))
  appuifw.app.menu = [(ru("Да"),da20), (ru('Нет'),net20)]
def vop21():
  t.color=0x3333ff
  t.set(ru('21. Вас интересует философские вопросы бытия?'))
  appuifw.app.menu = [(ru("Да"),da21), (ru('Нет'),net21)]
def vop22():
  t.color=0x3333ff
  t.set(ru('22. Верите лит Вы в любовь?'))
  appuifw.app.menu = [(ru("Да"),da22), (ru('Нет'),net22)]
def vop23():
  t.color=0x3333ff
  t.set(ru('23. Много ли времени Вы уделяете чтению книг?'))
  appuifw.app.menu = [(ru("Да"),da23), (ru('Нет'),net23)]
def vop24():
  t.color=0x3333ff
  t.set(ru('24. Можете ли Вы,долго заниматься делом,которое не приносит материальной выгоды?'))
  appuifw.app.menu = [(ru("Да"),da24), (ru('Нет'),net24)]
def vop25():
  t.color=0x3333ff
  t.set(ru('25. Считаете ли Вы,что женщина должна пользоваться такой же свободой, как и мужчина?'))
  appuifw.app.menu = [(ru("Да"),da25), (ru('Нет'),net25)]
def vop26():
  t.color=0x3333ff
  t.set(ru('26. Слушаете ли Вы советы друзей?'))
  appuifw.app.menu = [(ru("Да"),da26), (ru('Нет'),net26)]
def vop27():
  t.color=0x3333ff
  t.set(ru('27. В целом Вы доверяете людям?'))
  appuifw.app.menu = [(ru("Да"),da27), (ru('Нет'),net27)]
def vop28():
  t.color=0x3333ff
  t.set(ru('28. Легко ли Вам ради друга пожертвовать своими интересами?'))
  appuifw.app.menu = [(ru("Да"),da28), (ru('Нет'),net28)]
def vop29():
  t.color=0x3333ff
  t.set(ru('29. Вы думаете, что успех зависит в большей степени от обстоятельств, чем от Вас самого?'))
  appuifw.app.menu = [(ru("Да"),da29), (ru('Нет'),net29)]
def vop30():
  t.color=0x3333ff
  t.set(ru('30. Легко ли Вы забываете обиды?'))
  appuifw.app.menu = [(ru("Да"),da30), (ru('Нет'),net30)]

#функции, отвечающие за подсчет ответов "Да" и "Нет"
def da1():
  global x1,y1
  y1=0
  x1=0
  x1=x1+1
  vop2()
def net1():
  global y1,x1
  x1=0
  y1=0
  y1=y1+1
  vop2()
def da2():
  global x1,y1
  x1=x1+1
  vop3()
def net2():
  global y1,x1
  y1=y1+1
  vop3()
def da3():
  global x1,y1
  x1=x1+1
  vop4()
def net3():
  global y1,x1
  y1=y1+1
  vop4()
def da4():
  global x1,y1
  x1=x1+1
  vop5()
def net4():
  global y1,x1
  y1=y1+1
  vop5()
def da5():
  global x1,y1,z1
  x1=x1+1
  if x1>y1: z1=1
  else: z1=0
  vop6()
def net5():
  global y1,x1,z1
  y1=y1+1
  if x1>y1: z1=1
  else: z1=0
  vop6()

def da6():
  global x2,y2
  x2=0
  y2=0
  x2=x2+1
  vop7()
def net6():
  global y2,x2
  x2=0
  y2=0
  y2=y2+1
  vop7()
def da7():
  global x2,y2
  x2=x2+1
  vop8()
def net7():
  global y2,x2
  y2=y2+1
  vop8()
def da8():
  global x2,y2
  x2=x2+1
  vop9()
def net8():
  global y2,x2
  y2=y2+1
  vop9()
def da9():
  global x2,y2
  x2=x2+1
  vop10()
def net9():
  global y2,x2
  y2=y2+1
  vop10()
def da10():
  global x2,y2,z2
  x2=x2+1
  if x2>y2: z2=1
  else: z2=0
  vop11()
def net10():
  global y2,x2,z2
  y2=y2+1
  if x2>y2: z2=1
  else: z2=0
  vop11()

def da11():
  global x3,y3
  x3=0
  y3=0
  x3=x3+1
  vop12()
def net11():
  global y3,x3
  x3=0
  y3=0
  y3=y3+1
  vop12()
def da12():
  global x3,y3
  x3=x3+1
  vop13()
def net12():
  global y3,x3
  y3=y3+1
  vop13()
def da13():
  global x3,y3
  x3=x3+1
  vop14()
def net13():
  global y3,x3
  y3=y3+1
  vop14()
def da14():
  global x3,y3
  x3=x3+1
  vop15()
def net14():
  global y3,x3
  y3=y3+1
  vop15()
def da15():
  global x3,y3,z3
  x3=x3+1
  if x3>y3: z3=1
  else: z3=0
  vop16()
def net15():
  global y3,x3,z3
  y3=y3+1
  if x3>y3: z3=1
  else: z3=0
  vop16()

def da16():
  global x4,y4
  x4=0
  y4=0
  x4=x4+1
  vop17()
def net16():
  global y4,x4
  x4=0
  y4=0
  y4=y4+1
  vop17()
def da17():
  global x4,y4
  x4=x4+1
  vop18()
def net17():
  global y4,x4
  y4=y4+1
  vop18()
def da18():
  global x4,y4
  x4=x4+1
  vop19()
def net18():
  global y4,x4
  y4=y4+1
  vop19()
def da19():
  global x4,y4
  x4=x4+1
  vop20()
def net19():
  global y4,x4
  y4=y4+1
  vop20()
def da20():
  global x4,y4,z4
  x4=x4+1
  if x4>y4: z4=1
  else: z4=0
  vop21()
def net20():
  global y4,x4,z4
  if x4>y4: z4=1
  else: z4=0
  y4=y4+1
  vop21()

def da21():
  global x5,y5
  x5=0
  y5=0
  x5=x5+1
  vop22()
def net21():
  global y5,x5
  x5=0
  y5=0
  y5=y5+1
  vop22()
def da22():
  global x5,y5
  x5=x5+1
  vop23()
def net22():
  global y5,x5
  y5=y5+1
  vop23()
def da23():
  global x5,y5
  x5=x5+1
  vop24()
def net23():
  global y5,x5
  y5=y5+1
  vop24()
def da24():
  global x5,y5
  x5=x5+1
  vop25()
def net24():
  global y5,x5
  y5=y5+1
  vop25()
def da25():
  global x5,y5,z5
  x5=x5+1
  if x5>y5: z5=1
  else: z5=0
  vop26()
def net25():
  global y5,x5,z5
  if x5>y5: z5=1
  else: z5=0
  y5=y5+1
  vop26()

def da26():
  global x6,y6
  x6=0
  y6=0
  x6=x6+1
  vop27()
def net26():
  global y6,x6
  x6=0
  y6=0
  y6=y6+1
  vop27()
def da27():
  global x6,y6
  x6=x6+1
  vop28()
def net27():
  global y6,x6
  y6=y6+1
  vop28()
def da28():
  global x6,y6
  x6=x6+1
  vop29()
def net28():
  global y6,x6
  y6=y6+1
  vop29()
def da29():
  global x6,y6
  x6=x6+1
  vop30()
def net29():
  global y6,x6
  y6=y6+1
  vop30()
def da30():
  global x6,y6,z6
  x6=x6+1
  if x6>y6: z6=1
  else: z6=0
  rasch()
def net30():
  global y6,x6,z6
  y6=y6+1
  if x6>y6: z6=1
  else: z6=0
  rasch()

#функция рассчета и определения конечного результата
def rasch():
  global ot,z1,z2,z3,z4,z5,z6
  ot1='молодой талантливый сын века'
  ot2='уязвленный честолюбец' 
  ot3='противоречивая личность с порочными наклонностями'  
  ot4='раскаявшийся грешник' 
  ot5='мягкий интеллигент'
  ot6='невинный ягнёнок' 
  ot7='вечный неудачник'  
  ot8='ленивый аристократ' 
  ot9='деловой человек, лишенный сентиментов'
  ot10='грубая, властная, ограниченная натура' 
  ot11='самодовольный хмырь'  
  ot12='мот и жуир, прожигатель жизни' 
  ot13='простой хороший парень'
  ot14='большой оригинал с необъяснимыми странностями' 
  ot15='ненадёжный товарищ'  
  ot16='натуральный дикарь, испорченный цивилизацией' 
  ot17='половой-гигант'
  ot18='неисправимый идеалист, витающий в облаках' 
  ot19='хитрый интриган'  
  ot20='обиженный судьбою убеждённый холостяк' 
  ot21='недалёкий дилетант с узким кругозором'
  ot22='предприимчивый авантюрист с тёмным прошлым' 
  ot23='редкий бриллиант'  
  ot24='рыцарь с подмоченной репутацией' 
  ot25='предел мечтаний любой женщины'
  ot26='коварный обольститель' 
  ot27='храбрый заяц'  
  ot28='моральный инвалид 1-ой группы' 
  ot29='однолюб-сексплуататор'
  ot30='похотливый циничный женоненавистник' 
  ot31='деспотичный учитель человечества'
  ot32='сексуальный маньяк-террорист' 
  ot33='горе, а не мужчина'  
  ot34='непризнанный гений, отягощенный комплексом неполноценности' 
  ot35='старый греховодник' 
  ot36='сердцеед с периферии' 
  ot37='рубака-парень, свой в доску' 
  ot38='лицо, не обезображенное интеллектом' 
  ot39='любитель острых ощущений' 
  ot40='белая ворона или тёмная лошадка' 
  ot41='безнадёжный жлоб с претензией на оригинальность' 
  ot42='государственный муж, погрязший в рутине' 
  ot43='кустарь-одиночка' 
  ot44='мирный обыватель' 
  ot45='добропорядочный отец семейства' 
  ot46='честный работник' 
  ot47='умный человек' 
  ot48='безбожный и хулитель без совести и чести' 
  ot49='трезвый материалист без всяких предрассудков' 
  ot50='бандит с большой дороги' 
  ot51='борец за правду с мещанским уклоном' 
  ot52='эгоистичный собственник' 
  ot53='желчный скользкий тип' 
  ot54='олух царя небесного' 
  ot55='расчётливый негодяй' 
  ot56='мрачный тиран, одержимый манией величия' 
  ot57='светский лев' 
  ot58='дитя с неразвитым вкусом' 
  ot59='персона вне всяких подозрений' 
  ot60='тайный алкоголик' 
  ot61='дамский угодник или обыкновенный бабник' 
  ot62='трогательный,сентиментальный, утончённый поклонник декаданса' 
  ot63='одарённый представитель богемы' 
  if str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111111': ot=ot1
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011111': ot=ot2
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001111': ot=ot3
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000111': ot=ot4
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000011': ot=ot5
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000001': ot=ot6
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000000': ot=ot7
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100000': ot=ot8
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110000': ot=ot9
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111000': ot=ot10
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111100': ot=ot11
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111110': ot=ot12
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111011': ot=ot13
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111010': ot=ot14
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111001': ot=ot15
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='111101': ot=ot16
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000100': ot=ot17
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000010': ot=ot18
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000110': ot=ot19
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='000101': ot=ot20
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110001': ot=ot21
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110101': ot=ot22
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110011': ot=ot23
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110110': ot=ot24
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110010': ot=ot25
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110100': ot=ot26
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='110111': ot=ot27
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001000': ot=ot28
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001110': ot=ot29
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001101': ot=ot30
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001010': ot=ot31
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001100': ot=ot32
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001001': ot=ot33
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='001011': ot=ot34
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='101000': ot=ot35
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='101111': ot=ot36
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='101101': ot=ot37
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='101110': ot=ot38
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='101100': ot=ot39
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='101011': ot=ot40
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='101010': ot=ot41
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010010': ot=ot42
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010111': ot=ot43
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010001': ot=ot44
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010011': ot=ot45
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010101': ot=ot46
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010110': ot=ot47
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010100': ot=ot48
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='010000': ot=ot49
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011000': ot=ot50
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011011': ot=ot51
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011110': ot=ot52
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011101': ot=ot53
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011001': ot=ot54
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011100': ot=ot55
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='011010': ot=ot56
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100110': ot=ot57
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100001': ot=ot58
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100101': ot=ot59
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100011': ot=ot60
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100100': ot=ot61
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100010': ot=ot62
  elif str(z1)+str(z2)+str(z3)+str(z4)+str(z5)+str(z6)=='100111': ot=ot63
  rez()

#функция вывода полученного результата на экран
def rez():
  global ot
  t.color=0x3333ff
  t.set(ru('Ваш результат : '))
  t.color=0xff0000
  t.add(ru('Вы '+str(ot)))
  appuifw.app.menu = [(ru('Меню'), menu)]

#функция выхода
def exit():
    appuifw.app.set_exit()

appuifw.app.screen='normal'

appuifw.app.body
t = appuifw.Text()
appuifw.app.body = t

#убирает моргающий курсор
appuifw.app.body.focus=False

app=e32.Ao_lock()
menu()
