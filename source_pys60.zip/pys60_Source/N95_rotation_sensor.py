#  "N95 Rotation sensor" application
# (c) Copyright 2007 Jurgen Scheible under terms of GPL

#  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Note: You need to have at least Python for S60 version 1.4.1 installed on your phone to get this to work.


import sensor, appuifw, audio, e32

sensor_type = sensor.sensors()['RotSensor']
N95_sensor = sensor.Sensor(sensor_type['id'],sensor_type['category'])
N95_sensor.set_event_filter(sensor.RotEventFilter())

def get_sensor_data(status):
    if status == sensor.orientation.TOP :
        appuifw.note(u"BOTTOM", "info")
    elif status == sensor.orientation.BOTTOM :
        appuifw.note(u"TOP", "info")   
    elif status == sensor.orientation.LEFT :
        appuifw.note(u"RIGHT", "info") 
    elif status == sensor.orientation.RIGHT :
        appuifw.note(u"LEFT", "info")

def quit():
    N95_sensor.disconnect()
    app_lock.signal()

N95_sensor.connect(get_sensor_data)
print ' Turn your phone right or left or up or down!'

appuifw.app.title = u"N95 Rotation sensor"
appuifw.app.exit_key_handler = quit
app_lock = e32.Ao_lock()
app_lock.wait()