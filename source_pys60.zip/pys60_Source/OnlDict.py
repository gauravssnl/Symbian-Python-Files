#OnlDict_v1.20 by Кулиев Абакар,Газетдинов Альберт

import os,e32,sys,appuifw

RU=lambda text:text.decode('utf-8')

INF=lambda mess:appuifw.note(RU(mess),"info",1)
ERR=lambda mess:appuifw.note(RU(mess),"error",1)

def internet(name):
	appuifw.Content_handler().open_standalone(sys.argv[0][0]+u':\\system\\apps\\RunPython\\Apps\\OnlDict\\'+name)

def screen(menu=[],body=None,stack=[]):
	if menu and body:
		stack.append((appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.body))
		appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.body=menu,menu[-1][1],body
	else:
		appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.body=stack.pop()

class sets:
	def __init__(self):
		self.path=sys.argv[0][0]+':\\system\\apps\\OnlDict\\OnlDict.set'
		self.keys=[]
		try:
			for line in open(self.path,'rb').read().split('\n'):
				key,value=line.split('=')
				setattr(self,key,eval(value))
				self.keys.append(key)
		except:
			ERR('Ошибка при загрузки настроек')
			os.abort()
	def save(self):
		open(self.path,'wb').write('\n'.join([key+'='+repr(getattr(self,key)) for key in self.keys]))
sets=sets()

class error:
	flag=0
	def write(self,text):
		if self.flag:
			appuifw.app.body.add(RU(text))
		else:
			self.flag=1
			mess='Произошла ошибка в программе OnlDict v1.20'
			ERR(mess)
			screen([
				(RU('Выйти'),os.abort)],
				appuifw.Text(RU(mess)+u'.\n'+RU('Отправьте нижеследующий текст разработчикам.\n')))
			appuifw.app.body.color=(255,0,0)
sys.stderr=error()

sets.NAMES=(
	RU('Англо-Русское'),
	RU('Русско-Английское'),
	RU('Немецко-Русское'),
	RU('Русско-Немецкое'),
	RU('Французско-Русское'),
	RU('Русско-Французское'),
	RU('Италльянско-Русское'),
	RU('Испано-Русское'),
	RU('Русско-Испанское'),
	RU('Англо-Немецкое'),
	RU('Немецко-Английское'),
	RU('Англо-Французское'),
	RU('Французско-Английское'),
	RU('Французско-Немецкое'),
	RU('Немецко-Французское'),
	RU('Англо-Испанское'),
	RU('Испанско-Английское'),
	RU('Французско-Испанское'),
	RU('Испанско-Французское'),
	RU('Англо-Португальское'),
	RU('Португальско-Английское'),
	RU('Немецко-Испанское'),
	RU('Испанско-Немецкое'),
	RU('Итальянско-Английское'))

sets.SENDS=(
	"er",
	"re",
	"gr",
	"rg",
	"fr",
	"rf",
	"ir",
	"sr",
	"rs",
	"eg",
	"ge",
	"ef",
	"fe",
	"fg",
	"gf",
	"es",
	"se",
	"fs",
	"sf",
	"ep",
	"pe",
	"gs",
	"sg",
	"ie")

def translate(mode):
	import socket
	if appuifw.app.body.len()==0:
		return ERR("Введите текст для перевода")
	try:
		sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		sock.connect((u"wap.translate.ru",80))
		sock.send("GET /wap2/translator.aspx/result/?tbDirection="+sets.SENDS[mode]+"&tbText="+appuifw.app.body.get().encode("utf-8").replace(" ","+")+"&Submit= HTTP/1.0\r\nHost: wap.translate.ru\r\nRange: bytes=0-\r\nAccept-Encoding: *//*\r\nUser-agent: Python 1.4\r\n\r\n")
		page=""
		while 1:
			load=sock.recv(8192)
			if not load:
				break
			page+=load
		sock.close()
	except:
		return ERR("Невозможно загрузить информацию. Попробуйте еще раз.")
	else:
		page=page[page.find("result")+6:]
		page=page[page.find("result")+34:]
		appuifw.app.body.set(RU(page[:page.find("</p>")-25]))

def newlist():
	result=[]
	for index in range(len(sets.NAMES)):
		if index in sets.LANGS:
			result.append(u"+ "+sets.NAMES[index])
		else:
			result.append(u"- "+sets.NAMES[index])
	return result

def check():
	index=appuifw.app.body.current()
	try:
		sets.LANGS.remove(index)
	except:
		sets.LANGS.append(index)
	appuifw.app.body.set_list(newlist(),index)

screen([
	(RU('Перевести'),lambda:screen(
		[(sets.NAMES[index],eval("lambda: translate("+str(index)+")")) for index in sets.LANGS]+
		[(RU('Назад'),screen)],
		appuifw.Text())),
	(RU('Настройки'),lambda:screen([
		(RU('Изменить'),check),
		(RU('Назад'),lambda:sets.save() or screen())],
		appuifw.Listbox(newlist(),check))),
	(RU('О программе'),lambda:screen([
#		(RU('www.mobi.ru'),lambda:internet('wwwmobi.html')),
#		(RU('wap.mobimag.ru'),lambda:internet('wapmobi.html')),
		(RU('Назад'),screen)],
		appuifw.Text(RU('Название:\n	OnlDict v1.20\nРазработчики:\n	Кулиев Абакар\n	Газетдинов Альберт\nКоординаты:\n	www.mobi.ru\n	wap.mobimag.ru\n	tarlovka@rambler.ru')))),
	(RU('Выйти'),lambda:appuifw.query(RU('Выйти из программы?'),'query') and os.abort())],
	appuifw.Text(RU('	Программа переводит текст с русского языка на иностранные и наоборот используя интернет сервис wap.translate.ru После нажатия на Перевести необходимо ввести текст и выбрать направление перевода (изменяются в настройках).')))

if sys.argv[0].find(u'\\Python\\')!=-1:
	appuifw.app.title=u'OnlDict'
	lock=e32.Ao_lock()
	os.abort=lock.signal
	lock.wait()