#скрипт Растабродяги
import appswitch
import e32
from graphics import *
import appuifw
from appuifw import *
import sys
def ru(x):return x.decode('utf-8')
def sleep(seconds):e32.ao_sleep(float(seconds))
appuifw.app.screen='full'

def Draw2():
   global index
   global canv
   if(index==0):
#создаем черный фон. . .
      canv.rectangle((0, 0, 176, 208), (0, 0, 0), fill = (0, 0, 0))
#картинка загрузки. . .
      canv.blit(img1,target=(0, 140))
#текст над ней. . .
      canv.text((52, 130),ru('ЗАГРУЗКА'),(200, 20, 0))
#сама загрузка(линии)
      a=1
      while a<126:   
         canv.rectangle((48, 153, a, 155), (255, 0, 0), fill = (255, 0,  0))
         canv.rectangle((48, 155, a, 157), (255, 0, 50), fill = (255, 0,  50))
         canv.rectangle((48, 157, a, 164), (200, 0, 20), fill = (200, 0, 20))
         canv.rectangle((48, 164, a, 166), (150, 0, 10), fill = (150, 0, 10))
         canv.rectangle((48, 166, a, 167), (150, 0, 10), fill = (100, 0, 5))
         sleep(0.03)
         a=a+1
#летающие рожи=)
      b=1
      while b<70:   
         canv.blit(img2,target=(72-b, b))
         sleep(0.01)
         b=b+1
      c=1
      while c<70:   
         canv.blit(img2,target=(72+c, c))
         sleep(0.01)
         c=c+1
      d=1
      while d<80:   
         canv.blit(img2,target=(72, d))
         sleep(0.01)
         d=d+1
#надпись о начале
      canv.text((52, 30),ru('НАЧНЕМ. . .'),(200, 20, 0))
      sleep(0.8)
      e=1
      while e<103:   
         canv.text((52, 30+e),ru('НАЧНЕМ. . .'),(200, 20, 0))
         sleep(0.03)
         e=e+1
      canv.text((52, 132),ru('НАЧНЕМ. . .'),(250, 50, 50))
      canv.text((52, 133),ru('НАЧНЕМ. . .'),(100, 0, 0))
      canv.text((52, 134),ru('НАЧНЕМ. . .'),(250, 250, 250))
      f=1
      while f<208:   
#капли абсента=)
         canv.blit(img3,target=(0, f))
         sleep(0)
         f=f+1
      canv.rectangle((0, 207, 176, 208), (150, 0, 10), fill = (100, 0, 5))
      g=1
      while g<208:   
         canv.blit(img3,target=(33, g+1))
         sleep(0)
         g=g+1
      canv.rectangle((0, 205, 176, 208), (150, 0, 10), fill = (100, 0, 5))
      h=1
      while h<208:   
         canv.blit(img3,target=(65, h+1))
         sleep(0)
         canv.blit(img3,target=(165, h+1))
         sleep(0)
         h=h+1
      canv.rectangle((0, 201, 176, 208), (150, 0, 10), fill = (100, 0, 5))
      i=1
      while i<208:   
         canv.blit(img3,target=(40, i+1))
         sleep(0)
         canv.blit(img3,target=(100, i))
         sleep(0)
         canv.blit(img3,target=(150, i+1))
         i=i+1
      canv.rectangle((0, 192, 176, 208), (150, 0, 10), fill = (100, 0, 5))
      j=1
      while j<208:   
         canv.rectangle((0, 0, 176, j), (150, 0, 10), fill = (100, 0, 5))
         sleep(0)
         j=j+1

def quit():
   appuifw.app.exit_key_handler=quit
         
app_lock = e32.Ao_lock()
index=0
img1 = Image.open('e:\\system\\Apps\\loading\\res\\loading.jpg')
img2 = Image.open('e:\\system\\Apps\\loading\\res\\logos.jpg')
img3 = Image.open('e:\\system\\Apps\\loading\\res\\blood.jpg')
appuifw.app.body=canv=Canvas(redraw_callback=Draw)
Draw2()
app_lock.wait()

