"""
By Watt
sanwatt@nm.ru

Пакман

"""
import e32,os,appuifw

from random import randint, choice

import thread,audio
from graphics import *


def ru(text):
 return text.decode('utf-8')

appuifw.app.screen='full'

last_key=0
def callback(event):
    global last_key
    if event['type'] == appuifw.EEventKey:
       last_key=event['keycode']



canvas=appuifw.Canvas(event_callback=callback)
appuifw.app.body=canvas
draw=Draw(canvas)

sleep = e32.ao_sleep

dir='e:\\system\\apps\\RunPython\\Apps\\Pac_man\\Media\\'


ipak=Image.open(dir+'pacman.jpg')

goroh=audio.Sound.open(dir+"goroh.wav")

ho=audio.Sound.open(dir+"ho.wav")

bonus=audio.Sound.open(dir+"bonus.wav")

cry=audio.Sound.open(dir+"cry.wav")


def sv():
 global stenka
 s=choice([1,2,3,4])
 stenka=Image.open(dir+'sten'+str(s)+'.jpg')

def stena(x,y):
  canvas.blit(stenka,target=(x,y))


# Рисуем Колобка
class PM:
 def __init__(self):
   self.r=0; self.r1=230; self.r2=-200
 def pak(self,x,y,x2=0,y2=0,ris=0,pkx=0,pky=0):
  if x2: draw.ellipse((x2+1,y2+1,x2+13,y2+13),0xffffff,0xffffff)

  if pky: 
   #self.r1=240; self.r2=120
 
   draw.ellipse((x+1,y+1,x+13,y+13),0x0,0xffcc55)
   if pky==-4: draw.line((x+6,y+8,x+6,y+11),0,width=2)
   else:
    draw.point((x+4,y+6),0,width=2)
    draw.point((x+8,y+6),0,width=2)
    draw.arc((10,10,50,50),0,0)

  else:
   if pkx==4: self.r1=20; self.r2=-40
   if pkx==-4: self.r1=230; self.r2=-200
   draw.pieslice((x+1,y+1,x+13,y+13),(self.r1-self.r)*0.0174,(self.r2+self.r)*0.0174,0x0,0xffcc55)
   self.r+=10
   if self.r >=40: self.r=0
   draw.point((x+6,y+3),0,width=2) 

PM=PM()
pak=PM.pak

# Счетчик
class St:
 def __init__(self):
  self.sh=0; self.g=0;self.obs=0
 def sch(self,h=0,pk=0):
   self.sh+=h
   draw.rectangle((10,192,60,206),0xffffff,0xffffff)
   draw.text((15,206),unicode(str(self.sh+self.obs)),0xdd2222,font=u'Acb14')
   if pk:
    for i in xrange(Pac.z):
     pak(150-i*15,193,ris=1)
    draw.text((65,204),u'LEVEL-'+unicode(str(Lev.lev+1)),0x2222dd,font=u'LatinPlain12')
   if self.sh==self.g: ebc(f=1)


St=St()

# Класс координат для Колобка и пауков
class Baza:
  
 def __init__(self):
  self.sx=self.sy=self.ssx=self.ssy=self.k_x=self.k_y=self.kx=self.ky=self.m=0

 def vch(self,x,y,o=1,p=0):
  mx=self.k_x; my=self.k_y
  if o: self.kx+=x/4; self.ky+=y/4
  if abs(self.kx)==4: self.kx=0
  if abs(self.ky)==4: self.ky=0
  self.ssx=self.sx; self.ssy=self.sy
  self.sx+=x; self.sy+=y
  if x>0 or y>0: self.k_x=(self.sx+12)/16; self.k_y=(self.sy+12)/16
  else: self.k_x=self.sx/16; self.k_y=self.sy/16
 
  koor=k[self.k_y][self.k_x]
  if not koor:
   self.sx-=x; self.sy-=y; self.kx-=x/4; self.ky-=y/4; self.k_x=mx; self.k_y=my
  else:
   if p:     
    pak(self.sx,self.sy,self.ssx,self.ssy,pkx=x,pky=y)
   else:
    if self.ssx: 
     draw.rectangle((self.ssx,self.ssy,self.ssx+14,self.ssy+14),0xffffff,0xffffff) 
    for i in ls:   
       if 0< k[self.k_y+i[1]][self.k_x+i[0]] <3: gor((self.k_x+i[0])*16,(self.k_y+i[1])*16)
       elif k[self.k_y+i[1]][self.k_x+i[0]]==3: bon((self.k_x+i[0])*16,(self.k_y+i[1])*16)
    pauk(self.sx,self.sy,Pac.pop)
    if B_p.k_x == self.k_x and B_p.k_y == self.k_y and not Pac.pop:
     Pac.kz=0
  if p:
   if 0<koor<4 and self.kx==0 and self.ky==0:
     if koor !=1:
       k[self.k_y][self.k_x]=5
       if koor==3: 
        Pac.pop=0x2222aa; thread.start_new_thread(tim,()) 
        if Menu.zv: bonus.play()
     else:k[self.k_y][self.k_x]=4    
     St.sch(1)
     #if koor !=3: goroh.play()
     
 # выбор пути паука 
 def cho(self):
  if self.kx==0 and self.ky==0:
   self.lt=[]
   for i in ls:
     if k[self.k_y+i[1]][self.k_x+i[0]]:
       self.lt.append(i)  
   self.m=choice(self.lt)
  if Pac.kz: self.vch(self.m[0]*4,self.m[1]*4)
  

B_p=Baza()


def tim():
 sleep(10)
 Pac.pop=0

# Управление Колобком
class Pac:
 def __init__(self):
  self.x=self.y=self.kz=self.pop=0; self.z=3; self.sp=-1

 def job(self):
  if not self.kz: ebc()
  while 1:
   if not self.kz: ebc()

   for i in range(len(list)):
     if last_key==list[i]: self.x=ls[i][0]*4;self.y=ls[i][1]*4
   x=self.x; y=self.y
   for e in xrange(4):
     if not Pac.kz: break
     B_p.vch(x,y,p=1)
     for i in range(len(list)):
       if last_key==list[i]: self.x=ls[i][0]*4;self.y=ls[i][1]*4
     sleep(0.1)
 
Pac=Pac()


list=[63498,63496,63497,63495]

ls=[[0,1],[1,0],[0,-1],[-1,0]]

def gor(x,y):
  draw.ellipse((x+4,y+4,x+11,y+11),fill=0x33cc33)


def bon(x,y):
  draw.ellipse((x+3,y+3,x+12,y+12),fill=0xff3333)



def pauk(x,y,c):
  draw.line((x+2,y+12,x+14,y+1),0xff0000)
  draw.line((x+1,y+1,x+13,y+13),0xff0000)
  draw.line((x,y+7,x+14,y+7),0xff0000)
  draw.ellipse((x+3,y+4,x+12,y+14),fill=c)
  draw.ellipse((x+4,y+2,x+11,y+8),fill=c)

speed=[0.08,0.04,0.03,0.0157,0.012,0.008]


# Создаем пауков, max 6 штук
class fka:
 def  __init__(self):
   self.s1=self.s2=self.s3=self.s4=self.s5=self.s6=0
 def sss(self,x,y):
   for kl in self.__dict__:
     if not self.__dict__[kl]:
      self.__dict__[kl]=Baza()
      self.__dict__[kl].k_x=x; self.__dict__[kl].k_y=y; self.__dict__[kl].vch(x*16,y*16,0); Pac.sp+=1; break
  
fka=fka()


# Обработка уровня 0-стена 1-паук 2-горох 3-бонус 6-колобок
def mat(k,t=1):
 Pac.sp=-1; PM.r=0; PM.r1=230; PM.r2=-200
 for i in range(len(k)):
   for ii in range(len(k[i])):    
     if not k[i][ii]: stena(ii*16,i*16) 
     elif k[i][ii]==2: 
       gor(ii*16,i*16)
       if t:St.g+=1
     elif k[i][ii]==4: fka.sss(ii,i)
     elif k[i][ii]==6: B_p.k_x=ii; B_p.k_y=i; B_p.vch(ii*16,i*16,0,p=1)
     elif k[i][ii]==1: 
       fka.sss(ii,i)
       if t: St.g+=1
     elif k[i][ii]==3:
       bon(ii*16,i*16)
       if t: St.g+=1


# чтение уровней
class Lev:
 def __init__(self):
  self.lev=0
 def levels(self):
  sv()
  fo=open(dir+'levels','r')
  level=fo.readlines()
  fo.close()
  if len(level)<self.lev+1:self.lev=0;St.obs=0
  level=level[self.lev]
  return eval(level)

 def confi(self,o='r',z=1):
   fo=open(dir+'conf',o)
   if o=='r':
    con=fo.readlines()
    self.lev=eval(con[0])
    St.obs=eval(con[1])
   else:
     if z: fo.write(str(self.lev)+'\n'+str(St.obs))
     else: fo.write(u'0\n0')
   fo.close()


Lev=Lev()

Pac.kz=1

# конец уровня
def ebc(f=0,a=1):
 Pac.kz=0
 sleep(0.5)
 if a:
  if Menu.zv:
   if not f: cry.play()
   else: ho.play()
   sleep(0.5)
 for key in B_p.__dict__.keys():
    B_p.__dict__[key]=0
 for klu in fka.__dict__:
    fka.__dict__[klu]=0
 canvas.clear(0xffffff)
 Pac.kz=1
 if a: 
   Pac.z-=1
   if f: Lev.lev+=1; St.obs=St.obs+St.sh; Lev.confi('w'); St.sh=0; St.g=0; Pac.z=3; start()   
   elif Pac.z: St.sch(); mat(k,0);xy()
   else: St.sh=0; St.g=0; Pac.z=3; start()
 else: St.sh=0; St.g=0

# цикл пауков
def st():
 while Pac.kz:
   for klu in fka.__dict__:
    if fka.__dict__[klu]:
      fka.__dict__[klu].cho(); sleep(speed[Pac.sp])
 

def start():
 global k
 canvas.clear(0xffffff)
 Lev.confi()
 k=Lev.levels()
 mat(k); xy()


def xy():
 St.sch(pk=1)
 thread.start_new_thread(st,())
 sleep(0.1)
 Pac.job()


def press(p=0):
 if p:
  canvas.bind(63497,lambda:Menu.menu(-10))
  canvas.bind(63498,lambda:Menu.menu(10))
  canvas.bind(63557,lambda:Menu.pusk())

 else:
  canvas.bind(63497,lambda:None)
  canvas.bind(63498,lambda:None)
  canvas.bind(63557,lambda:None)



class Menu:
 def __init__(self):
  self.y=self.zv=0
 def menu(self,y=0):
  if not self.y:
   for i in range(208):
    draw.line((0,i,176,i),i)

   canvas.blit(ipak,target=(13,30))

   draw.text((48,206),u'sanwatt@nm.ru',0x111133,font=u'Alp13')
  self.y+=y
  if self.y>40:self.y=10
  elif self.y<10:self.y=40
  a1=a2=a3=a4=0x2222dd
  if self.y==10: a2=0xffaa44
  elif self.y==20: a3=0xffaa44
  elif self.y==30: a4=0xffaa44
  else: a1=0xffaa44
  draw.text((55,120),ru('Новая игра'),a1,font=u'LatinBold12')
  draw.text((50,135),ru('Продолжить'),a2,font=u'LatinBold12')
  draw.text((72,150),ru('Звук'),a3,font=u'LatinBold12') 
  draw.text((68,165),ru('Выход'),a4,font=u'LatinBold12')
  

 def pusk(self):
  if self.y==20: zvuk()
  else:
   press()
   if self.y==10:start()
   if self.y==30: os.abort()
   else: Lev.confi('w',0);start()
 
Menu=Menu()

def zvuk():
 if Menu.zv: Menu.zv=0;s=ru('Выключен')
 else: Menu.zv=1;s=ru('Включен')
 appuifw.note(s,'info')
 sleep(0.01); Menu.y=0; Menu.menu()

app_lock = e32.Ao_lock()

def quit():
  ebc(a=0)
  Menu.y=0
  Menu.menu()
  press(1) 


appuifw.app.exit_key_handler=quit

Menu.menu()
press(1)


app_lock.wait()