print "perevod:"
print "fantom forever"
# Диктофон с функцией продолжить запись

import appuifw
import e32
#импорт звуковой модули
import audio


# определяет имя записи
filename = 'e:\\boo.wav'

#  определяет партию диктофона:
def recording():
    global S
    # открывает запись файла на примере (S)
    S=audio.Sound.open(filename)
    # делает запись с функцией остановки
    S.record()
    print "Recording on! To end it, select stop from menu!"

# определяет партию воспроизведения:
def playing():
    global S
    try:
        # открывает звуковой файл на примере (S)
        S=audio.Sound.open(filename)
        # воспроизводит звуковой файл
        S.play()
        print "Playing"
    except:
        print "Record first a sound!"

# остановка записи
def closing():
    global S
    S.stop()
    S.close()
    print "Stopped"


def exit_key_handler():
    script_lock.signal()
    appuifw.app.set_exit()
    

script_lock = e32.Ao_lock()

appuifw.app.title = u"Sound recorder"

# установка  меню
appuifw.app.menu = [(u"\u041f\u043e\u0441\u043b\u0443\u0448\u0430\u0442\u044c", playing),
                    (u"\u0417\u0430\u043f\u0438\u0441\u044c", recording),
                    (u"\u0421\u0442\u043e\u043f", closing)]

appuifw.app.exit_key_handler = exit_key_handler
script_lock.wait()


 

