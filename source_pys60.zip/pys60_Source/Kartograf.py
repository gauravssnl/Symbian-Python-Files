from appuifw import app,Canvas,query
from graphics import Image
import e32,mbm
app.body=c=Canvas()
app.screen='full'
class coloreg:
 def __init__(s):
  s.I=Image.new((176,208))
  s.I2=Image.new((16,16))
  s.I2.rectangle((0,0,16,16),0,0xff0000)
  s.X,s.Y,s.Co=0,1,0x000000
 def graph(s): 
  def b1(r):
   if r[0]=='x' and r[1]=='+':s.X+=16
   if r[0]=='x' and r[1]=='-':s.X-=16
   if r[0]=='y' and r[1]=='+':s.Y+=16
   if r[0]=='y' and r[1]=='-':s.Y-=16
   c.blit(s.I)
   c.blit(s.I2,target=(s.X,s.Y))
  def b2(index):
   s.I2=mbm.image(u'e:\\system\\apps\\kartograf\\graphics.mbm',index)
  c.bind(63557,lambda:s.I.blit(s.I2,target=(s.X,s.Y)))
  c.bind(63495,lambda:b1(['x','-']))
  c.bind(63496,lambda:b1(['x','+']))
  c.bind(63497,lambda:b1(['y','-']))
  c.bind(63498,lambda:b1(['y','+']))
  c.bind(63586,lambda:s.I.save(u'e:\\karta.png'))

  app.menu=[(u'doroga',\
((u'bok',lambda:b2(0)),\
(u'verx',lambda:b2(1)))),\

(u'perekrestok',\
((u'levo',lambda:b2(2)),\
(u'niz',lambda:b2(3)),\
(u'pravo',lambda:b2(4)),\
(u'verx',lambda:b2(5)),\
(u'4',lambda:b2(6)))),\

(u'povorot',\
((u'niz pravo',lambda:b2(7)),\
(u'niz levo',lambda:b2(8)),\
(u'levo verx',lambda:b2(9)),\
(u'pravo verx',lambda:b2(10)))),\

(u'dom',\
((u'chastnyj',lambda:b2(11)),\
(u'xruscevka',lambda:b2(12)),\
(u'mnogoetazhka',lambda:b2(13)))),\

(u'znaki',\
((u'svetofor',lambda:b2(14)),\
(u'medicina',lambda:b2(15)),\
(u'stoyjanka',lambda:b2(16)))),\
(u'voda',lambda:b2(17))]

coloreg().graph()
e32.Ao_lock().wait()