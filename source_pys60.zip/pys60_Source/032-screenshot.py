
import graphics

print "Hi there!"
img = graphics.screenshot()
img.save(u"e:\\Images\\screenshot.png")
