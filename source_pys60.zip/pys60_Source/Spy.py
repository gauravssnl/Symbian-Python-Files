import os,e32,appuifw,audio
from graphics import *

def ru(x):return x.decode('utf-8')

if not os.path.exists('e:\\spy'):os.makedirs('e:\\spy')
n=1
s=20
nm=2

def sec():
 global s
 s=appuifw.query(ru('Повторить через ? секунд'),'number')

def num():
 global nm
 nm=appuifw.query(ru('Сколько скринов?'),'number')

def st():
 global n,s,nm
 e32.start_exe(u"z:\\system\\programs\\apprun.exe",u"\"E:\\system\\Apps\\Phone\\Phone.app")
 a=audio.Sound.open('e:\\spy\\rec.amr')
 a.record(),e32.ao_yield()
 while n<=nm:
  e32.ao_sleep(s)
  scr=screenshot()
  scr.save('e:\\spy\\'+str(n)+'.png',bpp=24)
  n+=1
 a.stop()
 appuifw.app.set_exit()

appuifw.app.menu=[(u'Start',st),(u'Seconds',sec),(u'Number',num)]