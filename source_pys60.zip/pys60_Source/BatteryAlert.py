import appuifw, e32, audio, os

def ru(x):return x.decode('utf-8')

try:
  import sysagent, miso, uikludges
except:
  appuifw.note(ru('Ошибка загрузки сторонних модулей'),'error')
  
if os.path.exists("E:\\Python\\BatAlert.aac")==1:
  pass
else:
  appuifw.note(ru('Файл звука не найден!'),'error')
  os.abort()

uikludges.set_right_softkey_text(ru('Закрыть'))
body=appuifw.Text()
appuifw.app.body=body
body.color=0x0

body.add(ru('BatteryAlert...\nby maNseries\n'))
body.add(ru('-------------------------\n'))
body.add(ru('Звук "E:\\Python\\BatAlert.aac"\n'))
body.add(ru('-------------------------\n'))
body.add(ru('>Скрипт запущен\n'))

snd=audio.Sound.open("E:\\Python\\BatAlert.aac")

def alert():
  try:
     body.add(ru('>Тревога!\n'))
     snd.play()
     try:
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
       e32.ao_sleep(1)
       miso.vibrate(500,100)
     except:
       pass
     e32.ao_sleep(10)
  except:
      appuifw.note(ru('Ошибка! Файл не найден!'),'error')
      body.add(ru('>Ошибка!\n'))

def main_f():
  running=1
  while running:
    bat=sysagent.charger_status()
    if bat==0:
       pass
    if bat==1:
       alert()
       running=0
    e32.ao_sleep(0.5)
appuifw.note(ru('Активировано'),'conf')
body.add(ru('>Активировано...\n'))
main_f()

appuifw.app.screen='normal'

app_lock = e32.Ao_lock()
app_lock.wait()