
import location
print location.gsm_location()
