#{ By zombiee }#
import miso
import hack

print u'By zombiee'
Address=0x4E #адрес процесса
ner=miso.get_hal_attr(Address) #смена приоретета на запись
print hack.peek(ner) #выводим значение процесса
hack.poke(ner,97) # записываем
print hack.peek(ner) # и выводим

#удачи в изучении