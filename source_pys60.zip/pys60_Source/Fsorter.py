#by Albert927
import e32,appuifw,uikludges,rusos,string#use rusos by Shrim
a=appuifw
abt=a.Text
abl=a.Listbox
abc=a.Canvas
an=a.note
aq=a.query
ln,cn,ab,al=[],0,0,e32.Ao_lock()
def ag(n=-1):
 global ln,cn,ll,la
 if n==-1:n=ln.pop()
 else:ln.append(cn)
 cn,a.app.screen,a.app.menu,a.app.exit_key_handler,t=n,la[n][0],ll[n],ll[n][-1][1],uikludges.set_right_softkey_text(ll[n][-1][0])
 ar()
def ar():
 global la,cn,ab
 a.app.body=ab=la[cn][1]()
def ae():
 al.signal()
 a.app.set_exit()
def amq(m):return aq(m,'query')
def amt(m,d=''):return str(aq(m,'text',d))
def amo():an(u'\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u043e')
def ame():an(u'\u041e\u0448\u0438\u0431\u043a\u0430','error')
#
import os,time
class E:
 def __init__(s,d,e):
  s.d,s.e,s.a,s.f,=d,e,0,[]
  for i in e:s.f.append([])
e=E('E:\\others\\',['.mp3','.ogg','.wav','.amr','.jpg','.gif','.avi','.3gp'])
def ge():e.a=ab.current()
#
def scbl():
 l=[]
 for i in range(0,len(e.e)):
  l.append(unicode(e.e[i][1:]+u' - '+str(len(e.f[i]))))
 return abl(l,sced)

def scd(d):
 e.f=[]
 for i in e.e:e.f.append([])
 scgd(d+':')
 ar()

def scbd():
 e.f=[]
 for i in e.e:e.f.append([])
 scgd('C:')
 scgd('E:')
 ar()

def scgd(d):
  for i in os.listdir(d):
   if i!='system':scg(d+'\\'+i)

def scg(d):
 if os.path.isfile(d):
  for i in range(0,len(e.e)):
   if string.lower(d)[-4:]==e.e[i]:
    e.f[i].append(unicode(rusos.ru(d)))
 if os.path.isdir(d):
  for i in os.listdir(d):scg(d+'\\'+i)
#
def sced():
 ge()
 ag(1)
 f=''
 for i in e.f[e.a]:f+=i+u'\n\n'
 ab.color=(0,0,0)
 ab.set(u'\u041d\u0430\u0439\u0434\u0435\u043d\u043e: '+unicode(str(len(e.f[e.a])))+u'\n\n'+f)
 ab.set_pos(0)
 ab.focus=False

def scfm(m=0):
 sd=unicode(e.d+e.e[e.a][1:]+u'\\')
 try:os.makedirs(sd)
 except:pass
 for i in e.f[e.a]:
  i=i.replace('\\\\','\\')
  try:
   e32.file_copy(sd+i.split(u'\\')[-1],i)
   if m:
    try:os.remove(i)
    except:pass
  except:pass
 if m:an(u'\u0424\u0430\u0439\u043b\u044b \u043f\u0435\u0440\u0435\u043c\u0435\u0449\u0435\u043d\u044b \u0432 \u043f\u0430\u043f\u043a\u0443\n'+sd)
 else:an(u'\u0424\u0430\u0439\u043b\u044b \u0441\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d\u044b \u0432 \u043f\u0430\u043f\u043a\u0443\n'+sd)
 e.f[e.a]=[]

def scfs():
 sd=e.d+'sorter\\'+e.e[e.a][1:]+'.txt'
 try:os.makedirs(e.d)
 except:pass
 f=open(sd,'w')
 for i in e.f[e.a]:f.write(i+u'\n')
 f.close()
 an(u'\u0421\u043f\u0438\u0441\u043e\u043a \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d \u0432 \u0444\u0430\u0439\u043b '+unicode(sd))
#
la=[['normal',scbl],['normal',abt]]
ll=[
[(u'\u0421\u043a\u0430\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c',((u'\u043e\u0431\u0430 \u0434\u0438\u0441\u043a\u0430',scbd),(u'\u0434\u0438\u0441\u043a C:',lambda:scd('C')),(u'\u0434\u0438\u0441\u043a E:',lambda:scd('E')))),
(u'\u0412\u044b\u0445\u043e\u0434',ae)],
[(u'\u0421\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u0442\u044c',scfm),
(u'\u041f\u0435\u0440\u0435\u043c\u0435\u0441\u0442\u0438\u0442\u044c',lambda:scfm(1)),
(u'\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a',scfs),
(u'\u041d\u0430\u0437\u0430\u0434',ag)]]
#
ag(0)
al.wait()