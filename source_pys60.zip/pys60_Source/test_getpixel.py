import e32
from graphics import *
import fgimage

# test getpixel:
# 1. draw something
# 2. get pixel value
# 3. draw that pixel value somewhere else

img = Image.new((176, 208))
img.point((10,10), 0x00ff00, width=10) # green
value = fgimage.getpixel(10, 10, img._bitmapapi())
img.point((20,20), value, width=1)
print hex(value)

def drawit():
    canvas.blit(img)

appuifw.app.body = canvas = appuifw.Canvas()
drawit()
e32.ao_sleep(5)
