
import appuifw

appuifw.query(u"Type a word:", "text")

appuifw.query(u"Type a number:", "number")

appuifw.query(u"Type a time:", "time")

appuifw.query(u"Type a password:", "code")

appuifw.query(u"Do you like PyS60", "query")
