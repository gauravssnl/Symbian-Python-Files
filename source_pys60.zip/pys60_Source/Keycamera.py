#script by kule
import keycapture,keypress,e32,appuifw,appswitch
appuifw.app.body=appuifw.Text()
lock = e32.Ao_lock()
def exit():
    lock.signal()
    x.stop()
    appuifw.app.set_exit()
appuifw.app.title = u'key camera'
appuifw.app.screen = 'normal'
appuifw.app.exit_key_handler=exit
x=keycapture.KeyCapturer(lambda m:keypress.simulate_key(0xf849,0xf849))
x.keys=(63560,)
x.start()
appswitch.switch_to_bg(u'keyCamera')
lock.wait()