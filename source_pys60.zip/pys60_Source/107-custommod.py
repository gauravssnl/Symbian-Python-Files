
import mymodule, appuifw

appuifw.note(u"This is the main program")
mymodule.askword()
