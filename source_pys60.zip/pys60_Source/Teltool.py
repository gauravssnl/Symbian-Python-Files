import sys
class ConsoleOutput(object):
  def __init__(s, path):
    s.path = path
    s.f = open(s.path,"w+")
    s.f.close()

  def write(s,string):
    s.f = open(s.path,"a+")
    s.f.write(string)
    s.f.close()

sys.stderr = ConsoleOutput("D:\\teltool_err")
sys.stdout = ConsoleOutput("D:\\teltool_out")

import appuifw
import e32
import os
import contacts

def ru(x):
  return x.decode('utf-8')
def ur(x):
  return x.encode('utf-8')

def printout(mess, clr = 0x0, addline = True):
  appuifw.app.body.color = clr
  appuifw.app.body.set_pos(appuifw.app.body.len())
  appuifw.app.body.add(mess)
  if addline:
    appuifw.app.body.set_pos(appuifw.app.body.len())
    appuifw.app.body.add(u"\n")
  try: appuifw.app.body.focus = False
  except: pass
  e32.ao_yield()

def anote(mess):
  appuifw.note(mess,"info")
def aerror(mess):
  appuifw.note(mess,"error")

def print_exception():
  import sys
  import traceback
  type, value, tb = sys.exc_info()
  sys.last_type = type
  sys.last_value = value
  sys.last_traceback = tb
  tblist = traceback.extract_tb(tb)
  del tblist[:1]
  list = traceback.format_list(tblist)
  if list:
    list.insert(0, u"Trace:\n")
  list[len(list):] = traceback.format_exception_only(type, value)
  tblist = tb = None
  printout(unicode(str(list).replace("\\n","\n")))

def _getname(contact):
    name1 = contact.find(u"first_name")
    name2 = contact.find(u"last_name")
    if len(name1) == 0: name1 = u""
    else:               name1 = name1[0].value
    if len(name2) == 0: name2 = u""
    else:               name2 = name2[0].value
    return name1 + u" " + name2

def _insert(contact, pt):
  numbers = contact.find(pt)
  for number in numbers:
    global codes
    for q in range(len(codes)):
      prefix = codes[q].split(u" ")[0]
      city = codes[q].split(u" ")[1]
      if number.value.find(prefix+city) != -1:
        contact.begin()
        number.value = number.value.replace(prefix+city,prefix + u"(" + city + u")")
        contact.commit()
        printout(number.value)

def Insert():
  base = contacts.open()
  appuifw.app.body.set(u"")
  ClearScreen()
  printout(ru("Подгружаю базу контактов..."))
  conts = base.find(u"")
  for contact in conts:
    printout(_getname(contact))
    _insert(contact, u"mobile_number")
    _insert(contact, u"phone_number")

  printout(ru("\nОперация добавления скобок завершена"))

def _delete(contact, pt):
  numbers = contact.find(pt)
  for number in numbers:
    if number.value.find(u"(") != -1:
       contact.begin()
       number.value = number.value.replace(u"(",u"").replace(u")",u"").replace(u"-",u"")
       contact.commit()
       printout(number.value)

def Delete():
  base = contacts.open()
  ClearScreen()
  printout(ru("Подгружаю базу контактов..."))
  conts = base.find(u"")
  for contact in conts:
    printout(_getname(contact))
    _delete(contact, u"mobile_number")
    _delete(contact, u"phone_number")
  printout(ru("\nОперация удаления скобок и дефисов завершена"))


class PrefixEditor:
  def run(s):
    s.oldbody = appuifw.app.body
    s.oldexitkeyhandler = appuifw.app.exit_key_handler
    s.oldmenu = appuifw.app.menu
    s.oldtitle = appuifw.app.title
    s.oldscreen = appuifw.app.screen
    s.canceled = False
    appuifw.app.screen = "normal"
    appuifw.app.exit_key_handler = s.CancelEnteringPrefixes
    appuifw.app.menu = [(ru("OK"),s.PrefixesEntered),
                        (ru("Отмена"),s.CancelEnteringPrefixes)]
    appuifw.app.title = ru("Ввод кодов")
    appuifw.app.body = appuifw.Text()
    
    global codes
    if len(codes) == 0:
      codes = [u"+7 916",u"8 903",u"+7 905"]
      anote(ru("Введите коды городов в точности по шаблону"))
    text = ""
    for i in range(len(codes)):
      text = text + codes[i] + "\n"
    appuifw.app.body.set(unicode(text))
    
    s.lock = e32.Ao_lock()
    s.lock.wait()
    
  def PrefixesEntered(s):
    text = appuifw.app.body.get()
    global codes
    text = text.replace(u"\u2029",u"\n")
    codes = text.split(u"\n")
    try:
      while u"" in codes:
        codes.remove(u"")
    except: pass
    anote(ru("Коды введены"))
    s.exit()
    
  def CancelEnteringPrefixes(s):
    s.canceled = True
    aerror(ru("Отменено пользователем"))
    s.exit()

  def exit(s):
    appuifw.app.body = s.oldbody
    try: appuifw.app.body.focus = False
    except: pass
    appuifw.app.exit_key_handler = s.oldexitkeyhandler
    appuifw.app.menu = s.oldmenu
    appuifw.app.title = s.oldtitle
    appuifw.app.screen = s.oldscreen
    s.lock.signal()

def InsertSkobki():
  pe = PrefixEditor()
  pe.run()
  if not pe.canceled: Insert()

def ClearScreen():
  appuifw.app.body.set(u"")
  
def _convert(contact, pt, s1, s2):
  numbers = contact.find(u"mobile_number")
  for number in numbers:
    if number.value.startswith(s1):
      contact.begin()
      number.value = s2 + number.value[len(s1):]
      contact.commit()
      printout(number.value)

def Convert():
  try:
    res = appuifw.multi_query(ru("Заменить"), ru("на"))
    if res == None:
      aerror(ru("Отменено пользователем"))
      return
    s1, s2 = res[0], res[1]
    base = contacts.open()
    ClearScreen()
    printout(ru("Подгружаю базу контактов..."))
    conts = base.find(u"")
    for contact in conts:
      printout(_getname(contact))
      _convert(contact, u"mobile_number", s1, s2)
      _convert(contact, u"phone_number", s1, s2)
    printout(ru("\nОперация изменения префикса завершена"))
  except:
    aerror(ru("Произошла ошибка"))
    raise

def _getnumbers(contact, pt):
  numbers = contact.find(pt)
  return filter(lambda x: len(x)>0, map(lambda x: x.value, numbers))
  
def DuplicatesFind():
  base = contacts.open()
  ClearScreen()
  printout(ru("Подгружаю базу контактов..."))
  conts = base.find(u"")
  printout(ru("Ищу дубликаты..."))
  dict = {}
  for contact in conts:
    name = _getname(contact)
    numbers = []
    numbers.extend(_getnumbers(contact, u"mobile_number"))
    numbers.extend(_getnumbers(contact, u"phone_number"))
    for number in numbers:
      if dict.has_key(number):
        printout("\n" + number, clr = 0xff0000)
        printout(dict[number], clr = 0x0000ff)
        printout(name, clr = 0x0000ff)
      else: dict.update({number: name})
    
  printout(ru("\nПоиск дубликатов завершен"))
  
def ShowHelp():
  try:
    helpf = open(ur(app_path+u"help.txt"),"r")
    help = helpf.read()
    helpf.close()
  except:
    aerror(ru("Файл справки не найден!"))
    return
  printout(ru(help))
  appuifw.app.body.set_pos(0)
  e32.ao_yield()
  appuifw.app.body.set_pos(140)

def Compact():
  ClearScreen()
  printout(ru("Сжимаю файл контактов. Дождитесь завершения"))
  base = contacts.open()
  base.compact()
  printout(ru("Операция завершена успешно"))
   
def About():
  authorinfo = """Produced by Atrant\natrant@front.ru"""
  anote(ru(authorinfo))
  programinfo = """Teltool v0.1"""
  anote(ru(programinfo))
  programinfo = """Обновление и обсуждение программы всегда на dimonvideo.ru"""
  anote(ru(programinfo))

def Exit():
  global script_lock
  script_lock.signal()
  if runninginstandaloneapp == True:
    appuifw.app.set_exit()

codes = []
app_path = ru(os.path.split(sys.argv[0])[0]+"\\")

runninginstandaloneapp = True
if app_path.find(ru("Python")) != -1 or app_path.find(ru("Tower")) != -1:
  runninginstandaloneapp = False

if runninginstandaloneapp == True:
  appuifw.app.body = appuifw.Text()

ShowHelp()

appuifw.app.menu = [(ru("Добавить ( )"), InsertSkobki),
                    (ru("Удалить ( ) -"), Delete),
                    (ru("Замена префиксов"), Convert),
                    (ru("Поиск дубликатов"), DuplicatesFind),
                    (ru("Сжать базу"), Compact),
                    (ru("Справка"), ShowHelp),
                    (ru("О программе"), About),
                    (ru("Выход"), Exit)]

script_lock = e32.Ao_lock()
if runninginstandaloneapp == False:
  old_handler = appuifw.app.exit_key_handler
  appuifw.app.exit_key_handler = Exit
  script_lock.wait()
  appuifw.app.exit_key_handler = old_handler

print "exited"