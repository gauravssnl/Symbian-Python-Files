import sys
class ConsoleOutput(object):
  def __init__(s, path):
    s.path = path
    s.f = open(s.path,"w+")
    s.f.close()

  def write(s,string):
    s.f = open(s.path,"a+")
    s.f.write(string)
    s.f.close()

sys.stderr = ConsoleOutput("D:\\telconvertor_err")
sys.stdout = ConsoleOutput("D:\\telconvertor_out")

import appuifw
import e32
import os
import contacts

def ru(x):
  return x.decode('utf-8')
def ur(x):
  return x.encode('utf-8')

def printout(mess, clr = 0x0, addline = True):
  appuifw.app.body.color = clr
  appuifw.app.body.set_pos(appuifw.app.body.len())
  appuifw.app.body.add(mess)
  if addline:
    appuifw.app.body.set_pos(appuifw.app.body.len())
    appuifw.app.body.add(u"\n")
  try: appuifw.app.body.focus = False
  except: pass
  e32.ao_yield()

def anote(mess):
  appuifw.note(mess,"info")
def aerror(mess):
  appuifw.note(mess,"error")

def print_exception():
  import sys
  import traceback
  type, value, tb = sys.exc_info()
  sys.last_type = type
  sys.last_value = value
  sys.last_traceback = tb
  tblist = traceback.extract_tb(tb)
  del tblist[:1]
  list = traceback.format_list(tblist)
  if list:
    list.insert(0, u"Trace:\n")
  list[len(list):] = traceback.format_exception_only(type, value)
  tblist = tb = None
  printout(unicode(str(list).replace("\\n","\n")))

def Convert():
  try:
    res = appuifw.multi_query(ru("Заменить"), ru("на"))
    if res == None:
      aerror(ru("Отменено пользователем"))
      return
    s1, s2 = res[0], res[1]
    base = contacts.open()
    printout(ru("Подгружаю базу контактов..."))
    e32.ao_yield()
    conts = base.find(u"")
    for contact in conts:
      name1 = contact.find(u"first_name")
      name2 = contact.find(u"last_name")
      if len(name1) == 0: 
         name1 = u""
      else: 
         name1 = name1[0].value
      if len(name2) == 0: 
         name2 = u""
      else: 
         name2 = name2[0].value
      printout(name1 + u" " + name2)
      i = 0
      numbers = 0
      while i < 2:
        if i == 0: 
            numbers = contact.find(u"mobile_number")
        if i == 1: 
            numbers = contact.find(u"phone_number")
        for number in numbers:
          if number.value.startswith(s1):
            contact.begin()
            number.value = s2 + number.value[len(s1):]
            contact.commit()
            printout(number.value)
            e32.ao_yield()
        i += 1
    printout(ru("\nОперация изменения префикса завершена"))
  except:
    aerror(ru("Произошла ошибка"))
    raise

def Compact():
  printout(ru("Сжимаю файл контактов. Дождитесь завершения"))
  e32.ao_yield()
  base = contacts.open()
  base.compact()
  printout(ru("Операция завершена успешно"))

def About():
  authorinfo = """Produced by Atrant\natrant@front.ru"""
  anote(ru(authorinfo))
  programinfo = """Обновление и обсуждение программы всегда на dimonvideo.ru"""
  anote(ru(programinfo))

def Exit():
  global script_lock
  script_lock.signal()
  if runninginstandaloneapp == True:
    appuifw.app.set_exit()

app_path = ru(os.path.split(sys.argv[0])[0]+"\\")

runninginstandaloneapp = True
if app_path.find(ru("Python")) != -1 or app_path.find(ru("Tower")) != -1:
  runninginstandaloneapp = False

if runninginstandaloneapp == True:
  appuifw.app.body = appuifw.Text()

printout(ru("Программа для преобразования префиксов номеров телефонов в контактной книге (например, можно заменить 8 на +7 и наоборот)"))

appuifw.app.menu = [(ru("Изменить префикс"), Convert),
                    (ru("Сжать базу"), Compact),
                    (ru("О программе"), About),
                    (ru("Выход"), Exit)]

script_lock = e32.Ao_lock()
if runninginstandaloneapp == False:
  old_handler = appuifw.app.exit_key_handler
  appuifw.app.exit_key_handler = Exit
  script_lock.wait()
  appuifw.app.exit_key_handler = old_handler

print "ok"