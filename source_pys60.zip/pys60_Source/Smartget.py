#SmartGET_v2.00 by Gazetdinov Albert (tarlovka@rambler.ru). Copyright 2007. All Rights Reserved.

import os,e32,sys,time,thread,socket,appuifw,graphics

ru=lambda text:text.decode("utf-8")
ur=lambda text:text.encode("utf-8")

if e32.s60_version_info==(1,2):
	appuifw.note(ru("Symbian 6.1 не поддерживается"),"error")
	os.abort()

class errs:
	def write(self,text,list=[]):
		if list:appuifw.app.body.add(ru(text))
		else:
			appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.body,appuifw.app.title,appuifw.app.screen=[],os.abort,appuifw.Text(),ru("Ошибка"),"normal"
			appuifw.app.body.color=0xff0000
			list.append(1)

class sets:
	__path__="c:\\system\\apps\\smartget\\"
	__sets__="sets200.dat"
	__urls__="urls.dat"
	__list__={
		"flag_load":	0,
		"flag_remove":	0,
		"down_drive":	"E:",
		"down_folder":	"Загруженные",
		"down_point":	-1,
		"down_thread":	3,
		"schd_exit":	0,
		"schd_zone":	0,
		"schd_start":	60.0,
		"schd_stop":	28740.0}
	def __init__(self):
		try:os.makedirs(self.__path__)
		except:pass
		try:
			for name,text in map(lambda line:line.split("="),open(self.__path__+self.__sets__,"r").read().splitlines()):self.__dict__[name]=eval(text)
		except:
			self.__dict__.update(self.__list__)
			self.save_sets()
		try:urls.list=[down(http,name) for http,name in eval(open(self.__path__+self.__urls__,"r").read())]
		except:urls.list=[]
	def exch(self):
		scrn.flag_body=1
		old=appuifw.app.title,appuifw.app.screen
		appuifw.app.screen="normal"
		appuifw.app.title=ru("Настройки")
		no_yes,drives,zones=[ru("нет"),ru("да")],[u"C:",u"E:"],range(-12,13,1)
		point_list,point_ipid=[u"None"]+[point["name"] for point in socket.access_points()],[point["iapid"] for point in socket.access_points()]
		try:point_pos=point_ipid.index(self.down_point)+1
		except:point_pos=0
		form=appuifw.Form([
			(ru("Количество потоков"),"combo",([unicode(index) for index in range(1,6)],self.down_thread-1)),
			(ru("Точка доступа"),"combo",(point_list,point_pos)),
			(ru("Имя диска"),"combo",(drives,drives.index(ru(self.down_drive)))),
			(ru("Имя папки"),"text",ru(self.down_folder)),
			(ru("Время старта"),"time",self.schd_start),
			(ru("Время остановки"),"time",self.schd_stop),
			(ru("Смещение времени (час)"),"combo",([unicode(index) for index in zones],zones.index(self.schd_zone))),
			(ru("Автовыход таймера"),"combo",(no_yes,self.schd_exit)),
			(ru("Автостарт добавленной"),"combo",(no_yes,self.flag_load)),
			(ru("Автоудаление готовой"),"combo",(no_yes,self.flag_remove))],
			appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced)
		form.execute()
		self.down_thread=int(form[0][2][1])+1
		point_pos=int(form[1][2][1])
		if point_pos==0:self.down_point=-1
		else:self.down_point=point_ipid[point_pos-1]
		self.down_drive=ur(drives[form[2][2][1]])
		self.down_folder=ur(form[3][2])
		self.schd_start,self.schd_stop=form[4][2],form[5][2]
		self.schd_zone=zones[form[6][2][1]]
		self.schd_exit=int(form[7][2][1])
		self.flag_load,self.flag_remove=int(form[8][2][1]),int(form[9][2][1])
		appuifw.app.title,appuifw.app.screen=old
		scrn.flag_body=1
		self.save_sets()
	def save_sets(self):
		open(self.__path__+self.__sets__,"w").write("\n".join([name+"="+repr(self.__dict__[name]) for name in self.__list__.keys()]))
	def save_list(self):
		open(self.__path__+self.__urls__,"w").write(repr([(line.http,line.name) for line in urls.list]))

class down:
	flag,size,lock=0,-1,0
	def __init__(self,http,name):
		self.http,self.name=http,name
	def load(self):
		try:
			if self.lock:return
			elif len([line for line in urls.list if line.flag==1])>=sets.down_thread:
				self.flag=3
				return
			self.flag,self.lock,self.size=1,1,-1
			pipe=0
			while self.flag==1:
				try:os.mkdir(sets.down_drive+"\\"+sets.down_folder)
				except:pass
				if pipe==32:
					self.flag=4
					break
				else:pipe+=1
				addr=self.http.replace("http://","")
				host,path=addr[:addr.find("/")],addr[addr.find("/"):]
				full=(sets.down_drive+"\\"+sets.down_folder+"\\"+self.name).replace("\\\\","\\")
				socket.set_default_access_point(socket.access_point(sets.down_point))
				mode="a"
				try:self.seek=os.stat(full)[6]
				except:self.seek=0
				self.seek_d=0
				try:
					sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
					sock.connect((ru(host),80))
					sock.send("GET %s HTTP/1.0\r\nHost: %s:80\r\nRange: bytes=%s-\r\nAccept: */*\r\nUser-agent: SmartGET\r\n\r\n" % (path,host,self.seek))
					self.clock=time.clock()
					data=""
					while 1:
						dfind=data.find("\r\n\r\n")
						if dfind!=-1:break
						e32.ao_sleep(1)
						data+=sock.recv(512)
				except:continue
				info,load=data[:dfind].replace("\r\n"," ").split(" "),data[dfind+4:]
				if info[1][0]=="3":
					try:pos=info.index("Location:")
					except:pos=info.index("Uri:")
					self.http=info[pos+1]
					continue
				elif info[1][0] in ("4","5"):
					self.flag=4
					break
				try:self.size=self.seek+int(info[info.index("Content-Length:")+1])
				except:mode,self.seek,self.size="w",0,-1
				try:info[info.index("Content-Range:")]
				except:mode,self.seek="w",0
				try:file=open(full,mode,65536)
				except:
					self.flag=4
					break
				while self.flag==1:
					if not load and not data:
						if self.size==-1:self.flag=2
						break
					file.write(load)
					self.seek+=len(load)
					self.seek_d+=len(load)
					if self.size!=-1 and self.seek>=self.size:
						self.flag=2
						break
					e32.ao_sleep(1)
					try:load=sock.recv(8192)
					except:break
					data=""
				try:file.close()
				except:pass
			try:sock.close()
			except:pass
			self.lock=0
			list=[line for line in urls.list if line.flag==3]
			if list:thread.start_new_thread(list[0].load,())
			if self.flag==2 and sets.flag_remove:
				urls.list.remove(self)
				urls.pos()
				sets.save_list()
		except:self.flag=4

class urls:
	icon=[0,0,1,0,0]
	icon_pos,list_pos=2,0
	simb="""!"#$%&()*+,/:;<=>?@[\]^`{|}~"""+chr(39)
	def event(self,code):
		if code["type"]==appuifw.EEventKey:
			scrn.flag_body=0
			code=code["scancode"]
			if code==14:
				if self.icon_pos==0:self.icon_pos=4
				else:self.icon_pos-=1
				self.icon=[0,0,0,0,0]
				self.icon[self.icon_pos]=1
			elif code==15:
				if self.icon_pos==4:self.icon_pos=0
				else:self.icon_pos+=1
				self.icon=[0,0,0,0,0]
				self.icon[self.icon_pos]=1
			elif code==16:
				if self.list_pos==0:self.list_pos=len(urls.list)-1
				else:self.list_pos-=1
				self.pos()
			elif code==17:
				if self.list_pos==len(urls.list)-1:self.list_pos=0
				else:self.list_pos+=1
				self.pos()
			elif code==167:
				if scrn.schd_body:return
				elif self.icon[2]:new()
				elif urls.list:
					if self.icon[0] and self.list[self.list_pos].flag in (1,3):self.list[self.list_pos].flag=0
					elif self.list[self.list_pos].flag in (0,2,4):
						if self.icon[1]:
							if sets.down_point==-1:return appuifw.note(ru("Выберите точку доступа в настройках"),"error")
							thread.start_new_thread(self.list[self.list_pos].load,())
						elif self.icon[3]:new(1)
						elif self.icon[4]:
							del self.list[self.list_pos]
							self.pos()
							sets.save_list()
			elif code==55:
				appuifw.app.orientation="automatic"
				scrn.load()
			elif code==56:
				appuifw.app.orientation="portrait"
				scrn.load()
			elif code==57:
				appuifw.app.orientation="landscape"
				scrn.load()
			scrn.flag_body=1
	def pos(self):
		if self.list:
			if self.list_pos<0:self.list_pos=0
			if self.list_pos>=len(self.list):self.list_pos=len(self.list)-1
			if self.list_pos<self.list_min:self.list_min-=self.list_min-self.list_pos
			if self.list_pos>self.list_min+self.list_max-1:self.list_min+=self.list_pos-(self.list_min+self.list_max-1)
			if len(self.list)<self.list_min+self.list_max and len(self.list)>=self.list_max:self.list_min-=self.list_min+self.list_max-len(self.list)
	def start(self):
		if not urls.list or sets.down_point==-1:return
		scrn.schd_body,index=0,0
		for line in self.list:
			if line.flag==0:
				index+=1
				if index<=sets.down_thread:thread.start_new_thread(line.load,())
				else:line.flag=3
			elif line.flag==1:
				index+=1
	def stop(self):
		for line in self.list:
			if line.flag in (1,3):line.flag=0
	def clear(self):
		self.list=[]
	def schd(self):
		if not urls.list or sets.down_point==-1:return
		self.stop()
		temp,zone=time.time(),sets.schd_zone*3600
		if time.localtime(sets.schd_start+zone)[3:6]<time.localtime(temp)[3:6]:temp+=86400
		sets.time_start=time.mktime(time.localtime(temp)[:3]+time.localtime(sets.schd_start+zone)[3:6]+time.localtime(temp)[6:])
		if time.localtime(sets.schd_stop+zone)[3:6]<time.localtime(sets.schd_start)[3:6]:temp+=86400
		sets.time_stop=time.mktime(time.localtime(temp)[:3]+time.localtime(sets.schd_stop+zone)[3:6]+time.localtime(temp)[6:])
		self.stack=appuifw.app.menu,appuifw.app.exit_key_handler
		appuifw.app.menu=[(ru("Отмена"),self.back)]
		appuifw.app.exit_key_handler=self.back
		scrn.schd_flag,scrn.schd_body=1,1
	def back(self):
		scrn.schd_flag,scrn.schd_body=0,0
		appuifw.app.menu,appuifw.app.exit_key_handler=self.stack
		self.stop()

class scrn:
	flag_find=appuifw.app.full_name().lower().find(u"python")
	color=(0xff0000,0x00ff00,0x0000ff,0xff007f,0xff7f00)
	schd_flag,schd_body=0,0
	masc="%Y.%m.%d %H:%M:%S"
	def load(self):
		self.info_d=(self.info_dstop,self.info_dstart,self.info_dfull,self.info_dpause,self.info_derror)
		self.flag_body=0
		appuifw.app.body=appuifw.Canvas(event_callback=urls.event)
		self.body=graphics.Image.new(appuifw.app.body.size)
		self.body_width,self.body_height=appuifw.app.body.size
		measure=self.body.measure_text(u"SIyj,'")[0]
		self.text_height=3*measure[3]-measure[1]
		self.icon_s=self.body_width/5
		if str(self.icon_s)[-1] in ("1","3","5","7","9"):self.icon_s-=1
		self.icon_o=(self.body_width-self.icon_s*5)/2
		self.line_t=(self.body_width-self.body.measure_text(u"9999.99.99 99:99:99")[1])/2
		self.line_s=[]
		height=(self.body_height-self.icon_s)/self.text_height-3
		offset=(self.body_height-self.icon_s-self.text_height*(height+3))/2+self.icon_s+measure[3]-measure[1]
		for line in range(height):
			offset+=self.text_height
			self.line_s.append(offset)
		urls.list_min,urls.list_max=0,height
		self.icon_1=5
		self.icon_2=self.icon_s-self.icon_1
		self.icon_3=self.icon_s+self.icon_1
		self.icon_4=self.icon_s/2
		self.icon_5=2*self.icon_s-self.icon_1
		self.icon_6=2*self.icon_s+self.icon_1
		self.icon_7=2*self.icon_s+self.icon_4
		self.icon_8=3*self.icon_s-self.icon_1
		self.icon_9=3*self.icon_s+self.icon_1
		self.icon_18=12
		self.icon_10=self.icon_s-self.icon_18
		self.icon_11=4*self.icon_s-self.icon_18
		self.icon_12=4*self.icon_s-5
		self.icon_13=3*self.icon_s+self.icon_18
		self.icon_14=4*self.icon_s+self.icon_1
		self.icon_15=5*self.icon_s-self.icon_1
		self.icon_16=5*self.icon_s-self.icon_18
		self.icon_17=4*self.icon_s+self.icon_18
		self.info_1=2
		self.info_2=self.icon_s
		self.info_3=self.body_width-1
		self.info_4=self.info_2+self.text_height
		self.info_5=1
		self.info_6=self.info_2-1
		self.info_7=self.info_3-1
		self.info_8=self.info_4-1
		self.info_9=self.icon_1
		self.info_10=self.icon_s+measure[3]
		self.info_11=self.info_9-measure[1]
		self.info_12=self.info_10-measure[1]
		self.info_13=self.info_11+self.icon_1
		self.info_14=self.icon_s+self.icon_1
		self.info_15=self.info_14-measure[1]
		self.info_16=self.info_10-measure[1]/2
		self.info_17=self.info_15+self.icon_1
		self.info_18=2*self.icon_s+self.icon_1
		self.info_19=self.info_18+measure[3]
		self.info_20=self.info_18-measure[1]
		self.info_21=self.info_20+self.icon_1
		self.info_22=3*self.icon_s+self.icon_1+measure[3]
		self.info_23=3*self.icon_s+self.icon_1-measure[1]-measure[3]
		self.info_24=3*self.icon_s+2*self.icon_1-measure[1]
		self.info_25=4*self.icon_s+self.icon_1
		self.info_26=self.info_25-measure[1]
		self.info_27=self.info_26+self.icon_1
		self.info_28=-measure[1]
		self.info_29=self.info_28+self.info_1
		self.info_30=self.info_29+3*self.info_1
		self.info_31=measure[3]
		self.stat_1=2
		self.stat_2=self.body_height-2*self.text_height+1
		self.stat_3=self.body_width-1
		self.stat_4=self.body_height-1
		self.stat_5=1
		self.stat_6=self.stat_2-1
		self.stat_7=self.stat_3-1
		self.stat_8=self.stat_4-1
		self.stat_9=3
		self.stat_10=self.stat_2+2
		self.stat_11=self.stat_3-2*self.stat_9
		self.stat_13=self.stat_10-measure[1]+measure[3]/2
		self.stat_12=self.stat_13+measure[3]
		self.stat_14=5
		self.stat_15=self.body_width/2
		self.stat_16=self.body_width-self.stat_14
		self.stat_17=self.stat_13-measure[1]+measure[3]+measure[3]/2
		self.flag_body=1
	def loop(self):
		self.load()
		self.flag_loop=1
		while self.flag_loop:
			timer=time.clock()
			try:
				if self.flag_body:
					self.body.clear(0xffffff)
					self.icon()
					self.info()
					if self.schd_flag and self.schd_body:self.schd()
					elif urls.list:self.list()
				appuifw.app.body.blit(self.body)
			except:pass
			if self.schd_flag and self.schd_body:
				if time.time()>=sets.time_start:urls.start()
			elif self.schd_flag and time.time()>=sets.time_stop:
				if sets.schd_exit:exit()
				else:urls.back()
			delta=0.06+timer-time.clock()
			if delta>0:e32.ao_sleep(delta)
			else:e32.ao_yield()
		if self.flag_find==-1:os.abort()
	def icon_stop(self,color):
		self.body.polygon((self.icon_o+self.icon_1,self.icon_1,		self.icon_o+self.icon_2,self.icon_1,		self.icon_o+self.icon_2,self.icon_2,	self.icon_o+self.icon_1,self.icon_2),color,width=3)
	def icon_start(self,color):
		self.body.polygon((self.icon_o+self.icon_3,self.icon_1,		self.icon_o+self.icon_5,self.icon_4,		self.icon_o+self.icon_3,self.icon_2),color,width=3)
	def icon_append(self,color):
		self.body.line((self.icon_o+self.icon_7,self.icon_1,		self.icon_o+self.icon_7,self.icon_2),color,width=3)
		self.body.line((self.icon_o+self.icon_6,self.icon_4,		self.icon_o+self.icon_8,self.icon_4),color,width=3)
	def icon_edit(self,color):
		self.body.polygon((self.icon_o+self.icon_9,self.icon_2,		self.icon_o+self.icon_9,self.icon_10,		self.icon_o+self.icon_11,self.icon_1,	self.icon_o+self.icon_12,12,		self.icon_o+self.icon_13,self.icon_2),color,width=3)
	def icon_remove(self,color):
		self.body.polygon((self.icon_o+self.icon_14,self.icon_1,	self.icon_o+self.icon_15,self.icon_1,		self.icon_o+self.icon_16,self.icon_2,	self.icon_o+self.icon_17,self.icon_2),color,width=3)
	def icon(self):
		if urls.icon[0]:self.icon_stop(0xff0000)
		else:self.icon_stop(0xcfcfcf)
		if urls.icon[1]:self.icon_start(0x00ff00)
		else:self.icon_start(0xcfcfcf)
		if urls.icon[2]:self.icon_append(0x0000ff)
		else:self.icon_append(0xcfcfcf)
		if urls.icon[3]:self.icon_edit(0x00ff00)
		else:self.icon_edit(0xcfcfcf)
		if urls.icon[4]:self.icon_remove(0xff0000)
		else:self.icon_remove(0xcfcfcf)
	def info_stop(self):
		self.body.rectangle((self.icon_o+self.info_9,self.info_10,		self.icon_o+self.info_11,self.info_12),self.color[0],width=2)
		self.body.text((self.icon_o+self.info_13,self.info_12),unicode(len([0 for line in urls.list if line.flag==0])),0x000000)
	def info_start(self):
		self.body.polygon((self.icon_o+self.info_14,self.info_10,		self.icon_o+self.info_15,self.info_16,		self.icon_o+self.info_14,self.info_12),self.color[1],width=2)
		self.body.text((self.icon_o+self.info_17,self.info_12),unicode(len([1 for line in urls.list if line.flag==1])),0x000000)
	def info_full(self):
		self.body.line((self.icon_o+self.info_18,self.info_16,			self.icon_o+self.info_19,self.info_12),self.color[2],width=2)
		self.body.line((self.icon_o+self.info_19,self.info_12,			self.icon_o+self.info_20,self.info_10),self.color[2],width=2)
		self.body.text((self.icon_o+self.info_21,self.info_12),unicode(len([2 for line in urls.list if line.flag==2])),0x000000)
	def info_pause(self):
		self.body.line((self.icon_o+self.info_22,self.info_10,			self.icon_o+self.info_22,self.info_12),self.color[3],width=2)
		self.body.line((self.icon_o+self.info_23,self.info_10,			self.icon_o+self.info_23,self.info_12),self.color[3],width=2)
		self.body.text((self.icon_o+self.info_24,self.info_12),unicode(len([3 for line in urls.list if line.flag==3])),0x000000)
	def info_error(self):
		self.body.line((self.icon_o+self.info_25,self.info_10,			self.icon_o+self.info_26,self.info_12),self.color[4],width=2)
		self.body.line((self.icon_o+self.info_26,self.info_10,			self.icon_o+self.info_25,self.info_12),self.color[4],width=2)
		self.body.text((self.icon_o+self.info_27,self.info_12),unicode(len([4 for line in urls.list if line.flag==4])),0x000000)
	def info_dstop(self,seek):
		self.body.rectangle((self.info_1,seek-self.info_28,		self.info_29,seek),self.color[0],width=2)
	def info_dstart(self,seek):
		self.body.polygon((self.info_1,seek-self.info_28,		self.info_29,seek-self.info_28/2,		self.info_1,seek),self.color[1],width=2)
	def info_dfull(self,seek):
		self.body.line((self.info_1,seek-self.info_28/2,		self.info_1+self.info_31,seek),self.color[2],width=2)
		self.body.line((self.info_1+self.info_31,seek,			self.info_29,seek-self.info_28),self.color[2],width=2)
	def info_dpause(self,seek):
		self.body.line((self.info_1+self.info_31,seek,			self.info_1+self.info_31,seek-self.info_28),self.color[3],width=2)
		self.body.line((self.info_29-self.info_31,seek,			self.info_29-self.info_31,seek-self.info_28),self.color[3],width=2)
	def info_derror(self,seek):
		self.body.line((self.info_1,seek,						self.info_29,seek-self.info_28),self.color[4],width=2)
		self.body.line((self.info_1,seek-self.info_28,			self.info_29,seek),self.color[4],width=2)
	def info(self):
		self.body.rectangle((self.info_1,self.info_2,self.info_3,self.info_4),0x8f8f8f)
		self.body.rectangle((self.info_5,self.info_6,self.info_7,self.info_8),0xdfdfdf,0xcfcfcf)
		self.info_stop()
		self.info_start()
		self.info_full()
		self.info_pause()
		self.info_error()
		self.body.rectangle((self.stat_1,self.stat_2,self.stat_3,self.stat_4),0x8f8f8f)
		self.body.rectangle((self.stat_5,self.stat_6,self.stat_7,self.stat_8),0xdfdfdf,0xcfcfcf)
	def list(self):
		index=0
		for line in urls.list[urls.list_min:urls.list_min+urls.list_max]:
			self.info_d[line.flag](self.line_s[index])
			pos=urls.list.index(line)
			name=unicode(pos+1)+". "+ru(line.name)
			if pos==urls.list_pos:
				self.body.text((self.info_30,self.line_s[index]),name.upper(),self.color[line.flag])
				if line.flag==1:
					seek,size,kbps,temp,width=u"",u"",u"",-1,self.stat_11
					if line.size!=-1:
						part=1.0*line.seek/line.size
						proc=str(round(part*100,1))+u"%"
						width=self.stat_11*part
						measure=self.body.measure_text(proc,maxwidth=width-self.stat_9)
						temp=(width-measure[1])/2
						seek=str(line.seek/1024)+u"kb"
						size=str(line.size/1024)+u"kb"
						kbps=str(round((line.seek_d/1024)/(time.clock()-line.clock),2))+u"kb/s"
					self.body.rectangle((self.stat_9,self.stat_10,self.stat_9+width,self.stat_12),0x0000cf,0x0000cf)
					if temp>0:self.body.text((self.stat_9+temp,self.stat_13),proc[:measure[2]],0x000000)
					self.body.text((self.stat_14,self.stat_17),seek,0x000000)
					self.body.text((self.stat_15-self.body.measure_text(size)[1]/2,self.stat_17),size,0x000000)
					self.body.text((self.stat_16-self.body.measure_text(kbps)[1],self.stat_17),kbps,0x000000)
			else:self.body.text((self.info_30,self.line_s[index]),name,0x000000)
			index+=1
	def schd(self):
		self.body.text((self.line_t,self.line_s[0]),unicode(time.strftime(self.masc,time.localtime(time.time()))),0x000000)
		self.body.text((self.line_t,self.line_s[1]),unicode(time.strftime(self.masc,time.localtime(sets.time_start))),0x000000)
		self.body.text((self.line_t,self.line_s[2]),unicode(time.strftime(self.masc,time.localtime(sets.time_stop))),0x000000)

def new(flag=0):
	urls.temp_flag=flag
	if flag:urls.temp_http,urls.temp_name=urls.list[urls.list_pos].http,urls.list[urls.list_pos].name
	else:urls.temp_http,urls.temp_name="",""
	def body():
		if appuifw.app.body.len()<16:return 1
		urls.temp_http=ur(appuifw.app.body.get())
		if not urls.temp_name:
			temp_name=""
			temp_http=urls.temp_http.replace("http://","")
			for simb in temp_http[temp_http.rfind("/")+1:]:
				if simb not in urls.simb:temp_name+=simb
			urls.temp_name=temp_name
		if not urls.temp_name:urls.temp_name="noname"
	def full():
		if body():return
		if urls.temp_flag:urls.list[urls.list_pos].name,urls.list[urls.list_pos].http=urls.temp_name,urls.temp_http
		else:
			urls.list.append(down(urls.temp_http,urls.temp_name))
			urls.list_pos=512
			urls.pos()
		sets.save_list()
		back()
		if not urls.temp_flag and sets.flag_load:thread.start_new_thread(urls.list[-1].load,())
	def name():
		if body():return
		name=appuifw.query(ru("Имя файла:"),"text",ru(urls.temp_name))
		if name:urls.temp_name=ur(name)
	def back():
		appuifw.app.body,appuifw.app.exit_key_handler,appuifw.app.menu,appuifw.app.screen,appuifw.app.title=scrn.stack
		scrn.flag_body=1
	scrn.flag_body=0
	scrn.stack=appuifw.app.body,appuifw.app.exit_key_handler,appuifw.app.menu,appuifw.app.screen,appuifw.app.title
	if urls.temp_flag:appuifw.app.title=ru("Изменить")
	else:appuifw.app.title=ru("Добавить")
	appuifw.app.screen="normal"
	appuifw.app.menu=[
		(ru("Готово"),full),
		(ru("Указать имя"),name),
		(ru("Назад"),back)]
	appuifw.app.exit_key_handler=back
	appuifw.app.body=appuifw.Text(ru(urls.temp_http))

def help():
	scrn.flag_body=1
	urls.stack=appuifw.app.screen,appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.title,appuifw.app.body
	appuifw.app.screen="normal"
	appuifw.app.menu=[(ru("Назад"),back)]
	appuifw.app.exit_key_handler=back
	appuifw.app.title=ru("О программе")
	appuifw.app.body=appuifw.Text(ru("Название:\n	SmartGET v2.00\nРазработчик:\n	Газетдинов Альберт\nКоординаты:\n	www.mobi.ru\n	tarlovka@rambler.ru"))

def back():
	appuifw.app.screen,appuifw.app.menu,appuifw.app.exit_key_handler,appuifw.app.title,appuifw.app.body=urls.stack
	scrn.flag_body=1

def exit():
	scrn.flag_loop=0

try:
	sys.stderr=errs()
	urls,scrn=urls(),scrn()
	sets=sets()
	appuifw.app.exit_key_handler=lambda:appuifw.query(ru("Выйти из программы"),"query") and exit()
	appuifw.app.screen="full"
	appuifw.app.menu=[
		(ru("Групповые"),(
			(ru("стартовать все"),urls.start),
			(ru("остановить все"),urls.stop),
			(ru("удалить все"),urls.clear),
			(ru("таймер"),urls.schd))),
		(ru("Настройки"),sets.exch),
		(ru("О программе"),help),
		(ru("Выйти"),exit)]
	if scrn.flag_find!=-1:scrn.loop()
	else:e32.ao_sleep(0,scrn.loop)
except:
	import traceback
	traceback.print_exc()