# Grishberg
# функции для преобразования rgb в hls
# я нашей этот алгоритм в нете, написанный на паскале, вот посидел и переделал под питон.
# пользуйтесь наздоровье!
# Grishberg@rambler.ru

import appuifw
from appuifw import *
from graphics import *
import e32
from Rgb import *

r_var=1
def quit():
    global r_var
    r_var=0

appuifw.app.screen='full'
img=Image.new((176,208))
def handle_redraw(rect):
    canvas.blit(img)

r_var=1
canvas=appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)
appuifw.app.body=canvas
app.exit_key_handler=quit
img.clear(0xffffff)
y=0
c1=256*256
c2=256
while r_var and y<176:
 x=0
 while x<208:
   r,g,b=hlstorgb(x,y,240)
   c=r*c1+g*c2+b
   img.point((y,x),c,width=1)
   x=x+1
 y=y+1
 handle_redraw(())
 e32.ao_yield()

while r_var:
    handle_redraw(())
    e32.ao_yield()