from appuifw import *
import appuifw,math,e32
from rusos import *
from graphics import *
from e32 import *
#В данной версии реализовано: квадратные уравнения,число в степень,список степеней,арифметическая прогрессия.Добавил наработки тригонометрии. Также идет разработка графического интерфейса.Но местами он с тормозами.
# переменные цветов
bl=0xffffff
ch=0x000000

def exit():
#        script_lock.signal()
    global running
    running=0
    appuifw.app.set_exit()

def sinys():
    formm('sinn')		 

def cosin():
   formm('coss')
   
def tangens():
   formm('tnn')
   
def cotan():
  formm('ctnn')

def formm(fun):
  menu=appuifw.popup_menu([ru('Вычисляем?'),ru('Рисуем?')],ru('Чем страдаем? : '))
  if menu==0:
    i=appuifw.popup_menu([ru('Градусы'),ru('Радианы')],ru('в чем измеряем :'))
    a=appuifw.query(ru('Введите значение'),"float")
    if i==1:
	  if fun=='coss':
		k=str(math.cos(a))
	  if fun=='sinn':
		k=str(math.sin(a))
	  if fun=='tnn':
		k=str(math.tan(a))
	  if fun=='ctnn':
		k=1/(str(math.tan(a)))
    if i==0:
      pi=float(str(math.pi)[:5])
      if fun=='coss':
		k=str(math.cos((pi/180)*a))
      if fun=='sinn':
		k=str(math.sin((pi/180)*a))
      if fun=='tnn':
		k=str(math.tan((pi/180)*a))
      if fun=='ctnn':
		k=str(1/(math.tan((pi/180)*a)))
    img.clear(bl)
    diz(ru('Получили : '),5,20)
    diz(u''+k,5,32)
  if menu==1:
    appuifw.app.screen='full'
    if fun=='coss':
		fn=ru('косинус')
    if fun=='sinn':
	  fn=ru('синус')
    if fun=='tnn':
	  fn=ru('тангенс')
    if fun=='ctnn':
	  fn=ru('котангенс')
    if appuifw.query(ru("Вводить параметры?"), "query") == True:
	  q=appuifw.query(ru('Введите степень')+fn+ru('а : '),"float")
	  sd=appuifw.query(ru('Введите коэффициент b : '),"float")
	  c=appuifw.query(ru('Введите множитель перед x : '),"float")
	  n=appuifw.query(ru('Введите множитель перед')+fn+ru('ом : '),"float")
    else:
	  q=1
	  sd=0
	  c=1
	  n=1
    diz1()
    i=0
    if fun=='coss':
      while i<20:
        y=n*((math.cos(i*c))**q)+sd
        img.point((15*i-35,15*y+102),ch)
        handle_redraw(())
        e32.ao_yield()
        i+=0.05
    if fun=='sinn':
      while i<20:
        y=n*((math.sin(i*c))**q)+sd
        img.point((15*i-35,15*y+102),ch)
        handle_redraw(())
        e32.ao_yield()
        i+=0.05
    if fun=='ctnn':
      while i<20:
        y=n*((math.tan(i*c))**q)+sd
        img.point((15*i-35,15*y+102),ch)
        handle_redraw(())
        e32.ao_yield()
        i+=0.05
    if fun=='tnn':
      while i<20:
        try:
          y=n*(1/((math.tan(i*c)))**q)+sd
          img.point((15*i-35,15*y+102),ch)
        except:
          None
        handle_redraw(())
        e32.ao_yield()
        i+=0.05

def arifmp():
#    ищем определенный член арифмет. прогрессии( один  )
    a=appuifw.query(ru('Введите первый член арифм.прогрессии'),"float")
    d=appuifw.query(ru('Введите разность прогрессии'),"float")
    n=appuifw.query(ru('Введите номер члена'),"float")
    i=0
    j=[]
    while i<n:
        m=a+d
        a=m
        i+=1
	a=u''+str(a)
    img.clear(bl)
    diz(ru("Получили : "),5,20)
    diz(a,5,32)

def spisok():
    appuifw.app.screen='normal'
    appuifw.app.title=ru('Список степеней числа')
    a=appuifw.query(ru('введите число'),"number")
    b=appuifw.query(ru('введите количество степеней'),"number")
    r=range(b)
    i=a
    f=0
    while f<b:
        r[f]=i
        f+=1
        i*=a
    m=str(r)
    img.clear(0xffffff)
    diz(ru("Получили:"),5,20)
    diz(u""+m,5,32)

def cg():
   appuifw.app.screen='normal'
   appuifw.app.title=ru('Кв.уравнение')
   a=appuifw.query(ru('введите коф. А'),"float")
   b=appuifw.query(ru('введите коф. В'),"float")
   c=appuifw.query(ru('введите коф. С'),"float")
   D=b*b-4*a*c
   if D<0:
        E=str(D)
        img.clear(bl)
        diz(ru('При данных коэффициентах квадратное уравнение корней не имеет!'),1,20)
        img.text((2,56),ru('Попробуйте еще раз.'),ch)
        img.text((2,68),u'D='+E,ch)
   if D>0:
      x=(-b+math.sqrt(D))/(2*a)
      xx=(-b-math.sqrt(D))/(2*a)
      j=ru('Ответ:')
      w=str(x)
      ww=str(xx)
      E=str(D)
      img.clear(bl)
      img.text((10,20),u''+j,ch)
      img.text((30,40),u'x1='+w,ch)
      img.text((30,52),u'x2='+ww,0x000000)
      img.text((30,64),u'D='+E,0x000000)
   if D==0:
      x=(-b+math.sqrt(D))/(2*a)
      k=ru('Возможен только один корень!')
      j=ru('Ответ:')
      w=str(x)
      E=str(D)
      img.clear(bl)
      img.text((10,20),u''+k,0x000000)
      img.text((10,32),u''+j,0x000000)
      img.text((30,44),u'x1='+w,0x000000)
      img.text((30,56),u'D='+E,0x000000)

def arifm():
   appuifw.app.screen='normal'

   appuifw.app.title=ru('Арифмет.прогрессия')
   a=appuifw.query(ru('Введите первый член'),'number')
   d=appuifw.query(ru('Введите разность прогрессии'),'number')
   e=appuifw.query(ru('Введите количество членов прогрессии'),'number')
   k=(a+d*(e-1))+d
   k=str(range(a,k,d))
   img.clear(0xffffff)
   diz(ru('Получилась следующая последовательность : '),5,20)
   diz(u''+k,5,44)

def step():
    appuifw.app.title=ru('Степень')
    a=appuifw.query(ru('введите число возводимое в степень'),'float')
    b=appuifw.query(ru('введите показатель степени'),'float')
    k=u''+str(a**b)
    img.clear(0xffffff)
    diz(ru('Получили : '),5,15)
    diz(k,5,30)
	

def fkt():
         appuifw.app.screen='normal'
         appuifw.app.title=ru('Факториал')
         a=appuifw.query(ru('Введите число'),'float')
	 i=1
	 c=1
	 while i<=a:
		 ba=c*i
		 c=ba
		 i+=1
         img.clear(bl)
	 diz(ru("Пголучили : "),5,20)
	 diz(u''+str(c),5,33)

	 
def info(q):
	 i=1
	 while i<5:
		 img.line(150,208-i,150,208-(i+5))
		 img.line(176-i,170,176-(i+5),170)
		 i+=5
               	 handle_redraw(())
          	 e32.ao_yield()

	 img.text((155,199),u'^ = '+q,ch)
	 
def diz1():
   img.clear(bl)
   img.line((0,101,176,101),0x0000f0,width=2)
   img.line((10,0,10,208),0x0000f0,width=2)
   img.line((5,87,13,87),0x0000f0,width=2)
   img.line((59,96,59,107),0x0000f0,width=2)
   img.text((170,91),u'x',0x000000)
   img.text((15,10),u'y',0x000000)
   img.text((2,115),u'0',ch)
 
def diz(text,x,y):
# финкция для оформления текста большой длинны
	if x<=5: 
          m=23
	if 5<x<=10:
          m=21
	q = len(text)
	if q>=23:
		 None
	if q<23:
		 m=q

	if q>20:
	   w=q/24
	   e=q-24*w
	   i=0
	   while i<w+2:
		  if i==0:
			o=text[:m]
                        if o[m-1]==' ' or '.':
			  img.text((x,y),o,0x000000)
                        else:
			  img.text((x,y),o+'-',ch)

#                        print o[m-1], 6
		  if i>0:
			o=text[m*i:m*(i+1)]
#                        if o[m-2]==' ':
# 			  img.text((x,y+i*12),o,ch)
#                        else:
			img.text((x,y+i*12),o+u'-',ch)
#		  if i>15:
#		    wm=appuifw.popup_menu([u'one',u'two',u'ajtaj'],u'noner')
#		    if wm==0:
#                        img.clear(0xffffff)
#                    ma=text[0:24*i]
#                    diz(ma,5,20)
#		    if wm==1:
#                        img.clear(0xffffff)
#                        ma=text[24*i:]
#                        diz(ma,5,20)
   
		  i+=1
	else:
	  img.text((x,y),text,0x000000)

def about():
  appuifw.note(u'Maker by SDO1600\ncopyright 2006\nsdo1600@rambler.ru','info')

#script_lock=e32.Ao_lock()
app_lock=e32.Ao_lock()
appuifw.app.screen='normal'
img=Image.new((176,208))
diz(ru(' Данная программа предназначена для решения разнообразных математических задач.'),5,20)
diz(ru('Нажмите "Функции" для выбора операции'),5,68)

def handle_redraw(rect):
    canvas.blit(img)

canvas=appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)

running=1
appuifw.app.body = canvas   

def menu():
  global wtp
  q=ru('кв.уравнение')
  n=ru('число в степень')
  m=ru('Арифметическая')
  o=ru('Прогрессии')
  appuifw.app.menu = [(u""+q, cg),(ru('Факториал'),fkt),(ru('число в степень'),step),(ru('Список степеней числа'),spisok),
                      (ru("Тригонометрия"),((u"sin", sinys),
(u'cos', cosin),
(u'ctan',cotan),
(u'tan', tangens))),
                      (u""+o, ((u""+m, arifm),
(ru('n-ый член'), arifmp))),(u'About',about),(ru('Выход'),exit)]
menu()

appuifw.app.exit_key_handler=exit
#script_lock.wait()
app_lock.wait()