def ru(x):return x.decode('utf-8')
import appuifw
appuifw.Content_handler().open_standalone(ru("E:\\Python\\PyfClock.swf"))
appuifw.app.set_exit()
