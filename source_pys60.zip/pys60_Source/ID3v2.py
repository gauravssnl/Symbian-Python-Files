#script by Makovar
#used progress_bar by _KILLED_
import powlite_fm, os, e32
from appuifw import *
def ru(x):return x.decode('utf-8')
def H(x):return x.decode('hex')
def U(x):return x.encode('UTF-16')
fileman = powlite_fm.manager()
canv = ''
A, B, C, P, R = 'ID3'+H('03'+'0'*8+'5f77')+'TPE1', 'TIT2', '0'*4, 'APIC', 'image/jpeg'+H('000300')
l = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']
#=======#
def canvas_bar(i,l):
  procent=l*0.01
  obw=i/procent
  canv.clear(0xaaaaaa)
  canv.rectangle((7,100,7+obw*1.6,110),0xff0000,0x0000ff)
  canv.text((7,95),u''+str(obw)[:5]+u'%')
  e32.ao_sleep(0.00001)
#========#
def Exit():
    global script_lock
    script_lock.signal()
    app.set_exit()
#========#
def X(a):
    if a/16 > 15:
        if a/256 > 15:return C+l[a/4096]+l[(a%4096)/256]+l[((a%4096)%256)/16]+l[a%16]+C+'01'
        return C+'0'+l[a/256]+l[(a%256)/16]+l[a%16]+C+'01'
    return C+'00'+l[a/16]+l[a%16]+C+'01'
#================#
def Choose_File():
    global canv
    def L(s):return len(s)*2+3
    FN = fileman.AskUser('E:\\Sounds', ext=['.mp3']).encode('utf-8')
    if FN == None:return
    T = query(ru("Исполнитель"), 'text')
    if T == None:Choose_File()
    S = query(ru("Название"), 'text')
    if S == None:Choose_File()
    PQ = query(ru('Вставить картинку?'), 'query')
    Q = '0'
    if PQ == 1:
        def PF():
            picpath = fileman.AskUser('E:\\Images', ext=['.jpg', 'jpeg']).encode('utf-8')
            if picpath != None and os.path.getsize(picpath) > 65535:
                note(ru("Такие большие картинки не поддерживаются!"), 'error')
                return -1
            return picpath
        picpath = PF()
        while picpath == -1:
            picpath = PF()
        if picpath != None:
            PicRead = file(picpath).read()
            Q = P+H(X(L(PicRead)/2+13)[:-1]+'0')+R+PicRead
    pm = popup_menu([ru("Быстро (запись поверх)"), ru("Долго (склеивание)")], ru("Как сохранять?"))
    teg = A+H(X(L(T)))+U(T)+B+H(X(L(S)))+U(S)+Q+H('0'*1024)
    if pm == None:Choose_File()
    elif pm == 0:
        try:
            file(FN, 'r+').write(teg)
            note(ru("Готово"), 'conf')
        except:
            note(ru("Не получается..."), 'error')
    else:
        oldbody = app.body
        app.body = canv = Canvas()
        kb = 10000
        size = os.path.getsize(FN)
        Num, ost = size/kb, size%kb
        os.rename(FN, FN[:-1])
        r, w = open(FN[:-1]), open(FN, 'w')
        if size > kb*10:TF = kb*10
        else: TF = size
        Rr = r.read(TF)
        Rr = Rr.encode('hex')
        r.seek(0)
        if r.read(3) == 'ID3':
            j = Rr.find('0'*200)/2
            if j != -1:
                r.seek(j)
                ost -= j%kb
                if ost < 0:
                    Num -= 1
                    ost = kb+ost
                if j > kb:
                    Num -= j/kb
        else:r.seek(0)
        w.write(teg)
        for i in range(Num):
            canvas_bar(i,Num)
            w.write(r.read(kb))
        w.write(r.read(ost))
        r.close(), w.close()
        os.remove(FN[:-1])
        app.body = oldbody
    Choose_File()
app.body = Listbox([ru("Загрузка")], lambda:None)
script_lock = e32.Ao_lock()
Choose_File()
Exit()