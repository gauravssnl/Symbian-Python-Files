# Done by Malk0m for Dimonvideo.ru
# Report about bugs to malk1@gtn.ru
# File DownLOADER 0.3

import appuifw
import TopWindow
import e32
#import threading

def about():
    appuifw.note(u'Malk0m Software malk1@gtn.ru','info')
    menu()

def test(bl,blsize,size):
    appuifw.app.body.clear()
    print 'Download size is',size,'Bt', 'or ',size/1000,' Kb'

def downloade(folder):
    import os
    import urllib
    if folder == 2: folder = 'c:\\'
    elif folder == 1: folder = 'e:\\'
    try:
        url=appuifw.query(u'Whats URL to download?','text')
        filed=os.path.split(url)
        filed=folder + filed[1]
    except: 
        appuifw.note(u'Its Not url!','error')
        menu()
    try: 
        appuifw.app.body.clear()
        print 'Connecting...'
        urllib.urlretrieve(url,filed,test)
    except: 
        appuifw.note(u'error with server','error')
        menu()
    else: 
        appuifw.note(u'Done','conf')
        appuifw.app.body.clear()
        size=os.path.getsize(filed)
        size=size/1000
        print size, 'KB Downloaded' 
        print 'File in ', filed

def image(color):
    pict=TopWindow.TopWindow()
    pict.size=(30,30)
    pict.background_color=color
    pict.show()
    app.wait()

def start():
    global folder
    menu = [u'E:\\',u'C:\\']
    index = appuifw.popup_menu(menu,u'Select a Folder')
    if index == 0:
        folder = 1
        downloade(folder)
    elif index == 1:
        folder = 2
        downloade(folder)
    

Menu = [u'Select URL',u'About',u'Exit']

def menu():
    #image(29464612)
    index = appuifw.selection_list(Menu)
    if index == 0: start()
    elif index == 1: about()
    elif index == 2: exit()

def exit():
    appuifw.app.set_exit()

app=e32.Ao_lock()
menu()