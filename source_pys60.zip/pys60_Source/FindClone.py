###by Seldon86

import os,e32,rusos,appuifw

ru,aa,FD,FN,FS,B,W,I,J=rusos.ru,appuifw.app,[],[],[],0,e32.Ao_lock(),0,0

def body(t):
 global B
 B.set(t)
 B.set_pos(0)
 e32.ao_sleep(0.001)
def scan(d,f=''):
 global FD,FN,FS,I,J
 a=d+'/'+f
 if os.path.isfile(a):
  I+=1
  if I>100:
   I,J=1,J+1
   body(ru('Найдено файлов: ')+unicode(str(J)+'00'))
  FD.append(ru(d))
  FN.append(ru(f))
  try:FS.append(os.stat(a)[6])
  except:FS.append('?')
 elif os.path.isdir(a):
  for i in os.listdir(a):scan(a,i)
def find():
 global FD,FN
 FD,FN,T,I,J=[],[],'',0,0
 body(ru('Идет сканирование.'))
 scan('c:')
 scan('e:')
 body(ru('Найдено файлов: ')+unicode(len(FN))+ru('\nИдет поиск дубликатов.'))    
 LF,I,J=len(FN)-1,0,0
 while LF!=-1:
  i=0
  while i<LF:
   if FN[-1]==FN[i] and FS[-1]==FS[i]:
    I+=1
    if I>10:
     I,J=1,J+1
     body(ru('Найдено дубликатов: ')+unicode(str(J)+'0.'))
    T+=unicode(ru('Имя: ')+FN[i]+ru(',\nразмер: ')+str(FS[i])+ru('байт,\nв папке: ')+FD[-1]+ru(',\nв папке: ')+FD[i]+'.\n\n')
   i+=1
  del FD[-1],FN[-1],FS[-1]
  LF=len(FN)-1
 if len(T)==0:T=ru('Дубликатов нет.')
 else:
  T=ru('Найдено дубликатов: ')+unicode(str(I+J*10))+'\n\n'+T
  try:
   F=open('c:/findclone.txt','w')
   F.write(rusos.codos(T))
   F.close()
   T=ru('Результат поиска сохранен в файле: ')+'\nc://findclone.txt.\n\n'+T
  except:pass
 body(T)
def exit():
 W.signal()
 aa.set_exit()

B=aa.body=appuifw.Text()
B.color=(0,0,0)
body(ru('Программа готова к работе.'))
aa.exit_key_handler=exit
aa.menu=[(ru('Поиск'),find),(ru('Выход'),exit)]
W.wait()