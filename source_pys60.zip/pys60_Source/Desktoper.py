######################################################################
#
# DesktOper v 1.08 - Desktop stile 6680 - by Mimmo 'Oper' Campagna
#
# Sviluppato da Mimmo 'Oper' Campagna - 24/01/2007
# NOTE: E' richiesto PyS60 versione 1.3.14 o successivo
#
# Aggiunte alla 1.07:
# 1-Modifica immissione dati
# 2-Aggiunta iconpack P@sco e PietroR91
# 3-Eliminati tutti i momenti di riavvio (solo la cattura icone lo prevede ancora)
# 4-Ottimizzazione
######################################################################

import TopWindow
import graphics
import appuifw
import string
import os
import ntpath
import e32
import keycapture
from key_codes import *
import appswitch
import calendar
import time
import random

global selez, visibile, timer, scadenza
global capturer # cattura tasti
global matita   # tempo di attesa per la matita
global mostrato_memo, posy, old_posy
global spostamento, sposta_x, sposta_y
global patto
global old_elle, old_evento, old_anniv, old_riga1, old_riga2, old_riga3, old_riga4, old_riga5
global vocab
global max_line
global allegato1, allegato2, allegato3, allegato4, allegato5
global img1, img2, img3, img4, img5, mask1, mask2, mask3, mask4, mask5
global menu1, menu2, menu3, menu4, menu5

max_line   = 71     # righe file lingua
sposta_x   = 0      # x per l'animazione
sposta_y   = 0      # y per l'animazione
spostamento= 0      # per l'animazione
animazione = 0      # per l'animazione del menu
tipo_anim  = 0      # tipo animazione 0=random 1=sinistra-destra 2=alto-basso 3=destra-sinistra 4=basso-alto
mostrato_memo = 0   # stato del memo a video
visibile   = 1      # 1=barra visibile 0=barra nascosta
selez      = 1
posx, posy = 0, 0   # posizione iniziale della barra
old_posy   = 0
sx, sy     = 176, 67# size imamgine della barra
i_x, i_y   =  34, 29# size icone
Phone      = [u'Phone', u'Telephone']
ctetich_   = 0      # colore testo etichette
cmemo_     = 0      # colore memo calendario
cselez_    = 0      # colore selezione
etich_sino = 1      # 1=etichette si - 0=etichette no
memo_sino  = 1      # 1=memo si - 0=memo no
icone_sino = 1      # 1=icone si - 0=icone no
num_ico    = 5      # numero icone a video
no_bordo   = 13     # pixel per togliere il bordo
memory     = "C","E","Z"
listaprog  = []
vocab      = []

_nome_     = ""
_programma_= ""

######################################################################
def Crea_Maschera(img):
    width, height = img.size
    mask = graphics.Image.new(img.size, '1')
    transparent_color = img.getpixel((0,0))[0]
    for y in range(height):
        line = img.getpixel([(x, y) for x in range(width)])
        for x in range(width):
            if line[x] == transparent_color:
                mask.point((x,y), 0)
    return mask

######################################################################
def Cattura_Tema():
    global shot_img, posy
    __img = graphics.screenshot()
    shot_img = graphics.Image.new((sx,sy))
    for __y in range(sy):
        line = __img.getpixel([(__x, __y +posy) for __x in range(sx)])
        for __x in range(sx):
            shot_img.point((__x,__y), line[__x])

######################################################################
def Cattura_Icone():  # serve ad abilitare la cattura e a switchare al menu
    global cattura
    cattura = 1
    appuifw.note(vocab[0]) #"Nel menu premi il tasto matita per catturare le prime 5 icone."
    appswitch.switch_to_fg(u"Menu")
    e32.ao_sleep(0.2)

######################################################################
def Salva_Icona(n, xxx, yyy, __img, screenshot_img, ssx, ssy):
    global patto
    for __y in range(ssy):
        line = __img.getpixel([(__x+xxx, __y +yyy) for __x in range(ssx)])
        for __x in range(ssx):
            screenshot_img.point((__x,__y), line[__x])
    im = screenshot_img.resize((34,23))
    im.save(patto + '\\IconPack\\icona'+str(n)+'.png')

######################################################################
def OK_Cattura_Icone(): # viene eseguita solo col tasto matita e se si и nel menu
    global cattura
    cattura=0
    __img = graphics.screenshot()
    e32.ao_sleep(0.5)
    appswitch.switch_to_fg(u"DesktOper")
    e32.ao_sleep(0.5)
    appuifw.note(vocab[1]) #"Attendere..."
    ssx, ssy = 42,29 # icona normale
    screenshot_img = graphics.Image.new((ssx,ssy))
    Salva_Icona (1,   9, 47, __img, screenshot_img, ssx, ssy) # (n. icona, x, y, __img, screenshot_img, ssx, ssy)
    Salva_Icona (2,  67, 47, __img, screenshot_img, ssx, ssy)
    Salva_Icona (3, 125, 47, __img, screenshot_img, ssx, ssy)
    Salva_Icona (4,   9, 94, __img, screenshot_img, ssx, ssy)
    Salva_Icona (5,  67, 94, __img, screenshot_img, ssx, ssy)
    appuifw.note(vocab[2]) #"Icone catturate."

######################################################################
def Trova_File(Nomefile):
    try:
        f=open(Nomefile)
        f.close
        return 1
    except:
        return 0

######################################################################
def Show_Screen():

    if appswitch.application_list(1)[0] in Phone:

        global sposta_y, spostamento, sposta_x
        global old_elle, old_evento, old_anniv, old_riga1, old_riga2, old_riga3, old_riga4, old_riga5
        global img1, img2, img3, img4, img5, mask1, mask2, mask3, mask4, mask5

        if spostamento == 0:
            global capturer
            capturer.keys = (
                 EKeyYes,            # Tasto di chiamata
                 EKeyLeftArrow,      # Joystick a sinistra
                 EKeyRightArrow,     # Joystick a destra
                 EKeyUpArrow,        # Joystick a sinistra
                 EKeyDownArrow,      # Joystick a destra
                 EKeySelect,         # Joystick premuto
                 EKeyMenu,           # Tasto Menu
                 EKeyEdit,           # Tatsto Matita
                 EKeyRightSoftkey,   # SoftKey destro
                 EKeyLeftSoftkey,    # SoftKey sinistra
                )
            global maskcal, visibile, conteggio
            global menu1, menu2, menu3, menu4, menu5
            global mostrato_memo

        global mask1, mask2, mask3, mask4, mask5
        global shot_img

        imag = graphics.Image.new((sx, sy))
        imag.blit(shot_img)

        if icone_sino==0:
            capturer.keys = (
                 EKeyYes,            # Tasto di chiamata
                 #EKeyLeftArrow,      # Joystick a sinistra
                 #EKeyRightArrow,     # Joystick a destra
                 #EKeySelect,         # Joystick premuto
                 EKeyMenu,           # Tasto Menu
                 EKeyEdit,           # Tatsto Matita
                 EKeyRightSoftkey,   # SoftKey destro
                 EKeyLeftSoftkey,    # SoftKey sinistra
                )

        z=0 # posizione y
        if icone_sino:
            #################### 1^ linea tratteggiata #################
            if spostamento==0:
                _i=3
                for x_ in range((sx/3)+2):
                    imag.point((_i*(x_-1), z), cselez_, width=1)

            z=2
            ####################  icone ################################
            if num_ico>0:
                imag.blit(img1, mask = mask1, target = (i_x*0 +1 +sposta_y, z +2 +sposta_x))
            if num_ico>1:
                imag.blit(img2, mask = mask2, target = (i_x*1 +2 +sposta_y, z +2 +sposta_x))
            if num_ico>2:
                imag.blit(img3, mask = mask3, target = (i_x*2 +3 +sposta_y, z +2 +sposta_x))
            if num_ico>3:
                imag.blit(img4, mask = mask4, target = (i_x*3 +4 +sposta_y, z +2 +sposta_x))
            if num_ico>4:
                imag.blit(img5, mask = mask5, target = (i_x*4 +5 +sposta_y, z +2 +sposta_x))

            #################### selezione #############################
            if num_ico>1:
                imag.rectangle([i_x * (selez -1) +selez +sposta_y,   2 +sposta_x,
                                i_x * (selez) +selez -1 +sposta_y, i_y -1 +sposta_x], cselez_, width=2)

            z += i_y
            #################### 2^ linea tratteggiata #################
            if spostamento == 0:
                _i = 3
                for x_ in range((sx/3) + 3):
                    imag.point((_i * (x_ -1), z-1), cselez_, width = 1)

            #################### eventuali etichette ###################
            if etich_sino == 1:
                z += 11
                if   selez == 1: tes = u'' + menu1
                elif selez == 2: tes = u'' + menu2
                elif selez == 3: tes = u'' + menu3
                elif selez == 4: tes = u'' + menu4
                elif selez == 5: tes = u'' + menu5
                imag.text((i_x * (selez -1) +selez +sposta_y, z-1 +sposta_x), tes, fill = ctetich_, font = u"LatinPlain12")
                z += 13
            else:
                z += 12
        else:
            z=12

        if spostamento == 0:
            ################### icona  memo ##############################
            if memo_sino == 1:
                imag.blit(imgcal, mask = maskcal, target = (3, z -14))

                #################### testo memo ##############################
                if mostrato_memo == 0:
                    mostrato_memo = 1

                    elle          = 0
                    appuntamento  = 0 # ha orario
                    anniversario  = 0 # non ha orario
                    evento        = 0 # non ha orario
                    total         = 0 # somma di app+mem+anniv

                    cal     = calendar.open()
                    tt      = time.time() # ora
                    tempo   = tt - tt%60  # azzera i secondi nell'orario visto che i memo non ne hanno
                    lista   = cal.find_instances(tempo, tempo)
                    numlist = len(lista)

                    if numlist > 0:
                        i=0
                        appuuu=[]
                        memooo=[]
                        annivv=[]
                        for valore in range(numlist):
                            i = lista[valore]['id']
                            entry   = cal[i]
                            testocal= entry.content                #xxx
                            dovecal = entry.location               #xxx
                            inizio  = time.ctime(entry.start_time) #gio gen 18 12:00:00 2007
                            fine    = time.ctime(entry.end_time)   #gio gen 18 13:00:00 2007
                            if entry.type == 'appointment':    #appuntamento
                                if entry.start_time >= tempo:  # se l'appuntamento non и arrivato
                                    appuntamento += 1
                                    appuuu.append(u''+inizio.split(' ')[3][:-3]+' '+testocal+' '+dovecal)
                            elif entry.type == 'event':        #memo
                                evento += 1
                                memooo.append(u'' +testocal)
                            elif entry.type == 'anniversary':  #anniversario
                                anniversario += 1
                                annivv.append(u'' +testocal)

                        appuuu.sort()

                        total = appuntamento +evento +anniversario
                        if total == 0:
                            la_riga=[u'',u'',u'',u'',u'']
                            la_riga[0]=u''+vocab[6]  #'Solo memo scaduti'
                        else:
                            la_riga=[]
                            for i in range(appuntamento):
                                la_riga.append(appuuu[i])
                            for i in range(appuntamento,appuntamento+evento):
                                la_riga.append(memooo[appuntamento -i])
                            for i in range(appuntamento+evento, total):
                                la_riga.append(annivv[appuntamento+evento -i])
                            for i in range(total,5):
                                la_riga.append(u'')
                    else:
                        la_riga=[u'',u'',u'',u'',u'']
                        la_riga[0]=u''+vocab[7]  #'Oggi nessun memo'

                    old_evento = evento           # numero eventi
                    old_anniv  = anniversario     # numero anniversari
                    old_elle   = u''+str(total)   # compreso memo e anniversari
                    old_riga1  = la_riga[0]
                    old_riga2  = la_riga[1]
                    old_riga3  = la_riga[2]
                    old_riga4  = la_riga[3]
                    old_riga5  = la_riga[4]

                ics=16
                imag.text((ics, z-2+ 0),'['+old_elle+']', cmemo_, font = u"LatinBold12")
                if int(old_elle) > 9:
                    ics+=17+7
                else:
                    ics+=17
                aaa = u''
                if old_evento > 0: aaa += '[M]'
                if old_anniv  > 0: aaa += '[A]'
                imag.text((  0, z-2+11), aaa, cselez_, font = u"LatinBold12")

                imag.text((ics, z -2), old_riga1, cmemo_, font = u"LatinBold12")
                imag.text((ics, z+10), old_riga2, cmemo_, font = u"LatinBold12")
                imag.text((ics, z+22), old_riga3, cmemo_, font = u"LatinBold12")
                imag.text((ics, z+34), old_riga4, cmemo_, font = u"LatinBold12")
                imag.text((ics, z+46), old_riga5, cmemo_, font = u"LatinBold12")

        if len(screen.images) > 0:
            screen.remove_image(screen.images[0][0])
        screen.add_image(imag,(0 , 0, sx, sy))
        screen.show()

        if spostamento == 0:
            visibile  = 1
            conteggio = 0
            IniziaConto()

######################################################################
def Hide_Screen():
    global visibile, conteggio, timer
    global mostrato_memo
    global capturer
    capturer.keys = (
                 EKeyYes,            # Tasto di chiamata
                 #EKeyLeftArrow,      # Joystick a sinistra
                 #EKeyRightArrow,     # Joystick a destra
                 EKeySelect,         # Joystick premuto
                 EKeyMenu,           # Tasto Menu
                 EKeyEdit,           # Tatsto Matita
                 EKeyRightSoftkey,   # SoftKey destro
                 EKeyLeftSoftkey,    # SoftKey sinistra
                )

    mostrato_memo = 0
    visibile      = 0
    conteggio     = 0
    screen.hide()
    timer.cancel()

######################################################################
def Destra():
    global selez, spostamento
    selez += 1
    if selez > num_ico:
        selez = 1
    spostamento = 0
    Show_Screen()

######################################################################
def Sinistra():
    global selez, spostamento
    selez -= 1
    if selez < 1:
        selez = num_ico
    spostamento = 0
    Show_Screen()

######################################################################
def Premuto():
    global selez, allegato1,allegato2, allegato3, allegato4, allegato5
    Hide_Screen() # scomparsa veloce
    if   selez == 1: alleg = allegato1
    elif selez == 2: alleg = allegato2
    elif selez == 3: alleg = allegato3
    elif selez == 4: alleg = allegato4
    elif selez == 5: alleg = allegato5
    e32.start_exe('z:\\system\\programs\\apprun.exe', alleg)

######################################################################
def Opzioni():
    global etich_sino, memo_sino, no_bordo, posy, old_posy
    global laten, matita, ctetich_, cmemo_, cselez_, animazione, tipo_anim, icone_sino, num_ico
    global scadenza, spostamento, patto

    #lettura da file opzioni
    archivio=patto + '\\Settings\\options.txt'
    effe = open(archivio, 'r')
    riga=effe.readlines()
    effe.close()

    _y         = int(riga[0][:-2]) # altezza in pixel dove posizionare la barra
    etich_sino = int(riga[1][:-2]) # Etichette: 1=si 0=no
    _laten     = int(riga[2][:-2]) # latenza apparizione menu a video
    _matita    = int(riga[3][:-2]) # latenza uscita barra con la matita
    _ctetich_  =     riga[4][:-2]  # colore testo etichette
    memo_sino  = int(riga[5][:-2]) # Memo: 1=si 0=no
    _cmemo_    =     riga[6][:-2]  # colore memo calendario
    _cselez_   =     riga[7][:-2]  # colore selezione
    animazione = int(riga[8][:-2]) # Animazione: 1=si 0=no
    tipo_anim  = int(riga[9][:-2]) # Tipo animazione: 1=sinistra-destra 2=alto-basso 3= 4=
    icone_sino= int(riga[10][:-2]) # Icone: 1=si 0=no
    num_ico   = int(riga[11][:-2]) # numero icone

    z=1
    while z:
        #listacolori= [u'Personale...',u'Bianco',u'Nero',  u'Rosso', u'Verde', u'Blu',   u'Fuxia', u'Giallo',u'Cyano', u'Grigio C.',u'Grigio S.',u'Rosa C.',u'Rosa S.',u'Viola C.',u'Viola S.',u'Verde C.',u'Verde S.',u'Giallo C.',u'Giallo S.',u'Arancio',u'Arancio C.',u'Marrone',u'Granata']  #42 .. #64
        listacolori = [vocab[42],      vocab[43],vocab[44],vocab[45],vocab[46],vocab[47],vocab[48],vocab[49],vocab[50],vocab[51],   vocab[52],   vocab[53], vocab[54], vocab[55],  vocab[56],  vocab[57],  vocab[58],  vocab[59],   vocab[60],   vocab[61], vocab[62],    vocab[63], vocab[64]]  #42 .. #64
        listacodici = [u'Personale...',u'FFFFFF',u'000000',u'FF0000',u'00FF00',u'0000FF',u'FF00FF',u'FFFF00',u'00FFFF',u'CFCFCF',   u'5F5f5f',   u'FFA7A7', u'DA7171', u'B392FF',  u'6929FB',  u'52FBA9',  u'277952',  u'EFFC7D',   u'C8DB26',   u'FF9600', u'FFCA7E',    u'5D3200', u'600000' ]
        lista_anim  = [vocab[29], vocab[25], vocab[26], vocab[27], vocab[28]]
        lista_sino  = [vocab[19], vocab[18]] # no, si

        c_s=0
        c_e=0
        c_m=0
        for i in range (len(listacodici)):
            if unicode(_cselez_) == unicode(listacodici[i]):
                c_s=i
            if unicode(_ctetich_) == unicode(listacodici[i]):
                c_e=i
            if unicode(_cmemo_) == unicode(listacodici[i]):
                c_m=i

        dati = [
            (vocab[ 8]+' (1-120)',          'number', _y),                      #posizione della barra
            (vocab[10]+'(0='+vocab[11]+')', 'number', _laten),                  #secondi di permanenza
            (vocab[13]+'(0-5)',             'number', _matita),                 #secondi per uscita tasto matita
            (vocab[69]+'',                  'combo', (lista_sino, icone_sino)), #icone si/no 1/0
            (vocab[70]+' (1-5)',            'number', num_ico),                 #n. icone
            (vocab[15]+' (RGB hex)',        'combo', (listacolori, c_s)),       #colore selezione
            (vocab[17]+'',                  'combo', (lista_sino, etich_sino)), #etichette si/no 1/0
            (vocab[20]+' (RGB hex)',        'combo', (listacolori, c_e)),       #colore etichette
            (vocab[21]+'',                  'combo', (lista_sino, memo_sino)),  #memo si/no 1/0
            (vocab[22]+' (RGB hex)',        'combo', (listacolori, c_m)),       #colore memo
            (vocab[23]+'',                  'combo', (lista_sino, animazione)), #animazione barra si/no 1/0
            (vocab[24]+'',                  'combo', (lista_anim, tipo_anim))   #tipo animazione 1/5
           ]
        flags = appuifw.FFormEditModeOnly+appuifw.FFormDoubleSpaced
        fff = appuifw.Form(dati, flags)
        fff.execute()

        numero = fff[  0  ][2]              # number
        posy = int(numero)
        _y1  = str(numero) +chr(13)+chr(10)

        numero = fff[  1  ][2]              # number
        laten    = int(numero)
        scadenza = laten * 10
        _laten1  = str(numero) +chr(13)+chr(10)

        numero = fff[  2  ][2]              # number
        matita  = int(numero)
        _matita = str(numero) +chr(13)+chr(10)

        numero = fff[  3  ][2][1]
        lettera= fff[  3  ][2][0][numero]   # combo
        icone_sino  = int(numero)
        icone_sino1 = str(numero) +chr(13)+chr(10)

        numero = fff[  4  ][2]              # number
        num_ico  = int(numero)
        num_ico1 = str(numero) +chr(13)+chr(10)

        numero = fff[  5  ][2][1]
        lettera= fff[  5  ][2][0][numero]   # combo
        if numero==0:
            cselez_=-1
        else:
            cselez_  = eval('0x' + listacodici[numero])
            cselez_1 = str(listacodici[numero]) +chr(13)+chr(10)

        numero = fff[  6  ][2][1]
        lettera= fff[  6  ][2][0][numero]   # combo
        etich_sino = int(numero)
        etichsino1 = str(numero) +chr(13)+chr(10)

        numero = fff[  7  ][2][1]
        lettera= fff[  7  ][2][0][numero]   # combo
        if numero==0:
            ctetich_=-1
        else:
            ctetich_  = eval('0x' + listacodici[numero])
            ctetich_1 = str(listacodici[numero]) +chr(13)+chr(10)

        numero = fff[  8  ][2][1]
        lettera= fff[  8  ][2][0][numero]   # combo
        memo_sino = int(numero)
        memosino1 = str(numero) +chr(13)+chr(10)

        numero = fff[  9  ][2][1]
        lettera= fff[  9  ][2][0][numero]   # combo
        if numero==0:
            cmemo_=-1
        else:
            cmemo_  = eval('0x' + listacodici[numero])
            cmemo_1 = str(listacodici[numero]) +chr(13)+chr(10)

        numero = fff[ 10  ][2][1]
        lettera= fff[ 10  ][2][0][numero]   # combo
        animazione  = int(numero)
        animazione1 = str(numero) +chr(13)+chr(10)

        numero = fff[ 11  ][2][1]
        lettera= fff[ 11  ][2][0][numero]   # combo
        tipo_anim  = int(numero)
        tipo_anim1 = str(numero) +chr(13)+chr(10)

        #controlli
        if (posy>=1) and (posy <=120):
            if (laten>=0) and (laten<=3600):
                if (matita>=0) and (matita<=5):
                    if (num_ico>=1) and (num_ico<=5):
                        z=0
                    else:
                        #errore per num_ico
                        appuifw.note(vocab[70]+': '+'Da 1 a 5 icone')
                else:
                   #errore per matita
                   appuifw.note(vocab[13]+': '+vocab[14]) #"Da 0 a 5 secondi."
            else:
                #errore per laten
                appuifw.note(vocab[10]+': '+vocab[12]) #"Numero da 0 a 3600."
        else:
            #errore per posy
            appuifw.note(vocab[8]+': '+vocab[9]) #"Un numero da 1 a 120."

        if z==1:
            _y         = posy        # altezza in pixel dove posizionare la barra
            _laten     = laten       # latenza apparizione menu a video
            _matita    = matita      # latenza uscita barra con la matita

    #controllo colore selezione
    if cselez_!=-1:
        cselez_1 = str(listacodici[fff[  5  ][2][1]]) +chr(13)+chr(10)
    else:
        #inserire il valore esadecimale per cselez_
        zz  = 1
        tes = vocab[15]+':\n(RGB hex)' #'Colore selezione'
        while zz:
            _nome_ = appuifw.query(tes, 'text', u'' + _cselez_)
            if _nome_ != None:
                try:
                    _prova__ = eval('0x' + _nome_)
                    zz=0
                except:
                    tes = vocab[16]+'\n+'+vocab[15]+':\n(RGB hex)'   #'Codice errato.' #'Colore selezione'
        cselez_  = eval('0x' + _nome_)
        _cselez_ = _nome_
        cselez_1 = str(_nome_) +chr(13)+chr(10)

    #controllo colore etichette
    if ctetich_!=-1:
        ctetich_1 = str(listacodici[fff[  7  ][2][1]]) +chr(13)+chr(10)
    else:
        #inserire il valore esadecimale per ctetich_
        zz  = 1
        tes = vocab[20]+':\n(RGB hex)' #'Colore etichette'
        while zz:
            _nome_ = appuifw.query(tes,'text',u'' + _ctetich_)
            if _nome_ != None:
                try:
                    _prova__ = eval('0x'+_nome_)
                    zz = 0
                except:
                    tes = vocab[16]+'\n'+vocab[20]+':\n(RGB hex)' #'Codice errato.' #'Colore etichette'
        ctetich_  = eval('0x' + _nome_)
        _ctetich_ = _nome_
        ctetich_1 = str(_nome_) +chr(13)+chr(10)

    #controllo colore memo
    if cmemo_!=-1:
         cmemo_1 = str(listacodici[fff[  9  ][2][1]]) +chr(13)+chr(10)
    else:
         #inserire il valore esadecimale per cmemo_
         zz  = 1
         tes = vocab[22]+':\n(RGB hex)' #'Colore memo'
         while zz:
             _nome_ = appuifw.query(tes,'text',u'' + _cmemo_)
             if _nome_ != None:
                 try:
                     _prova__ = eval('0x' + _nome_)
                     zz = 0
                 except:
                     tes = vocab[16]+'\n'+vocab[22]+':\n(RGB hex)' #'Codice errato.' #'Colore memo'
         cmemo_  = eval('0x' + _nome_)
         _cmemo_ = _nome_
         cmemo_1 = str(_nome_) +chr(13)+chr(10)

    #salva su file
    effe = open(archivio, 'w')
    effe.write(_y1)
    effe.write(etichsino1)
    effe.write(_laten1)
    effe.write(_matita)
    effe.write(ctetich_1)
    effe.write(memosino1)
    effe.write(cmemo_1)
    effe.write(cselez_1)
    effe.write(animazione1)
    effe.write(tipo_anim1)
    effe.write(icone_sino1)
    effe.write(num_ico1)
    effe.close()

    if icone_sino==0:
        memo_sino =1
        animazione=0

    ################# modifica la videata con le nuove opzioni
    appswitch.switch_to_fg(u"Phone")
    e32.ao_sleep(0.2)
    if old_posy != posy:
        screen.position = (posx, posy)
        Cattura_Tema()
        old_posy = posy
    if animazione:
        Appare()
    spostamento = 0
    Show_Screen()

######################################################################
def Programmi():
    global allegato1, allegato2, allegato3, allegato4, allegato5
    global img1, img2, img3, img4, img5, mask1, mask2, mask3, mask4, mask5, menu1, menu2, menu3, menu4, menu5
    global animazione, spostamento

    # ricerca programmi
    listaprog=[]
    appuifw.note(vocab[3]) #"Ricerca applicazioni installate..."
    for i in memory:
        listaapp = os.listdir(i+":\\system\\apps")
        for x in listaapp:
            cartelle = x.find(".")
            if cartelle == -1:
                programmfolder = os.listdir(i + ":\\system\\apps\\%s"%x)
                for app in programmfolder:
                    programmas = app.find(".app")
                    if programmas != -1:
                        if Trova_File (i + ":\\system\\apps\\" + app[:-4] + "\\" + app) == 1:
                            listaprog.append(unicode(i + ': ' + app[:-4]))

    if len(listaprog) != 0:
        listaprog.sort()

    # ricerca icone
    listapng=[]
    pngfolder = os.listdir(patto + "\\IconPack\\")
    for png in pngfolder:
        if Trova_File (patto + "\\IconPack\\" + png) == 1:
            listapng.append(unicode(png[:-4]))

    if len(listapng) != 0:
        listapng.sort()

    #leggere da opzioni il nome programma, le etichette e le icone salvate
    archivio = patto + '\\Settings\\progs.txt'
    effe = open(archivio, 'r')
    riga = effe.readlines()
    effe.close()
    _progr = []
    _progr.append(riga[0][:-2]) # programma 1
    _progr.append(riga[1][:-2]) # programma 2
    _progr.append(riga[2][:-2]) # programma 3
    _progr.append(riga[3][:-2]) # programma 4
    _progr.append(riga[4][:-2]) # programma 5

    archivio = patto + '\\Settings\\labels.txt'
    effe = open(archivio, 'r')
    riga = effe.readlines()
    effe.close()
    _label = []
    _label.append(riga[0][:-2]) # etichetta 1
    _label.append(riga[1][:-2]) # etichetta 2
    _label.append(riga[2][:-2]) # etichetta 3
    _label.append(riga[3][:-2]) # etichetta 4
    _label.append(riga[4][:-2]) # etichetta 5

    archivio = patto + '\\Settings\\icons.txt'
    effe = open(archivio, 'r')
    riga = effe.readlines()
    effe.close()
    _icons = []
    _icons.append(riga[0][:-2]) # icona 1
    _icons.append(riga[1][:-2]) # icona 2
    _icons.append(riga[2][:-2]) # icona 3
    _icons.append(riga[3][:-2]) # icona 4
    _icons.append(riga[4][:-2]) # icona 5

    totpro=[]
    totlab=[]
    totico=[]
    for conta in range (5):
        #trova la posizione di: programma, etichetta e icona e crea progsalvato[], etichsalvata[],iconasalvata[]
        a=_progr[conta][:1] #drive
        b=_progr[conta][15:]  #[e:\system\apps\]  b[nomeprogramma\nomeprogramma.app]
        c=b.find('\\')
        d=b[:c]   # d[nomeprogramma] [\nomeprogramma.app]
        trova=a+': '+d  #C: MyApp

        progsalvato=0
        for i in range(len(listaprog)):
            if trova.upper() == listaprog[i].upper() :
                progsalvato=i

        etichsalvata=unicode(_label[conta])

        iconasalvata=0
        for i in range(len(listapng)):
            if _icons[conta].upper() == listapng[i].upper() :
                iconasalvata=i

        #nome, etichetta,icona
        dati = [
            (vocab[68]+' '+str(conta+1), 'combo', (listaprog, progsalvato)), #programma
            (vocab[32]+' '+str(conta+1), 'text',  etichsalvata),             #etichetta
            (vocab[67]+' '+str(conta+1), 'combo', (listapng,  iconasalvata)) #icona
           ]
        flags = appuifw.FFormEditModeOnly+appuifw.FFormDoubleSpaced
        fff = appuifw.Form(dati, flags)
        fff.execute()

        numero = fff[  0  ][2][1]
        lettera= fff[  0  ][2][0][numero]   # combo
        a=unicode(lettera[:1]+":\\system\\apps\\"+lettera[3:]+"\\"+lettera[3:]+".app")
        totpro.append(a)

        lettera = fff[  1  ][2]             # text
        totlab.append(lettera)

        numero = fff[  2  ][2][1]
        lettera= fff[  2  ][2][0][numero]   # combo
        totico.append(lettera)

    archivio = patto + '\\Settings\\progs.txt'
    effe = open(archivio, 'w')
    for _conta in range(5):
        effe.write(totpro[_conta] +chr(13)+chr(10)) # programma 1
        if   _conta==0: allegato1=totpro[_conta]
        elif _conta==1: allegato2=totpro[_conta]
        elif _conta==2: allegato3=totpro[_conta]
        elif _conta==3: allegato4=totpro[_conta]
        elif _conta==4: allegato5=totpro[_conta]
    effe.close()

    archivio = patto + '\\Settings\\labels.txt'
    effe = open(archivio, 'w')
    for _conta in range(5):
        effe.write(totlab[_conta] +chr(13)+chr(10)) # etichetta 1
        if   _conta==0: menu1=totlab[_conta]
        elif _conta==1: menu2=totlab[_conta]
        elif _conta==2: menu3=totlab[_conta]
        elif _conta==3: menu4=totlab[_conta]
        elif _conta==4: menu5=totlab[_conta]
    effe.close()

    archivio = patto + '\\Settings\\icons.txt'
    effe = open(archivio, 'w')
    for _conta in range(5):
        effe.write(totico[_conta] +chr(13)+chr(10)) # etichetta 1
    effe.close()

    ########## carica icone
    img1 = graphics.Image.open(patto + '\\IconPack\\' + totico[0]+'.png')
    img2 = graphics.Image.open(patto + '\\IconPack\\' + totico[1]+'.png')
    img3 = graphics.Image.open(patto + '\\IconPack\\' + totico[2]+'.png')
    img4 = graphics.Image.open(patto + '\\IconPack\\' + totico[3]+'.png')
    img5 = graphics.Image.open(patto + '\\IconPack\\' + totico[4]+'.png')
    ########## crea maschere
    mask1 = Crea_Maschera(img1)
    mask2 = Crea_Maschera(img2)
    mask3 = Crea_Maschera(img3)
    mask4 = Crea_Maschera(img4)
    mask5 = Crea_Maschera(img5)

    ################# modifica la videata con le nuove opzioni
    appswitch.switch_to_fg(u"Phone")
    e32.ao_sleep(0.2)
    if animazione:
        Appare()
    spostamento = 0
    Show_Screen()

######################################################################
def cb_capture(key):
    global capturer, matita, spostamento
    if appswitch.application_list(1)[0] in Phone:

        capturer.forwarding=0
        if (key == EKeyLeftArrow):         # freccia sinistra
            Sinistra()
        elif (key == EKeyRightArrow):      # freccia destra
            Destra()
        elif (key == EKeySelect):          # premuto joy
            if visibile:
                Premuto()
            else:
                capturer.forwarding=1
        elif (key == EKeyEdit):            # matita
            if visibile == 0:
                if animazione:
                    Appare()
                spostamento = 0
                mostrato_memo = 0
                Show_Screen()
            else:
                e32.ao_sleep(matita)
                if animazione:
                    Scompare()
                Hide_Screen()
        elif (key == EKeyMenu):            # menu
            capturer.forwarding=1
            Hide_Screen() # scomparsa veloce
        elif (key == EKeyRightSoftkey):    # destro
            capturer.forwarding=1
            Hide_Screen() # scomparsa veloce
        elif (key == EKeyLeftSoftkey):     # sinistro
            capturer.forwarding=1
            Hide_Screen() # scomparsa veloce
        elif (key == EKeyYes):             # verde
            capturer.forwarding=1
            Hide_Screen() # scomparsa veloce
    else:
        capturer.forwarding=1
        Hide_Screen() # scomparsa veloce
        if appswitch.application_list(1)[0] == u"Menu":
            if (key == EKeyEdit):          # matita
               global cattura
               if cattura == 1:
                   OK_Cattura_Icone()
                   appuifw.note(vocab[33]+"\n"+vocab[34]) #"Il programma verra\' terminato." #"Riavvialo per attuare le modifiche."
                   quit()

######################################################################
def IniziaConto():
    global timer, conteggio, visibile, scadenza
    if scadenza != 0:
        conteggio += 1
        if (appswitch.application_list(1)[0] in Phone):
            i = 0
        else: # non sul desktop
            if visibile:
                visibile  = 0
                conteggio = 0
                timer.cancel()
                Hide_Screen() # scomparsa veloce
                return
        if(conteggio>=scadenza):
            visibile  = 0
            conteggio = 0
            timer.cancel()
            if animazione:
                Scompare()
            Hide_Screen()
            return
        timer.cancel()
        timer.after(0.1,IniziaConto)

######################################################################
def Appare():
    global mostrato_memo, sposta_y, spostamento, sposta_x
    mostrato_memo = 0
    spostamento   = 1
    if tipo_anim == 0:    #random
        tipo=random.randint(1,4)
    else:
        tipo=tipo_anim

    if tipo == 1:    # da sinistra a destra
        sposta_x = 0
        for i in range(30):
            sposta_y = i*6 -174
            Show_Screen()
            e32.ao_sleep(0.01)
    elif tipo == 2:  # da destra a sinistra
        sposta_x = 0
        for i in range(30):
            sposta_y = 174 -i*6
            Show_Screen()
            e32.ao_sleep(0.01)
    elif tipo == 3:  # dall'alto in basso
        sposta_y  = 0
        for i in range(12):
            sposta_x = i*6 -66
            Show_Screen()
            e32.ao_sleep(0.01)
    elif tipo == 4:  # dal basso in alto
        sposta_y  = 0
        for i in range(12):
            sposta_x = 66 -i*6
            Show_Screen()
            e32.ao_sleep(0.01)

######################################################################
def Scompare(): # da sinistra a destra
    global mostrato_memo, sposta_y, spostamento, sposta_x
    mostrato_memo = 0
    spostamento   = 1
    if tipo_anim == 0:    #random
        tipo=random.randint(1,4)
    else:
        tipo=tipo_anim

    if tipo == 1:    # da sinistra a destra
        sposta_x = 0
        for i in range(29):
            sposta_y = i*6
            Show_Screen()
            e32.ao_sleep(0.01)
    elif tipo == 2:  # da destra a sinistra
        sposta_x = 0
        for i in range(29):
            sposta_y = -i*6
            Show_Screen()
            e32.ao_sleep(0.01)
    elif tipo == 3:  # dall'alto in basso
        sposta_y  = 0
        for i in range(11):
            sposta_x = i*6
            Show_Screen()
            e32.ao_sleep(0.01)
    elif tipo == 4:  # dal basso in alto
        sposta_y  = 0
        for i in range(11):
            sposta_x = -i*6
            Show_Screen()
            e32.ao_sleep(0.01)

######################################################################
def Crediti():
    appuifw.note(u"DesktOper\nBy Mimmo \'Oper\' Campagna.")

######################################################################
def Lingua():
    global max_line, vocab
    listatxt=[]
    txtfolder = os.listdir(patto + "\\Languages\\")
    for txt in txtfolder:
        if Trova_File (patto + "\\Languages\\" + txt) == 1:
            listatxt.append(unicode(txt[:-4]))

    listatxt.sort()
    menu_scelta = appuifw.popup_menu(listatxt, vocab[4]) #"Scegli e premi Ok"
    if menu_scelta == None:
        _lingua_ = "Italiano"
    else:
        _lingua_ = str(listatxt[int(menu_scelta)])

    archivio = patto + '\\Settings\\Language.txt'
    effe = open(archivio, 'w')
    effe.write(_lingua_+chr(13)+chr(10))
    effe.close()

    ###### lettura lingua
    archivio = patto + '\\Languages\\'+_lingua_
    effe = open(archivio+'.txt', 'r')
    riga = effe.readlines()
    effe.close()

    vocab=[]
    for i in range(max_line):
        vocab.append(unicode(riga[i][:-2]))

    appuifw.app.menu   = [
                      (vocab[37], Opzioni),           #u"Personalizza"
                      (vocab[38], Programmi),         #u"Seleziona programmi"
                      (vocab[65], Lingua),            #u"Lingua"
                      (vocab[39], Cattura_Icone),     #u"Cattura icone"
                      (vocab[40], Crediti),           #u"Credits"
                      (vocab[41], quit)               #u"Esci"
                     ]

######################################################################
def quit():
    global term
    term=0
    appuifw.app.set_exit()

######################################################################
######################################################################
app_lock = e32.Ao_lock()

path  = u'' + str(os.path.split(appuifw.app.full_name())[0][:1])
patto = path + ':\\system\\apps\\RunPython\\Apps\\DesktOper'

###### lettura lingua
archivio = patto + '\\Settings\\language.txt'
effe = open(archivio, 'r')
riga = effe.readlines()
effe.close()

archivio = patto + '\\Languages\\'+riga[0][:-2]
effe = open(archivio+'.txt', 'r')
riga = effe.readlines()
effe.close()

for i in range(max_line):
    vocab.append(unicode(riga[i][:-2]))

########## carica icone
effe = open(patto+'\\Settings\\icons.txt', 'r')
riga = effe.readlines()
effe.close()

img1 = graphics.Image.open(patto + '\\IconPack\\' + riga[0][:-2]+'.png')
img2 = graphics.Image.open(patto + '\\IconPack\\' + riga[1][:-2]+'.png')
img3 = graphics.Image.open(patto + '\\IconPack\\' + riga[2][:-2]+'.png')
img4 = graphics.Image.open(patto + '\\IconPack\\' + riga[3][:-2]+'.png')
img5 = graphics.Image.open(patto + '\\IconPack\\' + riga[4][:-2]+'.png')
imgcal = graphics.Image.open(patto + '\\Settings\\cal.png')

########## crea maschere
mask1 = Crea_Maschera(img1)
mask2 = Crea_Maschera(img2)
mask3 = Crea_Maschera(img3)
mask4 = Crea_Maschera(img4)
mask5 = Crea_Maschera(img5)
maskcal = Crea_Maschera(imgcal)

###### lettura opzioni
archivio = patto + '\\Settings\\options.txt'
effe = open(archivio, 'r')
riga = effe.readlines()
effe.close()
posy            = int(riga[0][:-2])  # altezza in pixel dove posizionare la barra
etich_sino      = int(riga[1][:-2])  # Etichette: 1=si 0=no
laten           = int(riga[2][:-2])  # latenza apparizione menu a video
matita          = int(riga[3][:-2])  # latenza uscita barra con il tasto matita
ctetich_ = eval('0x'+(riga[4][:-2])) # colore testo etichette
memo_sino       = int(riga[5][:-2])  # Etichette: 1=si 0=no
cmemo_   = eval('0x'+(riga[6][:-2])) # colore memo calendario
cselez_  = eval('0x'+(riga[7][:-2])) # colore selezione
animazione      = int(riga[8][:-2])  # Animazione: 1=si 0=no
tipo_anim       = int(riga[9][:-2])  # Tipo animazione: 1=sinistra-destra 2=alto-basso
icone_sino     = int(riga[10][:-2])  # Icone: 1=si 0=no
num_ico        = int(riga[11][:-2])  # numero icone

if icone_sino==0:
    memo_sino =1
    animazione=0

old_posy = posy

###### lettura programmi
effe = open(patto + '\\Settings\\progs.txt', 'r')
riga = effe.readlines()
effe.close()
allegato1 = riga[0][:-2] # applicazione 1
allegato2 = riga[1][:-2] # applicazione 2
allegato3 = riga[2][:-2] # applicazione 3
allegato4 = riga[3][:-2] # applicazione 4
allegato5 = riga[4][:-2] # applicazione 5

###### lettura etichette
effe = open(patto + '\\Settings\\labels.txt', 'r')
riga = effe.readlines()
effe.close()
menu1 = riga[0][:-2]     # etichetta applicazione 1
menu2 = riga[1][:-2]     # etichetta applicazione 2
menu3 = riga[2][:-2]     # etichetta applicazione 3
menu4 = riga[3][:-2]     # etichetta applicazione 4
menu5 = riga[4][:-2]     # etichetta applicazione 5

appuifw.app.screen = 'normal'
appuifw.app.menu   = [
                      (vocab[37], Opzioni),           #u"Personalizza"
                      (vocab[38], Programmi),         #u"Seleziona programmi"
                      (vocab[65], Lingua),            #u"Lingua"
                      (vocab[39], Cattura_Icone),     #u"Cattura icone"
                      (vocab[40], Crediti),           #u"Credits"
                      (vocab[41], quit)               #u"Esci"
                     ]
appuifw.app.body   = canvas = appuifw.Canvas(redraw_callback=None)

scadenza  = laten * 10 # = laten secondi ; 0=infinito
conteggio = 0
timer     = e32.Ao_timer()

screen          = TopWindow.TopWindow()
screen.size     = (sx, sy)
screen.position = (posx, posy)
#screen.corner_type = 'square'
#screen.background_color = 0xFF0000
#screen.fading = 1
#screen.shadow = 0#ombra

global capturer
capturer = keycapture.KeyCapturer(cb_capture)
capturer.keys = (
                 EKeyYes,            # Tasto di chiamata
                 #EKeyLeftArrow,      # Joystick a sinistra
                 #EKeyRightArrow,     # Joystick a destra
                 EKeySelect,         # Joystick premuto
                 EKeyMenu,           # Tasto Menu
                 EKeyEdit,           # Tatsto Matita
                 EKeyRightSoftkey,   # SoftKey destro
                 EKeyLeftSoftkey,    # SoftKey sinistra
                )
capturer.forwarding = 0
capturer.start()

appswitch.switch_to_fg(u"Phone")
e32.ao_sleep(0.2)
Cattura_Tema()

if animazione:
    Appare()
spostamento = 0
Show_Screen()

appuifw.app.exit_key_handler = quit
app_lock.wait()

