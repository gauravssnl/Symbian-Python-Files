python=[u'E:/system/libs/encodings/zlib_codec.py',u'E:/system/libs/encodings/uu_codec.py',u'E:/system/libs/encodings/utf_8.py',u'E:/system/libs/encodings/utf_7.py',u'E:/system/libs/encodings/utf_16_le.py',u'E:/system/libs/encodings/utf_16_be.py',u'E:/system/libs/encodings/utf_16.py',u'E:/system/libs/encodings/unicode_internal.py',u'E:/system/libs/encodings/unicode_escape.py',u'E:/system/libs/encodings/raw_unicode_escape.py',u'E:/system/libs/encodings/latin_1.py',u'E:/system/libs/encodings/hex_codec.py',u'E:/system/libs/encodings/charmap.py',u'E:/system/libs/encodings/base64_codec.py',u'E:/system/libs/encodings/ascii.py',u'E:/system/libs/encodings/aliases.py',u'E:/system/libs/encodings/__init__.py',u'E:/system/libs/random.py',u'E:/system/libs/zipfile.py',u'E:/system/libs/urllib.py',u'E:/system/libs/copy_reg.py',u'E:/system/libs/repr.py',u'E:/system/libs/copy.py',u'E:/system/libs/whrandom.py',u'E:/system/libs/StringIO.py',u'E:/system/libs/string.py',u'E:/system/libs/warnings.py',u'E:/system/libs/keyword.py',u'E:/system/libs/uu.py',u'E:/system/libs/urlparse.py',u'E:/system/libs/rfc822.py',u'E:/system/libs/quopri.py',u'E:/system/libs/mimetools.py',u'E:/system/libs/getpass.py',u'E:/system/libs/httplib.py',u'E:/system/libs/base64.py',u'E:/system/libs/atexit.py',u'E:/system/libs/codecs.py',u'E:/system/libs/site.py',u'E:/system/libs/sre_parse.py',u'E:/system/libs/sre_constants.py',u'E:/system/libs/sre_compile.py',u'E:/system/libs/sre.py',u'E:/system/libs/re.py',u'E:/system/libs/__future__.py',u'E:/system/libs/types.py',u'E:/system/libs/stat.py',u'E:/system/libs/traceback.py',u'E:/system/libs/linecache.py',u'E:/system/libs/codeop.py',u'E:/system/libs/code.py',u'E:/system/libs/shutil.py',u'E:/system/libs/ntpath.py',u'E:/system/libs/pack.py',u'E:/system/libs/os.py',u'E:/system/libs/key_codes.py',u'E:/system/libs/e32dbm.py',u'E:/system/libs/whichdb.py',u'E:/system/libs/anydbm.py',u'E:/system/libs/btconsole.py',u'E:/system/libs/python222.dll',u'E:/system/libs/_locationacq.pyd',u'E:/system/libs/glcanvas.pyd',u'E:/system/libs/gles.pyd',u'E:/system/libs/_topwindow.pyd',u'E:/system/libs/_keycapture.pyd',u'E:/system/libs/inbox.pyd',u'E:/system/libs/_calendar.pyd',u'E:/system/libs/_recorder.pyd',u'E:/system/libs/_telephone.pyd',u'E:/system/libs/_graphics.pyd',u'E:/system/libs/_camera.pyd',u'E:/system/libs/zlib.pyd',u'E:/system/libs/_sysinfo.pyd',u'E:/system/libs/_contacts.pyd',u'E:/system/libs/_location.pyd',u'E:/system/libs/_messaging.pyd',u'E:/system/libs/e32socket.pyd',u'E:/system/libs/e32db.pyd',u'E:/system/programs/python_launcher.exe',u'E:/system/libs/select.py',u'E:/system/libs/socket.py',u'E:/system/libs/calendar.py',u'E:/system/libs/sysinfo.py',u'E:/system/libs/camera.py',u'E:/system/libs/messaging.py',u'E:/system/libs/location.py',u'E:/system/libs/positioning.py',u'E:/system/libs/locationacq.py',u'E:/system/libs/gles_utils.py',u'E:/system/libs/topwindow.py',u'E:/system/libs/keycapture.py',u'E:/system/libs/audio.py',u'E:/system/libs/telephone.py',u'E:/system/libs/contacts.py',u'E:/system/libs/graphics.py',u'E:/system/libs/UserDict.py',u'E:/system/libs/weakref.py',u'E:/system/libs/appuifw.py',u'E:/system/data/appuifwmodule.rsc',u'C:/system/data/appuifwmodule.rsc',u'E:/system/libs/python_appui.dll']
modul=[u'E:/SYSTEM/LIBS/appcreation.pyc',u'E:/SYSTEM/LIBS/appswitch.pyd',u'E:/SYSTEM/LIBS/callstatus.pyd',u'E:/SYSTEM/LIBS/cerealizer.py',u'E:/SYSTEM/LIBS/clipboard.py',u'E:/SYSTEM/LIBS/DIR_ITER.PY',u'E:/SYSTEM/LIBS/easydb.py',u'E:/SYSTEM/LIBS/esysagent.py',u'E:/SYSTEM/LIBS/FGIMAGE.PYD',u'E:/SYSTEM/LIBS/FLASHY.PYD',u'E:/SYSTEM/LIBS/FTPLIB.PY',u'E:/SYSTEM/LIBS/HACK.PYD',u'E:/SYSTEM/LIBS/iapconnect.pyd',u'E:/SYSTEM/LIBS/key_modifiers.py',u'E:/SYSTEM/LIBS/KEYPRESS.PYD',u'E:/SYSTEM/LIBS/key_tricks.py',u'E:/SYSTEM/LIBS/LITE_FM.PYC',u'E:/SYSTEM/LIBS/MBM.PY',u'E:/SYSTEM/LIBS/MISO.PYD',u'E:/SYSTEM/LIBS/mmsmodule.pyd',u'E:/SYSTEM/LIBS/MUSIC.PYD',u'E:/SYSTEM/LIBS/powlite_fm.mbm',u'E:/SYSTEM/LIBS/powlite_fm.py',u'E:/SYSTEM/LIBS/proshivka.pyc',u'E:/SYSTEM/LIBS/RUSOS.PYC',u'E:/SYSTEM/LIBS/sets.py',u'E:/SYSTEM/LIBS/SWITCHOFF.PYD',u'E:/SYSTEM/LIBS/SYSAGENT.PYD',u'E:/SYSTEM/LIBS/UIDCRC.PY',u'E:/SYSTEM/LIBS/_UIDCRC.PYD',u'E:/SYSTEM/LIBS/uikludges.pyd',u'E:/SYSTEM/LIBS/UITRICKS.PYD',u'E:/SYSTEM/LIBS/VIBRA.PYD',u'E:/SYSTEM/LIBS/wmessaging.pyd',u'E:/SYSTEM/LIBS/encodings/CP1251.PY',u'E:/SYSTEM/LIBS/encodings/CP1251.PYC',u'E:/SYSTEM/LIBS/encodings/iso8859_5.py',u'E:/SYSTEM/LIBS/encodings/KOI8_R.PY',u'E:/SYSTEM/LIBS/encodings/KOI8_U.PY',u'E:/SYSTEM/LIBS/encodings/LATIN_1.PY']

from appuifw import *
import os
import e32
def ru(x):return x.decode('utf-8')
app.screen='large'
txt=Text()
txt.color=0x0
app.body=txt
txt.add(ru('Начало проверки файлов питона 1.40 ...\n'))
cp=0
cm=0
txt.color=0xff0000
for x in python:
 if os.path.exists(x)==0:
  txt.add(x)
  txt.add(u'\n')
  cp=cp+1
txt.color=0x0
e32.ao_sleep(1)
txt.add(ru('проверка питона закончена\n'))
e32.ao_sleep(1)
txt.add(ru('начало проверки модуль пака 1.16\n'))
txt.color=0xff0000
for x in modul:
 if os.path.exists(x)==0:
  txt.add(x)
  txt.add(u'\n')
  cm=cm+1
txt.color=0x0
e32.ao_sleep(1)
txt.add(ru('проверка модуль пака закончена\n'))
txt.color=0x00ff00
e32.ao_sleep(2)
txt.add(ru('Результат проверки:'))
txt.color=0x0

txt.add(ru('\nПитон:'))
if cp>0:
 txt.color=0xff0000
 txt.add(ru('проблемы с ')+str(cp)+ru(' файл'))
else:
 txt.color=0x00ff00
 txt.add(ru('Норма'))
txt.color=0x0

txt.add(ru('\nМодуль пак:'))
if cm>0:
 txt.color=0xff0000
 txt.add(ru('проблемы с ')+str(cp)+ru(' файл'))
else:
 txt.color=0x00ff00
 txt.add(ru('Норма'))
txt.color=0
txt.add(ru('\nсоздано: Игорь aka kAIST'))
txt.add(ru('\ne-mail: igor.kaist@gmail.com'))
txt.add(ru('\nICQ: 211141235'))

app_lock = e32.Ao_lock()
app_lock.wait()