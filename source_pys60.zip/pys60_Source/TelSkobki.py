import appuifw
import e32
import contacts
import string

codes = []

def ru(x):
    return x.decode('utf-8')

def ur(x):
    return x.encode('utf-8')
def anote(mess):
   appuifw.note(mess,"info")
def aerror(mess):
   appuifw.note(mess,"error")
def printout(mess):
    appuifw.app.body.add(mess)
    appuifw.app.body.add(u"\n")
def About():
    #authorinfo = """Produced by Atrant\natrant@front.ru"""
    authorinfo =  """Ca|wfpvw3qj3Rgar}gO}rgar}gSua|}g=af"""
    tmp = ""
    for qqqq in range(len(authorinfo)):
        tmp = tmp + chr(ord(authorinfo[qqqq]) ^ 19)
    authorinfo = tmp.replace("\\n","\n")
    anote(ru(authorinfo))
def Exit():
    appuifw.app.exit_key_handler = None
    global script_lock
    script_lock.signal()
class TelSkobki:
    def Insert(self):
       base = contacts.open()
       printout(ru("Подгружаю базу контактов..."))
       e32.ao_yield()
       conts = base.find(u"")
       for contact in conts:
          name1 = contact.find(u"first_name")
          name2 = contact.find(u"last_name")
          if len(name1) == 0: 
             name1 = u""
          else: 
             name1 = name1[0].value
          if len(name2) == 0: 
             name2 = u""
          else: 
             name2 = name2[0].value
          printout(u"\n" + name1 + u" " + name2)
          i = 0
          numbers = 0
          while i < 2:
            if i == 0: 
                numbers = contact.find(u"mobile_number")
                printout(ru("Мобильные:"))
            if i == 1: 
                numbers = contact.find(u"phone_number")
                printout(ru("Стационарные:"))
            for number in numbers:
                global codes
                for q in range(len(codes)):
                    prefix = codes[q].split(u" ")[0]
                    city = codes[q].split(u" ")[1]
                    if number.value.find(prefix+city) != -1:
                        contact.begin()
                        #if len(number.value) - len (prefix+city) == 7:
                        #    length = len(prefix+city)
                        #    number.value = prefix + city + number.value[length:length+3] + u"-" + number.value[length+3:length+5]+ u"-" +number.value[length+5:length+7]
                        number.value = number.value.replace(prefix+city,prefix + u"(" + city + u")")
                        contact.commit()
                printout( number.value)
                e32.ao_yield()
            i += 1
       printout(ru("\nОперация добавления скобок завершена"))
    def Delete(self):
       base = contacts.open()
       printout(ru("Подгружаю базу контактов..."))
       e32.ao_yield()
       conts = base.find(u"")
       for contact in conts:
          name1 = contact.find(u"first_name")
          name2 = contact.find(u"last_name")
          if len(name1) == 0: 
             name1 = u""
          else: 
             name1 = name1[0].value
          if len(name2) == 0: 
             name2 = u""
          else: 
             name2 = name2[0].value
          printout(u"\n" + name1 + u" " + name2)
          i = 0
          numbers = 0
          while i < 2:
            if i == 0: 
                numbers = contact.find(u"mobile_number")
                printout(ru("Мобильные:"))
            if i == 1: 
                numbers = contact.find(u"phone_number")
                printout(ru("Стационарные:"))
            for number in numbers:
             if number.value.find(u"(") != -1:
                contact.begin()
                number.value = number.value.replace(u"(",u"")
                number.value = number.value.replace(u")",u"")
                number.value = number.value.replace(u"-",u"")
                contact.commit()
             printout(number.value)
             e32.ao_yield()
            i += 1
       printout(ru("\nОперация удаления скобок и дефисов завершена"))
    def Compact(self):
       printout(ru("Сжимаю файл контактов. Дождитесь завершения"))
       e32.ao_yield()
       base = contacts.open()
       base.compact()
       printout(ru("Операция завершена успешно"))

    def PrefixesEntered(self):
        text = appuifw.app.body.get()
        global codes
        appuifw.app.body.set("")
        text = text.replace(u"\u2029",u"\n")
        codes = string.split(text,u"\n")
        try:
            while codes.index(u"") > -1:
                codes.remove(u"")
        except: pass
        print codes
        printout(ru("Коды сохранены"))
        
        self.SetMainMenu()
        self.Insert()
        
    def CancelEnteringPrefixes(self):
        appuifw.app.body.set(u"")
        printout(ru("Добавление скобок отмененно пользователем"))
        self.SetMainMenu()
    def SetPrefixes(self):
        global codes
        if len(codes) == 0:
             codes = [u"+7 916",u"8 903",u"+7 905"]
        text = ""
        anote(ru("Введите коды городов в точности по шаблону"))
        for i in range(len(codes)):
            text = text + codes[i] + "\n"
        appuifw.app.body.set(unicode(text))
        appuifw.app.menu = [(ru("OK"),self.PrefixesEntered),(ru("Отмена"),self.CancelEnteringPrefixes)]

    def SetMainMenu(self):
        appuifw.app.menu =  [(ru("Добавить ( )"), self.SetPrefixes),
                             (ru("Удалить ( ) и -"),self.Delete),
                             (ru("Сжать файл контактов"),self.Compact),
                             (ru("About"),About)]

ts = TelSkobki()
ts.SetMainMenu()
anote(ru("ИСПОЛЬЗОВАТЬ НА СВОЙ СТРАХ И РИСК"))
appuifw.app.body=text=appuifw.Text()
printout(ru("Программа готова к работе"))
printout(ru("Имеет смысл сделать резервную копию телефонной книги ;)" ) ) 

#appuifw.app.exit_key_handler = Exit
#script_lock = e32.Ao_lock()
#script_lock.wait()

print u"bye-bye"
