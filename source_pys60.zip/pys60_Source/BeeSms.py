import appuifw,urllib,urlquote,e32,graphics,os

app_lock=e32.Ao_lock()

def ru(x):return x.decode('utf-8')
def enc(x):return x.encode('windows-1251')

if os.path.exists('e:\\system\\apps\\BeeSms\\others\\BeeLogo.jpg'):
 CanPath='e:\\system\\apps\\BeeSms\\others\\BeeLogo.jpg'
 HlPath='e:\\system\\apps\\BeeSms\\others\\help.hlp'
else:
 CanPath='c:\\system\\apps\\BeeSms\\others\\BeeLogo.jpg'
 HlPath='c:\\system\\apps\\BeeSms\\others\\help.hlp'

def exit():
 app_lock.signal()
 appuifw.app.set_exit()

appuifw.app.body=appuifw.Canvas()
img=graphics.Image.open(CanPath)
appuifw.app.body.blit(img)

def sendsms():
 global kod,numb,kodq,numbq
 kod=appuifw.query(ru('Введите код оператора(9хх)'),'number')
 kod=str(kod)
 kodq=urlquote.quote(kod)
 numb=appuifw.query(ru('Введите номер телефона(7 цифр)'),'number')
 numb=str(numb)
 numbq=urlquote.quote(numb)
 appuifw.note(ru('Введите текст сообщения'))
 global round
 round=appuifw.Text()
 appuifw.app.screen='normal'
 appuifw.app.body=round
 round.set(ru(''))
 appuifw.app.menu=[(u'Ok',sendok)]
def sendok():
 snd=round.get()
 global sndq
 sndq=urlquote.quote(snd)
 appuifw.app.title=(ru('Предпросмотр'))
 appuifw.app.body=txt=appuifw.Text()
 txt.color=0
 txt.focus=False
 txt.add(ru('Кому:\n  +' +str(7)+str(kod)+str(numb)+'\n\nТекст:\n   '+str(snd)))
 txt.set_pos(0)
 txt.set_pos(20)
 appuifw.app.menu=[(ru('Отправить'),send),(ru('Назад'),backmenu)]
def send():
 appuifw.app.menu=[(ru('Выход'),exit)]
 urllib.urlopen(enc('http://www.beeonline.ru/servlet/send/sms/?prf=7'+str(kodq)+'&phone='+str(numbq)+'&message='+str(sndq)+'&number_sms=number_sms_send&termtype=G&translit=off&x=5&y=4'))
 appuifw.note(ru('Сообщение для +'+str(7)+kod+numb+' отправлено'),'conf')
 backmenu()
def backmenu():
 appuifw.app.body=appuifw.Canvas()
 appuifw.app.body.blit(img)
 appuifw.app.title=(ru('BeeSms'))
 appuifw.app.menu=[(ru('Написать сообщение'),sendsms),(ru('Помощь'),help),(ru('О проге..'),about),(ru('Выход'),exit)]
def help():
 f=open(HlPath,'r')
 r=f.read()
 f.close()
 appuifw.app.body=hlp=appuifw.Text()
 hlp.color=0
 hlp.focus=False
 hlp.add(ru(r))
 hlp.set_pos(0)
 hlp.set_pos(150)
 appuifw.app.menu=[(ru('Назад'),backmenu)]
def about():
 appuifw.note(u'BeeSms v.0.01\nby G.F.Ferre\nDimonVideo.ru')
 appuifw.app.body=appuifw.Canvas()
 appuifw.app.body.blit(img)

appuifw.app.menu=[(ru('Написать сообщение'),sendsms),(ru('Помощь'),help),(ru('О проге..'),about),(ru('Выход'),exit)]
appuifw.app.exit_key_handler=exit
app_lock.wait()