# by deckstor
import e32
import time
import fgimage
import graphics
img=graphics.Image.new((47,15))
fgi=fgimage.FGImage() 
while 1:
 img.rectangle((0,0,46,14),0x0000ff,0x000000)
 img.line((0,14,47,14),0x0088ff)
 img.line((46,0,46,14),0x0088ff)
 img.text((2,11),unicode(time.strftime('%H:%M:%S')),0xffffff)
 fgi.set(128,1,img._bitmapapi()) 
 e32.ao_sleep(1)