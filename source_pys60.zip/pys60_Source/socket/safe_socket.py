#
# pdis.socket.safe_socket
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Socket-like interface with friendlier semantics for the caller

SafeSocket wraps a blocking-socket Endpoint and provides implicit
connection close on exceptions or receipt of an EOF, as well as more
predictable behavior for recv() and sendall() when the connection has
been closed.
"""

from pdis.lib.best_threading import allocate_lock

class SafeSocket:
    """
    Socket-like interface for a connection endpoint

    The allowed usage of this interface in a multithreaded context is
    such that connection endpoints may be manipulated as follows by as
    many as four threads, A, B, C, and D, not necessarily distinct:

      1. Thread A initiates or accepts the connection.
      2. Thread B operates the input side, namely recv().
      3. Thread C operates the output side, namely sendall().
      3. Thread D invokes close().

    All methods, including close(), can raise networking-related
    exceptions as determined by the underlying implementation.  (The
    rationale for allowing close() to raise exceptions is that they
    are best caught and logged at a higher level.)
    """

    def __init__(self, socket):
        """
        Initialize an instance.

        The first argument must be an object that implements the
        Endpoint interface in pdis.socket.blocking_socket.
        """
        self.socket = socket
        self.mutex = allocate_lock()

    def recv(self, size):
        """
        Receive at most "size" bytes and return the data as a string.

        This blocks until either an EOF or some data has been received.
        It returns an empty string if the connection has been closed.
        """
        try:
            data = ""
            s = self.socket
            if s is not None:
                data = s.recv(size)
        finally:
            if not data:
                if self.socket is None:
                    return ""
                self.close()

        return data

    def sendall(self, data):
        """
        Transmit the given string.

        This does nothing if the connection has been closed.
        """
        try:
            s = self.socket
            if s is not None:
                s.sendall(data)
        except:
            if self.socket is not None:
                self.close()
                raise

    def close(self):
        """
        Close the connection and free all associated resources.

        This transmits an EOF on the output stream and simulates an
        immediate EOF on the input stream.  It can safely be called
        more than once.

        Calling close() while another thread is blocked in recv() will
        cause the call to recv() to return.

        Although it is good practice to call close() when an EOF is
        received, the connection is closed implicitly when recv()
        returns an empty string or any method raises an exception.
        """
        self.mutex.acquire()
        try:
            s = self.socket
            if s is not None:
                self.socket = None
                s.close()
        finally:
            self.mutex.release()
