#
# pdis.socket.loopback_socket
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from Queue import Queue

from pdis.socket.socket_exceptions import ServerTerminated

class LoopbackEndpoint:
    def __init__(self, outbound, inbound):
        self.outbound = outbound
        self.inbound = inbound
        self.rbuf = ""

    def close(self):
        self.outbound.put("")

    def sendall(self, data):
        if data:
            self.outbound.put(data)

    def recv(self, size):
        data = self.rbuf
        if not data:
            if self.inbound is None:
                return ""
            data = self.inbound.get()
            if not data:
                self.inbound = None
                return ""
        self.rbuf = data[size:]
        return data[:size]

class LoopbackServer:
    def __init__(self):
        self.terminated = False
        self.queue = Queue()

    def close(self):
        if not self.terminated:
            self.terminated = True
            self.queue.put(None)     # Cause accept() to fall through.

    def accept(self):
        if self.terminated:
            raise ServerTerminated
        connection = self.queue.get()
        if self.terminated:
            raise ServerTerminated
        return LoopbackEndpoint(connection[1], connection[0])

class LoopbackManager:
    def __init__(self):
        self.servers = {}               # Map names to servers.

    def close(self):
        pass

    def connect(self, address):
        name = self._parse_address(address)
        server = self.servers[name]
        connection = (Queue(5), Queue(5))
        server.queue.put(connection)
        return LoopbackEndpoint(connection[0], connection[1])

    def listen(self, address):
        name = self._parse_address(address)
        server = LoopbackServer()
        self.servers[name] = server
        return server

    def _parse_address(self, address):
        if not address:
            return "default"
        else:
            return address[0]

factory = LoopbackManager
