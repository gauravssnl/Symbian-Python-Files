#
# pdis.socket.tls_socket
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Pekka Kanerva <Pekka.Kanerva@HIIT.FI>
#          Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import socket
import time

from pdis.socket.socket_exceptions import ConnectionFailed, ServerTerminated
from pdis.socket.transport_registry import register_manager

from tlslite.api import TLSConnection, HandshakeSettings
from cryptoIDlib.CertChain import CertChain
from cryptoIDlib.utils.keyfactory import generateRSAKey, parseXMLKey
from threading import Lock


class TLSEndpoint:
    """
    Socket-like interface for a TLS encrypted connection endpoint.

    The tlslite library uses different methods to handhake the public
    keys and certificates used to encrypt the transmission and
    authenticate the peers. Thus, we need to specify a certain role
    for the endpoint depending on whether the endpoint is functioning
    as a server or as a client.

    Currently the server and client keys are stored on files in /tmp
    directory. The final storage location would be the PDIS internal
    'db/repository' file.
    """
    
    def __init__(self, identity, endpoint_role, socket):
        self.connection = None
        self.role = endpoint_role
        self.socket = socket
        self.connection = TLSConnection(self.socket)
        self.connection.closeSocket = True
        self.handshake(identity)
        

    def recv(self, size):
        return self.connection.recv(size)
    
    def sendall(self, data):
        self.connection.sendall(data)

    def close(self):
        self.connection.close()

    def get_peer_id(self):
        return self._get_peer_public_key().hash()

    def handshake(self, identity):
        self._handshake(identity)


    # Private methods
    
    def _handshake(self, identity):
        key, cert_chain = identity[:]
        if self.role == "client":
            self.connection.handshakeClientCert(certChain = cert_chain,
                                                privateKey = key)
        elif self.role == "server":
            settings = HandshakeSettings()
            self.connection.handshakeServer(certChain = cert_chain,
                                            privateKey = key,
                                            settings = settings,
                                            reqCert = True)
        else:
            pass

    def _get_peer_public_key(self):
        session = self.connection.session
        if self.role == "client":
            return session.serverCertChain.getEndEntityPublicKey()
        elif self.role == "server":
            return session.clientCertChain.getEndEntityPublicKey()


class TLSServer:
    def __init__(self, identity, address):
        self.identity = identity
        self.address = address

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind(address)
        self.socket.listen(5)

        self.terminated = False

    def close(self):
        if not self.terminated:
            self.terminated = True

            # Cause accept() to fall through and close the socket for us.
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect(self.address)
            sock.close()

    def accept(self):
        sock, client_address = self.socket.accept()
        if self.terminated:
            sock.close()
            self.socket.close()
            raise ServerTerminated
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)

        self.endpoint = TLSEndpoint(self.identity, "server", sock)
        return self.endpoint
    


class TLSManager:
    """
    TODO:
    - naming conventions: decide what is the 'ID' of a repository. Is
      it the
      - public key or the hash of the public key
      - the certificate used in the TLS/SSL connection
      - the (key,certificate_chain) pair
      - ...    
    - decide the reasonable location for the key and the certificate
    of the repository. (current working directory was just the 'first
    draft' solution, not a final one, so is /tmp)
    """
    def __init__(self):
        self.key = None
        self.cert_chain = None
        self.mutex = Lock()
        self.identity = self.get_identity()
        

    def close(self):
        self.sock.close()

    def connect(self, address):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        try:
            self.sock.connect(address)
        except socket.error:
            raise ConnectionFailed
        return TLSEndpoint(self.identity, "client", self.sock)

    def listen(self, address):
        return TLSServer(self.identity, address)


    def get_identity_hash(self):
        return self._get_key_hash()


    def get_identity(self):
        return self._get_identity()


    def generate_key(self, keybits=1024, implementations=['python']):
        return self._generate_key(self, keybits, implementations)



    # Private methods

    def _get_identity(self):
        try:
            id = self._get_repo_identity()
        except NotImplementedError:
            id = self._get_tmp_identity()

        return id

    def _get_repo_identity(self):
        raise NotImplementedError

    
    def _get_tmp_identity(self):
        self.key = self._get_key()
        if not self.cert_chain:
            self.cert_chain = self._get_cert_chain(self.key);

        return (self.key, self.cert_chain)
    

    def _get_key(self, keybits=1024, implementations=['python']):

        keyfile = self._get_keyfile()

        try:
            key_string = open(keyfile).read()
            key = parseXMLKey(key_string, private=True)
            self.cert_chain = None

        # If no key is found, we need a new key and a new certificate
        except IOError:
            key = self._generate_key(keybits, implementations)
            self._store_key(key)
            self.cert_chain = self._get_cert_chain(key)
            self._store_cert_chain(self.cert_chain)

        # If the existing key is shorter than the one is being
        # requested, we need a new key
        if key.__len__() < keybits:
            key = self._generate_key(keybits, implementations)
            self.cert_chain = self._get_cert_chain(key)
            self._store_cert_chain(self.cert_chain)

        return key


    def _get_key_hash(self):
        return self.key.hash()


    def _generate_key(self, keybits, implementations):
        return generateRSAKey(keybits, implementations)        


    def _store_key(self, key):
        self.mutex.acquire()
        keyfile = self._get_keyfile()
        f = open(keyfile, 'w')
        f.write(key.write())
        f.close()
        self.mutex.release()


    def _get_keyfile(self):
        return '/tmp/repo_key.xml'

    def _get_certfile(self):
        return '/tmp/repo_cert.xml'


    def _get_cert_chain(self, key, sec_level=112):
        
        certfile = self._get_certfile()

        try:
            cert_string = open(certfile).read()
            cert_chain = CertChain()
            cert_chain.parse(cert_string)
        except IOError:
            cert_chain = self._generate_cert_chain(key, sec_level)

        return cert_chain


    def _generate_cert_chain(self, key, sec_level):
        cert_chain = CertChain()
        cert_chain.addCert("a", [key], secLevel = sec_level)
        
        return cert_chain


    def _store_cert_chain(self, cert_chain):
        self.mutex.acquire()
        certfile = self._get_certfile()
        f = open(certfile, 'w')
        f.write(cert_chain.write())
        f.close()
        self.mutex.release()
        

register_manager("tls", TLSManager())
