#
# pdis.socket.buffered_stream
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#
# Some code fragments below have been derived from Python's socket.py.
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Bidirectional byte stream with read and write buffering
"""

from pdis.socket.socket_exceptions import SessionClosed

class BufferedStream:
    """
    Bidirectional byte stream with read and write buffering

    The client interface defined here is comprised of two parts: an
    output side, including write(), flush(), and close(), and an input
    side, including read() and readline().  close() is considered to
    be on the output side because it flushes the output stream.  The
    input and output sides can be operated concurrently, but they are
    not otherwise thread-safe.

    All methods can raise networking-related exceptions as determined
    by the underlying implementation.

    The interface could be extended to further conform to that of a
    file-like object if desired.
    """

    default_bufsize = 8192

    def __init__(self, socket, bufsize = -1):
        """
        Initialize an instance.

        The first argument must be an instance of SafeSocket.

        The buffer size defaults to the value of "default_bufsize".
        The conventions for requesting unbuffered or line-buffered
        output by specifying a buffer size of 0 or 1, respectively,
        are *not* supported.
        """
        self.socket = socket

        if bufsize < 0:
            bufsize = self.default_bufsize
        self.bufsize = bufsize

        self.closed = False
        self.wbuf = _Buffer()
        self.rbuf = ""

    def close(self):
        """
        Close the stream and free all underlying resources.

        This appends an EOF to the output stream and simulates an
        immediate EOF on the input stream. A best-effort attempt is
        made to flush the ouput stream.

        close() can safely be called more than once.  Whether it has
        been called can be determined by examining the value of the
        instance variable "closed".
        """
        if self.closed:
            return
        self.closed = True

        self._flush()
        self.socket.close()

    def write(self, data):
        """
        Append a string to the output stream.

        Transmission of the data is triggered when the number of bytes
        reaches or exceeds the specified buffer size.

        SessionClosed is raised if the output stream has been closed.
        """
        if self.closed:
            raise SessionClosed

        self.wbuf.append(data)
        if self.wbuf.len >= self.bufsize:
            self._flush()

    def flush(self):
        """
        Flush the output buffer.

        This triggers the transmission of the entire contents of the
        output buffer.

        SessionClosed is raised if the output stream has been closed.
        """
        if self.closed:
            raise SessionClosed

        self._flush()

    def _flush(self):
        data = self.wbuf.drain()
        if data:
            try:
                n = 2 * self.bufsize
                for i in range(0, len(data), n):
                    self.socket.sendall(data[i:i+n])
            except:
                self.closed = True
                raise

    def read(self, size):
        """
        Read exactly "size" bytes, or less if the read hits EOF.

        An empty string is returned when EOF is encountered
        immediately.

        (The "size" parameter could be made optional to further
        conform to the standard interface for file-like objects.)
        """
        if self.closed:
            return ""

        # The following code has been derived from _fileobject.read()
        # in socket.py in Python 2.4a3.
        data = self.rbuf
        buf_len = len(data)
        if buf_len >= size:
            self.rbuf = data[size:]
            return data[:size]
        buffers = []
        if data:
            buffers.append(data)
        self.rbuf = ""
        while True:
            left = size - buf_len
            recv_size = max(self.bufsize, left)
            data = self._recv(recv_size)
            if not data:
                break
            buffers.append(data)
            n = len(data)
            if n >= left:
                self.rbuf = data[left:]
                buffers[-1] = data[:left]
                break
            buf_len += n
        return "".join(buffers)

    def readline(self):
        """
        Read one entire line from the input stream.

        A trailing newline character is kept in the string (but may be
        absent when the stream ends with an incomplete line).  An empty
        string is returned only when EOF is encountered immediately.

        (An optional "size" parameter could be added to this method to
        further conform to the standard interface for file-like objects.)
        """
        if self.closed:
            return ""

        # The following code has been derived from _fileobject.readline()
        # in socket.py in Python 2.4a3.
        data = self.rbuf
        nl = data.find('\n')
        if nl >= 0:
            nl += 1
            self.rbuf = data[nl:]
            return data[:nl]
        buffers = []
        if data:
            buffers.append(data)
        self.rbuf = ""
        while True:
            data = self._recv(self.bufsize)
            if not data:
                break
            buffers.append(data)
            nl = data.find('\n')
            if nl >= 0:
                nl += 1
                self.rbuf = data[nl:]
                buffers[-1] = data[:nl]
                break
        return "".join(buffers)

    def _recv(self, size):
        try:
            return self.socket.recv(size)
        except:
            if self.closed:
                return ""
            self.closed = True
            raise

class _Buffer:
    def __init__(self):
        self.buf = []
        self.len = 0

    def append(self, data):
        if not isinstance(data, str):
            raise TypeError

        self.buf.append(data)
        self.len += len(data)

    def get_len(self):
        return self.len

    def drain(self):
        contents = self.buf
        self.buf = []
        self.len = 0

        return "".join(contents)
