#
# pdis.socket.transport_registry
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Registry for implementations of the blocking socket interface

This module provides the following services:

  - Autoloading of implementation modules based on a built-in mapping
    of transport names to module names.

  - Global register_manager() and lookup_manager() functions providing
    a dynamic mapping of transport names to implementations of the
    Manager interface.

  - Generic connect() and listen() convenience functions taking
    address tuples that include the transport name as the first
    element and returning an implementation of the Endpoint or Server
    interface, respectively.

For example, the following initiates a TCP connection and returns the
connection endpoint in the form of an object implementing the Endpoint
interface:

    endpoint = connect(("tcp", "pdis.hiit.fi", 35800))

And the following creates a server object that listens for incoming
TCP connections and provides an accept() method for retrieving the
resulting connection endpoints:

    server = listen(("tcp", "", 35800))

If a manager for "tcp" had not already been registered, either of the
above calls would have autoloaded the module "pdis.socket.tcp_socket".

If you wanted to use an alternative implementation of "tcp", you could
simply import the desired module explicitly before making either of
the above calls.  Such a module might additionally register the same
manager instance under some other transport name, say "ao_tcp", in which
case autoloading of the module could be supported under that name.
"""

import sys

# Default mapping of transport names to module names:
socket_modules = {
    #"loopback" : "pdis.socket.loopback_socket",
    "tcp" : "pdis.socket.tcp_socket",
    "bt" : "pdis.socket.bt_socket",
    }

# Mapping of transport names to module names for Symbian OS:
symbian_socket_modules = {
    #"loopback" : "pdis.socket.loopback_socket",
    "tcp" : "aosocket.symbian.tcp",
    "bt" : "aosocket.symbian.bt",
    }

def create_manager(transport):
    if sys.platform == "symbian_s60":
        table = symbian_socket_modules
    else:
        table = socket_modules

    name = table[transport]
    module = get_module(name)
    return module.factory()

def get_module(name):
    mod = __import__(name)    # Returns top-level package, not module.
    for comp in name.split(".")[1:]:
        mod = getattr(mod, comp)
    return mod

# Mapping of transport names to Manager instances:
_socket_managers = {}

def register_manager(transport, manager):
    """
    Register a socket manager implementing the named transport.

    This would normally be called when the module defining the
    implementation is imported.
    """
    _socket_managers[transport] = manager

def lookup_manager(transport):
    """
    Return a socket manager implementing the named transport.
    """
    if transport not in _socket_managers:
        _socket_managers[transport] = create_manager(transport)

    return _socket_managers[transport]

def connect(address):
    """
    Initiate a connection.

    The returned object will implement the Endpoint interface.
    ConnectionFailed is raised if a connection to the specified
    address cannot be established.

    The argument is a tuple specifying the remote address to connect
    to, including the transport name as its first element.

    This is similar to creating and then connecting a Unix socket.
    """
    transport, params = _split_address(address)
    manager = lookup_manager(transport)
    return manager.connect(params)

def listen(address):
    """
    Start a new server to listen for incoming connections.

    The returned object implements the Server interface.

    The argument is a tuple specifying the local address to bind to,
    or other parameters for initializing the server.  It must include
    the transport name as its first element.

    This is similar to creating a Unix socket and then calling bind
    and listen on it.
    """
    transport, params = _split_address(address)
    manager = lookup_manager(transport)
    return manager.listen(params)

def _split_address(address):
    assert isinstance(address, tuple)
    return address[0], address[1:]

def close_all_managers():
    """
    Close all registered socket managers.

    This is intended as a convenient aid to cleanly shutting down an
    application, particularly under Symbian OS.
    """
    while _socket_managers:
        transport, manager = _socket_managers.popitem()
        try:
            manager.close()
        except:
            # We ignore exceptions in case some manager is registered
            # twice and doesn't like being closed more than once.
            pass
