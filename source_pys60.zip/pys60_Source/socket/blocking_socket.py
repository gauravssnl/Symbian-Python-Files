#
# pdis.socket.blocking_socket
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Socket-like interface to underlying transport

This abstraction exists primarily to factor network-specific and
platform-specific issues out of pdis.pipe.message_pipe.

The classes defined below are simply interface definitions.
"""

from pdis.socket.socket_exceptions import *

class Endpoint:
    """
    Socket-like interface for a connection endpoint

    The allowed usage of this interface in a multithreaded context is
    such that connection endpoints may be manipulated as follows by as
    many as four threads, A, B, C, and D, not necessarily distinct:

      1. Thread A initiates or accepts the connection.
      2. Thread B operates the input side, namely recv().
      3. Thread C operates the output side, namely sendall().
      3. Thread D invokes close().

    All methods, including close(), can raise networking-related
    exceptions as determined by the underlying implementation.  (The
    rationale for allowing close() to raise exceptions is that they
    are best caught and logged at a higher level.)
    """

    def recv(self, size):
        """
        Receive at most "size" bytes and return the data as a string.

        This blocks until either an EOF or some data has been received.
        It will either return an empty string or raise an exception if
        the connection has been closed.
        """
        raise NotImplementedError

    def sendall(self, data):
        """
        Transmit the given string.

        This typically raises an exception if the connection has been
        closed.
        """
        raise NotImplementedError

    def close(self):
        """
        Close the connection and free all associated resources.

        This transmits an EOF on the output stream and simulates an
        immediate EOF on the input stream.  All subsequent method
        invocations may raise exceptions.

        Calling close() while another thread is blocked in recv() will
        cause the call to recv() to either return or raise an exception.

        Even if an EOF has been received or some method has raised an
        exception, you must call close() to insure that all resources
        are freed.
        """
        raise NotImplementedError

class Server:
    """
    Interface for listening for incoming connections

    The allowed usage of this interface in a multithreaded context is
    such that server instances may be manipulated as follows by as
    many as three threads, A, B, and C, not necessarily distinct:

      1. Thread A initializes the server instance.
      2. Thread B repeatedly calls accept().
      3. Thread C invokes close().
    """

    def close(self):
        """
        Shut down the connection server.

        This causes all calls to accept(), including any currently
        blocked call, to raise ServerTerminated.  The server's network
        resources are freed by accept() at that time.

        This does not close previously created endpoints, on the
        presumption that it is more natural for the caller to keep
        track of them.
        """
        raise NotImplementedError

    def accept(self):
        """
        Accept a connection.

        The returned object will implement the Endpoint interface.
        May raise ServerTerminated.
        """
        raise NotImplementedError

class Manager:
    """
    Interface for creating connection endpoints and servers.

    Typically a single manager will be created for each different
    network transport.

    This interface is required to be thread-safe.
    """

    def close(self):
        """
        Release any resources associated with the manager.

        This may or may not have the effect of closing the endpoints
        and servers that have been created by the manager, depending
        on the implementation.  It is good practice to close them
        explicitly before closing the manager.
        """
        raise NotImplementedError

    def connect(self, address):
        """
        Initiate a connection.

        The returned object will implement the Endpoint interface.
        ConnectionFailed is raised if a connection to the specified
        address cannot be established.

        The argument is a tuple specifying the remote address to
        connect to.  It does not include the transport name.

        This is similar to creating and then connecting a Unix socket.
        """
        raise NotImplementedError

    def listen(self, address):
        """
        Start a new server to listen for incoming connections.

        The returned object implements the Server interface.

        The argument is a tuple specifying the local address to bind
        to, or other parameters for initializing the server.  It does
        not include the transport name.

        This is similar to creating a Unix socket and then calling
        bind and listen on it.
        """
        raise NotImplementedError
