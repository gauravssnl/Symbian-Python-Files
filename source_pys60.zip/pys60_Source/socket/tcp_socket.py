#
# pdis.socket.tcp_socket
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import socket

from pdis.socket.socket_exceptions import ConnectionFailed, ServerTerminated

class TCPEndpoint:
    def __init__(self, socket):
        self.socket = socket

    def recv(self, size):
        return self.socket.recv(size)

    def sendall(self, data):
        self.socket.sendall(data)

    def close(self):
        try:
            try:
                self.socket.shutdown(2)
            except socket.error:
                pass
        finally:
            self.socket.close()

    def fileno(self):
        return self.socket.fileno()

class TCPServer:
    def __init__(self, address):
        self.address = address

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind(address)
        self.socket.listen(5)

        self.terminated = False

    def close(self):
        if not self.terminated:
            self.terminated = True

            # Cause accept() to fall through and close the socket for us.
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect(self.address)
            sock.close()

    def accept(self):
        sock, client_address = self.socket.accept()
        if self.terminated:
            sock.close()
            self.socket.close()
            raise ServerTerminated
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        return TCPEndpoint(sock)

class TCPManager:
    def __init__(self):
        pass

    def close(self):
        pass

    def connect(self, address):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        try:
            sock.connect(address)
        except socket.error:
            raise ConnectionFailed
        return TCPEndpoint(sock)

    def listen(self, address):
        return TCPServer(address)

factory = TCPManager
