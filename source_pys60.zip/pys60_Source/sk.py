import inbox,contacts,e32,messaging
def add_sms(id):
    inb=inbox.Inbox()
    e32.ao_sleep(0.1)
    mes_ids=i.sms_messages()
    tel=inb.address(id)
    base=contacts.open()
    name=base.find(tel)
    if tel==None:
        pass
    else:
        messaging.sms_send()

inb=inbox.Inbox()
inb.bind(add_sms)