import appuifw,string,keypress,keycapture,appswitch,e32,time
def ru(x):return x.decode('utf-8')

an=appuifw.note
aq=appuifw.query
aa=appuifw.app

aa.body=r=appuifw.Text()
aa.body.color=0x3300cc
aa.screen='normal'
aa.body.focus=False
r.set(ru('Поехали?\nВНИМАНИЕ:\nесли тебе нужен пробел,пиши space,\nесли обратная черта дроби-bs\nВопросы на icq 392589688'))

def T():
 try:
  i=aq(ru('Введи букву(регистр важен)'),'text')
  r.set(ru('Сканкод буквы "')+str(i)+ru('" = ')+L_t[i])
 except:
  an(u'Error\nenglish only!\none letter only!','error')

def D():
 try:
  i=aq(ru('Введи число'),'number')
  r.set(ru('Сканкод цифры "')+str(i)+ru('" = ')+L_d[i])
 except:
  an(u'Error\none digit only!','error')

def P():
 try:
  i=aq(ru('Выбери знак через *'),'text')
  r.set(ru('Сканкод знака "')+str(i)+ru('" = ')+L_p[i])
 except:
  an(u'Error\none symbol only!','error')

def HELP():
 an(ru('Пробел - space\n \ - bs'),'info')

def ABOUT():
 an(u'by sawka6600\nicq 392589688','info')

def EXIT():
 aa.set_exit()

L_t={'A':'65','B':'66','C':'67','D':'68','E':'69','F':'70','G':'71','H':'72','I':'73','J':'74','K':'75','L':'76','M':'77','N':'78','O':'79','P':'80','Q':'81','R':'82','S':'83','T':'84','U':'85','V':'86','W':'87','X':'88','Y':'89','Z':'90','a':'97','b':'98','c':'99','d':'100','e':'101','f':'102','g':'103','h':'104','i':'105','j':'106','k':'107','l':'108','m':'109','n':'110','o':'111','p':'112','q':'113','r':'114','s':'115','t':'116','u':'117','v':'118','w':'119','x':'120','y':'121','z':'122'}

L_d={0:'48',1:'49',2:'50',3:'51',4:'52',5:'53',6:'54',7:'55',8:'56',9:'57'}

L_p={'space':'32','Space':'32','!':'33','"':'34','#':'35','$':'36','%':'37','&':'38',"'":'39',')':'41','(':'40','*':'42','+':'43',',':'44','-':'45','.':'46','/':'47',':':'58',';':'59','<':'60','=':'61','>':'62','?':'63','@':'64',']':'93','bs':'92','Bs':'92','[':'91','^':'94','_':'95','{':'123','|':'124','}':'125'}

aa.menu=[(ru('Текст'),T),(ru('Числа'),D),(ru('Знаки'),P),(ru('Помощь'),HELP),(ru('About'),ABOUT),(ru('Выход'),EXIT)]
e32.Ao_lock().wait()