#
# All rights reserved
#  by _killed_
# _killed_@list.ru
# http://killed.h2m.ru
#
# nf == New Format
#
## ### ### ### ##
from struct import pack,unpack
from os import path,listdir
from appuifw import app
import e32
def readL(f,pos=None):
 if pos!=None:
  f.seek(pos)
 return unpack('L',f.read(4))[0]

def packer(list):
 f=open('e:/nf/2.nf','w')
 trailer=pack('L',len(list))
 f.write('0'*4)
 for i in list:
  trailer+=pack('L',f.tell())
  f.write(pack('L',len(i))+i)
  x=open('e:/nf/p/'+i)
  dl=path.getsize('e:/nf/p/'+i)
  f.write(pack('L',dl)+x.read())
  x.close()
 end=f.tell()
 f.seek(0)
 f.write(pack('L',end))
 f.seek(end)
 f.write(trailer)
 f.close()
 print 'pack done'

def unpaker(path):
 f=open(path)
 f.seek(readL(f))
 num=readL(f)
 offs=[]
 for i in range(num):
  offs.append(readL(f))
 for i in offs:
  f.seek(i)
  dln=readL(f)
  x=open('e:/nf/u/'+f.read(dln),'w')
  dln=readL(f)
  x.write(f.read(dln))
  x.close()
 f.close()
 print 'unpack done'

app.menu=[(u'pack',lambda:packer(listdir('e:/nf/p/'))),\
(u'unpack',lambda:unpaker('e:/nf/2.nf'))]
e32.Ao_lock().wait()