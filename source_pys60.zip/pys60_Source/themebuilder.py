#script by _VersouL_
#Decode utf-8
#программа для создания тем на смартфонах под ос симбиан
#очень стыдно за кривой код :-(
#код защищен лицензией GNU
import appuifw,graphics,e32,os,struct,random,keycapture,appswitch
appuifw.app.screen='full'
if os.path.isdir('e:\\system\\apps\\themebuilder'):
 DISC__='e:'
else:
 DISC__='c:'
KJ____,M____P,A____N,G____I,A____Q=1,DISC__+'\\themebuilder',appuifw.note,graphics.Image,appuifw.query
if not os.path.isdir(DISC__+'\\Themebuilder'):
 os.makedirs(DISC__+'\\Themebuilder')
FILE__=open(M____P+'\\set.ini','w')
FILE__.write('0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n')
FILE__.close()
BODY__=G____I.new((176,208))
img=G____I.open(DISC__+'\\system\\apps\\themebuilder\\images\\p2.png')
img_m=G____I.open(DISC__+'\\system\\apps\\themebuilder\\images\\p3.png')
kjg=0
z,p=1,1
def ru(dec):return dec.decode('utf-8')
def colore(x):
 if x[-6:-4]==u'_m':
  col=8
 else:
  col=16
 return col
def automask(im):
 width,height=im.size
 mask=G____I.new(im.size,'1')
 tran=im.getpixel((0,0))[0]
 for y in range(height):
  line=im.getpixel([(x,y) for x in range(width)])
  for x in range(width):
   if line[x]==tran:
    mask.point((x,y),0)
 return mask
def color(rgb,c):
 r,g,b=rgb
 if c==8:return chr((r*2+g*5+b)/8)
 elif c==24:return chr(b)+chr(g)+chr(r)
 else:
  i,red,blue=0,None,None
  while i<256:
   if red==None and r<=i+4:red=int(i/8.25)
   if blue==None and b<=i+4:blue=int(i/8.25)
   if red!=None and blue!=None:break
   i+=8.25
  color,i=red*8+blue*0x100,0
  for green in range(8):
   if i in [0,65,130,195]:period=32
   else:period=33
   if g>i+period-2:i+=period
   else:
    for j in range(0,32,4):
     if g<=i+j+2:color+=j*0x800+green;break
    break
  return chr(color/0x100)+chr(color%0x100)
#==#
def create_skn():
 import shab
 uid=random.Random().randint(1,999999)
 uid=str('%016d'%uid)
 upath=uid[6:8]+uid[4:6]+uid[2:4]+uid[0:2]+uid[14:16]+uid[12:14]+uid[10:12]+uid[8:10]
 FILE__=open(M____P+'\\set.ini','r')
 h=FILE__.readlines()
 FILE__.close()
 FILE__=open(M____P+'\\set.ini','w')
 FILE__.write(''.join(h[:0]+[upath+'\n']+h[1:]))
 FILE__.close()
 gm=24
 FILE__=open(M____P+'\\set.ini','r')
 FILE__=f.readlines()
 FILE__.close()
 if h[5][:-1]!='0':
  gm+=5
 if h[6][:-1]!='0':
  gm+=2
 rname_theme=h[1][:-1]
 name_theme='00'
 for i in rname_theme:
  name_theme=name_theme+str(i.encode('hex'))+'00'
 len_n=str(hex(len(name_theme)/2+12)[2:])
 len_nf=str(hex(len(rname_theme))[2:])
 if len(len_nf)==1:
  len_nf='0'+len_nf
 if len(len_n)==1:
  len_n='0'+len_n
 name='f5'+len_n+'000000010001000100'+len_nf+name_theme
 os.makedirs(M____P+'\\'+rname_theme+'\\!\\system\\skins\\'+upath)
 FILE__=open(M____P+'\\'+rname_theme+'\\!\\system\\skins\\'+upath+'\\Themebuilder.skn','w')
 #FILE__.write((shab.begin(uid,name)+shab.main2()+shab.nozam()).decode('hex'))
 FILE__.write(shab.begin(uid,name).decode('hex'))
 g1=FILE__.tell()
 FILE__.write((shab.main1()+shab.colors()).decode('hex'))
 g2=FILE__.tell()
 g3=str(hex(g2-g1+2)[2:])
 if len(g3)%2:
  g3='0'+g3
 if len(g3)==4:
  g3=g3[2:]+g3[:2]
 FILE__.seek(g1+1)
 FILE__.write((g3).decode('hex'))
 FILE__.seek(g1+10)
 FILE__.write((str(hex(gm)[2:])).decode('hex'))
 FILE__.seek(g2)
 FILE__.write((shab.zam()).decode('hex'))
 g4=f.tell()
 g5=str(hex(g4-g2)[2:])
 if len(g5)%2:
  g5='0'+g5
 if len(g5)==4:
  g5=g5[2:]+g5[:2]
 FILE__.seek(g2+3)
 FILE__.write((g5).decode('hex'))
 FILE__.seek(g4)
 FILE__.write((shab.end).decode('hex'))
 g=str(hex(FILE__.tell())[2:])
 if len(g)%2:
  g='0'+g
 g=g[2:]+g[:2]
 FILE__.seek(0)
 FILE__.write((g).decode('hex'))
 FILE__.close()
def snip_imgs():
 rname_theme=A____Q(ru('название темы'),'text')
 FILE__=open(M____P+'\\set.ini','r')
 h=FILE__.readlines()
 FILE__.close()
 try:
  FILE__=open(M____P+'\\set.ini','w')
  FILE__.write(''.join(h[:1]+[rname_theme+'\n']+h[2:]))
  FILE__.close()
  if not os.path.isdir(M____P+'\\create'):
   os.makedirs(M____P+'\create')
  try:
   e32.file_copy(DISC__+'\\themebuilder\\create\\000.png',DISC__+'\\system\\apps\\themebuilder\\images\\p1.png')
   e32.file_copy(DISC__+'\\themebuilder\\create\\001_m.png',DISC__+'\\system\\apps\\themebuilder\\images\\p1.png')
  except:
   note(2,'программа повреждена')
  FILE__=open(M____P+'\\set.ini')
  g=FILE__.readlines()
  FILE__.close()
  g1=G____I.open(M____P+'\\'+g[3])
  m=G____I.new((176,44))
  m.blit(g1,source=((0,0),(176,44)))
  G____I.save(m,M____P+'\\create\\002.png')
  m=G____I.new((176,144))
  m.blit(g1,source=((0,44),(176,188)))
  G____I.save(m,M____P+'\\create\\003.png')
  m=G____I.new((176,20))
  m.blit(g1,source=((0,188),(176,208)))
  G____I.save(m,M____P+'\\create\\004.png')
  g2=G____I.open(M____P+'\\'+g[4])
  m=G____I.new((176,44))
  m.blit(g2,source=((0,0),(176,44)))
  G____I.save(m,M____P+'\\create\\005.png')
  m=G____I.new((176,144))
  m.blit(g2,source=((0,44),(176,188)))
  G____I.save(m,M____P+'\\create\\006.png')
  m=G____I.new((176,188))
  m.blit(g2,source=((0,0),(176,188)))
  G____I.save(m,M____P+'\\create\\007.png')
  m=G____I.new((176,20))
  m.blit(g2,source=((0,188),(176,208)))
  G____I.save(m,M____P+'\\create\\008.png')
  m=G____I.new((176,4))
  m.blit(g2,source=((0,204),(176,4)))
  G____I.save(m,M____P+'\\create\\009.png')
  FILE__=open(M____P+'\\set.ini','r')
  h=FILE__.readlines()
  FILE__.close()
  nk=10
  kn=7
  if h[6][:-1]!='0':
   try:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[6][:-1]+'\\il.png')
   except:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[6][:-1]+'\\il.jpg')
   nk+=1
   try:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[6][:-1]+'\\il_m.png')
   except:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[6][:-1]+'\\il_m.jpg')
   nk+=1
   try:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[6][:-1]+'\\ip.png')
   except:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[6][:-1]+'\\ip.jpg')
   nk+=1
   try:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[6][:-1]+'\\ip_m.png')
   except:
    e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[6][:-1]+'\\ip_m.jpg')
   nk+=1
  for i in range(7,32):
   if h[i][:-1]!='0':
    try:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[i][:-1]+'\\is.png')
    except:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[i][:-1]+'\\is.jpg')
    nk+=1
    try:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[i][:-1]+'\\is_m.png')
    except:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[i][:-1]+'\\is_m.jpg')
    nk+=1
    try:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[i][:-1]+'\\ib.png')
    except:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'.png',M____P+'\\'+h[i][:-1]+'\\ib.jpg')
    nk+=1
    try:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[i][:-1]+'\\ib_m.png')
    except:
     e32.file_copy(M____P+'\\create\\'+str('%03d'%nk)+'_m.png',M____P+'\\'+h[i][:-1]+'\\ib_m.jpg')
    nk+=1
 except:
  cr4()




###''''''''''''''''''''''''''<*>''''''''''''''''''''''''''''###


#функция создания мбм создана по образу и подобию
#одноименной функции в программе mbm tool by shrim 
#за что ему спасибо его сайт shrim.h2m.ru
def create_mbm():
 global color
 FILE__=open(M____P+'\\set.ini')
 h=FILE__.readlines()
 FILE__.close()
 upath=h[0]
 trailer=''
 FILE__=open(M____P+'\\'+h[1][:-1]+'\\!\\system\\skins\\'+h[0][:-1]+'\\themebuilder.mbm','w')
 FILE__.write('3700001042000010000000003964394700000000'.decode('hex'))
 for i in os.listdir(M____P+'\\create'):
  img=graphics.Image.open(M____P+'\\create\\'+i)
  trailer+=struct.pack('i',f.tell())
  x,y=img.size
  FILE__.write(struct.pack('iiiiii',0,40,x,y,0,0))  
  if colore(i)==8:
   FILE__.write(struct.pack('iiii',8,0,0,1))
  elif colore(i)==16:
   FILE__.write(struct.pack('iiii',16,1,0,3))
  if x%4:
   if colore(i)==16:
    wx=x+x%2
   else:
    wx=x+(4-x%4)
  else:
   wx=x
  start=FILE__.tell()
  akt,buf,n,h,pre=None,[],0,0,0
  for yy in range(y):
   for xx in range(wx):
    if xx<=x:
     xy=img.getpixel((xx,yy))[0]
    else:
     xy=(255,255,255)
    if xy==pre:
     xy=akt
    else:
     pre=xy;xy=color(xy,colore(i))
    if akt==None:
     akt,h=xy,1
    elif akt==xy:
     if len(buf)>1:
      FILE__.write(chr(0x100-len(buf[:-1]))+''.join(buf[:-1]))
     buf,h=[],1
     if n<0x7f:
      n+=1
     else:
      FILE__.write(chr(n)+akt)
      n=0
    else:
     if h:
      FILE__.write(chr(n)+akt)
      h,n=0,0
     if len(buf)<0x80:
      buf.append(xy)
     else:
      FILE__.write(chr(0x100-len(buf))+''.join(buf))
      buf=[xy]
     akt=xy
  if h:
   FILE__.write(chr(n)+akt)
  elif buf:
   FILE__.write(chr(0x100-len(buf))+''.join(buf))
  end=FILE__.tell()
  FILE__.seek(start-40)
  FILE__.write(struct.pack('i',end-start+40))
  FILE__.seek(end)
 offset=FILE__.tell()
 FILE__.seek(16)
 FILE__.write(struct.pack('i',offset))
 FILE__.seek(offset)
 FILE__.write(struct.pack('i',len(trailer)/4))
 FILE__.write(trailer)
 FILE__.close()

###''''''''''''''''''''''''''<*>''''''''''''''''''''''''''''###
def keysall(x):
 global p
 if p==1:
  keys3(x)
 elif p==2:
  keys4(x)
 elif p==3:
  keys1(x)
 elif p==4:
  keys2(x)
 elif p==5:
  keys7(x)
 elif p==6:
  keys8(x)
 elif p==7:
  keys9(x)
 elif p==8:
  keys10(x)
 elif p==9:
  keys11(x)
 elif p==10:
  keys12(x)
 elif p==11:
  keys5(x)

def ef1():
 global KJ____,z,kjg
 z=1
 cr1()
def ef2():
 global KJ____,z,kjg
 z=1
 cr5()
def ef3():
 global KJ____,z,kjg
 z=1
 cr4()
def keys1(x):
 global KJ____,z,kjg
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=2
   cr1()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>2:
    KJ____=1
   cr1()
  elif x['scancode']==167:
   z=1
   if KJ____==1:
    KJ____,kjg=1,0
    cr2()
   elif KJ____==2:
    KJ____,kjg=1,0
    cr3()
  elif x['scancode']==164:
   z=1
   KJ____=1
   cr4()
def keys8(x):
 global KJ____,z,kjg
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=3
   cr4()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>3:
    KJ____=1
   cr4()
  elif x['scancode']==164:
   z=1
   if KJ____==1:
    create()
   elif KJ____==2:
    KJ____,kjg=1,0
    cr5() 
  elif x['scancode']==167:
   z=1
   if KJ____==1:
    create()
   elif KJ____==2:
    KJ____,kjg=1,0
    cr5()
def keys9(x):
 global KJ____,kjg,szam,z
 gmd=[3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33]
 FILE__=open(M____P+'\\set.ini','r')
 h=FILE__.readlines()
 FILE__.close() 
 g=len(szam)/5
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=5
    kjg-=1
    if kjg<0:
     kjg=g
   cr5()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>5:
    KJ____=1
    kjg+=1
    if kjg>g:
     kjg=0
   cr5()
  elif x['scancode']==167:
   z=1
   if KJ____+5*kjg==1:
    KJ____=1
    cr6()
   elif KJ____+5*kjg==2:
    KJ____=1
    cr7()
   elif KJ____+5*kjg in gmd:
    FILE__=open(M____P+'\\set.ini','w')
    FILE__.write(''.join(h[:2]+[str(gmd[KJ____+1+5*kjg])+'\n']+h[3:]))
    FILE__.close()
    KJ____,kjg=1,0
    cr8()
  elif x['scancode']==164:
   z=1
   KJ____,kjg=1,0
   cr4()
def keys2(x):
 global KJ____,kjg,z
 d=os.listdir(M____P)
 try:
  d.remove('create')
 except:
  pass
 try:
  d.remove('set.ini')
 except:
  pass
 g=len(d)/10
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=10
    kjg-=1
    if kjg<0:
     kjg=g
   cr2()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>10:
    KJ____=1
    kjg+=1
    if kjg>g:
     kjg=0
   cr2()
  elif x['scancode']==167:
   z=1
   e=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10])
   if e.size!=(176,208):
    note(2,'картинка не 176х208')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:3]+[d[KJ____-1+10*kjg]+'\n']+h[4:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr1()
  elif x['scancode']==164:
   z=1
   e=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10])
   if e.size!=(176,208):
    note(2,'картинка не 176х208')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:3]+[d[KJ____-1+10*kjg]+'\n']+h[4:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr1()
def keys10(x):
 global KJ____,kjg,z
 d=os.listdir(M____P)
 try:
  d.remove('create')
 except:
  pass
 try:
  d.remove('set.ini')
 except:
  pass
 g=len(d)/10
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=10
    kjg-=1
    if kjg<0:
     kjg=g
   cr6()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>10:
    KJ____=1
    kjg+=1
    if kjg>g:
     kjg=0
   cr6()
  elif x['scancode']==167:
   z=1
   try:
    try:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i.png')
    except:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i.jpg')
    try:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i_m.png')
    except:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i_m.jpg')
   except:
    note2(2,'ошибка файла')
   if g1.size!=(51,56) and g2.size!=(51,56):
    note2(2,'файл не 51х56')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:5]+[d[KJ____-1+10*kjg]+'\n']+h[6:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr5() 
  elif x['scancode']==164:
   z=1
   try:
    try:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i.png')
    except:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i.jpg')
    try:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i_m.png')
    except:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\i_m.jpg')
   except:
    note2(2,'ошибка файла')
   if g1.size!=(51,56) and g2.size!=(51,56):
    note2(2,'файл не 51х56')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:5]+[d[KJ____-1+10*kjg]+'\n']+h[6:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr5() 
def keys11(x):
 global KJ____,kjg,z
 d=os.listdir(M____P)
 try:
  d.remove('create')
 except:
  pass
 try:
  d.remove('set.ini')
 except:
  pass
 g=len(d)/10
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=10
    kjg-=1
    if kjg<0:
     kjg=g
   cr7()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>10:
    KJ____=1
    kjg+=1
    if kjg>g:
     kjg=0
   cr7()
  elif x['scancode']==167:
   z=1
   try:
    try:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip.png')
    except:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip.jpg')
    try:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip_m.png')
    except:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip_m.jpg')
    try:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il.png')
    except:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il.jpg')
    try:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il_m.png')
    except:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il_m.jpg')
   except:
    note2(2,'ошибка файла')
   if g1.size!=(12,29) and g2.size!=(12,29) and g3.size!=(12,29) and g4.size!=(12,29):
    note2(2,'файл не 12х29')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:6]+[d[KJ____-1+10*kjg]+'\n']+h[7:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr5()
  elif x['scancode']==164:
   z=1
   try:
    try:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip.png')
    except:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip.jpg')
    try:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip_m.png')
    except:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ip_m.jpg')
    try:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il.png')
    except:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il.jpg')
    try:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il_m.png')
    except:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\il_m.jpg')
   except:
    note2(2,'ошибка файла')
   if g1.size!=(12,29) and g2.size!=(12,29) and g3.size!=(12,29) and g4.size!=(12,29):
    note2(2,'файл не 12х29')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:6]+[d[KJ____-1+10*kjg]+'\n']+h[7:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr5() 
def keys12(x):
 global KJ____,kjg,z
 FILE__=open(M____P+'\\set.ini','r')
 h=FILE__.readlines()
 FILE__.close() 
 kjm=int(h[2])
 d=os.listdir(M____P)
 try:
  d.remove('create')
 except:
  pass
 try:
  d.remove('set.ini')
 except:
  pass
 g=len(d)/10
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=10
    kjg-=1
    if kjg<0:
     kjg=g
   cr8()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>10:
    KJ____=1
    kjg+=1
    if kjg>g:
     kjg=0
   cr8()
  elif x['scancode']==167:
   z=1
   try:
    try:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib.png')
    except:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib.jpg')
    try:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib_m.png')
    except:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib_m.jpg')
    try:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is.png')
    except:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is.jpg')
    try:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is_m.png')
    except:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is_m.jpg')
   except:
    note2(2,'ошибка файла')
   if g1.size!=(44,44) and g2.size!=(44,44) and g3.size!=(42,29) and g4.size!=(42,29):
    note2(2,'файл не 12х29')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:int(h[2][:-1])]+[d[KJ____-1+10*kjg]+'\n']+h[int(h[2][:-1])+1:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr5()
  elif x['scancode']==164:
   z=1
   try:
    try:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib.png')
    except:
     g1=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib.jpg')
    try:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib_m.png')
    except:
     g2=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\ib_m.jpg')
    try:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is.png')
    except:
     g3=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is.jpg')
    try:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is_m.png')
    except:
     g4=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10]+'\\is_m.jpg')
   except:
    note2(2,'ошибка файла')
   if g1.size!=(44,44) and g2.size!=(44,44) and g3.size!=(42,29) and g4.size!=(42,29):
    note2(2,'файл не 12х29')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:int(h[2][:-1])]+[d[KJ____-1+10*kjg]+'\n']+h[int(h[2][:-1])+1:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr5()
def keys7(x):
 global KJ____,kjg,sch2,z
 d=os.listdir(M____P)
 try:
  d.remove('create')
 except:
  pass
 try:
  d.remove('set.ini')
 except:
  pass
 g=len(d)/10
 if x['type']==3:
  if x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=10
    kjg-=1
    if kjg<0:
     kjg=g
   cr3()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>10:
    KJ____=1
    kjg+=1
    if kjg>g:
     kjg=0
   cr3()
  elif x['scancode']==167:
   z=1
   e=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10])
   if e.size!=(176,208):
    note(2,'картинка не 176х208')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:4]+[d[KJ____-1+10*kjg]+'\n']+h[5:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr1()
  elif x['scancode']==164:
   z=1
   e=G____I.open(M____P+'\\'+d[KJ____-1+kjg*10])
   if e.size!=(176,208):
    note(2,'картинка не 176х208')
   FILE__=open(M____P+'\\set.ini','r')
   h=FILE__.readlines()
   FILE__.close()
   FILE__=open(M____P+'\\set.ini','w')
   FILE__.write(''.join(h[:4]+[d[KJ____-1+10*kjg]+'\n']+h[5:]))
   FILE__.close()
   KJ____,kjg=1,0
   cr1()
def keys3(x):
 global z,KJ____
 if x['type']==3:
  if x['scancode']==164:
   KJ____=1
   z=1
   menu1()
def keys4(x):
 global KJ____,z
 if x['type']==3:
  if x['scancode']==164:
   z=1
   if KJ____==1:
    KJ____=1
    cr1()
   elif KJ____==2:
    KJ____=1
    info()
   elif KJ____==3:
    os.abort()
  elif x['scancode']==167:
   z=1
   if KJ____==1:
    KJ____=1
    cr1()
   elif KJ____==2:
    KJ____=1
    info()
   elif KJ____==3:
    os.abort()
  elif x['scancode']==16:
   z=0
   KJ____-=1
   if KJ____<1:
    KJ____=3
   menu1()
  elif x['scancode']==17:
   z=0
   KJ____+=1
   if KJ____>3:
    KJ____=1
   menu1()
def keys5(x):
 if x['type']==3:
  if x['scancode']==164:
   main()
  elif x['scancode']==167:
   main()
def keys6(x):
 if x['type']==3:
  if x['scancode']==164:
   cr1()
  elif x['scancode']==165:
   cr1()
  elif x['scancode']==167:
   cr1()
def note(y,x):
 if y==1:
  y='инфомация'
 elif y==2:
  y='ошибка'
 appuifw.app.body=canvas=appuifw.Canvas(event_callback=keys6)
 appuifw.app.exit_key_handler=cr1
 BODY__.clear((0xbb00dd))
 BODY__.rectangle((10,90,165,130),0x880099,0x880099)
 BODY__.line((13,130,167,130),0x550066)
 BODY__.line((13,131,167,131),0x550066)
 BODY__.line((13,132,167,132),0x550066)
 BODY__.line((165,93,165,133),0x550066)
 BODY__.line((166,93,166,133),0x550066)
 BODY__.line((167,93,167,133),0x550066)
 BODY__.text((40,105),ru(y),0x998800)
 BODY__.text((17,125),ru(x),0x998800)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('назад'),0x998800,font=u'Alb17b')
 canvas.blit(BODY__)
 e32.ao_yield()
 e32.ao_sleep(3)
 cr1()
def note2(y,x):
 if y==1:
  y='инфомация'
 elif y==2:
  y='ошибка'
 appuifw.app.body=canvas=appuifw.Canvas(event_callback=keys6)
 appuifw.app.exit_key_handler=cr1
 BODY__.clear((0xbb00dd))
 BODY__.rectangle((10,90,165,130),0x880099,0x880099)
 BODY__.line((13,130,167,130),0x550066)
 BODY__.line((13,131,167,131),0x550066)
 BODY__.line((13,132,167,132),0x550066)
 BODY__.line((165,93,165,133),0x550066)
 BODY__.line((166,93,166,133),0x550066)
 BODY__.line((167,93,167,133),0x550066)
 BODY__.text((40,105),ru(y),0x998800)
 BODY__.text((17,125),ru(x),0x998800)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('назад'),0x998800,font=u'Alb17b')
 canvas.blit(BODY__)
 e32.ao_yield()
 e32.ao_sleep(3)
 cr5()
def info():
 global p
 p=11
 appuifw.app.exit_key_handler=main
 BODY__.clear((0xbb00dd))
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('назад'),0x998800,font=u'Alb17b')
 b=80
 while b>0:
  BODY__.rectangle((10,90+b,165,170),0x880099,0x880099)
  BODY__.line((13,170,167,170),0x550066)
  BODY__.line((13,171,167,171),0x550066)
  BODY__.line((13,172,167,172),0x550066)
  BODY__.line((165,93+b,165,173),0x550066)
  BODY__.line((166,93+b,166,173),0x550066)
  BODY__.line((167,93+b,167,173),0x550066)
  canvas.blit(BODY__)
  e32.ao_sleep(0.005)
  b-=1
 e32.ao_sleep(0.07)
 BODY__.text((15,160),u'support',0x998800,font=u'Alpi12')
 BODY__.text((65,160),u'SMARTU.NET',0x998800,font=u'Albi12')
 BODY__.text((143,160),u'Lab.',0x998800,font=u'Alpi12')
 canvas.blit(BODY__)
 e32.ao_sleep(0.07)
 BODY__.text((15,145),u'release is created at',0x998800,font=u'Alpi12')
 canvas.blit(BODY__)
 e32.ao_sleep(0.07)
 BODY__.text((15,130),u'by',0x998800,font=u'Alpi12')
 BODY__.text((40,130),u'_VersouL_',0x998800,font=u'Albi12')
 canvas.blit(BODY__)
 e32.ao_sleep(0.07)
 BODY__.text((17,105),u'ThemeBuilder v1.03 ',0x998800,font=u'Albi12')
 canvas.blit(BODY__)
def menu1():
 global KJ____,z,p
 p=2
 appuifw.app.exit_key_handler=main
 BODY__.clear(0xbb00dd)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('выбор'),0x998800,font=u'Alb17b')
 if z:
  b=62
  while b>0:
   BODY__.rectangle((10,116+b,90,178),0x880099,0x880099)
   BODY__.line((13,178,93,178),0x550066)
   BODY__.line((13,179,93,179),0x550066)
   BODY__.line((13,180,93,180),0x550066)
   BODY__.line((90,118+b,90,178),0x550066)
   BODY__.line((91,118+b,91,178),0x550066)
   BODY__.line((92,118+b,92,178),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
  e32.ao_sleep(0.07)
  BODY__.text((14,173),ru('выход'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
  BODY__.text((14,153),ru('о программе'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
  BODY__.text((14,133),ru('старт'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
 BODY__.rectangle((10,116,90,178),0x880099,0x880099)
 BODY__.rectangle((11,98+20*KJ____,89,117+20*KJ____),0x9900cc,0x9900cc)
 BODY__.line((13,178,93,178),0x550066)
 BODY__.line((13,179,93,179),0x550066)
 BODY__.line((13,180,93,180),0x550066)
 BODY__.line((90,119,90,178),0x550066)
 BODY__.line((91,119,91,178),0x550066)
 BODY__.line((92,119,92,178),0x550066)
 BODY__.text((14,173),ru('выход'),0x998800)
 BODY__.text((14,153),ru('о программе'),0x998800)
 BODY__.text((14,133),ru('старт'),0x998800)
 canvas.blit(BODY__)
def cr1():
 global KJ____,p,z
 FILE__=open(M____P+'\\set.ini','r')
 h=FILE__.readlines()
 FILE__.close()
 if h[3][:-1]=='0':
  h1='не задано'
 else:
  h1=h[3][:-1]
 if h[4][:-1]=='0':
  h2='не задано'
 else:
  h2=h[4][:-1]
 p=3
 appuifw.app.exit_key_handler=main
 BODY__.clear(0xbb00ee)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('готово'),0x998800,font=u'Alb17b')
 if z:
  b=62
  while b>0:
   BODY__.rectangle((25,60+b,150,122),0x880099,0x880099)
   BODY__.line((150,62+b,150,124),0x550066)
   BODY__.line((151,62+b,151,124),0x550066)
   BODY__.line((152,62+b,152,124),0x550066)
   BODY__.line((28,122,153,122),0x550066)
   BODY__.line((28,123,153,123),0x550066)
   BODY__.line((28,124,153,124),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
  e32.ao_sleep(0.07)
  BODY__.text((35,115),ru(h2),0x998800)
  BODY__.text((35,105),ru('фон в меню'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
  BODY__.text((35,85),ru(h1),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
  BODY__.text((35,75),ru('главный фон'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
 BODY__.rectangle((25,60,150,122),0x880099,0x880099)
 BODY__.line((150,63,150,124),0x550066)
 BODY__.line((151,63,151,124),0x550066)
 BODY__.line((152,63,152,124),0x550066)
 BODY__.line((28,122,153,122),0x550066)
 BODY__.line((28,123,153,123),0x550066)
 BODY__.line((28,124,153,124),0x550066)
 BODY__.rectangle((26,31+30*KJ____,149,61+30*KJ____),0x9900cc,0x9900cc)
 BODY__.text((35,75),ru('главный фон'),0x998800)
 BODY__.text((35,85),ru(h1),0x998800)
 BODY__.text((35,105),ru('фон в меню'),0x998800)
 BODY__.text((35,115),ru(h2),0x998800)
 canvas.blit(BODY__)
def cr2():
 global KJ____,kjg,z,p
 p=4
 h=os.listdir(M____P)
 try:
  h.remove('create')
 except:
  pass
 try:
  h.remove('set.ini')
 except:
  pass
 appuifw.app.exit_key_handler=ef1
 BODY__.clear(0xbb00ee)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('выбор'),0x998800,font=u'Alb17b')
 if z:
  b=150
  while b>0:
   BODY__.rectangle((25,20+b,150,170),0x880099,0x880099)
   BODY__.line((150,23+b,150,173),0x550066)
   BODY__.line((151,23+b,151,173),0x550066)
   BODY__.line((152,23+b,152,173),0x550066)
   BODY__.line((28,170,153,170),0x550066)
   BODY__.line((28,171,153,171),0x550066)
   BODY__.line((28,172,153,172),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
 BODY__.rectangle((25,20,150,170),0x880099,0x880099)
 BODY__.line((150,23,150,173),0x550066)
 BODY__.line((151,23,151,173),0x550066)
 BODY__.line((152,23,152,173),0x550066)
 BODY__.line((28,170,153,170),0x550066)
 BODY__.line((28,171,153,171),0x550066)
 BODY__.line((28,172,153,172),0x550066)
 BODY__.rectangle((26,6+15*KJ____,149,19+15*KJ____),0x9900cc,0x9900cc)
 try:
  BODY__.text((35,32),ru(h[0+10*kjg]),0x998800)
 except:
  BODY__.text((35,32),ru(''),0x998800)
 try:
  BODY__.text((35,47),ru(h[1+10*kjg]),0x998800)
 except:
  BODY__.text((35,47),ru(''),0x998800)
 try:
  BODY__.text((35,62),ru(h[2+10*kjg]),0x998800)
 except:
  BODY__.text((35,62),ru(''),0x998800)
 try:
  BODY__.text((35,77),ru(h[3+10*kjg]),0x998800)
 except:
  BODY__.text((35,77),ru(''),0x998800)
 try:
  BODY__.text((35,92),ru(h[4+10*kjg]),0x998800)
 except:
  BODY__.text((35,92),ru(''),0x998800)
 try:
  BODY__.text((35,107),ru(h[5+10*kjg]),0x998800)
 except:
  BODY__.text((35,107),ru(''),0x998800)
 try:
  BODY__.text((35,122),ru(h[6+10*kjg]),0x998800)
 except:
  BODY__.text((35,122),ru(''),0x998800)
 try:
  BODY__.text((35,137),ru(h[7+10*kjg]),0x998800)
 except:
  BODY__.text((35,137),ru(''),0x998800)
 try:
  BODY__.text((35,152),ru(h[8+10*kjg]),0x998800)
 except:
  BODY__.text((35,152),ru(''),0x998800)
 try:
  BODY__.text((35,167),ru(h[9+10*kjg]),0x998800)
 except:
  BODY__.text((35,167),ru(''),0x998800)
 canvas.blit(BODY__)
def cr6():
 global KJ____,kjg,p,z
 p=8
 h=os.listdir(M____P)
 try:
  h.remove('create')
 except:
  pass
 try:
  h.remove('set.ini')
 except:
  pass
 appuifw.app.exit_key_handler=ef2
 BODY__.clear(0xbb00ee)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('выбор'),0x998800,font=u'Alb17b')
 if z:
  b=150
  while b>0:
   BODY__.rectangle((25,20+b,150,170),0x880099,0x880099)
   BODY__.line((150,23+b,150,173),0x550066)
   BODY__.line((151,23+b,151,173),0x550066)
   BODY__.line((152,23+b,152,173),0x550066)
   BODY__.line((28,170,153,170),0x550066)
   BODY__.line((28,171,153,171),0x550066)
   BODY__.line((28,172,153,172),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
 BODY__.rectangle((25,20,150,170),0x880099,0x880099)
 BODY__.line((150,23,150,173),0x550066)
 BODY__.line((151,23,151,173),0x550066)
 BODY__.line((152,23,152,173),0x550066)
 BODY__.line((28,170,153,170),0x550066)
 BODY__.line((28,171,153,171),0x550066)
 BODY__.line((28,172,153,172),0x550066)
 BODY__.rectangle((26,6+15*KJ____,149,19+15*KJ____),0x9900cc,0x9900cc)
 try:
  BODY__.text((35,32),ru(h[0+10*kjg]),0x998800)
 except:
  BODY__.text((35,32),ru(''),0x998800)
 try:
  BODY__.text((35,47),ru(h[1+10*kjg]),0x998800)
 except:
  BODY__.text((35,47),ru(''),0x998800)
 try:
  BODY__.text((35,62),ru(h[2+10*kjg]),0x998800)
 except:
  BODY__.text((35,62),ru(''),0x998800)
 try:
  BODY__.text((35,77),ru(h[3+10*kjg]),0x998800)
 except:
  BODY__.text((35,77),ru(''),0x998800)
 try:
  BODY__.text((35,92),ru(h[4+10*kjg]),0x998800)
 except:
  BODY__.text((35,92),ru(''),0x998800)
 try:
  BODY__.text((35,107),ru(h[5+10*kjg]),0x998800)
 except:
  BODY__.text((35,107),ru(''),0x998800)
 try:
  BODY__.text((35,122),ru(h[6+10*kjg]),0x998800)
 except:
  BODY__.text((35,122),ru(''),0x998800)
 try:
  BODY__.text((35,137),ru(h[7+10*kjg]),0x998800)
 except:
  BODY__.text((35,137),ru(''),0x998800)
 try:
  BODY__.text((35,152),ru(h[8+10*kjg]),0x998800)
 except:
  BODY__.text((35,152),ru(''),0x998800)
 try:
  BODY__.text((35,167),ru(h[9+10*kjg]),0x998800)
 except:
  BODY__.text((35,167),ru(''),0x998800)
 canvas.blit(BODY__)
def cr7():
 global KJ____,kjg,p,z
 p=9
 h=os.listdir(M____P)
 try:
  h.remove('create')
 except:
  pass
 try:
  h.remove('set.ini')
 except:
  pass
 appuifw.app.exit_key_handler=ef2
 BODY__.clear(0xbb00ee)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('выбор'),0x998800,font=u'Alb17b')
 if z:
  b=150
  while b>0:
   BODY__.rectangle((25,20+b,150,170),0x880099,0x880099)
   BODY__.line((150,23+b,150,173),0x550066)
   BODY__.line((151,23+b,151,173),0x550066)
   BODY__.line((152,23+b,152,173),0x550066)
   BODY__.line((28,170,153,170),0x550066)
   BODY__.line((28,171,153,171),0x550066)
   BODY__.line((28,172,153,172),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
 BODY__.rectangle((25,20,150,170),0x880099,0x880099)
 BODY__.line((150,23,150,173),0x550066)
 BODY__.line((151,23,151,173),0x550066)
 BODY__.line((152,23,152,173),0x550066)
 BODY__.line((28,170,153,170),0x550066)
 BODY__.line((28,171,153,171),0x550066)
 BODY__.line((28,172,153,172),0x550066)
 BODY__.rectangle((26,6+15*KJ____,149,19+15*KJ____),0x9900cc,0x9900cc)
 try:
  BODY__.text((35,32),ru(h[0+10*kjg]),0x998800)
 except:
  BODY__.text((35,32),ru(''),0x998800)
 try:
  BODY__.text((35,47),ru(h[1+10*kjg]),0x998800)
 except:
  BODY__.text((35,47),ru(''),0x998800)
 try:
  BODY__.text((35,62),ru(h[2+10*kjg]),0x998800)
 except:
  BODY__.text((35,62),ru(''),0x998800)
 try:
  BODY__.text((35,77),ru(h[3+10*kjg]),0x998800)
 except:
  BODY__.text((35,77),ru(''),0x998800)
 try:
  BODY__.text((35,92),ru(h[4+10*kjg]),0x998800)
 except:
  BODY__.text((35,92),ru(''),0x998800)
 try:
  BODY__.text((35,107),ru(h[5+10*kjg]),0x998800)
 except:
  BODY__.text((35,107),ru(''),0x998800)
 try:
  BODY__.text((35,122),ru(h[6+10*kjg]),0x998800)
 except:
  BODY__.text((35,122),ru(''),0x998800)
 try:
  BODY__.text((35,137),ru(h[7+10*kjg]),0x998800)
 except:
  BODY__.text((35,137),ru(''),0x998800)
 try:
  BODY__.text((35,152),ru(h[8+10*kjg]),0x998800)
 except:
  BODY__.text((35,152),ru(''),0x998800)
 try:
  BODY__.text((35,167),ru(h[9+10*kjg]),0x998800)
 except:
  BODY__.text((35,167),ru(''),0x998800)
 canvas.blit(BODY__)
def cr8():
 global KJ____,kjg,z,p
 p=10
 h=os.listdir(M____P)
 try:
  h.remove('create')
 except:
  pass
 try:
  h.remove('set.ini')
 except:
  pass
 appuifw.app.exit_key_handler=ef2
 BODY__.clear(0xbb00ee)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('выбор'),0x998800,font=u'Alb17b')
 if z:
  b=150
  while b>0:
   BODY__.rectangle((25,20+b,150,170),0x880099,0x880099)
   BODY__.line((150,23+b,150,173),0x550066)
   BODY__.line((151,23+b,151,173),0x550066)
   BODY__.line((152,23+b,152,173),0x550066)
   BODY__.line((28,170,153,170),0x550066)
   BODY__.line((28,171,153,171),0x550066)
   BODY__.line((28,172,153,172),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
 BODY__.rectangle((25,20,150,170),0x880099,0x880099)
 BODY__.line((150,23,150,173),0x550066)
 BODY__.line((151,23,151,173),0x550066)
 BODY__.line((152,23,152,173),0x550066)
 BODY__.line((28,170,153,170),0x550066)
 BODY__.line((28,171,153,171),0x550066)
 BODY__.line((28,172,153,172),0x550066)
 BODY__.rectangle((26,6+15*KJ____,149,19+15*KJ____),0x9900cc,0x9900cc)
 try:
  BODY__.text((35,32),ru(h[0+10*kjg]),0x998800)
 except:
  BODY__.text((35,32),ru(''),0x998800)
 try:
  BODY__.text((35,47),ru(h[1+10*kjg]),0x998800)
 except:
  BODY__.text((35,47),ru(''),0x998800)
 try:
  BODY__.text((35,62),ru(h[2+10*kjg]),0x998800)
 except:
  BODY__.text((35,62),ru(''),0x998800)
 try:
  BODY__.text((35,77),ru(h[3+10*kjg]),0x998800)
 except:
  BODY__.text((35,77),ru(''),0x998800)
 try:
  BODY__.text((35,92),ru(h[4+10*kjg]),0x998800)
 except:
  BODY__.text((35,92),ru(''),0x998800)
 try:
  BODY__.text((35,107),ru(h[5+10*kjg]),0x998800)
 except:
  BODY__.text((35,107),ru(''),0x998800)
 try:
  BODY__.text((35,122),ru(h[6+10*kjg]),0x998800)
 except:
  BODY__.text((35,122),ru(''),0x998800)
 try:
  BODY__.text((35,137),ru(h[7+10*kjg]),0x998800)
 except:
  BODY__.text((35,137),ru(''),0x998800)
 try:
  BODY__.text((35,152),ru(h[8+10*kjg]),0x998800)
 except:
  BODY__.text((35,152),ru(''),0x998800)
 try:
  BODY__.text((35,167),ru(h[9+10*kjg]),0x998800)
 except:
  BODY__.text((35,167),ru(''),0x998800)
 canvas.blit(BODY__)
def cr3():
 global KJ____,kjg,p,z
 p=5
 h=os.listdir(M____P)
 try:
  h.remove('create')
 except:
  pass
 try:
  h.remove('set.ini')
 except:
  pass
 appuifw.app.exit_key_handler=ef1
 BODY__.clear(0xbb00ee)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('выбор'),0x998800,font=u'Alb17b')
 if z:
  b=150
  while b>0:
   BODY__.rectangle((25,20+b,150,170),0x880099,0x880099)
   BODY__.line((150,23+b,150,173),0x550066)
   BODY__.line((151,23+b,151,173),0x550066)
   BODY__.line((152,23+b,152,173),0x550066)
   BODY__.line((28,170,153,170),0x550066)
   BODY__.line((28,171,153,171),0x550066)
   BODY__.line((28,172,153,172),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
 BODY__.rectangle((25,20,150,170),0x880099,0x880099)
 BODY__.line((150,23,150,173),0x550066)
 BODY__.line((151,23,151,173),0x550066)
 BODY__.line((152,23,152,173),0x550066)
 BODY__.line((28,170,153,170),0x550066)
 BODY__.line((28,171,153,171),0x550066)
 BODY__.line((28,172,153,172),0x550066)
 BODY__.rectangle((26,6+15*KJ____,149,19+15*KJ____),0x9900cc,0x9900cc)
 try:
  BODY__.text((35,32),ru(h[0+10*kjg]),0x998800)
 except:
  BODY__.text((35,32),ru(''),0x998800)
 try:
  BODY__.text((35,47),ru(h[1+10*kjg]),0x998800)
 except:
  BODY__.text((35,47),ru(''),0x998800)
 try:
  BODY__.text((35,62),ru(h[2+10*kjg]),0x998800)
 except:
  BODY__.text((35,62),ru(''),0x998800)
 try:
  BODY__.text((35,77),ru(h[3+10*kjg]),0x998800)
 except:
  BODY__.text((35,77),ru(''),0x998800)
 try:
  BODY__.text((35,92),ru(h[4+10*kjg]),0x998800)
 except:
  BODY__.text((35,92),ru(''),0x998800)
 try:
  BODY__.text((35,107),ru(h[5+10*kjg]),0x998800)
 except:
  BODY__.text((35,107),ru(''),0x998800)
 try:
  BODY__.text((35,122),ru(h[6+10*kjg]),0x998800)
 except:
  BODY__.text((35,122),ru(''),0x998800)
 try:
  BODY__.text((35,137),ru(h[7+10*kjg]),0x998800)
 except:
  BODY__.text((35,137),ru(''),0x998800)
 try:
  BODY__.text((35,152),ru(h[8+10*kjg]),0x998800)
 except:
  BODY__.text((35,152),ru(''),0x998800)
 try:
  BODY__.text((35,167),ru(h[9+10*kjg]),0x998800)
 except:
  BODY__.text((35,167),ru(''),0x998800)
 canvas.blit(BODY__)
def cr4():
 global KJ____,z,p
 p=6
 BODY__.clear(0xbb00dd)
 BODY__.text((125,200),ru('назад'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('выбор'),0x998800,font=u'Alb17b')
 appuifw.app.exit_key_handler=ef1
 if z:
  b=92
  while b>0:
   BODY__.rectangle((25,40+b,150,132),0x880099,0x880099)
   BODY__.line((150,43+b,150,135),0x550066)
   BODY__.line((151,43+b,151,135),0x550066)
   BODY__.line((152,43+b,152,135),0x550066)
   BODY__.line((28,132,153,132),0x550066)
   BODY__.line((28,133,153,133),0x550066)
   BODY__.line((28,134,153,134),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
  e32.ao_sleep(0.07)
  BODY__.text((35,115),ru('настройка цвета'),0x998800)
  BODY__.text((40,127),ru('текста'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
  BODY__.text((35,83),ru('дополнительные'),0x998800)
  BODY__.text((40,95),ru('настройки'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
  BODY__.text((35,60),ru('создать тему'),0x998800)
  canvas.blit(BODY__)
  e32.ao_sleep(0.07)
 BODY__.rectangle((25,40,150,132),0x880099,0x880099)
 BODY__.line((150,43,150,135),0x550066)
 BODY__.line((151,43,151,135),0x550066)
 BODY__.line((152,43,152,135),0x550066)
 BODY__.line((28,132,153,132),0x550066)
 BODY__.line((28,133,153,133),0x550066)
 BODY__.line((28,134,153,134),0x550066)
 BODY__.rectangle((26,11+30*KJ____,149,41+30*KJ____),0x9900cc,0x9900cc)
 BODY__.text((35,60),ru('создать тему'),0x998800)
 BODY__.text((35,83),ru('дополнительные'),0x998800)
 BODY__.text((40,95),ru('настройки'),0x998800)
 BODY__.text((35,115),ru('настройка цвета'),0x998800)
 BODY__.text((40,127),ru('текста'),0x998800)
 canvas.blit(BODY__)
def cr5():
 global KJ____,kjg,szam,z,p
 p=7
 FILE__=open(M____P+'\\set.ini','r')
 g=FILE__.readlines()
 FILE__.close()
 gh=[]
 for i in range(5,34):
  if g[i][:-1]=='0':
   gh.append('не задано')
  else:
   gh.append(g[i][:-1])
 appuifw.app.exit_key_handler=ef3
 BODY__.clear(0xbb00ee)
 BODY__.text((125,200),ru('готово'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('готово'),0x998800,font=u'Alb17b')
 if z:
  b=140
  while b>0:
   BODY__.rectangle((25,27+b,150,167),0x880099,0x880099)
   BODY__.line((150,30+b,150,170),0x550066)
   BODY__.line((151,30+b,151,170),0x550066)
   BODY__.line((152,30+b,152,170),0x550066)
   BODY__.line((28,167,153,167),0x550066)
   BODY__.line((28,168,153,168),0x550066)
   BODY__.line((28,169,153,169),0x550066)
   canvas.blit(BODY__)
   e32.ao_sleep(0.005)
   b-=1
 BODY__.rectangle((25,27,150,167),0x880099,0x880099)
 BODY__.line((150,31,150,170),0x550066)
 BODY__.line((151,31,151,170),0x550066)
 BODY__.line((152,31,152,170),0x550066)
 BODY__.line((28,167,153,167),0x550066)
 BODY__.line((28,168,153,168),0x550066)
 BODY__.line((28,169,153,169),0x550066)
 BODY__.rectangle((26,01+27*KJ____,149,31+27*KJ____),0x9900cc,0x9900cc)
 try:
  BODY__.text((35,42),ru(szam[0+5*kjg]),0x998800)
 except:
  BODY__.text((35,42),ru(''),0x998800)
 try:
  BODY__.text((35,52),ru(gh[0+5*kjg]),0x998800)
 except:
  BODY__.text((35,52),ru(''),0x998800)
 try:
  BODY__.text((35,69),ru(szam[1+5*kjg]),0x998800)
 except:
  BODY__.text((35,69),ru(''),0x998800)
 try:
  BODY__.text((35,79),ru(gh[1+5*kjg]),0x998800)
 except:
  BODY__.text((35,79),ru(''),0x998800)
 try:
  BODY__.text((35,96),ru(szam[2+5*kjg]),0x998800)
 except:
  BODY__.text((35,96),ru(''),0x998800)
 try:
  BODY__.text((35,106),ru(gh[2+5*kjg]),0x998800)
 except:
  BODY__.text((35,106),ru(''),0x998800)
 try:
  BODY__.text((35,123),ru(szam[3+5*kjg]),0x998800)
 except:
  BODY__.text((35,123),ru(''),0x998800)
 try:
  BODY__.text((35,133),ru(gh[3+5*kjg]),0x998800)
 except:
  BODY__.text((35,133),ru(''),0x998800)
 try:
  BODY__.text((35,150),ru(szam[4+5*kjg]),0x998800)
 except:
  BODY__.text((35,150),ru(''),0x998800)
 try:
  BODY__.text((35,160),ru(gh[4+5*kjg]),0x998800)
 except:
  BODY__.text((35,160),ru(''),0x998800)
 canvas.blit(BODY__)
def main():
 global p
 p=1
 appuifw.app.exit_key_handler=os.abort
 BODY__.clear(0xbb00dd)
 BODY__.text((125,200),ru('выход'),0x998800,font=u'Alb17b')
 BODY__.text((5,200),ru('меню'),0x998800,font=u'Alb17b')
 BODY__.text((60,105),ru('версия 1.03'),0x000000,font=u'Alp17b')
 BODY__.blit(img,target=((0,40),(176,60)),mask=automask(img_m))
 canvas.blit(BODY__)
def create():
 snip_imgs()
 create_skn()
 create_mbm()
szam=['часы','индикаторы','меню','темы','калькулятор','контакты','календарь','сообщения','кам/вид(нов)','кам/вид(стар)','радио','галерея(нов)','галерея(стар)','дела','чат','режимы','актив','блютуз','ик порт','настройки','часы','конвертер','журнал','заметки','диктофон','дисп приложений','память','справка','дисп файлов']
appuifw.app.body=canvas=appuifw.Canvas(event_callback=keysall)
main()
e32.Ao_lock().wait()
