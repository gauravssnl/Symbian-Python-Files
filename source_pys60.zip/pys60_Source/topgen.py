host=200 #��c�o xoc�o�
time=10 #�ay�a � coe���e���x � ce�y��ax
cats=['wap-top.ru/top/count.php?uid=2887','top.nash-kovcheg.ru/cnt/3307.gif','x-wap.ru/top/count.php?uid=3124'] #cc���� �a �a�a�o��

p="/3.0 (06.27.1.0) SymbianOS/9.1 Series60/3.0 Profile/MIDP-2.0 Configuration/CLDC-1.1" #�oc����c ��ep-a�e��a
ua=["SAMSUNG-","MOT","Nokia","SIE-","SonyEricsson",'LG-','SEC-','Opera'] #�pe���c� � ��ep-a�e��a

from socket import *
from random import *
import e32
apo=access_point(select_access_point())
set_default_access_point(apo)
apo.start()
for i in xrange(1,host+1):
 try:
  for cat in cats:
   cat=cat.split('/',1)
   host=cat[0]
   path='/'+cat[1]
   s=socket(AF_INET,SOCK_STREAM)
   if host!="x-wap.ru":
    s.connect((host,80))
   else:
    s.connect(('www.x-wap.ru',80))
   s.send('GET '+path+' HTTP/1.0\r\nReferer: http://erocity.wen.ru\r\nHost: '+host+'\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nConnection: Close\r\nUser-Agent: '+ua[randint(0,len(ua)-1)]+str(randint(0,600))+p+'\r\n\r\n')
   s.close()
   del s
 except:
  print'error'
 try:
  apo.stop()
  e32.ao_sleep(time)
  apo.start()
 except:
  print'fatal error'
  continue
 print i