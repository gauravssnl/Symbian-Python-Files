#created by Vital 6630
def ru(x):return x.decode('utf-8')
def ur(x):return x.encode('utf-8')
import appuifw
import e32
appuifw.app.screen='full'
appuifw.app.body=t=appuifw.Text()
t.focus=False
t.font=u'Alb17b'
t.color=0x000080
t.set(ru('\n'*4+'  M O D C H A N G E R'))
t.font=u'LatinPlain12'
t.add(ru('\n'*9+'\t\tзагрузка...'))
e32.ao_sleep(0.5)
import os
import error
from key_codes import *
try:
  import easydb
  import powlite_fm
  import string
except:
  appuifw.note(ru('Установите подборку модулей'),'error')
  os.abort()
fileman = powlite_fm.manager()
r=easydb.EasyDB()
w=easydb.EasyDB()
icon1=appuifw.Icon(u"z:\\system\\data\\avkon.mbm",134,135)
icon2=appuifw.Icon(u"z:\\system\\data\\avkon.mbm",140,141)
icon3=appuifw.Icon(u"z:\\system\\data\\avkon.mbm",186,187)
dir=appuifw.app.full_name()[0]+':\\System\\Apps\\ModChanger\\'
HELP=dir+'Help\\'
INI=dir+'ModChanger.cdb'
SET=dir+'Settings.cdb'
if os.path.exists(SET)==0:
  if appuifw.query(ru('Выбрать папку для сохранения файлов?'),"query")==True:
    path=fileman.AskUser(find ="dir")
    if path==None:
      DATA=dir+'Data\\'
    else:
      DATA=path+'ModChanger\\'
  else:
    DATA=dir+'Data\\'
  appuifw.note(ru('Выбрана папка:\n')+DATA,'info')
  w.Load(SET,create=True)
  w.Add(ru('DATA'),DATA)
r.Load(SET)
DATA=r.Get(ru('DATA'))
if os.path.exists(DATA)==0:
  os.mkdir(DATA)
Data=ur(DATA)
Data_old=[]
Data_old,index_old,title=[],[],[]
Data_old.append(ur(DATA))
index_old.append(0)
### загрузка файла ###
def load():
  index=appuifw.app.body.current()
#  file=ru(Data)+profile_name[index][0]
  file=ru(Data)+files[index]
  r.Load(INI)
  link=r.Get(ru(Data[:-1]))
  e32.file_copy(link,unicode(file))
  e32.ao_sleep(0.5)
  appuifw.note(ru('Готово!'),'conf')
### папки ###
def new_part():
  global link,name
  name=appuifw.query(ru('Имя папки:'),'text')
  if name==None:return
  find1()
  if name==None:return
  part=Data+ur(name)
  os.mkdir(part)
  if Data!=ur(DATA):
    link=fileman.AskUser()
    if link==None:return
    appuifw.app.title=ru('создание...')
    e32.ao_sleep(0.5)
    mod=os.path.split(link)[1]
    e32.file_copy(ru(Data)+name+'\\'+mod,ur(link))
    w.Load(INI,create=True)
    w.Add(ru(part),link)
  MENU()
def rename_part():
  global name
  a=profile[appuifw.app.body.current()]
  if Data==ur(DATA) and len(os.listdir(a))>0:
    appuifw.note(ru('Невозможно переименовать!\nПапка не пустая!'),'error')
    return
  i=appuifw.app.body.current()
  if os.path.isdir(profile[i]):
    part_old=profile[i]
    name=appuifw.query(ru('Новое имя:'),"text",files[i])
    if name==None:return
    find1()
    if name==None:return
    appuifw.app.title=ru('переименование...')
    e32.ao_sleep(0.5)
    os.rename(part_old,Data+ur(name))
    if Data!=ur(DATA):
      part=Data+ur(name)
      r.Load(INI)
      link=r.Get(ru(part_old[:-1]))
      w.Load(INI,create=True)
      w.Add(ru(part),link)
      w.Del(ru(part_old[:-1]))
  MENU()
def del_part():
  index=appuifw.app.body.current()
  if os.path.isdir(profile[index]):
    part=profile[index]
    if appuifw.query(ru('Удалить папку?'),"query")==True:
      appuifw.app.title=ru('удаление...')
      del_dir(part)
      os.rmdir(part)
      try:
        w.Load(INI,create=True)
        w.Del(ru(part[:-1]))
      except:pass
  else:delete()
  MENU()
def del_dir(path):
  for name in os.listdir(path):
    e32.ao_sleep(0.001)
    new=path+name+'\\'
    if os.path.isdir(new):
      del_dir(new)
      try:
        os.rmdir(new)
        w.Load(INI,create=True)
        w.Del(ru(new[:-1]))
      except:pass
    else:
      try:os.remove(new[:-1])
      except:pass
### файлы ###
def add():
  global name
  path=fileman.AskUser(ext=[end])
  if path==None:return
  name=os.path.split(path)[1]
  find2()
  if name==None:return
  e32.file_copy(ru(Data)+name,path)
  MENU()
def rename():
  global name
  i=appuifw.app.body.current()
  name=appuifw.query(ru('Новое имя:'),'text',profile_name[i][0])
  if name==None:return
  name=name+end
  find2()
  if name==None:return
  os.rename(profile[i],Data+ur(name))
  MENU()
def delete():
  i=appuifw.app.body.current()
  if appuifw.query(ru("Удалить '")+profile_name[i][0]+ru("'?"),"query")==True:
    os.remove(profile[i])
    MENU()
def view():
  if len(title)<2:return
  appuifw.note(ru('Расширение:\n')+string.upper(end[1:]),'info')
### поиск ###
def find1():
  global name
  try:
    for a in range(0,len(files)):
      if string.lower(files[a])==string.lower(name):
        menu=[ru('изменить имя'),ru('отмена')]
        i=appuifw.popup_menu(menu,ru('Файл уже существует:'))
        if i==None:name=None
        if i==0:
          name=appuifw.query(ru('Новое имя:'),'text',name)
          if name!=None:
            find1()
        if i==1:name=None
  except:pass
def find2():
  global name
  for a in range(0,len(files)):
    if string.lower(files[a])==string.lower(name):
      menu=[ru('изменить имя'),ru('заменить файл'),ru('отмена')]
      i=appuifw.popup_menu(menu,ru('Файл уже существует:'))
      if i==None:name=None
      if i==0:
        name=name.split(u".")[0]
        name=appuifw.query(ru('Новое имя:'),'text',name)
        if name!=None:
          name=name+end
          find2()
      if i==1:pass
      if i==2:name=None
### помощь ###
def help():
  appuifw.app.screen='normal'
  appuifw.app.title=ru('Помощь')
  files=map(ru,os.listdir(HELP))
  i=appuifw.selection_list(files)
  if i==None:
    MENU()
    return
  file=ur(HELP+files[i])
  f=open(file,'r')
  text=f.read()
  f.close()
  appuifw.app.screen='full'
  appuifw.app.body=t=appuifw.Text()
  t.focus=False
  t.font=u'LatinPlain12'
  t.color=0x444444
  t.set(ru(text))
  t.set_pos(0)
  appuifw.app.exit_key_handler=MENU
  appuifw.app.menu=[(ru('Помощь'),help),(ru('Назад'),MENU)]
### о программе ###
def about():
  appuifw.note(ru('ModChanger\nАвтор: Vital 6630\nICQ: 383822726'),'info')
### выход ###
def quit():os.abort()
### директория назад ###
def dir1():
  global Data,Data_old,index,index_old,title
  if len(Data_old)==1:
    Data_old,index_old,title=[],[],[]
    Data_old.append(ur(DATA))
    index_old.append(appuifw.app.body.current())
  else:
    title[len(title)-1:len(title)]=[]
    Data_old[len(Data_old)-1:len(Data_old)]=[]
    Data=Data_old[len(Data_old)-1]
    index=index_old[len(index_old)-1]
    index_old[len(index_old)-1:len(index_old)]=[]
  MENU()
  return
### директория вперед ###
def dir2():
  global Data,Data_old,index,index_old,title,end
  if profile==[]:return
  if os.path.isdir(profile[appuifw.app.body.current()]):
    index=appuifw.app.body.current()
    title.append(profile_name[index][0])
    Data=profile[index]
    Data_old.append(Data)
    index_old.append(index)
    index=0
    if len(title)>1:
      try:
        r.Load(INI)
        link=r.Get(ru(Data[:-1]))
        end=os.path.split(link)[1]
        end=end.split(u".")[1]
        end=u'.'+end
      except:
        end=u''
  MENU()
### меню ###
def menu():
  global index
  if profile==[]:return
  index=appuifw.app.body.current()
  if os.path.isdir(profile[index]):
    dir2()
  else:
    load()
def MENU():
  global Data_old,files,profile,profile_name,old,index_old
  profile,profile_name=[],[]
  files=map(ru,os.listdir(Data))
  c=os.listdir(Data)
  for a in range(0,len(c)):
    file=Data+c[a]+'\\'
    if os.path.isdir(file):
      profile.append(file)
      if len(os.listdir(file))>0:
        aa=[(string.upper(ru(c[a])), icon2)]
      else:
        aa=[(string.upper(ru(c[a])), icon1)]
      profile_name.append(aa[0])
  for a in range(0,len(c)):
    file=Data+c[a]
    if not os.path.isdir(file):
      profile.append(file)
      n=ru(c[a])
      n=n.split(u".")[0]
      aa=[(n, icon3)]
      profile_name.append(aa[0])
  if len(os.listdir(ur(DATA)))==0:
    appuifw.app.body=z=appuifw.Listbox([(ru('нет записей'),ru("читай раздел 'Помощь'"))],help)
    appuifw.app.menu=[(ru('Создать'),new_part),(ru('Помощь'),help),(ru('Выйти'),quit)]
    z.bind(63586,new_part)
  else:
    if profile_name==[]:
      profile_name.append(ru('нет данных'))
    try:
      appuifw.app.body.set_list(profile_name,index)
    except:
      appuifw.app.body=z=appuifw.Listbox(profile_name,menu)
      z.bind(8,del_part)
      z.bind(53,view)
      z.bind(63586,load)
      z.bind(63495,dir1)
      z.bind(63496,dir2)
    mn=[ru('создать'),ru('добавить')]
    if len(title)<2:
      appuifw.app.menu=[(ru('Папка'),((mn[len(title)],new_part),(ru('переименовать'),rename_part),(ru('удалить (с)'),del_part))),(ru('Справка'),((ru('помощь'),help),(ru('о программе'),about))),(ru('Выйти'),quit)]
    else:
      appuifw.app.menu=[(ru('Файл'),((ru('загрузить (ОК)'),load),(ru('добавить'),add),(ru('переименовать'),rename),(ru('см. расширение (5)'),view),(ru('удалить (с)'),delete))),(ru('Справка'),((ru('помощь'),help),(ru('о программе'),about))),(ru('Выйти'),quit)]

  appuifw.app.screen='normal'
  try:
    appuifw.app.title=title[len(title)-1]
  except:
    appuifw.app.title=u'...'
  appuifw.app.set_tabs([u''],menu)
  appuifw.app.exit_key_handler=quit
MENU()
if appuifw.app.full_name().find(u'Python')!=-1:
  lock=e32.Ao_lock()
  os.abort=lock.signal
  lock.wait()
