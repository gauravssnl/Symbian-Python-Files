import switchoff
#switchoff.Shutdown()
#switchoff.Restart()