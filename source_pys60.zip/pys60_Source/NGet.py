import httplib
import time
import appuifw
import urlparse
import e32,os
from graphics import*
import string
import keypress

def ru(x):return x.decode('utf-8')

img=Image.new((176,208))
appuifw.app.screen='full'

def re_raw(tk):
  canvas.blit(img)
  
canvas=appuifw.Canvas(redraw_callback=re_raw)
appuifw.app.body=canvas

############################

def sleep(seconds):
    e32.ao_sleep(float(seconds))

############################
##  sim_key(63555,0) # levaya soft-klavisha
##  sim_key(63555,0)
def sim_key(code1,code2):
  keypress.simulate_key(code1,code2)
  
SCANS={'0':48,'1':49,'2':50,'3':51,'4':52,'5':53,'6':54,'7':55,'8':56,'9':57,'*':42,'#':35,'LeftSoft':63554,'LS':63554,'RightSoft':63555,'RS':63555,'RS':63555,'Select':63557,'S':63557,'Left':63495,'L':63495,'Right':63496,'R':63496,'Up':63497,'U':63497,'Down':63498,'D':63498}


# *** start graf ***

def fas(nu):
  appuifw.app.screen = 'full'
  appuifw.app.body=canvas
  a=0
  while a<208:
    img.line((0,a,176,a),(a+45,0,0))
    a=a+1
  img.rectangle((0,0,176,208),0x00bb00,width=3)
  img.polygon((0,184,60,184,84,208,0,208,0,184),0x00bb00,0x00bb00)
  img.text((14,202),u'\u041c\u0415\u041d\u042e',0xffffff,font=u'alb17b')
  smen(bor=nu)
  re_raw(())
  menu()

nab=(ru(' FGet'),u' \u0421\u0422\u041e\u041f',u' \u041f\u0423\u0421\u041a')

def smen(bor):
 a=4
 while a<28:
  img.polygon((116,208-a,176,208-a,176,208,116-a,208,116,208-a),0x00bb00,0x00bb00)
  img.text((120,226-a),nab[bor],0xffffff,font=u'alb17b')
  e32.ao_sleep(0.05)
  re_raw(())
  a=a+4

def fas2():
  appuifw.app.screen = 'full'
  a=0
  while a<50:
    img.line((0,a,176,a),(a+45,0,0))
    a=a+1
  img.rectangle((0,0,176,50),0x00bb00,width=3)

def fas3():
 pass

def progress():
   fas2()
   siz_f=os.stat('e://'+name)
   siz_f=siz_f[6]
   img.text((5,16),u'%s'%name,0x00ff00)
   img.rectangle((4,30,171,46),0xcc33cc)
   
   if size == None:
    img.polygon((4,30,4,46,4+167,46,4+167,30,4,30),0xcc33cc,0x00ff00)
    img.text((5,28),u'\u0425 \u0417 /'+str(siz_f),0xffffff)

   else:
    if siz_f !=0:
     proc=float(int(size))/float(siz_f)
     if proc==0:
      P=167
      ps=6.21
      cent=100
     else:
      P=167/proc
      ps=6.21/proc
      cent=100/proc

     img.pieslice((10,70,166,160),4.72-ps,4.75,fill=210)
     img.polygon((4,30,4,46,4+P,46,4+P,30,4,30),0xcc33cc,0x00ff00)  
    img.text((5,28),unicode(str(size))+u'/'+str(siz_f),0xffffff)
   re_raw(())

# *** end graf ***


def fac():
 fas(nu=0)
# **start download**



def md():
  global cc
  if cc==0:
    cc=1
    smen(bor=2)
  else:
    cc=0
    smen(bor=1)
    connect()

def md2():
  global cc2
  if cc2==0:
    cc2=1
    smen(bor=2)
    while cc2:
      e32.ao_sleep(0.5)
  else:
    cc2=0
    smen(bor=1)
    razbor()


# *** end down ***

# ** start timer **

def tik(hh,mm,ss):
  fas2()
  img.text([12,30], u"%02d:%02d:%02d" % (hh, mm, ss), 0xffffff, font=u'Acb14')
  global tim_ch,tim_min
  img.text([100,30],tim_ch+u':'+tim_min+u':00', 0xffffff, font=u'Acb14')
  re_raw(())

def timer():
 global ranning
 ranning=1
 while ranning:
  t = time.time() + time.clock()%1
  hh, mm, ss = time.localtime(t)[3:6]
  if tim_ch+tim_min == u"%02d%02d"%(hh,mm) :
   ranning=0
   spis()
  else:
    e32.ao_sleep(1.00)
    tik(hh,mm,ss)

#  ** end timer **
def fget():
  aja='z:\\System\\programs\\apprun.exe'
  smart='e:\\System\\Apps\\fget.app'
  e32.start_exe(aja,smart)


def spis():
  fget()
  sleep(2.01)
  sim_key(SCANS['LS'],0)
  sleep(1.01)
  sim_key(SCANS['D'],0)
  sleep(1.01)
  sim_key(SCANS['LS'],0)
  sleep(2.01)
  sim_key(SCANS['LS'],0)
  sleep(1.01)
  appuifw.app.set_exit()

def t_z():
  fas(nu=0)
  global tim_ch,tim_min
  tim_ch = appuifw.query(u"\u0427\u0430\u0441 (00-23):", "text")
  if len(tim_ch) !=2:
   appuifw.note(u'\u0427\u0430\u0441\u044b \u0432\u0432\u0435\u0434\u0435\u043d\u044b \u043d\u0435 \u0432\u0435\u0440\u043d\u043e','info')
   t_z()
  tim_min = appuifw.query(u"\u041c\u0438\u043d\u0443\u0442\u044b (00-59):","text")
  if len(tim_min) !=2:
   appuifw.note(u'\u041c\u0438\u043d\u0443\u0442\u044b \u0432\u0432\u0435\u0434\u0435\u043d\u044b \u043d\u0435 \u0432\u0435\u0440\u043d\u043e','info')
   t_z() 



app_lock = e32.Ao_lock()


def exit():appuifw.note(ru('Good by!'),'info'),appuifw.app.set_exit()
  
def dem():
  pass

def s_z():
 appuifw.app.body=canvas
 appuifw.app.screen='full'
 menu()

def gur():
  t_z()
  appuifw.note(u"\u0422\u0430\u0439\u043c\u0435\u0440 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d",'conf')
  timer()



def menu():
 appuifw.app.menu =[(ru("Установить таймер"),gur),(u'\u0412\u044b\u0445\u043e\u0434',exit)]

appuifw.app.exit_key_handler = fget
fas(nu=0)


app_lock.wait()