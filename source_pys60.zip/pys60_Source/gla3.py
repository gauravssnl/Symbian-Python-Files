import e32,appuifw,graphics,time

def save(a,f): 
 try:f=open(f+'.gla','w')
 except:return
 f.write(str(a.l)+'\n'+a.i+'\n'+`a.o`)
 f.close()
def load(f):
 a=Ani()
 try:f=open(f+'.gla')
 except:return a
 t=f.read().splitlines()
 f.close()
 a.l,a.i,a.o=int(t[0]),t[1],eval(t[2])
 return a

def glue(a):
 n,a=a[0],a[1:]
 for i in a:
  for j in i.o:
   j[0]+=n.l
   j[1]+=n.l
  n.o+=i.o
  n.l+=i.l
 return n
def rgb(j):
 j[2]+=j[0]<<16
 j[2]+=j[1]<<8
 return j[2]

gc,gp,gl,gt,gq,ge,gr,gtb,gqb,geb,grb,gi=0,1,2,3,4,5,6,7,8,9,10,[
lambda i,j:i.clear(rgb(j[1:])),
lambda i,j:i.point((j[1],j[2]),rgb(j[3:]),width=j[6]),
lambda i,j:i.line((j[1],j[2],j[3],j[4]),rgb(j[5:]),width=j[8]),
lambda i,j:i.polygon((j[1],j[2],j[3],j[4],j[5],j[6]),rgb(j[7:]),rgb(j[10:]),width=j[13]),
lambda i,j:i.polygon((j[1],j[2],j[3],j[4],j[5],j[6],j[7],j[8]),rgb(j[9:]),rgb(j[12:]),width=j[15]),
lambda i,j:i.ellipse((j[1],j[2],j[3],j[4]),rgb(j[5:]),rgb(j[8:]),width=j[11]),
lambda i,j:i.rectangle((j[1],j[2],j[3],j[4]),rgb(j[5:]),rgb(j[8:]),width=j[11]),
lambda i,j:i.polygon((j[1],j[2],j[3],j[4],j[5],j[6]),rgb(j[7:]),width=j[10]),
lambda i,j:i.polygon((j[1],j[2],j[3],j[4],j[5],j[6],j[7],j[8]),rgb(j[9:]),width=j[12]),
lambda i,j:i.ellipse((j[1],j[2],j[3],j[4]),rgb(j[5:]),width=j[8]),
lambda i,j:i.rectangle((j[1],j[2],j[3],j[4]),rgb(j[5:]),width=j[8])]

def draw(a):
 global gi
 o=[]
 for i in range(0,a.l+1):o.append([])
 for i in a.o:
  li=len(i)
  for j in range(i[0],i[1]):
   o[j].append([i[4]])
   ld=len(o[j])-1
   for k in range(5,li):
    if i[2]:
     o[j][ld].append(int(i[k][0]))
     i[k][0]+=i[k][1]
    else:o[j][ld].append(i[k])
 p=App()
 i=t=0
 ld=len(o)
 while p.k:
  if time.clock()-t>=0.055:
   t=time.clock()
   for j in o[i]:gi[j[0]](p.i,j)
   p.show()
   i+=1
   if i==ld:i=0

class Ani:
 def __init__(s,l=0,i=''):s.l,s.i,s.o,s.p=l,i,[],0
 def s(s,a):s.o.append([a[0],a[1],0,0,s.p]+a[2:])
 def d(s,a):s.a=a
 def v(s,a):n,s.a=s.o.append([s.a[0],a[0],1,0,s.p]+s.dt(s.a,a)),a
 def dt(s,a1,a2):
  a,r=float(a2[0]-a1[0]),[]
  for i in range(1,len(a1)):r.append([a1[i],round((a2[i]-a1[i])/a,3)])
  return r

aa=appuifw.app
class App:
 def __init__(s):
  aa.screen,aa.menu,aa.exit_key_handler='full',[],s.q
  s.c=aa.body=appuifw.Canvas()
  s.i,s.k=graphics.Image.new(s.c.size),1
 def show(s):
  s.c.blit(s.i)
  e32.ao_yield()
 def q(s):s.k=0