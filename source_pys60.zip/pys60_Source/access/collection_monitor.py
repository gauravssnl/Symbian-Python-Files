#
# pdis.access.collection_monitor
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Client-side cache for collection contents
"""

from pdis.versioning.et_metadata import get_key, get_id, compile_xpath
from pdis.lib.sleep import sleep

def _filter_by_key(data, key):
    return [item for item in data if get_key(item) == key]

def _filter_by_xpath(data, xpath, namespace_mapping=None):
    x = compile_xpath(xpath, namespace_mapping)
    return [item for item in data if x.evaluate(item)]

class CollectionMonitor:
    """
    Client-side cache for one collection

    A collection monitor maintains an up-to-date result set for a live
    query and issues callbacks when it changes.  It provides for
    fetching of data from the result set using XPath queries.
    """

    def __init__(self, db, name,
                 xpath="", namespace_mapping=None,
                 callback=None,
                 most_recent_only=False):
        """
        Construct a collection monitor.

        The arguments are as follows:
          db - an instance of pdis.access.et_repo_access.RepoAccess.
          name - the collection to monitor.
          xpath - an optional XPath expression.
          namespace_mapping - an optional namespace dictionary.
          callback - an optional callable taking no arguments.
          most_recent_only - a query option.
        """
        self._name = name
        self._callback = callback

        self._data = {}                 # Map IDs to documents.
        self._in_sync = False
        self._query = db.create_live_query(name, self._update,
                                           xpath, namespace_mapping,
                                           most_recent_only=most_recent_only)

    def close(self):
        """
        Terminate the collection monitor's internal live query.
        """
        self._query.terminate()

    def query(self, xpath="", namespace_mapping=None, key=None):
        """
        Fetch items from the result set.

        You can optionally select a subset of the items using
        an XPath expression and/or a key.

        The result is a fresh list of element trees, which are
        themselves not copied, and which you must therefore take
        care not to modify.
        """
        data = self._get_data()

        if key is not None:
            data = _filter_by_key(data, key)

        if xpath:
            data = _filter_by_xpath(data, xpath, namespace_mapping)

        return data

    def _get_data(self):
        while not self._in_sync:
            sleep(0.1)

        return self._data.values()

    def _update(self, items_added, ids_removed, in_sync):
        data = self._data

        for id in ids_removed:
            try:
                del data[id]
            except KeyError:
                pass

        for item in items_added:
            id = get_id(item)
            data[id] = item

        if in_sync:
            self._in_sync = True
            if self._callback:
                self._callback()
