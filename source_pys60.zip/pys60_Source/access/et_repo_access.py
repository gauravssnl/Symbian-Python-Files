#
# pdis.access.et_repo_access
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
ElementTree-based client library for PDIS repository access

This library provides the same API as repo_access.py, except that XML
documents are represented as element structures instead of as strings.
See repo_access.py for available methods and further documentation.
"""

from pdis.lib.element import XML, Element
from pdis.versioning.et_metadata import *
from pdis.access import repo_access
from pdis.access.repo_access import Fault

class RepoAccess(repo_access.RepoAccess):
    """
    Client side of a communication session with a repository
    """

    def __init__(self, *args, **keys):
        repo_access.RepoAccess.__init__(self, *args, **keys)
        self.types = []               # Optimization for store_type().

    def get(self, collection, id):
        """
        Return the named object version or None.
        """
        result = repo_access.RepoAccess.get(self, collection, id)
        if result:
            return XML(result)
        else:
            return None

    def get_mrca(self, collection, ids):
        """
        Attempt to return the most recent common ancestor of the specified versions.
        """
        result = repo_access.RepoAccess.get_mrca(self, collection, ids)
        if result:
            return XML(result)
        else:
            return None

    def create(self, collection, item, parent_items=(), key=None):
        """
        Store a new object version.

        This is identical to repo_access.RepoAccess.create(), except
        for the representations of the new version and the parent
        versions.  Any metadata attributes (attributes on the root
        element in the "pdis" namespace) included with the new version
        are ignored.  For the parent versions, everything _other_ than
        the metadata attributes is ignored.
        """
        parent_item_strings = map(metadata_to_string, parent_items)
        item_string = data_to_string(item)
        repo_access.RepoAccess.create(
            self, collection, item_string, parent_item_strings, key)

    def modify(self, collection, item):
        """
        Create a version to supersede an existing one.

        The given document is assumed to be an edited copy of a
        previous version of the object, with the old metadata intact.
        This is a convenience function that simply calls create(),
        passing in the given document as both the new item and the
        sole parent item.
        """
        self.create(collection, item, (item,))

    def create_and_update_header(self, collection, item, parent_items=(),
                                 key=None):
        """
        Store a new object version.

        This is like create(), except that the metadata for the new
        item is added to the document that was passed in.
        """
        parent_item_strings = map(metadata_to_string, parent_items)
        item_string = data_to_string(item)
        result_string = repo_access.RepoAccess.create_and_get_header(
            self, collection, item_string, parent_item_strings, key)

        result = XML(result_string)
        copy_metadata(result, item)

    def modify_and_update_header(self, collection, item):
        """
        Create a version to supersede an existing one.

        This is like modify(), except that the metadata in the
        document passed in is updated.
        """
        self.create_and_update_header(collection, item, (item,))

    def kill(self, collection, item):
        """
        Mark a version as no longer current.
        """
        item_string = metadata_to_string(item)
        repo_access.RepoAccess.kill(self, collection, item_string)

    def query(self, collection, xpath="", namespace_mapping=None,
              key=None, ids_only=None, most_recent_only=None):
        """
        Return the current items matching the specified XPath query.

        This is identical to repo_access.RepoAccess.query(), except for
        the representation of the returned items (when ids_only is False).
        """
        if ids_only is None:
            ids_only = False

        results = repo_access.RepoAccess.query(
            self, collection, xpath, namespace_mapping,
            key, ids_only, most_recent_only)
        if ids_only:
            return results
        else:
            return map(XML, results)

    def create_live_query(self, collection, callback,
                          xpath="", namespace_mapping=None,
                          key=None, ids_only=None, most_recent_only=None):
        """
        Start a live query.

        This is identical to repo_access.RepoAccess.create_live_query(),
        except for the representation of the items passed back in callbacks.
        """
        return _LiveQuery(self, collection, callback,
                          xpath, namespace_mapping,
                          key, ids_only, most_recent_only)

    def get_types(self, collection):
        type_records = self.query(collection, "/pdis:type", key="")
        types = [record.text for record in type_records]
        types = _canonicalize(types)
        self.types = types
        return types

    def store_type(self, collection, type):
        if type not in self.types:
            if type not in self.get_types(collection):
                self.types.append(type)
                new = Element(qualify("type"))
                new.text = type
                self.create(collection, new, key="")

    def clear_type(self, collection, type):
        xpath = '/pdis:type[text() = "%s"]' % type
        for old in self.query(collection, xpath, key=""):
            self.kill(collection, old)
        while type in self.types:
            self.types.remove(type)

class _LiveQuery(repo_access._LiveQuery):
    """
    Live query handle returned by create_live_query()
    """

    def results(self, items, results_complete):
        """Internal callback"""
        if not self.terminated:
            if not self.ids_only[0]:
                items = map(XML, items)

            self.callback(items, [], results_complete)

    def update(self, items_added, items_removed):
        """Internal callback"""
        if not self.terminated:
            if not self.ids_only[0]:
                items_added = map(XML, items_added)

            if not self.ids_only[1]:
                items_removed = map(XML, items_removed)

            self.callback(items_added, items_removed, True)

def _canonicalize(list):
    table = {}
    for x in list:
        table[x] = None
    result = table.keys()
    result.sort()
    return result
