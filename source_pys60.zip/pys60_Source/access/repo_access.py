#
# pdis.access.repo_access
#
# Copyright 2003-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Client library for PDIS repository access

This is the basic client library, providing an API in which XML
documents are passed as strings.  It is especially handy for
experimentation and testing, but you may find et_repo_access.py more
convenient for real work.  In any case, the documentation strings in
this file are the right place to start reading.
"""

import sys

from pdis.lib import logging
from pdis.lib.best_threading import allocate_lock
from pdis.pipe.pipe import connect_client
from pdis.pipe.message_pipe_exceptions import *

_mutex = allocate_lock()
_live_query_counter = 0

def _allocate_query_id():
    _mutex.acquire()
    try:
        global _live_query_counter
        _live_query_counter += 1
        return str(_live_query_counter)
    finally:
        _mutex.release()

class RepoAccess:
    """
    Client side of a communication session with a repository

    All methods can raise exceptions when network or server-side
    errors occur.  Server-side errors in synchronous methods (those
    that return results) raise a Fault.  Such errors include attempts
    to access nonexistent collections and XPath-related errors, as
    well as abnormal error conditions.  Attempts to access nonexistent
    collections in asynchronous methods are ignored, while other
    server-side errors in asynchronous methods generally result in the
    session being closed, as do network errors, naturally.  Attempting
    to use a closed session raises SessionClosed.
    """

    def __init__(self, address=None,
                 host="localhost", port=35800,
                 listener=None, client_name=None, agent=False,
                 most_recent_only=False):
        """
        Start a session.

        A ConnectionFailed exception is raised if the session cannot
        be established.

        The most general way to specify the repository's address is
        with the address parameter, which can, for instance, take the
        form ("tcp", host, port) or ("bt", mac, channel).  The default
        is ("tcp", "localhost", 35800).  For TCP, one can alternatively
        simply specify values for the host and/or port parameters.

        The optional client name is an arbitrary informational string
        to be included in listings of incoming connections to a
        repository.  The agent flag can be set to True to cause the
        repository to give low priority to requests from this client.

        The most_recent_only flag is used to change the default
        (normally False) for the option of the same name in the
        various query methods.  Using it is not recommended.

        The optional listener parameter is used to specify an object
        that is to receive certain callbacks from the repository, not
        including live query callbacks.  The listener can define any
        of the following methods, all of which are optional.  The
        methods come in sets, and there are two alternative interfaces
        for monitoring what collections exist:

            collections_available(list)
            collection_added(name)
            collection_removed(name)

            collection_available(name)
            collection_removed(name)

            connected(repo_id, count)
            disconnected(repo_id, count)

            sync_dialog_state_changed(info)
        """
        if address is None:
            address = ("tcp", host, port)

        self.most_recent_only_default = most_recent_only
        self.listener = listener
        self.repo_id = None
        self.repo_name = None
        self.live_queries = {}
        self.pipe = connect_client(address, target=self)

        greeting = {}
        if client_name:
            greeting["client"] = client_name
        if agent:
            greeting["agent"] = True
        greeting["platform"] = sys.platform
        self.send("hello", greeting)

        if listener:
            self.send("enable_notifications", True)

    def close(self, timeout=10):
        """
        End the session.

        It is an error to call any other method after close(), but
        close() may be called more than once.
        """
        self.pipe.close(timeout=timeout)
        for live_query in self.list_live_queries():
            live_query.terminate()

    def flush(self):
        """
        Execute a no-op request-reply.
        """
        self.call("flush")

    #
    # Specialized access modes
    #

    def open_collection(self, name, only_if_exists=True):
        """
        Return a handle for an existing or newly created collection.

        This lets you replace

            result1 = repo.method1(collection_name, ...)
            result2 = repo.method2(collection_name, ...)

        with

            db = repo.open_collection(collection_name)
            result1 = db.method1(...)
            result2 = db.method2(...)
        """
        if only_if_exists:
            if not self.collection_exists(name):
                return None
        else:
            self.create_collection(name)

        return _Collection(self, name)

    def open_remote(self, repo_id):
        """
        Return a convenient handle for working with a remote repository.

        This lets you replace

            result1 = repo.remote(ID, "method1", ...)
            result2 = repo.remote(ID, "method2", ...)

        with

            remote = repo.open_remote(ID)
            result1 = remote.method1(...)
            result2 = remote.method2(...)
        """
        return _Proxy(self, repo_id)

    #
    # Collections
    #

    def list_collections(self):
        """
        Return a list of the names of the available collections.
        """
        return self.call("list_collections")

    def create_collection(self, name):
        """
        Create an empty collection if none exists with the given name.

        The name can be any Unicode string.
        """
        self.send("create_collection", name)

    def remove_collection(self, name):
        """
        Remove the collection if it exists.
        """
        self.send("remove_collection", name)

    def collection_exists(self, name):
        """
        Return True if the collection exists.
        """
        return self.call("collection_exists", name)

    #
    # Basic access
    #

    def get(self, collection, id):
        """
        Return the named object version as an XML document.

        If the version is no longer present in the repository,
        return None.  This method is useful only rarely, mainly
        in conjunction with ids_only queries.
        """
        result = self.call("get", collection, id)
        return result or None

    def create(self, collection, item_data, parent_headers=(), key=None):
        """
        Store a new object version.

        If you omit all optional arguments, this will create an
        initial version of a new object with a probabilistically
        unique key (object ID).  You can optionally specify the key
        using a keyword argument (perhaps in order to store a number
        of items under the same, semantically meaningful key).

        This method can also be used to modify an existing object, or
        more specifically, to create a new version to supersede an
        existing parent version, or even several parent versions (to
        resolve a conflict).  If both a key and one or more parent
        versions are specified, the key is ignored.  For the common
        case of one parent, using the modify() method may be more
        convenient.

        The new version and any parent versions are all specified as
        XML documents.  Any metadata attributes (attributes on the
        root element in the "pdis" namespace) included with the new
        version are ignored.  For the parent versions, everything
        _other_ than the metadata attributes is ignored.

        This method sends the creation command to the repository as a
        one-way message.  If you need to know the values of any of the
        metadata attributes of the created item, see create_and_get_header().
        """
        if parent_headers:
            self.send("modify_noreply", collection, item_data, parent_headers)
        elif key is not None:
            self.send("create_noreply", collection, item_data, key)
        else:
            self.send("create_noreply", collection, item_data)

    def modify(self, collection, item):
        """
        Create a version to supersede an existing one.

        The given document is assumed to be an edited copy of a
        previous version of the object, with the old metadata intact.
        """
        self.send("modify_noreply", collection, item, (item,))

    def create_and_get_header(self, collection, item_data, parent_headers=(),
                              key=None):
        """
        Store a new object version.

        This is similar to create(), except that it returns the new
        version header -- that is, the new item with everything other
        than the metadata attributes removed.
        """
        if parent_headers:
            return self.call("modify", collection, item_data, parent_headers)
        elif key is not None:
            return self.call("create", collection, item_data, key)
        else:
            return self.call("create", collection, item_data)

    def modify_and_get_header(self, collection, item):
        """
        Create a version to supersede an existing one.

        This is similar to modify(), except that it returns the header
        for the new version.
        """
        return self.call("modify", collection, item, (item,))

    def kill(self, collection, item_header):
        """
        Mark a version as no longer current.

        This is actually done by creating a "tombstone" version to
        supersede the given one.  Only the metadata attributes of the
        provided document are examined.
        """
        self.send("kill", collection, item_header)

    #
    # Querying
    #

    def query(self, collection, xpath="", namespace_mapping=None,
              key=None, ids_only=None, most_recent_only=None):
        """
        Return the current items matching the specified XPath query.

        If the XPath expression is the empty string, the query matches
        all current items in the collection other than tombstones.
        Tombstones never match any query.  Providing an XPath
        specifying at least the top-level tag ("/whatever") is
        recommended, to avoid unexpectedly matching items stored in
        the collection by other software (such as items describing the
        collection itself stored under the empty key).

        The namespace mapping associates prefixes appearing in the XPath
        expression with URIs.  The prefix "pdis" is defined implicitly.

        The "key", "ids_only" and "most_recent_only" parameters are
        intended to be specified using keyword arguments.

        The query can be restricted to a single key by specifying a
        value for "key".  It is still possible for several results to
        be returned, if there are several current versions.

        How the items are returned is determined by the value of
        "ids_only", which defaults to False:
            True - list of item IDs.
            False - list of XML documents.

        If the value of "most_recent_only" is True, only one version
        will be returned for each key.  If several current versions
        match the XPath, this will be the one that comes latest in
        standard total order (based on logical clock values).  The
        default is normally False, but this can be changed by passing
        a value for "most_recent_only" to the RepoAccess constructor.
        Most queries should generally use the normal default value of
        False and tolerate multiple results with the same key.  (There
        is often no reason to look at the key at all.)
        """
        if most_recent_only is None:
            most_recent_only = self.most_recent_only_default

        options = {}
        if namespace_mapping:
            options["namespace_mapping"] = namespace_mapping
        if key is not None:
            options["keys"] = [key]
        if ids_only:
            options["ids_only"] = True
        if most_recent_only:
            options["most_recent_only"] = True

        return self.call("query", collection, xpath, options)

    def count(self, *args, **keys):
        """
        Return the number of keys for which some current version satisfies the query.

        This is identical to count_objects().
        """
        return self.count_objects(*args, **keys)

    def count_objects(self, *args, **keys):
        """
        Return the number of keys for which some current version satisfies the query.
        """
        objects, versions = self.count_objects_and_versions(*args, **keys)
        return objects

    def count_versions(self, *args, **keys):
        """
        Return the number of current object versions that satisfy the query.
        """
        objects, versions = self.count_objects_and_versions(*args, **keys)
        return versions

    def count_objects_and_versions(self, collection, xpath="", namespace_mapping=None,
                                   key=None, most_recent_only=None):
        """
        Return a tuple of the number of objects/versions that satisfy the query.
        """
        if most_recent_only is None:
            most_recent_only = self.most_recent_only_default

        options = {}
        if namespace_mapping:
            options["namespace_mapping"] = namespace_mapping
        if key is not None:
            options["keys"] = [key]
        if most_recent_only:
            options["most_recent_only"] = True

        objects, versions = self.call("count", collection, xpath, options)
        return objects, versions

    def create_live_query(self, collection, callback,
                          xpath="", namespace_mapping=None,
                          key=None, ids_only=None, most_recent_only=None):
        """
        Start a live query.

        This initiates a query identical to that performed by query(),
        but it returns only a live query handle and then proceeds to
        generate a series of callbacks with the following signature:

            callback(self, items_added, items_removed, results_complete)

        Any number of live queries can be active at the same time.

        A live query enables the client to incrementally track a set
        of object versions corresponding to the query.  This set
        starts out empty and is then updated in accordance with each
        callback by possibly adding some items and possibly removing
        some.

        A live query executes in two phases.  First, the matching
        items are returned through a series of callbacks, possibly
        including corrections due to concurrent changes.  Then, when
        the client has been informed of the complete set of matching
        items, the query remains active in order to notify the client
        of changes to the set.

        Each callback specifies items to add to and remove from the
        current set.  Items are provided as either XML documents or
        just IDs, depending on the value specified for ids_only in the
        call to create_live_query().  Unlike in ordinary queries, the
        value of ids_only for a live query is a pair of booleans
        referring to items added and items removed, respectively.  The
        default is (False, True); i.e., items added are returned as
        XML documents, while items removed are returned as IDs.

        For backward compatibility, the value of ids_only can also be
        a single boolean, referring to items added.  In this case,
        items removed are always returned as IDs.

        The results_complete flag signals that the current set will be
        identical to the matching set of items in the repository after
        the callback has been processed.  The current set will track
        the matching set from that point on, and the results_complete
        flag will be true in all subsequent callbacks.

        It is recommended that each notification be treated as a unit
        in updating displayed information.  For example, if new items
        are provided only as IDs, the client should generally fetch
        the corresponding data from the server, if necessary, before
        wiping out-of-date items from the screen.
        """
        # Although the underlying protocol distinguishes between
        # live_query_results() notifications and live_query_update()
        # notifications, we fold these two cases together here, because
        # they are typically handled identically.
        return _LiveQuery(self, collection, callback,
                          xpath, namespace_mapping,
                          key, ids_only, most_recent_only)

    def list_live_queries(self):
        """
        Return a list of the active live query handles.
        """
        return self.live_queries.values()

    #
    # Repository info
    #

    def get_repo_id(self):
        """
        Return the repository ID (an opaque, globally unique string).
        """
        if self.repo_id is None:
            self.repo_id = self.call("get_repo_id")
        return self.repo_id

    def get_repo_name(self):
        """
        Return the repository's informal name.

        The value is cached by the client library and may not be up to
        date if somebody else changes it.
        """
        if not self.repo_name:
            self.repo_name = self.call("get_repo_name")
        return self.repo_name

    def set_repo_name(self, name):
        """
        Set the repository's informal name.

        The name can be any Unicode string.
        """
        self.call("set_repo_name", name)
        self.repo_name = None

    #
    # Sync management
    #

    def connect(self, address):
        """
        Set up a sync pipe from this repository to the one at the specified address.

        Returns the pipe ID (a positive integer) if the connection
        succeeds or a suitable sync pipe already exists.  Returns None
        otherwise.
        """
        pipe_id = self.call("connect", address)
        return pipe_id or None

    def disconnect(self, pipe_id):
        """
        Shut down a sync pipe.
        """
        return self.call("disconnect", pipe_id)

    def export_collection(self, collection, pipe_id):
        """
        Advertise a collection on a sync pipe and enable access to it.

        Requests by the remote repository to establish a sync dialog
        for this collection will be accepted on this sync pipe for the
        lifetime of the pipe.
        """
        return self.call("export_collection", collection, pipe_id)

    def start_sync(self, pipe_id, 
                   local_collection, remote_collection,
                   xpath="", namespace_mapping={}):
        """
        Request establishment of a sync dialog on the specified pipe.
        """
        return self.call("start_sync", pipe_id,
                         local_collection, remote_collection,
                         xpath, namespace_mapping)

    def stop_sync(self, pipe_id, 
                  local_collection, remote_collection,
                  xpath="", namespace_mapping={}):
        """
        Request termination of a sync dialog on the specified pipe.
        """
        return self.call("stop_sync", pipe_id,
                         local_collection, remote_collection,
                         xpath, namespace_mapping)

    def get_neighbors(self):
        """
        Return the IDs of all repositories to which this one has sync pipes open.

        If several sync pipes are open to the same repository, the ID
        will be listed only once.  The directly connected repository
        may or may not be listed, depending on whether it has a sync
        pipe open to itself.
        """
        neighbors = self.call("get_neighbors").keys()
        neighbors.sort()
        return neighbors

    def pick_pipe(self, repo_id):
        """
        Return the ID of a sync pipe connected to the specified repository.

        An attempt is made to select the pipe with the best bandwidth
        if more than one is open to the same repository.  Returns None
        if no sync pipe is found.
        """
        pipe_id = self.call("pick_pipe", repo_id)
        return pipe_id or None

    def get_pipe_info(self, pipe_id):
        """
        Return a dictionary containing information about the specified pipe.
        """
        for info in self.call("list_pipes", {"id": pipe_id}):
            return info
        return None

    def list_pipes(self):
        """
        Return a list of dictionaries witn information about open sync pipes.
        """
        return self.call("list_pipes", {"repo-to-repo?": True})

    def list_dialogs(self, filter={}):
        """
        Return a list of dictionaries with information about open sync dialogs.

        There may be zero or more sync dialogs open on each sync pipe.
        """
        return self.call("list_dialogs", filter)

    #
    # Advanced methods
    #

    def get_all_ids(self, collection):
        """
        Return a list of all IDs present in the collection.

        In conjunction with get(), this provides a way to access the
        complete contents of a collection, including superseded versions.
        """
        return self.call("get_all_ids", collection)

    def get_mrca(self, collection, ids):
        """
        Attempt to return the most recent common ancestor of the specified versions.

        If the most recent common ancestor is not identifiable or not
        available, return None.
        """
        result = self.call("get_mrca", collection, ids)
        return result or None

    def get_file(self, collection, file_id):
        """
        Return either the file contents or None.

        The file must be available within the directory tree mapped to
        the specified collection in __exports__.

        The file ID is the MD5 hash of the contents.
        """
        results = self.call2("get_file", (collection, file_id))
        if results[0]:
            return results[1]
        else:
            return None

    def get_remote_file(self, neighbor, collection, file_id):
        """
        Get a file from a remote repository.

        The return value will be either the file contents or None.

        The remote repository is specified by its ID.  It may be the
        repository to which we are connected or a repository directly
        connnected to it.

        The file must be available within the directory tree mapped to
        the specified collection in __exports__ at the remote repository.

        The file ID is the MD5 hash of the contents.
        """
        results = self.remote2(neighbor, "get_file", (collection, file_id))
        if results[0]:
            return results[1]
        else:
            return None

    def remote(self, neighbor, method, *params):
        """
        Invoke a method at a remote repository.

        The remote repository is specified by its ID.  It may be the
        repository to which we are connected or a repository directly
        connnected to it.

        The method may be either synchronous (normally invoked with
        call()) or asynchronous (normally invoked with send()).  If
        it is an asynchronous method, the return value is True.
        """
        result_list = self.remote2(neighbor, method, params)
        return result_list[0]

    def remote2(self, neighbor, method, params, *attachments):
        if neighbor == self.get_repo_id():
            return self.call2(method, params, *attachments)
        else:
            augmented_params = [neighbor, method]
            augmented_params.extend(params)
            return self.call2("remote", augmented_params, *attachments)

    def acquire(self, name):
        """
        Attempt to acquire the named lock.

        Returns True on success, or False if the lock is already held
        by someone else.
        """
        return self.call("acquire", name)

    def release(self, name):
        """
        Release the named lock.
        """
        return self.call("release", name)

    #
    # Deprecated methods
    #

    def query_object(self, collection, key,
                     xpath="", namespace_mapping=None,
                     ids_only=None, most_recent_only=None):
        """
        Return the current items representing versions of the specified object.

        This method is deprecated.  Use query() with the keyword
        parameter "key" instead.

        This function may return more than one item if concurrent
        editing has resulted in the creation of multiple, conflicting
        current versions of the object.  Tombstones are not returned.

        The result list is additionally filtered by the specified
        XPath query, which can be useful when an object ID maps into
        many documents.  The prefix "pdis" is implicitly included in
        the namespace mapping.

        How the items are returned is determined by the value of "ids_only",
        typically specified as a keyword parameter:
            True - list of item IDs.
            False - list of XML documents.
        """
        return self.query(collection, xpath, namespace_mapping,
                          key, ids_only, most_recent_only)

    #
    # Low-level methods
    #

    def send(self, method, *params):
        """
        Invoke an asynchronous method of the repository.
        """
        self.pipe.send(method, *params)

    def call(self, method, *params):
        """
        Invoke a synchronous method of the repository.
        """
        return self.pipe.call(method, *params)

    def call2(self, method, params, *attachments):
        return self.pipe.call2(method, params, *attachments)

    #
    # Internals
    #

    def startup(pipe, self):
        """Internal message pipe callback"""
        pass

    def shutdown(pipe, self):
        """Internal message pipe callback"""
        self.close(timeout=0)

    def receive(self, pipe, msgno, method, params, *attachments):
        """Internal message pipe callback"""
        try:
            if method.startswith("live_query_"):
                if not params:
                    raise ProtocolError
                self._dispatch_live_query_callback(method, params[-1], params[:-1])
            else:
                self._dispatch_repo_callback(method, params, *attachments)
        except:
            logging.log_exception("Exception in callback for incoming message.")

    def _dispatch_live_query_callback(self, method, query_id, params):
        live_query = self.live_queries.get(query_id)
        if live_query:
            if method == "live_query_results":
                live_query.results(*params)
            elif method == "live_query_update":
                live_query.update(*params)
            else:
                raise ProtocolError

    def _dispatch_repo_callback(self, method, params, *attachments):
        if method == "hello":
            pass
        elif method == "collections_available":
            self._invoke_repo_callback("collections_available", *params)
            for collection in params[0]:
                self._invoke_repo_callback("collection_available", collection)
        elif method == "collection_added":
            self._invoke_repo_callback("collection_added", *params)
            self._invoke_repo_callback("collection_available", *params)
        elif method == "collection_removed":
            self._invoke_repo_callback("collection_removed", *params)
        elif method in ("connected", "disconnected", "sync_dialog_state_changed"):
            self._invoke_repo_callback(method, *params)
        else:
            raise ProtocolError

    def _invoke_repo_callback(self, method, *args):
        if self.listener and hasattr(self.listener, method):
            getattr(self.listener, method)(*args)

class _Collection:
    """
    Handle returned by RepoAccess.open_collection()

    This class provides an alternative to invoking RepoAccess methods
    directly and passing in a collection name.  It is only for convenience
    and does not provide any new functionality relative to RepoAccess.

    See the corresponding methods in RepoAccess for documentation.
    """

    def __init__(self, repo, collection):
        self.repo = repo
        self.collection = collection

    def __getattr__(self, method_name):
        method = getattr(self.repo, method_name)
        collection = self.collection
        return lambda *args, **keys: method(collection, *args, **keys)

class _Proxy:
    """
    Handle returned by RepoAccess.open_remote()
    """

    def __init__(self, repo, neighbor):
        self.repo = repo
        self.neighbor = neighbor

    def __getattr__(self, method_name):
        getattr(self.repo, method_name) # Raise AttributeError if undefined.
        return lambda *args: self.repo.remote(self.neighbor, method_name, *args)

class _LiveQuery:
    """
    Live query handle returned by create_live_query()
    """

    def __init__(self, repo, collection, callback,
                 xpath="", namespace_mapping=None,
                 key=None, ids_only=None, most_recent_only=None):
        if namespace_mapping is None:
            namespace_mapping = {}

        if ids_only is None:
            ids_only = (False, True)
        elif isinstance(ids_only, type(True)):
            ids_only = (ids_only, True)
        else:
            assert len(ids_only) == 2

        if most_recent_only is None:
            most_recent_only = repo.most_recent_only_default

        self.repo = repo
        self.collection = collection
        self.callback = callback        # Used in et_repo_access.
        self.xpath = xpath
        self.namespace_mapping = namespace_mapping
        self.key = key
        self.ids_only = ids_only        # Used in et_repo_access.
        self.most_recent_only = most_recent_only

        self.terminated = False

        self.query_id = _allocate_query_id()
        self.repo.live_queries[self.query_id] = self

        options = {}
        if namespace_mapping:
            options["namespace_mapping"] = namespace_mapping
        if ids_only != (False, True):
            options["ids_only"] = ids_only
        if key is not None:
            options["keys"] = [key]
        if most_recent_only:
            options["most_recent_only"] = True

        self.repo.send("start_live_query", collection, xpath, options,
                       self.query_id)

    def terminate(self):
        """
        Terminate the live query.

        Callbacks will be cut off immediately.

        This method does not raise exceptions.  It may be called
        more than once.
        """
        if not self.terminated:
            self.terminated = True
            del self.repo.live_queries[self.query_id]
            try:
                self.repo.send("terminate_live_query", self.query_id)
            except SessionClosed:
                pass

    def results(self, items, results_complete):
        """Internal callback"""
        if not self.terminated:
            self.callback(items, [], results_complete)

    def update(self, items_added, items_removed):
        """Internal callback"""
        if not self.terminated:
            self.callback(items_added, items_removed, True)
