#
# pdis.access.pdis_url
#
# Copyright 2003-2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#
# Some code fragments below have been derived from Python's urlparse.py.
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Utility functions for working with pdis URLs

These always take the form of an http URL, even if the protocol name
is something else (for which the standard might specify a different
syntax).  Parameters, queries, and fragments are not supported.

The protocol name is interpreted as follows:

  * "pdis" - default protocol.  This is the only protocol name that
    might coexist with standard URLs.  It actually refers to our
    "tcp" transport, a default host of "localhost", and a default
    port of 35800.

  * "repoid" - here the host is interpreted as a repository ID.
    Specifying a port is not permitted.

  * <other> - here the protocol name refers to a message pipe
    transport.  The host field, if not empty, is the first
    parameter of the address tuple.  The port, if specified,
    is the second parameter (represented as an integer).

In all cases, the relative path is interpreted as a collection name.
"""

from urllib import quote, unquote
from os.path import basename

pdis_port = 35800

# Characters valid in scheme names
scheme_chars = ('abcdefghijklmnopqrstuvwxyz'
                'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                '0123456789'
                '+-.')

def urlsplit(url, scheme=''):
    """
    Parse a URL into 3 components: <scheme>://<netloc>/<path>

    Return a 3-tuple: (scheme, netloc, path).
    Note that we don't break the components up in smaller bits
    (e.g. netloc is a single string) and we don't expand % escapes.
    """
    # The following code has been derived from urlsplit()
    # in urlparse.py in Python 2.4a3.
    netloc = ''
    i = url.find(':')
    if i > 0:
        for c in url[:i]:
            if c not in scheme_chars:
                break
        else:
            scheme, url = url[:i].lower(), url[i+1:]
    if url[:2] == '//':
        i = url.find('/', 2)
        if i < 0:
            i = len(url)
        netloc, url = url[2:i], url[i:]
    return scheme, netloc, url

def parse_pdis_url(url):
    """
    Return ((transport[, host[, port]]), path) given a URL.

    A missing path is returned as None.  The port is returned as an
    integer if it is specified and it has the form of an integer.

    The transport is assumed to be "pdis" if it is omitted in the URL.
    However, the address resulting from a "pdis" URL is always translated
    before being returned, such that the returned transport is "tcp", the
    returned host defaults to "localhost", and the returned port defaults
    to 35800.
    """

    # Split the URL into components.
    transport, location, path = urlsplit(url, scheme = "pdis")

    # Split locations of the form "host:port".
    i = location.rfind(":")
    if i == -1:
        host = location
        port = None
    else:
        host = location[:i]
        port = location[i + 1:]
        if port.isdigit():
            port = int(port)

    # Make the path relative.
    path = unquote(path).lstrip('/')
    if not path:
        path = None

    # Translate "pdis" URLs.
    if transport == "pdis":
        transport = "tcp"
        if not host: host = "localhost"
        if port is None: port = pdis_port

    # Assemble the address.
    address = [transport]
    if host or port is not None:
        address.append(host)
    if port is not None:
        address.append(port)
    address = tuple(address)

    return (address, path)

def format_pdis_url(address, path = None):
    """
    Return a URL of the form "<transport>:[//<host>[:<port>]][/<path>]".

    The host and port are the second and third elements of the address tuple,
    whatever they are.  They need not actually represent a host name and a
    port number.  The path is normally a PDIS collection name.
    """
    assert isinstance(address, tuple)
    address = map(str, address)

    transport = address.pop(0)
    for c in transport:
        if c not in scheme_chars:
            raise TypeError, "Bad transport name."
    parts = ["%s:" % transport]

    if address:
        host = address.pop(0)
        if '/' in host:
            raise TypeError, "Bad host name."
        parts.append("//%s" % host)

    if address:
        port = address.pop(0)
        if '/' in port or ':' in port:
            raise TypeError, "Bad port name."
        parts.append(":%s" % port)

    if address:
        raise TypeError, "Too many components in address."

    if path is not None:
        parts.append("/%s" % quote(path))

    return "".join(parts)
