__doc__='Power mod by Atrant of Lite filemanager by Shrim'
__name__='PowLite FM'
class manager:
    def ru(s,x):
        return x.decode('utf-8')
    def ur(s,x):
        return x.encode('utf-8')
    def __init__(s):
        import appuifw,os,e32
        s.appuifw, s.os, s.e32 = appuifw,os,e32
        s.lock = s.e32.Ao_lock()
        s.curdir = None

    def AskUser(s, path = None, find = 'file', ext = []):
        #if s.curdir != None: s.appuifw.note(s.curdir,'info')
        if path == None and s.curdir != None and s.curdir != u'root': 
            path = s.os.path.split(s.curdir)[0]
            if path[-1] != '\\': path += '\\'
        s.oldscreen = s.appuifw.app.screen
        s.oldbody = s.appuifw.app.body
        s.oldexitkeyhandler = s.appuifw.app.exit_key_handler
        s.oldmenu = s.appuifw.app.menu
        s.oldtitle = s.appuifw.app.title
        try: 
            s.oldfocus = s.appuifw.app.body.focus
            s.appuifw.app.body.focus = 0
        except: pass
        if find == 'dir': s.appuifw.app.title = s.ru("Выбор папки")
        else: s.appuifw.app.title = s.ru("Выбор файла")

        s.find, s.ext = find, ext

        s.appuifw.app.screen = 'normal'
        s.appuifw.app.body = s.body = s.appuifw.Listbox(s.e32.drive_list())
        s.appuifw.app.exit_key_handler = s.exit
        s.menuChoose = (s.ru("Выбрать"),s.choose_item)
        s.menuOpen = (s.ru("Открыть"),s.browse_forward)
        s.menuBack = (s.ru("Назад"),s.browse_back)

        s.curlist = s.e32.drive_list()

        if not path: s.root()
        else:
            try: 
                path = s.ru(path)
            except: 
                pass
            s.curdir = s.os.path.normpath(path)
            if s.curdir[-1] != '\\':
                s.curdir = s.curdir + '\\'
            if s.os.path.exists(s.ur(path)) and s.os.path.isdir(s.ur(path)):
                s.listdir()
            else: s.root()

        s.body.bind(63495,s.browse_back)
        s.body.bind(63557,s.browse_forward)
        s.body.bind(63496,s.choose_item)
        s.body.bind(63497,lambda: s.construct_menu(-1))
        s.body.bind(63498,lambda: s.construct_menu(1))
        s.construct_menu(0)

        s.lock.wait()

        s.body.bind(63495,None)
        s.body.bind(63557,None)
        s.body.bind(63496,None)
        s.body.bind(63497,None)
        s.body.bind(63498,None)
        s.appuifw.app.body = s.oldbody
        s.appuifw.app.screen = s.oldscreen
        s.appuifw.app.exit_key_handler = s.oldexitkeyhandler
        s.appuifw.app.menu = s.oldmenu
        s.appuifw.app.title = s.oldtitle
        try: s.appuifw.app.body.focus = s.oldfocus
        except: pass
        tmp = None
        if s.choice_made: tmp = s.curdir
        if s.curdir != u'root':
            if s.find == 'file':
                s.curdir = s.os.path.split(s.curdir)[0]
            if s.curdir[-1] != '\\': s.curdir += '\\'
        #try:s.appuifw.note(tmp,'info')
        #except: pass
        return tmp

    def root(s):
        s.body.set_list(s.e32.drive_list())
        s.curdir = u'root'
        s.curlist = s.e32.drive_list()
        s.construct_menu(0)

    def construct_menu(s, add):
        def _set(x):
            s.appuifw.app.menu = x

        i = s.body.current() + add
        if i == -1: i = len(s.curlist) - 1
        elif i == len(s.curlist): i = 0
        if s.curdir == u'root':
            if s.find == 'dir':
                _set([s.menuChoose,s.menuOpen])
            else: _set([s.menuOpen])
            return
        elif i == 0: 
            _set([s.menuChoose])
            return
        else: 
            path = s.curdir + s.curlist[i]
        if not s.os.path.exists(s.ur(path)): # убираем квадратные скобки вокруг папки
            path = s.curdir + s.curlist[i][1:-1]
        if s.os.path.isdir(s.ur(path)):
            if s.find == 'dir':
                _set([s.menuChoose,s.menuOpen,s.menuBack]) 
            else:
                _set([s.menuOpen,s.menuBack])
        else:
            _set([s.menuChoose,s.menuBack])

    def listdir(s):
        templist, files, folders, resultlist = s.os.listdir(s.ur(s.curdir)), [], [], [u'<<<']
        if templist:
            for item in templist:
                if s.os.path.isfile(s.ur(s.curdir) + item):
                    if s.find == 'file':
                        if len(s.ext)>0:
                            for extension in s.ext:
                                if s.os.path.splitext(item)[1].lower() == extension.lower():
                                    files.append(item)
                        else: files.append(item)
                else: folders.append("["+item+"]")
            templist = folders + files
            for item in templist:
                resultlist.append(s.ru(item))
        else: resultlist = [u'<<<']
        s.body.set_list(resultlist)
        s.curlist = resultlist
        s.appuifw.app.menu = [s.menuChoose]

    def browse_back(s):
        if s.curdir == u'root': return
        elif len(s.curdir) == 3:
        	s.root()
        else:
            s.curdir = s.os.path.dirname(s.curdir[:-1])
            if s.curdir[-1] != '\\': s.curdir += '\\'
            s.listdir()

    def browse_forward(s):
        i = s.body.current()
        if s.curdir == u'root':
            path = s.e32.drive_list()[i]  + '\\'
        elif i == 0: 
            s.browse_back()
            return
        else: 
            path = s.curdir + s.curlist[i] + '\\'
        if not s.os.path.exists(s.ur(path)): # убираем квадратные скобки вокруг папки
            path = s.curdir + s.curlist[i][1:-1] + '\\'
        if s.os.path.isdir(s.ur(path)):
            s.curdir = path
            s.listdir()
        else:
            s.choose_item()

    def ch_made(s, p):
        s.curdir = p
        s.choice_made = True
        s.lock.signal()

    def choose_item(s):
        i = s.body.current()
        if s.curdir == u'root': 
            if s.find == 'dir':
                s.ch_made(s.e32.drive_list()[i] + '\\')
        elif i == 0:
            return
        else:
            item = s.curdir + s.curlist[i]
            if not s.os.path.exists(s.ur(item)): # убираем квадратные скобки вокруг папки
                item = s.curdir + s.curlist[i][1:-1] + '\\'
            if s.os.path.isdir(s.ur(item)):
                if s.find == 'dir':
                    s.ch_made(item)
            else:
                s.ch_made(item)

    def exit(s):
        s.choice_made = False
        s.lock.signal()
