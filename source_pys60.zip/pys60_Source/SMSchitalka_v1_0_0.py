# -*- coding: utf-8 -*-
import topwindow,appuifw,e32,audio,sys,graphics
from inbox import*
sys.setdefaultencoding("utf-8")
id=0
f=1
def ru(x):return x.decode("utf-8")

def messs(id_mess):
    global id,smss_topwindow,smss_Image,adresat,mes
    id=id_mess
    smss_topwindow = topwindow.TopWindow()
    x_max,y_max = smss_topwindow.maximum_size
    smss_topwindow.size = (x_max,y_max)
    smss_topwindow.background_color=0xffff00
    e32.ao_sleep(3)
    adresat=smss.address(id)
    mes=smss.content(id)
    smss_topwindow.show()
    smss_Image = graphics.Image.new((x_max-10,y_max-10))
    smss_Image.text((5,25),(adresat),fill=(255,0,0),font="title")
    smss_Image.text((5,40),("     "+mes),font="legend")
    smss_Image.text((-x_max+10,60),("     "+mes),font="legend")
    smss_Image.text((-x_max*2+20,80),("     "+mes),font="legend")
    smss_Image.text((-x_max*3+30,100),("     "+mes),font="legend")
    smss_Image.text((-x_max*4+40,120),("     "+mes),font="legend")
    smss_Image.text((-x_max*5+50,140),("     "+mes),font="legend")
    smss_Image.text((-x_max*6+60,160),("     "+mes),font="legend")
    smss_topwindow.add_image(smss_Image,(5,5))
    if f==0:
        e32.ao_sleep(20)
        smss_topwindow.hide()
    elif f>1:
        zagol()
    else:
        aud_sa()
def zagol():
    try:
       audio.say("вы получили новое сообщение")
       e32.ao_sleep(1)
       audio.say("отправитель")
       e32.ao_sleep(1)
       audio.say(adresat)
       e32.ao_sleep(10)
       smss_topwindow.hide()
    except:
         
        e32.ao_sleep(10)
        smss_topwindow.hide()
     
def aud_sa():
    try:
       audio.say("вы получили новое сообщение")
       e32.ao_sleep(1)
       audio.say("отправитель")
       e32.ao_sleep(1)
       audio.say(adresat)
       audio.say("текст сообщения")
       e32.ao_sleep(1.5)
       audio.say(mes)
       e32.ao_sleep(5) 
       sms_topwindow.hide()
    except:
       e32.ao_sleep(10)
       smss_topwindow.hide()
       
def gol():
    global f
    if f==0:
       f=f+1
       appuifw.app.menu=[(ru("голос заголовок"),gol)]
       roun.set(ru("\n"+"\n"+"\n"+"  ОЖИДАЕМ ВХОДЯЩЕЕ                СМС"+"\n"+"\n"+"\n"+"\n" +"чтение ВКЛ" ))
    elif f>1:
        f=f-2
        appuifw.app.menu=[(ru("голос вкл"),gol)]
        roun.set(ru("\n"+"\n"+"\n"+"  ОЖИДАЕМ ВХОДЯЩЕЕ                СМС"+"\n"+"\n"+"\n"+"\n" +"чтение ВЫКЛ" ))
    else:
       f=f+1
       appuifw.app.menu=[(ru("голос выкл"),gol)]       
       roun.set(ru("\n"+"\n"+"\n"+"  ОЖИДАЕМ ВХОДЯЩЕЕ                СМС"+"\n"+"\n"+"\n"+"\n" +"чтение ЗАГОЛОВОК"))
                


prog_lock=e32.Ao_lock()
roun=appuifw.Text()
roun.style=appuifw.STYLE_BOLD
roun.style = appuifw.HIGHLIGHT_SHADOW
roun.font="title"
appuifw.app.screen="large"
roun.set(ru("\n"+"\n"+"\n"+"  ОЖИДАЕМ ВХОДЯЩЕЕ                СМС"+"\n"+"\n"+"\n"+"\n" +"голос ВКЛ" ))        
appuifw.app.body=roun
appuifw.app.menu=[(ru("режим чтения"),gol)]
global smss
smss=Inbox()
smss.bind(messs)
prog_lock.wait()
