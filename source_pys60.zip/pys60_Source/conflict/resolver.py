#
# pdis.conflict.resolver
#
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Merge daemon

The merge daemon will attempt to eliminate conflicts in collections in
the repository that it is pointed at.  It will handle both preexisting
conflicts and newly arising ones.
"""

import time
from Queue import Queue, Empty

from pdis.lib import logging
from pdis.lib.element import copyelement
from pdis.access.et_repo_access import RepoAccess, Fault
from pdis.versioning.pdis_metadata import key_from_id
from pdis.versioning.et_metadata import \
     ETItem, get_id, get_metadata, clear_all_metadata

from pdis.conflict import simple_merge

initial_delay = 0.5
repeating_delay = 0

class Resolver:
    def __init__(self, merge_function=simple_merge.merge, address=("loopback",)):
        self.merge_function = merge_function
        self.address = address

        # The following is a mapping whose keys are collection names
        # and whose values are mappings from object IDs to lists of
        # current item IDs, excluding parentless versions and versions
        # missing from the repository.  (We do not resolve conflicts
        # involving parentless versions.)
        self.state = {}

        # The following queue is used to buffer notifications from the
        # repository.  Each entry is a pair of the form (callable, args).
        self.queue = Queue()

        self.repo = RepoAccess(address,
                               client_name="resolver",
                               agent=True,
                               listener=self)

    def collection_available(self, collection):
        """Repository listener callback"""
        if not collection.startswith("_"):
            self.queue.put((self._collection_available, (collection,)))

    def collection_removed(self, collection):
        """Repository listener callback"""
        pass

    def loop(self):
        try:
            self._loop()
        except:
            logging.log_exception("Conflict resolution loop terminated by exception.")

    def _loop(self):
        while True:
            try:
                f, args = self.queue.get_nowait()
                if repeating_delay > 0:
                    time.sleep(repeating_delay)
            except Empty:
                f, args = self.queue.get()
                if initial_delay > 0:
                    time.sleep(initial_delay)

            try:
                f(*args)
            except Fault, e:
                logging.log_exception("Ignoring %s." % e)

    def _collection_available(self, collection):
        def callback(added, removed, in_sync):
            self.queue.put((self._update, (collection, added, removed)))

        self.state[collection] = {}
        self.repo.create_live_query(collection, callback, ids_only=(True, True))

    def _update(self, collection, added, removed):
        map = self.state[collection]

        for id in removed:
            key = key_from_id(id)
            if key not in map:
                map[key] = []

            current = map[key]
            if id in current:
                current.remove(id)

        for id in added:
            key = key_from_id(id)
            if key not in map:
                map[key] = []

            current = map[key]
            if id in current:
                continue

            if not current:
                # There is only one ID, so we just record it without
                # doing any expensive checks on it.
                current.append(id)
                continue

            item = self.repo.get(collection, id)
            if item is None or not get_metadata(item, "parents"):
                # We are not going to try to resolve conflicts
                # involving parentless or missing versions.
                continue

            for id2 in list(current):
                item2 = self.repo.get(collection, id2)
                if item2 is None or not get_metadata(item2, "parents"):
                    # If we discover a parentless or missing version
                    # on the list, we might as well remove it.
                    current.remove(id2)
                    continue

                if self.resolve(collection, item, item2):
                    break

            current.append(id)

    def resolve(self, collection, item1, item2):
        # We currently consider only conflicts between versions having
        # a common ancestor.  However, it would be conceivable to
        # handle versions with identical content as a special case,
        # even if we continue to ignore parentless versions.
        if effectively_supersedes(item2, item1):
            result = item2
        elif effectively_supersedes(item1, item2):
            result = item1
        else:
            id1 = get_id(item1)
            id2 = get_id(item2)
            item0 = self.repo.get_mrca(collection, [id1, id2])
            if item0 is None:
                return False

            result = self.merge(item0, item1, item2)
            if result is None:
                return False

        self.repo.create(collection, result, [item1, item2])
        logging.logwrite('Resolved a conflict in "%s".' % collection)
        return True

    def merge(self, item0, item1, item2):
        item0 = copyelement(item0)
        item1 = copyelement(item1)
        item2 = copyelement(item2)

        clear_all_metadata(item0)
        clear_all_metadata(item1)
        clear_all_metadata(item2)

        return self.merge_function(item0, item1, item2)

def effectively_supersedes(item1, item2):
    """
    Test if item1 supersedes all versions in the join set of item2.
    """
    item1 = ETItem(item1)
    item2 = ETItem(item2)

    if item1.get_object_id() != item2.get_object_id():
        return False

    if item1.supersedes_version(item2.get_version_id()):
        return True

    join_set = item2.get_join_set()
    if not join_set:
        return False

    for v in join_set:
        if not item1.supersedes_version(v):
            return False

    return True
