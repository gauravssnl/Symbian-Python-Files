#
# pdis.conflict.simple_merge
#
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
#
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
Very conservative, generic three-way merge function

The inputs are three XML documents, provided as elementtree Element
instances.  The first is the original version and the others are
conflicting derived versions.  The result is either None or a new
version incorporating the changes from both of the derived versions.

This particular merge function operates by dividing each of the three
documents into the following parts and examining each triple of
corresponding parts independently:
 * the tag,
 * the text (which may be None),
 * the tail (which may be None),
 * each attribute definition, and
 * each set of child elements sharing the same tag.

The merge only succeeds if one of the following holds for each part:
 * The derived versions are identical.
 * Only one of the derived versions differs from the original.
"""

from pdis.lib.element import tostring

def merge(item0, item1, item2):
    result = item0.makeelement("", {})

    # Tag
    if item1.tag == item2.tag or item2.tag == item0.tag:
        result.tag = item1.tag
    elif item1.tag == item0.tag:
        result.tag = item2.tag
    else:
        return None

    # Text
    if item1.text == item2.text or item2.text == item0.text:
        result.text = item1.text
    elif item1.text == item0.text:
        result.text = item2.text
    else:
        return None

    # Tail
    if item1.tail == item2.tail or item2.tail == item0.tail:
        result.tail = item1.tail
    elif item1.tail == item0.tail:
        result.tail = item2.tail
    else:
        return None

    # Attributes
    keys = item0.keys() + item1.keys() + item2.keys()
    keys.sort()
    keys = _uniq(keys)
    for key in keys:
        val0 = item0.get(key)
        val1 = item1.get(key)
        val2 = item2.get(key)

        if val1 == val2 or val2 == val0:
            val = val1
        elif val1 == val0:
            val = val2
        else:
            return None

        if val is not None:
            result.set(key, val)

    # Children
    keys = ([child.tag for child in item0]
            + [child.tag for child in item1]
            + [child.tag for child in item2])
    keys.sort()
    keys = _uniq(keys)
    for key in keys:
        children0 = item0.findall(key)
        children1 = item1.findall(key)
        children2 = item2.findall(key)

        x0 = [tostring(child) for child in children0]
        x1 = [tostring(child) for child in children1]
        x2 = [tostring(child) for child in children2]

        x0.sort()
        x1.sort()
        x2.sort()

        if x1 == x2 or x2 == x0:
            children = children1
        elif x1 == x0:
            children = children2
        else:
            return None

        result[len(result):] = children

    return result

def _uniq(sorted_list):
    last = None
    result_list = []
    for x in sorted_list:
        if x != last:
            result_list.append(x)
            last = x
    return result_list

if __name__ == '__main__':
    from pdis.lib.element import XML

    test_data = [
        ('<a/>', '<b/>', '<a/>', '<b />'),
        ('<a/>', '<a/>', '<b/>', '<b />'),
        ('<a/>', '<b/>', '<b/>', '<b />'),
        ('<a/>', '<b/>', '<c/>', None),

        ('<a>x</a>', '<a>y</a>', '<a>x</a>', '<a>y</a>'),
        ('<a>x</a>', '<a>x</a>', '<a>y</a>', '<a>y</a>'),
        ('<a>x</a>', '<a>y</a>', '<a>y</a>', '<a>y</a>'),
        ('<a>x</a>', '<a>y</a>', '<a>z</a>', None),

        ('<a>x</a>', '<b>x</b>', '<a>y</a>', '<b>y</b>'),

        ('<a x="0" y="0" z="0" />',
         '<a x="0" y="2" z="3" />',
         '<a x="1" y="0" z="3" />',
         '<a x="1" y="2" z="3" />'),
        ('<a x="0"/>', '<a x="1"/>', '<a x="2"/>', None),

        ('<a><x>0</x><y>0</y><z>0</z></a>',
         '<a><x>0</x><y>2</y><z>3</z></a>',
         '<a><x>1</x><y>0</y><z>3</z></a>',
         '<a><x>1</x><y>2</y><z>3</z></a>'),
        ('<a><x>0</x></a>', '<a><x>1</x></a>', '<a><x>2</x></a>', None),

        ('<a/>',
         '<a><y/><z/></a>',
         '<a><x/><z/></a>',
         '<a><x /><y /><z /></a>'),
        ('<a/>', '<a><x>1</x></a>', '<a><x>2</x></a>', None),

        ('<a><x/><y/><z/></a>',
         '<a><y/></a>',
         '<a><x/></a>',
         '<a />'),
        ('<a><x/></a>', '<a></a>', '<a><x/><x/></a>', None),

        ('<a><x>0</x></a>',
         '<a><x>2</x><x>1</x><x>3</x></a>',
         '<a><x>1</x><x>3</x><x>2</x></a>',
         '<a><x>2</x><x>1</x><x>3</x></a>'),
        ('<a><x>3</x><x>2</x><x>1</x></a>',
         '<a><x>2</x><x>1</x><x>3</x></a>',
         '<a><x>4</x></a>',
         '<a><x>4</x></a>'),
        ('<a><x>3</x><x>2</x><x>1</x></a>',
         '<a><x>4</x></a>',
         '<a><x>2</x><x>1</x><x>3</x></a>',
         '<a><x>4</x></a>'),
        ]

    successes = 0

    for original, derived1, derived2, expected in test_data:
        result = merge(XML(original), XML(derived1), XML(derived2))
        if result is not None:
            result = tostring(result)

        if result == expected:
            successes += 1
        else:
            print "Test failed:"
            print "  Original  =", original
            print "  Derived 1 =", derived1
            print "  Derived 2 =", derived2
            print "  Expected  =", expected
            print "  Obtained  =", result

    print "%d of %d tests succeeded." % (successes, len(test_data))
