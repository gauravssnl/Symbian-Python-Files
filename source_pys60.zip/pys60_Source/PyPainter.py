import e32
import appuifw
import re
from math import *
from os import *
from graphics import *
import thread
import time
def ru(x):return x.decode('utf-8')
name = unicode(time.strftime("%d%m%H%M%S",time.localtime()))
e32.ao_yield()

appuifw.app.screen = 'full'
img = None
def handle_redraw(rect):
    if img:
        canvas.blit(img)

from key_codes import *

class Keyboard(object):
    def __init__(self,onevent=lambda:None):
        self._keyboard_state={}
        self._downs={}
        self._onevent=onevent
    def handle_event(self,event):
        if event['type'] == appuifw.EEventKeyDown:
            code=event['scancode']
            if not self.is_down(code):
                self._downs[code]=self._downs.get(code,0)+1
            self._keyboard_state[code]=1
        elif event['type'] == appuifw.EEventKeyUp:
            self._keyboard_state[event['scancode']]=0
        self._onevent()
    def is_down(self,scancode):
        return self._keyboard_state.get(scancode,0)
    def pressed(self,scancode):
        if self._downs.get(scancode,0):
            self._downs[scancode]-=1
            return True
        return False

keyboard = Keyboard()
appuifw.app.body = canvas = appuifw.Canvas(event_callback = keyboard.handle_event, redraw_callback=handle_redraw)

img = Image.new(canvas.size)
pic = Image.new(canvas.size)
undo_pic = Image.new(canvas.size)
(w,h) = canvas.size
cur_x = w/2
cur_y = h/2
offset_x = 0
offset_y = 0

class KeyboardListener:
    def __init__(self, kb):
        self.keyboard = kb
        self.running = True
        self.listener = None
        self.step = 1
        self.timer_running = False
        self.pressed = None
        
    def run(self):
        import thread
        thread.start_new_thread(self.key_loop, ())
        
    def close(self):
        self.running = False

    def start_timer(self):
        global cur_x, cur_y, offset_x, offset_y, canvas, w,h
        (x,y) = canvas.size
        if self.running and self.timer_running:
            if self.keyboard.is_down(self.pressed):
                if self.pressed == EScancodeLeftArrow:
                    if cur_x > 0:
                        cur_x = cur_x - self.step
                        cur_x = max((cur_x, 0))
                        if cur_x < offset_x:
                            offset_x = offset_x - self.step
                            offset_x = max((offset_x, 0))
                    self.step = self.step + 1/3
                    self.listener(False)
                if self.pressed == EScancodeRightArrow:
                    if cur_x < (w-1):
                        cur_x = cur_x + self.step
                        cur_x = min((cur_x, w-1))
                        if cur_x > (offset_x + x):
                            offset_x = offset_x + self.step
                            offset_x = min((offset_x, w-1-x))
                    self.step = self.step + 1/3
                    self.listener(False)
                if self.pressed == EScancodeUpArrow:
                    if cur_y > 0:
                        cur_y = cur_y - self.step
                        cur_y = max((cur_y, 0))
                        if cur_y < offset_y:
                            offset_y = offset_y - self.step
                            offset_y = max((offset_y, 0))
                    self.step = self.step + 1/3
                    self.listener(False)
                if self.pressed == EScancodeDownArrow:
                    if cur_y < (h-1):
                        cur_y = cur_y + self.step
                        cur_y = min((cur_y, h-1))
                        if cur_y > (offset_y + y):
                            offset_y = offset_y + self.step
                            offset_y = min((offset_y, h-1 - y))
                    self.step = self.step + 1/3
                    self.listener(False)
            e32.ao_sleep(0.1, self.start_timer)
            
    def reset_timer(self):
        self.timer_running = False
        self.pressed = None
        self.step = 1
        
    def key_loop(self):
        global cur_x, cur_y, canvas, offset_x, offset_y,w,h
        (x,y) = canvas.size
        while self.running == True:
            if self.keyboard.pressed(EScancodeLeftArrow):
                if cur_x > 0:
                    cur_x = cur_x - 1
                    if cur_x < offset_x:
                        offset_x = offset_x - 1
                self.reset_timer()
                self.listener(False)
            elif self.keyboard.pressed(EScancodeRightArrow):
                if cur_x < (w-1):
                    cur_x = cur_x + 1
                    if cur_x > (offset_x + x):
                        offset_x = offset_x + 1
                self.reset_timer()
                self.listener(False)
            elif self.keyboard.pressed(EScancodeUpArrow):
                if cur_y > 0:
                    cur_y = cur_y - 1
                    if cur_y < offset_y:
                        offset_y = offset_y - 1
                self.reset_timer()
                self.listener(False)
            elif self.keyboard.pressed(EScancodeDownArrow):
                if cur_y < (h-1):
                    cur_y = cur_y + 1
                    if cur_y > (offset_y + y):
                        offset_y = offset_y + 1
                self.reset_timer()
                self.listener(False)
            elif self.keyboard.pressed(EScancodeSelect):
                self.reset_timer()
                self.listener(True)
            elif self.keyboard.pressed(EScancodeHash):
                self.reset_timer()
                self.listener(False,True)
            elif self.keyboard.is_down(EScancodeLeftArrow):
                self.pressed = EScancodeLeftArrow
                self.timer_running = True
                self.start_timer()
            elif self.keyboard.is_down(EScancodeRightArrow):
                self.pressed = EScancodeRightArrow
                self.timer_running = True
                self.start_timer()
            elif self.keyboard.is_down(EScancodeUpArrow):
                self.pressed = EScancodeUpArrow
                self.timer_running = True
                self.start_timer()
            elif self.keyboard.is_down(EScancodeDownArrow):
                self.pressed = EScancodeDownArrow
                self.timer_running = True
                self.start_timer()
            e32.ao_yield()
            
    def listen(self, callback):
        self.listener = callback


class Draw(object):
    def __init__(self):
        global img, keyboard
        (ww, hh) = img.size
        self.h = hh
        self.w = ww
        self.exit_flag = False
        self.action_complete = False
        self.lock = e32.Ao_lock()
        self.old_exit_key_handler=self.abort
        self.old_title = appuifw.app.title
        appuifw.app.title = u"Dan's Sketcher"
        self.fill = False
        self.line_width = 1
        self.colour = 0x000000
        self.action = None
        self.set_menu()
        self.kb = KeyboardListener(keyboard)
        self.kb.listen(self.notify)
        self.kb.run()

    def set_menu(self):
        if self.fill == False:
            fill_ol = (ru('Заливка'),self.set_fill)
        else:
            fill_ol = (ru('Контур'),self.set_outline)
        appuifw.app.menu = [(ru('Линия'),self.line),
                            (ru('Прямоугольник'),self.rectangle),
                            (ru('Овал'),self.ellipse),
                            (ru('Текст'),self.text),
                            fill_ol,
                            (ru('Цвет'),self.set_colour),
                            (ru('Толщина линии'), self.set_line_width),
                            (ru('Сохранить'),self.save_file),
                            (ru('Открыть файл'),self.load_file),
                            (ru('Размер поля'),self.resize_img),
                            (ru('Отменить'), self.undo)]
    def load_file(self):
        global pic, undo_pic, w,h
        fn = appuifw.query(ru('Выбрать файл'),'text')
        if os.path.exists(fn):
            try:
                tmp_pic = Image.open(fn)
                (w,h) = tmp_pic.size
                pic = Image.new((w,h))
                pic.blit(tmp_pic,(0,0),(0,0))
                undo_pic = None
                self.notify(False)
            except:
                return
            
    def resize_img(self):
        global pic, undo_pic, w ,h, cur_x, cur_y, canvas
        self.action = None
        width = appuifw.query(ru('Ширина'),'number')
        height = appuifw.query(ru('Высота'),'number')
        if width != None and height != None:
            (tx,ty) = canvas.size
            cur_x = min(width/2,tx/2)
            cur_y = min(height/2,ty/2)
            offset_x = 0
            offset_y = 0
            w = width
            h = height
            tmp_pic = Image.new((width,height))
            tmp_pic.blit(pic,(0,0),(0,0))
            pic = Image.new((width,height))
            pic.blit(tmp_pic,(0,0),(0,0))
            #pic.save("resize.png")
            tmp_pic = Image.new((width,height))
            tmp_pic.blit(undo_pic,(0,0),(0,0))
            undo_pic = Image.new((width,height))
            undo_pic.blit(tmp_pic,(0,0),(0,0))
            self.notify(False)

    def draw_line(self, image):
        global cur_x, cur_y, first_xy,offset_x,offset_y
        image.line((first_xy,(cur_x,cur_y)),outline=self.colour, fill=None, width=self.line_width)

    def line(self):
        global cur_x, cur_y, first_xy
        self.action = self.draw_line
        first_xy = (cur_x, cur_y)

    def draw_rect(self, image):
        global cur_x, cur_y, first_xy
        (x1, y1) = first_xy
        x2 = cur_x
        y2 = cur_y
        if x1 > x2:
            tmp = x1
            x1 = x2
            x2 = tmp
        if y1 > y2:
            tmp = y1
            y1 = y2
            y2 = tmp
        if self.fill == False:
            image.rectangle(((x1,y1),(x2,y2)),outline=self.colour, fill=None, width=self.line_width)
        else:
            image.rectangle(((x1,y1),(x2,y2)),outline=self.colour, fill=self.colour, width=self.line_width)

    def rectangle(self):
        global cur_x, cur_y, first_xy
        self.action = self.draw_rect
        first_xy = (cur_x, cur_y)

    def draw_ellipse(self, image):
        global cur_x, cur_y, first_xy
        (a,b) = first_xy
        x1 = a + (a-cur_x)
        x2 = a - (a-cur_x)
        y1 = b + (b-cur_y)
        y2 = b - (b-cur_y)
        if x1 > x2:
            tmp = x1
            x1 = x2
            x2 = tmp
        if y1 > y2:
            tmp = y1
            y1 = y2
            y2 = tmp
        if self.fill == False:
            image.ellipse(((x1,y1),(x2,y2)),outline=self.colour, fill=None, width=self.line_width)
        else:
            image.ellipse(((x1,y1),(x2,y2)),outline=self.colour, fill=self.colour, width=self.line_width)

    def ellipse(self):
        global cur_x, cur_y, first_xy
        self.action = self.draw_ellipse
        first_xy = (cur_x, cur_y)

    def text(self):
        global cur_x, cur_y, pic, undo_pic
        txt = appuifw.query(ru('Введите текст'), 'text')
        if txt != None:
            pic.text((cur_x,cur_y),txt)
            self.notify(False)

    def set_outline(self):
        self.fill = False
        self.set_menu()

    def set_fill(self):
        self.fill = True
        self.set_menu()

    def set_colour(self):
        rgb = appuifw.query(ru('Цвет в HEX-виде (RRGGBB)'), 'text')
        if rgb != None:
            m = re.compile('([0-9a-fA-F]{6})').search(rgb)
            if m != None:
                r = m.group(1)
                self.colour = int(r,16)

    def set_line_width(self):
        lw = appuifw.query(ru('Толщина линии'), 'number')
        if lw != None:
            self.line_width = lw

    def save_file(self):
        fn = pic.save(u"E:\\%s.png" %name),appuifw.note(ru('Сохранено'))

    def undo(self):
        global pic, undo_pic
        if undo_pic != None:
            pic = undo_pic
            undo_pic = None

    def abort(self):
        self.exit_flag=True
        self.lock.signal()

    def close(self):
        appuifw.app.menu=[]
        appuifw.app.body = None
        appuifw.app.exit_key_handler = self.old_exit_key_handler
        appuifw.app.title = self.old_title

    def run(self):
        try:
            while not self.exit_flag:
                self.refresh()
                e32.ao_yield()
                self.lock.wait()
            return
        finally:
            self.kb.close()

    def notify(self, action, cancel=False):
        global pic, undo_pic
        if action == True:
            self.action_complete = True
        if cancel == True:
            self.action = None
        self.lock.signal()

    def refresh(self):
        global img, pic, undo_pic, offset_x, offset_y, cur_x, cur_y, canvas
        tmp_pic = Image.new(canvas.size)
        (tx,ty) = pic.size
        (ttx, tty) = canvas.size
        if(ttx > tx or tty > ty):
            tmp_pic.clear(0x7f7f7f)
        if self.action != None:
            if self.action_complete:
                undo_pic.blit(pic, (0,0), (0,0))
                self.action(pic)
                tmp_pic.blit(pic, (offset_x,offset_y), (0,0))
                self.action_complete = False
                self.action = None
            else:
                tmp_pic2 = Image.new(pic.size)
                tmp_pic2.blit(pic, (0,0), (0,0))
                self.action(tmp_pic2)
                tmp_pic.blit(tmp_pic2,(offset_x, offset_y),(0,0))
        else:
            tmp_pic.blit(pic, (offset_x,offset_y), (0,0))
        #draw cursor
        tmp_pic.line(((cur_x - offset_x,cur_y-offset_y-5),(cur_x-offset_x,cur_y-offset_y+5)),outline=0x7f7f7f, fill = 0x7f7f7f, width = 1)
        tmp_pic.line(((cur_x-offset_x-5,cur_y-offset_y),(cur_x-offset_x+5,cur_y-offset_y)),outline=0x7f7f7f, fill = 0x7f7f7f, width = 1)
        img.blit(tmp_pic,(0,0),(0,0))
        handle_redraw(())

d = Draw()
try:
    d.run()
finally:
    d.close()
