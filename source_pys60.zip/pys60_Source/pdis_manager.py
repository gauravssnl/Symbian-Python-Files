#
# pdis_manager.py
# 
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
# 
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import os
import sys
import time
import operator
from Queue import Queue, Empty

import e32
import appuifw
import key_codes

from pdis.lib.logging import *
from pdis.socket.transport_registry import close_all_managers
from pdis.access.collection_list_monitor import CollectionListMonitor
from pdis.access.sync_dialog_monitor import SyncDialogMonitor


if sys.platform == "symbian_s60":
    app_dir = "\\system\\apps\\python"
    lib_dir = "\\system\\libs"
else:
    app_dir = lib_dir = "."


supported_types = ["folder", "todo"]

type_names = {
    "folder": u"Folder",
    "todo": u"To Do",
    }

scripts = {
    "todo": "pdis_todo.py",
    }


def query_type(types=[]):
    valid_types = []
    for type in types:
        if type in supported_types:
            valid_types.append(type)
        else:
            note(u'Unsupported type: %s' % type, "info")

    if not valid_types:
        types = supported_types
    elif len(valid_types) == 1:
        return valid_types[0]
    else:
        # Unusual and/or abnormal case.
        types = valid_types

    names = [type_names[type] for type in types]
    index = popup_menu(names, u"Open as what?")
    return types[index]

def get_script_path(type):
    if type in scripts:
        return assemble_script_path(scripts[type])
    return None

def assemble_script_path(filename, dir = app_dir):
    if sys.platform == "symbian_s60":
        drive, tail = os.path.splitdrive(appuifw.app.full_name())
    else:
        drive = ""
    return os.path.join(drive, dir, filename)

def exec_script(path, *args):
    old_state = save_state()
    try:
        globals = {"__name__" : ""}
        execfile(path, globals)
        globals["main"](*args)
    except:
        log_exception()
        note(u'Fatal error in child script.', "error")
    restore_state(old_state)

def save_state():
    return (appuifw.app.title,
            appuifw.app.body,
            appuifw.app.menu,
            appuifw.app.exit_key_handler)

def restore_state(state):
    (appuifw.app.title,
     appuifw.app.body,
     appuifw.app.menu,
     appuifw.app.exit_key_handler) = state


class Cancel(Exception):
    pass

def note(*args):
    appuifw.note(*args)

def query(*args):
    result = appuifw.query(*args)
    if result is None:
        raise Cancel
    return result

def popup_menu(content, *args):
    assert content
    result = appuifw.popup_menu(content, *args)
    if result is None:
        raise Cancel
    return result

def selection_list(content, *args):
    assert content
    result = appuifw.selection_list(content, *args)
    if result is None:
        raise Cancel
    return result

def wrap(handler):
    def wrapper():
        try:
            handler()
        except Cancel:
            pass
        except:
            report_exception()

    return wrapper

def report_exception():
    from pdis.pipe.message_pipe_exceptions import Fault

    type, value = sys.exc_info()[:2]
    if type == Fault:
        note(u"Fault: %s" % value.message, "error")
    else:
        log_exception()
        note(u"Internal error: %s" % str(type), "error")


class View:
    def __init__(self, parent, tab,
                 double_spaced = False,
                 callback = lambda: None):
        self.parent = parent
        self.tab = tab
        self.double_spaced = double_spaced

        self.update_required = False
        self.refresh_required = False

        self.db = None
        self.data = []                  # Element type varies.
        self.data_valid = False
        self.data_eq = operator.eq

        label = u"Loading..."
        if double_spaced:
            label = (label, u"")
        self.listbox = appuifw.Listbox([label], callback)

        self.menu = []                # Updated in-place by refresh().

    def bind_backspace(self, callback):
        self.listbox.bind(key_codes.EKeyBackspace, callback)

    def init(self):
        self.db = self.parent.db

    def display(self):
        # Put this view on the screen.
        appuifw.app.title = self.parent.title
        appuifw.app.body = self.listbox
        appuifw.app.menu = self.menu

    def notify(self, refresh_only = False):
        self.parent.notify(self, refresh_only)

    def refresh(self):
        if not self.refresh_required:
            return
        self.refresh_required = False

        try:
            current_item = self.get_current_item()
        except Cancel:
            current_item = None

        if self.update_required:
            self.update_required = False
            self.update_data()

        if not self.data_valid:
            self._show_message(u"Loading...")
        elif not self.data:
            self._show_message(self.get_empty_message())
        else:
            content = [self.format(item) for item in self.data]
            index = None

            if current_item is not None:
                for i in range(len(self.data)):
                    if self.data_eq(self.data[i], current_item):
                        index = i
                        break

            if index is None:
                self.listbox.set_list(content)
            else:
                self.listbox.set_list(content, index)

        self.menu[:] = self.get_menu()

    def get_empty_message(self):
        return u"(Empty)"

    def _show_message(self, msg):
        if self.double_spaced:
            if len(msg) <= 17:
                msg = (msg, u"")
            else:
                msg = (u"", msg)
        self.listbox.set_list([msg])

    def get_current_item(self):
        if not self.data:
            raise Cancel
        current = self.listbox.current()
        return self.data[current]


class AdminView(View):
    def __init__(self, parent):
        View.__init__(self, parent, u"Admin",
                      double_spaced = True)

        self.menu_set_name = (u"Set Name", wrap(self.handle_set_name))
        self.menu_kill = (u"Stop Service", wrap(self.handle_kill))
        self.menu_enable_tracing = (u"Enable Tracing", wrap(self.handle_enable_tracing))
        self.menu_enable_expert = (u"Enable Expert Mode", wrap(self.handle_enable_expert))
        self.menu_disable_expert = (u"Disable Expert Mode", wrap(self.handle_disable_expert))
        self.notify()

    def update_data(self):
        self.data = [("Device name", self.db.get_repo_name()),
                     ("Device ID", self.db.get_repo_id()),
                     ]
        self.data_valid = True

    def format(self, (t, d)):
        return unicode(t), unicode(d)

    def get_menu(self):
        if self.parent.expert:
            mode_item = self.menu_disable_expert
        else:
            mode_item = self.menu_enable_expert

        return [self.menu_set_name,
                self.menu_kill,
                self.menu_enable_tracing,
                mode_item,
                ]

    def handle_set_name(self):
        name = query(u"Enter name for device/repository:", "text",
                     unicode(self.db.get_repo_name()))
        if name == "-":
            # A way to clear the name is useful for testing.
            name = ""
        self.db.set_repo_name(name.strip())
        self.notify()

    def handle_kill(self):
        query(u"Really shut down repository and exit?", "query")
        self.db.send("die")
        self.parent.abort()

    def handle_enable_expert(self):
        self._set_expert_mode(True)

    def handle_disable_expert(self):
        self._set_expert_mode(False)

    def _set_expert_mode(self, value):
        self.parent.expert = value
        self.parent.notify(self.parent.repo_view)
        self.parent.notify(self.parent.data_view, refresh_only = True)
        self.parent.notify(self.parent.sync_view, refresh_only = True)
        self.parent.notify(self.parent.admin_view, refresh_only = True)

    def handle_enable_tracing(self):
        self.db.call("enable_tracing", True)


class SyncView(View):
    def __init__(self, parent):
        View.__init__(self, parent, u"Sync",
                      double_spaced = True,
                      callback = wrap(self.handle_info))

        self.default_host = u"pdis.hiit.fi" # Updated by handle_tcp().

        self.bind_backspace(wrap(self.handle_disconnect))

        self.menu_tcp = (u"Connect TCP", wrap(self.handle_tcp))
        self.menu_bluetooth = (u"Connect Bluetooth", wrap(self.handle_bluetooth))
        self.menu_disconnect = (u"Disconnect", wrap(self.handle_disconnect))
        self.menu_info = (u"Show Info", wrap(self.handle_info))
        self.menu_stats = (u"Show Stats", wrap(self.handle_stats))
        self.menu_dialogs = (u"Show Dialogs", wrap(self.handle_dialogs))

        self.notify()

    def update_data(self):
        my_id = self.db.get_repo_id()
        self.data = [info for info in self.db.list_pipes()
                     if info["repo id"] != my_id]
        self.data_valid = True

    def get_empty_message(self):
        return u"(No connections)"

    def format(self, info):
        title = info["greeting"].get("repo name")
        if not title:
            title = info["repo id"]

        address = info["address"]
        if not address:
            description = ""
        else:
            description = ":".join(map(str, address))

        dialogs = self.parent.list_dialogs({"pipe id" : info["id"]})
        for dialog in dialogs:
            if not dialog["sync timestamp"]:
                title = u"~ %s" % title
                break

        return unicode(title), unicode(description)

    def get_menu(self):
        if not self.data:
            return [self.menu_tcp,
                    self.menu_bluetooth,
                    ]
        else:
            menu = [self.menu_tcp,
                    self.menu_bluetooth,
                    self.menu_disconnect,
                    self.menu_info,
                    self.menu_stats,
                    ]
            if self.parent.expert:
                menu.append(self.menu_dialogs)
            return menu

    def handle_tcp(self):
        host = query(u"Enter host name:", "text", self.default_host)
        address = ("tcp", host, 35800)
        if self.db.connect(address):
            note(u"Connected.", "conf")
            self.default_host = host
        else:
            note(u"Connect failed.", "error")

    def handle_bluetooth(self):
        import socket

        try:
            mac, services = socket.bt_discover()
        except socket.error, (code, msg):
            if code not in [4, 13]:
                note(u'Discovery raised socket error %d: %s' % (code, msg),
                     "error")
            raise Cancel

        port = services.get("PDIS")
        if port is None:
            note(u'"PDIS" service not available at remote device.', "info")
            raise Cancel

        address = ("bt", mac, port)
        if self.db.connect(address):
            note(u"Connected on port %d." % port, "conf")
        else:
            note(u"Connect failed.", "error")

    def handle_disconnect(self):
        info = self.get_current_item()
        if not self.db.disconnect(info["id"]):
            note(u"Disconnect failed.", "error")

    def handle_info(self):
        info = self.get_current_item()

        repo_id = info["repo id"]
        address = info["address"]
        repo_name = info["greeting"].get("repo name")
        platform = info["greeting"].get("platform")

        active = connected = False
        for dialog in self.parent.list_dialogs({"pipe id" : info["id"]}):
            connected = True
            if not dialog["sync timestamp"]:
                active = True

        if active:
            status = u"Synchronizing..."
        elif connected:
            status = u"In sync"
        else:
            status = u"Idle"

        content = [(u"Status", status)]
        if repo_name:
            content.append((u"Name", unicode(repo_name)))
        if repo_id:
            content.append((u"Repo ID", unicode(repo_id)))
        if platform:
            content.append((u"Platform", unicode(platform)))
        if address:
            content.append((u"Address", u":".join(map(unicode, address))))

        if content:
            popup_menu(content)

    def handle_stats(self):
        info = self.get_current_item()

        # Update info for current stats.
        info = self.db.get_pipe_info(info["id"])
        if info is None:
            raise Cancel

        content = []
        content.append(u"In:  %d (%d)" % (info["packets read"],
                                          info["bytes read"]))
        content.append(u"Out: %d (%d)" % (info["packets written"],
                                          info["bytes written"]))
        if self.parent.expert:
            dt = info["last timestamp"] - info["start timestamp"]
            content.append(u"")
            content.append(u"Time: %.3fs" % dt)
            content.append(u"In = %d/s" % round(info["bytes read"] / dt))
            content.append(u"Out = %d/s" % round(info["bytes written"] / dt))

        if content:
            popup_menu(content, u"Packets (bytes)")

    def handle_dialogs(self):
        info = self.get_current_item()
        dialogs = self.parent.list_dialogs({"pipe id" : info["id"]})

        def format(dialog):
            local = dialog["local collection"]
            remote = dialog["remote collection"]

            if dialog["sync timestamp"]:
                arrow = "<->"
            else:
                arrow = "<~>"

            return u"%s %s %s" % (local, arrow, remote)

        if dialogs:
            content = [format(dialog) for dialog in dialogs]
        else:
            content = [u"(Connection is idle.)"]

        if content:
            popup_menu(content, u"Local <-> Remote")


class RepoView(View):
    def __init__(self, parent):
        View.__init__(self, parent, u"Repo",
                      double_spaced = False,
                      callback = wrap(self.handle_open))

        self.bind_backspace(wrap(self.handle_delete))

        self.menu_open = (u"Open", wrap(self.handle_open))
        self.menu_new = (u"New", wrap(self.handle_new))
        self.menu_copy = (u"Copy", wrap(self.handle_copy))
        self.menu_delete = (u"Delete", wrap(self.handle_delete))
        self.menu_import = (u"Import", wrap(self.handle_import))
        self.menu_export = (u"Export", wrap(self.handle_export))
        self.menu_merge = (u"Merge", wrap(self.handle_merge))
        self.menu_info = (u"Show Info", wrap(self.handle_info))

    def update_data(self):
        if not self.parent.expert:
            self.data = self.parent.list_roots()
        else:
            self.data = self.parent.list_collections()

        self.data_valid = True

    def format(self, name):
        active = connected = False
        for dialog in self.parent.list_dialogs({"local collection" : name}):
            connected = True
            if not dialog["sync timestamp"]:
                active = True

        if active:
            marker = "<~>"
        elif connected:
            marker = "<->"
        else:
            marker = None

        if marker:
            return u"%s %s" % (marker, name)
        else:
            return unicode(name)

    def get_menu(self):
        if not self.data:
            return [self.menu_new,
                    self.menu_import,
                    ]
        else:
            return [self.menu_open,
                    self.menu_new,
                    #self.menu_copy,
                    self.menu_delete,
                    self.menu_import,
                    self.menu_export,
                    self.menu_merge,
                    self.menu_info,
                    ]

    def handle_open(self):
        name = self.get_current_item()
        types = self.db.get_types(name)
        type = query_type(types)
        self.parent.open_collection(name, type, self)

    def handle_new(self):
        self._new(u"Enter name for new folder or dataset:")

    def _new(self, prompt, default = ""):
        name = default
        while True:
            name = query(prompt, "text", unicode(name))

            if name.startswith("_"):
                note(u'Names starting with "_" are reserved.', "error")
                continue

            if self.parent.collection_exists(name):
                note(u'"%s" exists.' % name, "error")
                continue

            self.db.create_folder(name, quick = True)
            return name

    def handle_copy(self):
        pass

    def handle_delete(self):
        from pdis.mgt.subscribe import NotFound

        name = self.get_current_item()

        xpath = ('/collection[metadata_collection="%s" and metadata_key!=""]'
                 % name)
        if self.parent.query_exports(xpath):
            note(u'Contains local subscriptions. Cannot delete.', "error")
            raise Cancel

        subscriptions = self.db.query(name, "/pdis:subscription",
                                      key="", ids_only=True)
        if len(subscriptions) > 1:
            dialogs = self.parent.list_dialogs({"local collection" : name})
            if not dialogs:
                query(u"Deleting something while not connected"
                      u" to a replica is discouraged.",
                      "query")

        query(u'Delete "%s"?' % name, "query")
        if self.parent.data_view.folder == name:
            self.parent.data_view.clear_folder()
        try:
            self.db.unsubscribe_by_key(name, name, "")
        except NotFound:
            pass
        self.db.remove_collection(name)

    def handle_import(self):
        pipe_id, names = self._pick_connection2()
        if not names:
            note(u"Nothing exported.", "info")
            raise Cancel

        index = popup_menu(map(unicode, names), u"Import which?:")
        remote_name = names[index]

        local_name = self._new(u"Enter local name for it:", remote_name)

        self._start_sync(pipe_id, local_name, remote_name)

    def handle_export(self):
        name = self.get_current_item()
        info = self._pick_connection()
        if self.db.export_collection(name, info["id"]):
            device = info["greeting"].get("repo name")
            if device:
                device = u'"%s"' % device
            else:
                device = "The other device"
            note(u'%s may now import "%s".' % (device, name), "conf")
        else:
            note(u'Export failed.', "error")

    def handle_merge(self):
        local_name = self.get_current_item()

        pipe_id, names = self._pick_connection2()
        if not names:
            note(u"Nothing exported.", "info")
            raise Cancel

        index = popup_menu(map(unicode, names),
                           u'Pick remote collection:')
        remote_name = names[index]

        query(u'Irrevocably merge "%s" with "%s"?'
              % (local_name, remote_name), "query")
        self._start_sync(pipe_id, local_name, remote_name)

    def _pick_connection(self):
        sync_view = self.parent.sync_view
        connections = sync_view.data
        if not connections:
            note(u"No remote devices connected.", "info")
            raise Cancel
        elif len(connections) == 1:
            return connections[0]
        else:
            content = [sync_view.format(info) for info in connections]
            index = popup_menu(content, u"Choose connection:")
            return connections[index]

    def _pick_connection2(self):
        info = self._pick_connection()

        # Update info to get current greeting.
        info = self.db.get_pipe_info(info["id"])
        if info is None:
            raise Cancel

        id = info["id"]
        names = info["greeting"].get("collections", [])

        return id, names

    def _start_sync(self, pipe_id, name, remote_name):
        if self.db.start_sync(pipe_id, name, remote_name):
            note(u"Sync started.", "conf")
        else:
            note(u"Sync failed.", "error")

    def handle_info(self):
        name = self.get_current_item()
        content = [u"Name: %s" % name]

        for type in self.db.get_types(name):
            content.append(u"Type: %s" % type)

        active = connected = False
        for dialog in self.parent.list_dialogs({"local collection" : name}):
            connected = True
            if not dialog["sync timestamp"]:
                active = True

        devices = self.count_subscribers(name)

        if active:
            status = "Syncing..."
        elif connected:
            status = "In sync."
        elif devices > 1:
            status = "Isolated."
        elif devices == 1:
            status = "Not shared."
        else:
            status = "Not top-level."

        content.append(u"Status: %s" % status)
        content.append(u"Total devices: %s" % devices)

        objects, versions = self.db.count_objects_and_versions(name)
        content.append(u"")
        content.append(u"Objects: %s" % objects)
        content.append(u"Versions: %s" % versions)

        if self.parent.expert:
            all_versions = len(self.db.get_all_ids(name))
            content.append(u"All versions: %s" % all_versions)

        selection_list(content)

    def count_subscribers(self, folder):
        subscriptions = self.db.query(folder, "/pdis:subscription", key="")

        dict = {}
        for item in subscriptions:
            repo_id = item.findtext("repo")
            dict[repo_id] = dict.get(repo_id, 0) + 1

        return len(dict)


class DataView(View):
    def __init__(self, parent):
        from pdis.lib.element import equal

        View.__init__(self, parent, u"Data",
                      double_spaced = True,
                      callback = wrap(self.handle_open))

        self.folder = None              # Folder name or None.
        self.data_valid = True
        self.data_eq = equal

        self.monitor = None             # CollectionMonitor for folder.

        self.bind_backspace(wrap(self.handle_delete))

        self.menu_open = (u"Open", wrap(self.handle_open))
        self.menu_new = (u"New", wrap(self.handle_new))
        self.menu_view = (u"View/Edit", wrap(self.handle_view))
        self.menu_delete = (u"Delete", wrap(self.handle_delete))
        self.menu_subscribe = (u"Subscribe", wrap(self.handle_subscribe))
        self.menu_unsubscribe = (u"Unsubscribe", wrap(self.handle_unsubscribe))

        self.notify(refresh_only = True)

    def set_folder(self, folder):
        from pdis.access.collection_monitor import CollectionMonitor

        if self.folder == folder:
            return

        self._terminate()
        self.monitor = CollectionMonitor(
            self.db, folder, "/pdis:collection",
            callback = self.notify)

        self.folder = folder
        self.data = []
        self.data_valid = False

        self.notify(refresh_only = True)

    def clear_folder(self):
        self._terminate()

        self.folder = None
        self.data = []
        self.data_valid = True

        self.notify(refresh_only = True)

    def _terminate(self):
        if self.monitor:
            self.monitor.close()
            self.monitor = None

    def display(self):
        View.display(self)
        if self.folder:
            appuifw.app.title = unicode(self.folder)

    def update_data(self):
        if self.folder is not None:
            items = self.monitor.query("/pdis:collection")
            self.data = self.sort_data(items)
            self.data_valid = True

    def sort_data(self, items):
        triples = [(item.findtext("title"), item.findtext("description"), item)
                   for item in items]
        triples.sort()
        return [item for x, y, item in triples]

    def get_empty_message(self):
        if self.folder is None:
            return u"(Please open a folder.)"
        else:
            return u"(Empty)"

    def format(self, item):
        from pdis.versioning.et_metadata import get_key

        title = item.findtext("title", "(no title)")
        description = item.findtext("description", "")

        names = self.get_local_collections(get_key(item))
        if self.parent.expert and names:
            title = "%s (%s)" % (title, ", ".join(names))

        active = connected = False
        for dialog in self.parent.list_dialogs():
            if dialog["local collection"] in names:
                connected = True
                if not dialog["sync timestamp"]:
                    active = True

        if active:
            marker = "<~>"
        elif connected:
            marker = "<->"
        elif names:
            marker = "*"
        else:
            marker = None

        if marker:
            title = "%s %s" % (marker, title)

        return (unicode(title), unicode(description))

    def get_menu(self):
        if self.folder is None:
            return []
        elif not self.data:
            return [self.menu_new]
        else:
            return [self.menu_open,
                    self.menu_new,
                    self.menu_view,
                    self.menu_delete,
                    self.menu_subscribe,
                    self.menu_unsubscribe,
                    ]

    def handle_open(self):
        from pdis.versioning.et_metadata import get_key

        item = self.get_current_item()
        names = self.get_local_collections(get_key(item))
        if not names:
            query(u"Subscribe?", "query")
            name = self._subscribe(get_key(item), item.findtext("title"))
            self.db.flush()  # Make sure the dataset has been created.
        elif len(names) == 1:
            name = names[0]
        else:
            index = popup_menu(map(unicode, names), u"Open which?")
            name = names[index]

        types = self.db.get_types(name)
        type = query_type(types)

        self.parent.open_collection(name, type, self)

    def handle_new(self):
        from pdis.lib.element import Element, addsubelement
        from pdis.versioning.et_metadata import qualify
        from pdis.versioning.pdis_metadata import create_object_id

        # I have switched from using a Form here to querying for the
        # title because that makes it possible to do most of the work
        # asynchronously.  The problem with Forms is that they allow
        # the user to make a series of changes to the same record,
        # which forces us to use create_and_update_header() instead
        # of create().
        title = query(u"Enter title for new dataset:", "text")
        date = u"%04d-%02d-%02d" % time.gmtime()[:3]

        item = Element(qualify("collection"))
        addsubelement(item, u"title", title)
        addsubelement(item, u"date", date)

        # We go through a little trouble here to create the
        # subscription before the user-visible metadata record
        # so that the subscription will be in effect when the new
        # item appears on the screen.
        key = create_object_id()
        self._subscribe(key, item.findtext("title"))
        self.db.store_type(self.folder, "folder")
        self.db.create(self.folder, item, key=key)

        if sys.platform == "symbian_s60":
            note(u'The new entry will appear in a few seconds...', "conf")

    def handle_view(self):
        from pdis.lib.element import copyelement

        item = self.get_current_item()
        if item is not None:
            item = copyelement(item)
            content = [(unicode(child.tag), "text", unicode(child.text))
                       for child in item]
            tags = [child.tag for child in item]
            for tag in (u"title", u"description"):
                if tag not in tags:
                    content.append((tag, "text", u""))
            flags = appuifw.FFormDoubleSpaced
            if self.parent.expert:
                flags |= (appuifw.FFormAutoLabelEdit | appuifw.FFormAutoFormEdit)
            form = appuifw.Form(content, flags)
            form.save_hook = lambda content: self.save(item, content)
            form.execute()

    def save(self, item, content):
        from pdis.lib.element import addsubelement

        del item[:]
        updated_content = []

        for label, type, value in content:
            # Modifying the form contents seems to trigger bugs in
            # Python for Series 60.  I've seen the following:
            #  * Attempting to remove an item from the form contents
            #    resulted in its value being copied from some other field.
            #  * Changing the type resulted in a garbage value being displayed.
            # XXX Are these problems still present in v1.0?
            updated_content.append((label, type, value))

            label = label.lower()
            if "<" in label or ">" in label:
                # "Add detail" sets the label to "<label>", which is
                # not a legal XML name.
                label = "fixme"

            if type != "text":
                note(u"Field of type %s ignored." % type, "info")
                continue

            if value:
                addsubelement(item, label, value)

        content[:] = updated_content

        try:
            self.db.modify_and_update_header(self.folder, item)
            return True
        except:
            report_exception()
            return False

    def handle_delete(self):
        from pdis.versioning.et_metadata import get_key, get_id, qualify

        item = self.get_current_item()
        my_id = self.db.get_repo_id()
        records = self.db.query(self.folder, key=get_key(item))

        remote_subscriptions = conflicting = 0
        for record in records:
            if record.tag == qualify("subscription") \
                   and record.findtext("repo") != my_id:
                remote_subscriptions += 1
            elif record.tag == qualify("collection") \
                     and get_id(record) != get_id(item):
                conflicting += 1

        if remote_subscriptions and not conflicting:
            note(u"Others are subscribed.  Cannot delete.", "error")
            raise Cancel

        query(u'Really delete?', "query")
        if not conflicting:
            self._unsubscribe(get_key(item), verbose = False)
        if len(self.data) == 1:
            self.db.clear_type(self.folder, "folder")
        self.db.kill(self.folder, item)

    def handle_subscribe(self):
        from pdis.versioning.et_metadata import get_key

        item = self.get_current_item()
        self._subscribe(get_key(item), item.findtext("title"))

    def _subscribe(self, key, default_name=None):
        default_name = default_name or ""
        if not self.parent.expert:
            if self.get_local_collections(key):
                note(u"Already subscribed.", "info")
                raise Cancel
            name = self._pick_name(default_name)
        else:
            name = self._pick_name_expert(default_name, key)

        self.db.subscribe_by_key(name, self.folder, key, quick=True)
        return name

    def _pick_name(self, default):
        if default.startswith("_"):
            default = ""

        for i in range(1000):
            if i == 0:
                name = default
            else:
                name = "%s(%s)" % (default, i)

            if not self.parent.collection_exists(name):
                return name

        raise Cancel

    def _pick_name_expert(self, default, key):
        name = default
        while True:
            name = query(u"Enter local name:", "text", unicode(name))
            if name.startswith("_"):
                note(u'Names starting with "_" are reserved.', "error")
                continue

            if name not in self.get_local_collections(key) \
                   and self.parent.collection_exists(name):
                query(u"Dataset exists. Merge its contents?", "query")

            return name

    def handle_unsubscribe(self):
        from pdis.versioning.et_metadata import get_key

        item = self.get_current_item()
        self._unsubscribe(get_key(item))

    def _unsubscribe(self, key, verbose = True):
        names = self.get_local_collections(key)

        if verbose:
            if not names:
                note(u"Not subscribed.", "info")
                raise Cancel
            elif len(names) == 1:
                if self.parent.expert:
                    query(u'Unsubscribe "%s"?' % names[0], "query")
            else:
                if self.parent.expert:
                    index = popup_menu(map(unicode, names),
                                       u"Unsubscribe which?")
                    names = [names[index]]

        for name in names:
            self.db.unsubscribe_by_key(name, self.folder, key)
            if not self.parent.expert:
                self.db.remove_collection(name)

    def get_local_collections(self, key):
        from pdis.versioning.et_metadata import get_key

        xpath = ('/collection[metadata_collection="%s" and metadata_key="%s"]'
                 % (self.folder, key))
        exports = self.parent.query_exports(xpath)
        return [get_key(x) for x in exports]


class ManagerApp(CollectionListMonitor, SyncDialogMonitor):
    def __init__(self):
        CollectionListMonitor.__init__(self, self._collection_list_changed)
        SyncDialogMonitor.__init__(self, self._sync_dialog_state_changed)

        self.exports_monitor = None

        self.lock = e32.Ao_lock()
        self.queue = Queue()
        self.exit_flag = False

        self.expert = False

        self.saved_state = save_state()

        self.title = u"PDIS Manager"
        appuifw.app.title = self.title
        appuifw.app.exit_key_handler = wrap(self.handle_abort_request)

        self.repo_view = RepoView(self)
        self.data_view = DataView(self)
        self.sync_view = SyncView(self)
        self.admin_view = AdminView(self)

        self.views = [self.repo_view,
                      self.data_view,
                      self.sync_view,
                      self.admin_view,
                      ]
        self.tabs = [view.tab for view in self.views]
        self.set_tabs(self.repo_view)

    def connect(self, address):
        from pdis.mgt.subscribe import SubscriptionManager
        from pdis.access.collection_monitor import CollectionMonitor

        self.address = address
        self.db = SubscriptionManager(address, listener = self)

        for view in self.views:
            view.init()

        self.bt_name = ""
        self.bt_address = None
        try:
            import miso

            self.bt_name = miso.local_bt_name()
            logwrite("Bluetooth name = %s" % self.bt_name)

            self.bt_address = miso.local_bt_address()
            logwrite("Bluetooth address = %s" % self.bt_address)
        except ImportError:
            # probably running on a desktop
            pass
        except:
            log_exception()
            note(u"Bluetooth appears to be turned off.", "info")

        repo_name = self.db.get_repo_name()
        if not repo_name:
            text = query(u"Enter name for device/repository:", "text",
                         unicode(self.bt_name))
            repo_name = text.strip()
            self.db.set_repo_name(repo_name)

        self.exports_monitor = CollectionMonitor(
            self.db, "__exports__", "/collection",
            callback = self._exports_changed)

    def loop(self):
        try:
            self.lock.wait()
            while not self.exit_flag:
                try:
                    while True:
                        f, args = self.queue.get_nowait()
                        f(*args)
                except Empty:
                    pass

                for view in self.views:
                    view.refresh()

                self.lock.wait()
        finally:
            self.db.close()

    def close(self):
        # This business of clearing the tabs seems to be quite fragile.
        # Python crashes immediately if the body has already been set
        # to None.
        self.clear_tabs()
        restore_state(self.saved_state)

    def set_tabs(self, view):
        appuifw.app.set_tabs(self.tabs, self.handle_tab_select)
        self.activate_tab(view)

    def clear_tabs(self):
        appuifw.app.set_tabs([u""], lambda i: None)

    def activate_tab(self, view):
        index = self.views.index(view)
        appuifw.app.activate_tab(index)
        self.views[index].display()

    def handle_tab_select(self, index):
        self.views[index].display()

    def handle_abort_request(self):
        query(u"Quit PDIS Manager?", "query")
        self.abort()

    def abort(self):
        self.exit_flag = True
        self.lock.signal()

    def async_call(self, f, *args):
        self.queue.put((f, args))
        self.lock.signal()

    def notify(self, view, refresh_only = False):
        # Trigger a refresh.
        if not refresh_only:
            view.update_required = True
        view.refresh_required = True
        self.lock.signal()

    def connected(self, repo_id, count):
        self.notify(self.sync_view)

    def disconnected(self, repo_id, count):
        self.notify(self.sync_view)

    def _collection_list_changed(self):
        if self.expert:
            self.notify(self.repo_view)

    def _sync_dialog_state_changed(self, info):
        self.notify(self.repo_view, refresh_only = True)
        self.notify(self.data_view, refresh_only = True)
        self.notify(self.sync_view, refresh_only = True)

        if info["terminated"] == "no such collection":
            name = info["remote collection"]
            msg = u'Sync failed. "%s" not found.' % name
            self.async_call(note, msg, "error")

    def _exports_changed(self):
        self.notify(self.repo_view)
        self.notify(self.data_view, refresh_only = True)

    def query_exports(self, xpath = ""):
        return self.exports_monitor.query(xpath)

    def list_roots(self):
        from pdis.versioning.et_metadata import get_key

        roots = []
        for x in self.query_exports():
            if not x.findtext("metadata_key"):
                name = get_key(x)
                if x.findtext("metadata_collection") == name:
                    roots.append(name)

        roots.sort()
        return roots

    def open_collection(self, name, type, view):
        if type == "folder":
            self.data_view.set_folder(name)
            self.activate_tab(self.data_view)
        else:
            path = get_script_path(type)
            if path is not None:
                self.clear_tabs()
                try:
                    exec_script(path, name, self.address)
                finally:
                    self.set_tabs(view)

def start_service():
    from pdis.access.repo_access import RepoAccess, ConnectionFailed

    path = assemble_script_path("pdis_daemon.py", lib_dir)
    e32.start_server(unicode(path))
    note(u"Service launched...", "conf")

    for i in range(60):
        try:
            logwrite("Probing...")
            RepoAccess().close()
            logwrite("...probe succeeded.")
            return
        except ConnectionFailed:
            logwrite("...probe failed.")
            e32.ao_sleep(2.0)

    raise Cancel

def connect(app, address):
    from pdis.access.repo_access import ConnectionFailed

    while True:
        try:
            app.connect(address)
            return
        except ConnectionFailed:
            if sys.platform == "symbian_s60":
                query(u"Service not running. Start it?", "query")
                start_service()
                continue
            else:
                note(u"Service not running.  Sorry, exiting.", "info")
                raise Cancel

def main(address = ("tcp", "localhost", 35800)):
    app = ManagerApp()
    try:
        e32.ao_yield()
        try:
            connect(app, address)
        except Cancel:
            return

        app.loop()
    finally:
        logwrite("Exiting...")
        app.close()

if __name__ == "__main__":
    init_logging(FileLogger("manager.txt"))

    try:
        if sys.platform == "symbian_s60":
            main()
        else:
            from pdis.access.pdis_url import parse_pdis_url

            url = u"pdis://localhost"
            url = query(u"Enter URL for repository:", "text", url)
            address, unused = parse_pdis_url(url)
            main(address)
    except Cancel:
        pass
    except:
        log_exception()
        note(u"Fatal error.", "error")

    close_all_managers()
