 #ColorPicker by derelict
import appuifw
import e32
from graphics import *
from key_codes import *
import clipboard
import sys

cur_color=[0 for i in range(3)]
save_color=[0 for i in range(3)]
cur_index=0
label_color=(0xff0000,0x00ff00,0x0000ff)
label_name=map(unicode,("R: ","G: ","B: "))
hex_color="0x000000"
part_range=range(255,-1,-51)
web_pal=[(r,g,b) for r in part_range for g in part_range for b in part_range]

class Keyboard(object):
    def __init__(self,onevent=lambda:None):
        self._keyboard_state={}
        self._downs={}
        self._onevent=onevent
    def handle_event(self,event):
        if event['type'] == appuifw.EEventKeyDown:
            code=event['scancode']
            if not self.is_down(code):
                self._downs[code]=self._downs.get(code,0)+1
            self._keyboard_state[code]=1
        elif event['type'] == appuifw.EEventKeyUp:
            self._keyboard_state[event['scancode']]=0
        self._onevent()
    def is_down(self,scancode):
        return self._keyboard_state.get(scancode,0)
    def pressed(self,scancode):
        if self._downs.get(scancode,0):
            self._downs[scancode]-=1
            return True
        return False
    def num_pressed(self):
        scancode=EScancode0
        while scancode<=EScancode9:
            if self._downs.get(scancode,0):
                self._downs[scancode]-=1
                return (scancode-EScancode0)
            scancode+=1
        return -1

keyboard=Keyboard()

def quit():
    global running
    running=0
    appuifw.app.set_exit()

def handle_redraw(rect):
    img.clear()
    img.blit(back,target=(0,0),scale=1)
    draw_cursor()
    draw_scale()
    draw_sample()
    draw_text()
    canvas.blit(img)

def draw_scale():
    for i in range(3):
        cur_pos=193-int(cur_color[i]*0.7)
        img.line((15+i*20,15,15+i*20,193),0x000000)
        img.rectangle((11+i*20,cur_pos-3,20+i*20,cur_pos+3),0x000000,fill=label_color[i])

def draw_sample():
    img.rectangle((71,15,161,105),0x000000)
    img.rectangle((72,16,160,60),tuple(cur_color),fill=tuple(cur_color))
    img.rectangle((71,60,161,104),tuple(save_color),fill=tuple(save_color))

def draw_cursor():
    img.rectangle((9+cur_index*20,10,22+cur_index*20,198),0x000000,fill=0x99ccff)
    img.rectangle((68,113+16*(cur_index+1),103,128+16*(cur_index+1)),0x000000,fill=0x99ccff)

def draw_text():
    img.text((71,125),u"HEX: "+get_hex_color(cur_color))
    if tuple(cur_color) in web_pal:
        img.rectangle((150,113,163,128),0x000000,fill=0x99ccff)
        img.text((153,125),u"W")
    for i in range(3):
        img.text((71,125+16*(i+1)),label_name[i]+(repr(cur_color[i])).zfill(3))

def get_hex_color(rgb):
    result="0x"
    for part in rgb:
        hex_part=(hex(part))[2:].upper()
        result+=hex_part.zfill(2)
    return unicode(result)

appuifw.app.screen='full'
img=Image.new((176,208))
back=Image.open("e:\\images\\back.png")
canvas=appuifw.Canvas(event_callback=keyboard.handle_event,redraw_callback=handle_redraw)
appuifw.app.body=canvas
appuifw.app.exit_key_handler=quit

running=1

while running:
    handle_redraw(())
    e32.ao_yield()
    if keyboard.pressed(EScancodeLeftArrow):
        cur_index-=1
        if cur_index<0:
            cur_index=2
    if keyboard.pressed(EScancodeRightArrow):
        cur_index+=1
        if cur_index>2:
            cur_index=0
    if keyboard.pressed(EScancodeUpArrow):
        if cur_color[cur_index]<255:
            cur_color[cur_index]+=1
    if keyboard.pressed(EScancodeDownArrow):
        if cur_color[cur_index]>0:
            cur_color[cur_index]-=1
    if keyboard.pressed(EScancodeBackspace):
        cur_color[cur_index]=int((repr(cur_color[cur_index])).zfill(3)[:2])
    if keyboard.pressed(EScancodeSelect):
        save_color=cur_color[:]
    num=keyboard.num_pressed()
    if num!=-1:
        color_part=int((repr(cur_color[cur_index])).zfill(3)[1:]+repr(num))
        if 0<=color_part<=255:
            cur_color[cur_index]=color_part
    if keyboard.pressed(EScancodeHash):
        save_color,cur_color=cur_color[:],save_color[:]
    if keyboard.pressed(EScancodeStar):
        clipboard.Set(get_hex_color(cur_color))