# этот script тянет различные формы и текст с экрана


import appuifw
from appuifw import *
import e32
# вызов графики
from graphics import *



# создание тренера вызова
def quit():
    global running
    running=0
    appuifw.app.set_exit()

# установка большого размера экрана
appuifw.app.screen='large'

# назначение начального изображения (белый)
img=Image.new((176,208))

# добавление различных фигур и текста к изображению
# coord. Последовательность x1,x2,y1,y2
# квадрат. Значение х1 и х2 должны быть х1<у1 х2<у2
img.rectangle((50,50,126,178),0x9590ff,width=103)
# Для эллипса Значение х1 и х2 должны быть х1<у1 х2<у2
# задаем переменные х, х_, у, у_ чтобы можно было двигать корзину по дисплею, изменяя всего лишь переменную х или х_, не изменяя пропорции корзины.
x=10
x_=10
y=x+70
y_=x_+25
img.ellipse((x+16,x_+41,y-16,60+43),0x252525,width=6)
img.ellipse((x+13,x_+35,y-13,60+35),0x55A100,width=3)
img.ellipse((x+11,x_+30,y-11,60+30),0x9525A1,width=3)
img.ellipse((x+9,x_+25,y-9,60+25),0x00A1A1,width=3)
img.ellipse((x+7,x_+20,y-7,60+20),0xA100A1,width=3)
img.ellipse((x+5,x_+15,y-5,60+15),0x00A100,width=3)
img.ellipse((x+3,x_+10,y-3,60+10),0x00A1A1,width=3)
img.ellipse((x+1,x_+2,y-1,60+2),0x252525,width=5)
# назначить функцию измены (которая изменяет снова и снова)
# в этом случае изменяется изображение, с названием img используется блитирующая функция
def handle_redraw(rect):
    canvas.blit(img)

running=1

# определение холста, включение отзыва функции измены
canvas=appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)

# установка app.body в холст
appuifw.app.body=canvas

app.exit_key_handler=quit


# создание цикла, чтобы экран изменялся снова и снова, пока кнопка выхода не будет нажата 
while running:
    # измена экрана
    handle_redraw(())
    # "уступите" должен быт здесь, чтобы ключевые нажимы могли быть изменены
    e32.ao_yield()







        


 



