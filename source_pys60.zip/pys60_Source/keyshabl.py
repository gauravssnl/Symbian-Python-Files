#by Grishberg
import appuifw
from graphics import *
import e32
from key_codes import *

class kb(object):
    def __init__(self,onevent=lambda:None):
        self._kbs={}
        self._downs={}
        self._onedowns={}
        self._onerel={}
        self._onevent=onevent
    def he(self,event):
        if event['type'] == 3:
            code=event['scancode']
            if self._onerel.get(code,0):
                del self._onerel[code]
            if not self.is_down(code):
                self._downs[code]=self._downs.get(code,0)+1
                self._onedowns[code]=1
            self._kbs[code]=1
        elif event['type'] == 2:
            code=event['scancode']
            self._kbs[code]=0
            self._onerel[code]=1
            if self._onedowns.get(code,0)==1:
              del self._onedowns[code]
        self._onevent()
    def is_down(self,scancode):
        return self._kbs.get(scancode,0)
    def pressed(self,scancode):
        if self._downs.get(scancode,0):
            self._downs[scancode]-=1
            return True
        return False
    def onepress(self,scancode):
        if self._onedowns.get(scancode,0):
            del self._downs[scancode]
            return True
        return False
    def onrelase(self,scancode):
        if self._onerel.get(scancode,0):
            del self._onerel[scancode]
            return True
        return False


kb=kb()

appuifw.app.screen='full'
img=None
def handle_redraw(rect):
    if img:
        canvas.blit(img)
appuifw.app.body=canvas=appuifw.Canvas(
    event_callback=kb.he,
    redraw_callback=handle_redraw)
img=Image.new(canvas.size)

running=1
def quit():
    global running
    running=0
appuifw.app.exit_key_handler=quit

while running:
    e32.ao_yield()
    img.clear(0xffffff)
    if kb.onrelase(18):
      img.text((0,10),u'was released pen')
      print 'pen'
    handle_redraw(())
print 'end'
