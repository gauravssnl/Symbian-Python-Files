#
# pdis_daemon.py
# 
# Copyright 2004-2005 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
# 
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

"""
The PDIS repository server

Has no GUI stuff, and runs on the background in its own process.
"""

import e32

from pdis.lib.logging import *
init_logging(FileLogger("daemon.txt"))

from pdis.lib.best_threading import start_thread
from pdis.lib.priority import set_process_priority, set_thread_priority
from pdis.socket.transport_registry import close_all_managers

from pdis.repo.server import RepoServer
from pdis.access.repo_access import RepoAccess
from pdis.mgt.sync_agent import SyncAgent
from pdis.conflict.resolver import Resolver
from pdis.fsync.scan_e32 import Autoscanner
from pdis.fsync.advertise import Advertiser

import pdis.repo.repository
pdis.repo.repository.cache_size = 200

drive = "E:"
try:
    import os
    os.listdir(drive)
except:
    drive = "C:"

repo_dir = drive + "\\System\\Data\\pdis"

use_sync_agent = True
use_resolver = True
use_scanner = True
use_advertiser = True

try:
    try:
        set_process_priority(150)

        logwrite('Service starting...')
        script_lock = e32.Ao_lock()
        server = RepoServer(repo_dir, request_shutdown = script_lock.signal)
        server.listen(("loopback",))

        repo = RepoAccess(("loopback",))
        try:
            repo.create_collection("__exports__")
        finally:
            repo.close()

        server.listen(('tcp', '127.0.0.1', 35800))
        server.listen(("bt", {"service_id": 0x0442244e,
                              "service_name": u"PDIS"}))

        logwrite('Service started.')
        e32.ao_sleep(30)

        if use_sync_agent:
            logwrite('Starting sync agent...')
            sync_agent = SyncAgent()
            start_thread(target = sync_agent.loop,
                         name = "sync-agent")

        if use_resolver:
            logwrite('Starting conflict resolution agent...')
            resolver = Resolver()
            start_thread(target = resolver.loop,
                         name = "conflict-resolver")

        if use_scanner:
            def scanner_loop():
                set_thread_priority(-20)
                # The main loop must be run in the same thread that
                # did the initialization.
                scanner = Autoscanner()
                scanner.loop()

            logwrite('Starting file scanner...')
            start_thread(target = scanner_loop,
                         name = "file-scanner")

        if use_advertiser:
            logwrite('Starting file advertiser...')
            advertiser = Advertiser()
            start_thread(target = advertiser.loop,
                         name = "file-advertiser")

        logwrite('Agents launched.')
        script_lock.wait()

        logwrite('Service stopping...')
        server.close(timeout = 30)
    finally:
        close_all_managers()
        logwrite('Service stopped.')
except:
    log_exception()

#logwrite(str(e32._mem_info()))
