
import sysinfo
print "Battery level: %d" % sysinfo.battery()
