##by _virtual_machine_ 
import os,e32,appuifw,graphics,fgimage,appswitch

def RU(t):return t.decode('utf-8')
def UR(t):return t.encode('utf-8')

class Logo:
 def __init__(S):
  Driver='c'
  MainPath=':\\system\\apps\\AniSimb\\'
  try:Stat=os.stat(Driver+MainPath)
  except:Driver='e'
  S.ListPath=Driver+MainPath+'logo\\'
  S.SetPath=Driver+MainPath+'setting.txt'
  S.List=[]
  for Name in os.listdir(S.ListPath):S.List.append(RU(Name))
  File=open(S.SetPath,'r')
  S.Name=File.read()
  File.close()
  try:Index=S.List.index(RU(S.Name))
  except:Index=0
  S.Body=appuifw.app.body=appuifw.Listbox([u''],S.Select)
  S.Body.set_list(S.List,Index)
  appuifw.app.exit_key_handler=S.Exit
  appuifw.app.menu=[(RU('Активировать'),S.Select),(RU('Выйти'),S.Exit)]
  S.Lock=e32.Ao_lock()
  S.Wait=S.Lock.wait
  S.Load()

 def Select(S):S.Name=UR(S.List[S.Body.current()])
 def Exit(S):
  File=open(S.SetPath,'w')
  File.write(S.Name)
  File.close()
  S.Lock.signal()
  appuifw.app.set_exit()

 def Load(S):
  S.Last=S.Name
  S.Images=[]
  LogoPath=S.ListPath+S.Name+'\\'
  for File in os.listdir(LogoPath):
   if File[0]!='_':
    S.Images.append([graphics.Image.new((97,25)),graphics.Image.new((97,25),'1')])
    S.Images[-1][0].load(RU(LogoPath+File))
    S.Images[-1][1].load(RU(LogoPath+'_'+File))
 def Run(S):
  Scrn,Flag=1,1
  Fore,Back=graphics.Image.new((97,25)),graphics.Image.new((97,25))
  Pause=1.0/len(S.Images)
  FGImg=fgimage.FGImage()
  Phone=[u'Phone',u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d',u'Telephone']
  while 1:
   for Logo in S.Images:
    if appswitch.application_list(1)[0] in Phone:
     Flag=1
     if Scrn:
      Scrn=0
      Back.blit(graphics.screenshot(),source=((65,2),(162,27)))
     Fore.blit(Back)
     Fore.blit(Logo[0],mask=Logo[1])
     FGImg.set(65,2,Fore._bitmapapi())
    else:
     if Flag:
      Flag=0
      FGImg.unset()
     if S.Last!=S.Name:S.Load()
    e32.ao_sleep(Pause)

Logo=Logo()
Logo.Run()
Logo.Wait()