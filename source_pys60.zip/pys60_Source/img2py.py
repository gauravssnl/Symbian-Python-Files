import appuifw,os,e32,lite_fm,audio,clipboard
a,o,e=appuifw,os,e32
from graphics import*
from rusos import*
def ru(x):return x.decode('utf-8')
def exit():
 if a.query(ru('Вы действительно желаете выйти?'),'query'):
  a.note(ru('До встречи'),'conf')
  a.app.set_exit()
def svr():
 clipboard.Set(u''+gsw)
 a.note(ru('Скопировано'),'conf')
def prt():pass
def sf():
 ip=lite_fm.manager(ext='.py')
 h=open(ip,'w')
 h.write(gsw)
 h.close()
 a.note(ru('Файл сохранен успешно'),'conf')
def nst():
 x1=y1=0
 a.app.screen='normal'
 a.app.body=r=a.Text()
 a.app.menu=[(ru('Потерпи =) '),prt)]
 r.color=0xf
 r.set(u'import appuifw\nappuifw.app.body=c=appuifw.Canvas\n')
 e.ao_sleep(2)
 for y1 in range(y):
  for x1 in range(x):
   col=i.getpixel((x1,y1))
   r.add(u'c.point(('+str(x1)+','+str(y1)+'),'+str(col[0])+',width=1)\n')
   tomp=str(((float(x1+(x*y1))/(x*y))*100)+1)[:3]
   if tomp[1]=='.':tmp=tomp[:1]
   elif tomp[2]=='.':tmp=tomp[:2]
   else:tmp=100
   a.app.title=u''+str(tmp)+'%'
   x1+=1
   e.ao_sleep(0.00000001)
  y1+=1
 tra=audio.Sound.open('e:\\system\\apps\\tround\\ok.amr')
 global tra,gsw
 tra.play()
 a.note(ru('Готово'),'conf')
 a.app.title=ru('Готово')
 gsw=r.get()
 a.app.menu=[(ru('Скопировать в буфер обмена'),svr),(ru('Сохранить как'),sf)]
def open():
 a.app.screen='normal'
 a.app.title=ru('Выберете изображение')
 p=lite_fm.manager(ext='.png')
 a.app.screen='full'
 a.app.body=c=a.Canvas()
 i=Image.open(p)
 x,y=i.size
 a.app.title=u''+str(x)+' x '+str(y)
 c.clear(0xcccccc)
 c.blit(i,target=(2,2))
 global x,y,i
 a.app.menu=[(ru('Перевести в код питона'),nst)]
def ab():
 a.app.body=r=a.Text()
 r.color=0xf
 r.set(ru('Программа предназначена для перевода картинки в код графики питона, тоесть Вы выбираете картинку и на экране появиться код который потом можно скопировать в буфет обмена или записивать в *.py файлы и запускать как скрипт или исполняему программу. \nАвтор : VALIK\nICQ : 453012167\ne-mail : avatar3230@mail.ru\nСайт : pythons.ru'))
 a.app.menu=[(ru('Выход'),exit)]
 a.app.exit_key_handler=intro
def intro():
 a.app.body=r=a.Text()
 r.color=0xf
 r.set(ru('Автор : VALIK\nICQ : 453012167\ne-mail : avatar3230@mail.ru\n     Специально для сайта :\n              pythons.ru'))
 a.app.menu=[(ru('Выбрать изображения'),open),(ru('О программе'),ab)]
 a.app.exit_key_handler=exit
intro()