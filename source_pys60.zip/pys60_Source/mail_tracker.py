#SYMBIAN_UID=0x03747304

import appuifw
import string
from appuifw import *
import e32
from graphics import *
import os
import socket 
import location

mail_from  = u'zoff@mail.ru'
mail_rcpt  = u'zoff@mail.ru'
mail_serv  = u'smtp.mail.ru'
old_cellid = u'1'
running    = 1

def m_mailfrom():
    global mail_from
    mail_from=appuifw.query(u'MAIL FROM:','text',mail_from)
    print u'MAIL FROM:'+mail_from

def m_mailto():
    global mail_rcpt
    mail_rcpt=appuifw.query(u'MAIL TO:','text',mail_rcpt)
    print u'MAIL TO:'+mail_rcpt
    
def m_mailserver():
    global mail_serv
    mail_serv=appuifw.query(u'MAIL SERVER:','text',mail_serv)
    print u'MAIL SERV:'+mail_serv
    
def m_exit():
    running=0
    script_lock.signal()
    appuifw.app.set_exit()

def readline(self):
    s=[]
    while 1:
        c=self.recv(1)
        s.append(c)
        if c=='\n':
            break
    return ''.join(s)

script_lock = e32.Ao_lock()
appuifw.app.screen='large'
appuifw.app.body.clear()
appuifw.app.exit_key_handler=m_exit 
appuifw.app.menu = [(u"SET-To mail", m_mailto),
                    (u"SET-From mail", m_mailfrom),
                    (u"SET-Mail server", m_mailserver),
                    (u"EXIT", m_exit)]
print ' '
print '-== ZoFF-TRACKER =--'
print 'zimenkov@ntci.nnov.ru'
print ' '

while running:
    mcc, mnc, lac, cellid = location.gsm_location()
    dat1= u"CID=%s"%(cellid)
    if old_cellid != dat1:
        old_cellid = dat1
        
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        addr=(mail_serv,25)
        s.connect(addr)
        data = readline(s)
        s.send('HELO mail\r\n')
        data = readline(s)
        s.send('MAIL FROM:<'+mail_from+'>\r\n')
        data = readline(s)
        s.send('RCPT TO:<'+mail_rcpt+'>\r\n')
        data = readline(s)
        s.send('DATA\r\n')
        data = readline(s)
        s.send('Message from ZoFF-TRACKER\r\n')
        s.send(dat1.join('\r\n'))
        s.send('\r\n.\r\n')
        data = readline(s)
        s.send('QUIT\r\n')
        data = readline(s)
        s.close()
        print dat1
    e32.ao_sleep(300)  # 300 seconds !!!
