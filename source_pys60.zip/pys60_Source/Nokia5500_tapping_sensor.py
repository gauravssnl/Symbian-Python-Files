#  "My-phone-has-feelings-too" application
# (c) Copyright 2007 Jurgen Scheible under terms of GPL

#  This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#  You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Note: You need to have at least Python for S60 version 1.4.1 installed on your phone to get this to work.


import sensor, appuifw, audio, e32

sensor_type = sensor.sensors()['Tapping sensor']
tap_sensor_5500 = sensor.Sensor(sensor_type['id'],sensor_type['category'])
tap_sensor_5500.set_event_filter(sensor.EventFilter())

def get_sensor_data(status):
    #print status
    if status['data_2'] == 6 :
        audio.say(u"dont do this again")
    elif status['data_2'] == 5 :
        audio.say(u"yes, I love you, too")
    elif status['data_2'] == 3 :
        audio.say(u"this hurts")
    elif status['data_2'] == 4 :
        audio.say(u"I like that")

def quit():
    tap_sensor_5500.disconnect()
    app_lock.signal()

tap_sensor_5500.connect(get_sensor_data)

print ' Tap quickly 2 times with your finger on the:'
print '- display glass or'
print '- the back or'
print '- the left side (in middle part) or'
print '- the right side of the phone (in middle part)'

appuifw.app.title = u"5500 Tap sensor"
appuifw.app.exit_key_handler = quit
app_lock = e32.Ao_lock()
app_lock.wait()