import appuifw
import e32
from key_codes import *
from graphics import *
from rusos import*
def quit():
    global running
    running=0
    appuifw.app.set_exit()
#открываем картинку
try:img =Image.open('e:\\image.gif')
except:appuifw.note(ru('нет картинки в корне диска E с именем image.jpg'),'error')

running=1

appuifw.app.screen='full'
#создаем переменную графического поля
canvas=appuifw.Canvas()
#задаем рабочий стол в графический режим
appuifw.app.body=canvas

appuifw.app.exit_key_handler=quit


while running:        
    
    canvas.blit(img)#блитируюшая функция которая выводит картинку на экран
    e32.ao_yield()
    






