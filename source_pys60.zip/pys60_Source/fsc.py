class Filesystemcontrol:
	def __init__(self):import e32posix
	def delete(self,path):
		if self.isdir(path):
			if path.endswith('\\')==0:path+='\\'
			for name in e32posix.listdir(path):
				newpath=path+name
				if self.isdir(newpath):self.delete(newpath)
				else:
					try:e32posix.remove(newpath)
					except:pass
			try:e32posix.rmdir(path)
			except:pass
		elif self.isfile(path):
			try:e32posix.remove(path)
			except:pass
	def exists(self,path):
		try:e32posix.stat(path)
		except:return 0
		return 1
	def isdir(self,path):
		try:
			if e32posix.stat(path)[0]==16512:return 1
			return 0
		except:return 0
	def isfile(self,path):
		try:
			if e32posix.stat(path)[0]==32896:return 1
			return 0
		except:return 0
	def copy(self,target,source,stoper=0,HeTporaTb=1):
		if target.endswith('\\')==0:target+='\\'
		if source.endswith('\\'):source=source[:-1]
		name=source[source.rfind('\\')+1:]
		newtarget=target+name
		if self.exists(newtarget):
			if stoper:return 0
		if self.isdir(source):
			source+='\\'
			if not self.exists(newtarget):e32posix.mkdir(newtarget)
			for i in e32posix.listdir(source):
				newsource=source+i
				if self.isdir(newsource):self.copy(newtarget,newsource,0,0)
				else:e32.file_copy(newtarget,newsource)
		else:e32.file_copy(target,source)
		if HeTporaTb:return 1
	def move(target,source,stoper=0):
		if source.endswith('\\'):source=source[:-1]
		name=source[source.rfind('\\')+1:]
		if target.endswith('\\')==0:target+='\\'
		target+=name
		if self.exists(target):
			if stoper:return 0
		e32posix.rename(source,target)
		return 1
fsc=Filesystemcontrol()