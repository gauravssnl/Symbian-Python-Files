#resourse by oleg_ash aka Ash_Rockit
#edition by Dimontrans
#dimonvideo.ru
import os
from appuifw import *
import fgimage,e32,keycapture,sysinfo
from appswitch import *
from graphics import *
memory=fgimage.FGImage()
img=Image.new((100,35))
def tooth():
 try:
  e32.start_exe('z:\\system\\programs\\apprun.exe','e:\\system\\apps\\RunPython\\Apps\\bluefile\\tonglebt.app')
 except:
  e32.start_exe('z:\\system\\programs\\apprun.exe','c:\\system\\apps\\RunPython\\Apps\\bluefile\\tonglebt.app')
def exit(k):
 tooth()
 os.abort()
k=keycapture.KeyCapturer(exit)
k.keys=(63587,)
def delete():
 try:
  os.remove(u'c:\\system\\temp\\BTObex.tmp')
 except:
  try:
   os.remove(u'e:\\system\\BTObex.tmp')
  except:
   pass
tooth()
e32.ao_sleep(0.5)
switch_to_bg(u'Bluefile')
switch_to_fg(u'Phone')
delete()
size=0
s2=0
while 1:
 global size,s2
 img.rectangle((0,0,100,35),0xffffff,fill=0)
 spc=sysinfo.free_drivespace()
 if os.path.exists(u'e:\\system\\BTObex.tmp'):
  size=os.path.getsize(u'e:\\system\\BTObex.tmp')
  s1=str(size)
  s2=int(s1)/1024
  s3=str(s2)
  space=str(spc['E:']/(1024**2))
  img.text((4,16),(u'card: '),0x99ccff)
  img.text((33,16),(space.decode('utf-8')+' Mb'),0x99ffcc)
  img.text((4,29),(u'file: '),0x99ccff)
  img.text((25,29),(s3.decode('utf-8')+' kb'),0x99ffcc)
  img.rectangle((0,40,80,55), 0xffffff,fill=0)
 elif os.path.exists(u'c:\\system\\temp\\BTObex.tmp'):
  size=os.path.getsize(u'c:\\system\\temp\\BTObex.tmp')
  s1=str(size)
  s2=int(s1)/1024
  s3=str(s2)
  space=str(spc['C:']/(1024**2))
  img.text((4,16),(u'phone: '),0x99ccff)
  img.text((43,16),(space.decode('utf-8')+' Mb'),0x99ffcc)
  img.text((4,29),(u'file: '),0x99ccff)
  img.text((25,29),(s3.decode('utf-8')+' kb'),0x99ffcc)
  img.rectangle((0,40,80,55), 0xffffff,fill=0)
 else:
  pass
 if application_list(1)[0]==u'Phone':
  memory.set(72,91,img._bitmapapi())
  k.start()
 else:
  memory.set(58,5,img._bitmapapi())
  k.stop()
 e32.ao_sleep(0.3)