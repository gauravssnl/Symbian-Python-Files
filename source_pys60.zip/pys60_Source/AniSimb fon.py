###by _virtual_machine_ 
import e32,graphics,fgimage,appswitch

SetPath=':\\system\\apps\\AniSimb\\Settings.txt'
try:SetFile=open('c'+SetPath,'r')
except:SetFile=open('e'+SetPath,'r')
Events=SetFile.read().splitlines()
SetFile.close()

Settings,Pictures=Events[0].split(','),Events[1:]
SleepTime,DrawX,DrawY=round(1.0/int(Settings[0]),4),int(Settings[1]),int(Settings[2])
BGImg=[]

for ImgPath in Pictures:BGImg.append(graphics.Image.open(ImgPath))

Count,Flag,BGImgLen=0,1,len(BGImg)
FGImg,ClearImg=fgimage.FGImage(),graphics.Image.new((1,1))
while 1:
 AppActive=appswitch.application_list(1)[0]
 if (AppActive==u'Phone') or (AppActive==u'\u0422\u0435\u043b\u0435\u0444\u043e\u043d'):
  FGImg.set(DrawX,DrawY,BGImg[Count]._bitmapapi())
  Count+=1
  Flag=1
  if Count==BGImgLen:Count=0
 else:
  if Flag==1:FGImg.set(176,0,ClearImg._bitmapapi())
  Flag=0
 e32.ao_sleep(SleepTime)