
input = " this is, a TEST input!"
allowed = "abcdefghijklmnopqrstuvwxyz"
print "".join([c for c in input if c in allowed])
