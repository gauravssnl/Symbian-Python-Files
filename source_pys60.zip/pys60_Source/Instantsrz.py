class Russian:
 def __init__(s):
  from _codecs import utf_8_encode,utf_8_decode
  s.encode,s.decode=utf_8_encode,utf_8_decode
 def ru(s,x):return s.decode(x)[0]
 def ur(s,x):return s.encode(x)[0]
rus=Russian()
del Russian
class ZipInfo:
 def __init__(s,filename='NoName',date_time=(1980,1,1,0,0,0)):
  import struct
  s.pack,s.filename=struct.pack,filename.replace('\\','/')
  s.date_time,s.compress_type,s.comment,s.extra,s.create_system,s.create_version=date_time,0,'','',0,20
  s.extract_version,s.reserved,s.flag_bits,s.volume,s.internal_attr,s.external_attr=20,0,0,0,0,0
 def FileHeader(s):
  dt=s.date_time
  dosdate=(dt[0]-1980) << 9 | dt[1] << 5 | dt[2]
  dostime=dt[3] << 11 | dt[4] << 5 | (dt[5] // 2)
  if s.flag_bits & 0x08:CRC=compress_size=file_size=0
  else:CRC,compress_size,file_size=s.CRC,s.compress_size,s.file_size
  header=s.pack("<4s2B4H3l2H","PK\003\004",s.extract_version,s.reserved,s.flag_bits,s.compress_type,dostime,dosdate,CRC,compress_size,file_size,len(s.filename),len(s.extra))
  return header+s.filename+s.extra
class ZipFile:
 fp=None
 def __init__(s,file,mode="r"):
  import binascii,e32posix,time,imp,struct,_appuifw
  s.crc32,s.stat,s.localtime,dir=binascii.crc32,e32posix.stat,time.localtime,_appuifw.app.full_name()
  s.pack,s.unpack,dir=struct.pack,struct.unpack,str(dir[0])
  s.zlib=imp.load_dynamic('zlib',dir+':\\system\\apps\\instantsrz\\zlib.dll')
  s.debug,s.NameToInfo,s.filelist,s.compression,s._filePassed,s.filename=0,{},[],8,0,file
  s.mode=key=mode[0]
  modeDict={'r':'rb','w':'wb'}
  s.fp=open(file,modeDict[mode])
  if key=='r':s._GetContents()
 def _GetContents(s):
  fp=s.fp
  fp.seek(-22,2)
  filesize=fp.tell()+22
  endrec=s.unpack("<4s4H2lH",fp.read(22))
  size_cd,offset_cd,total=endrec[5],endrec[6],0
  x=filesize-22-size_cd
  concat=x-offset_cd
  s.start_dir=offset_cd+concat
  fp.seek(s.start_dir,0)
  while total<size_cd:
   centdir=s.unpack("<4s4B4H3l5H2l",fp.read(46))
   total=total+46
   filename=fp.read(centdir[12])
   x=ZipInfo(filename)
   x.extra=fp.read(centdir[13])
   x.comment=fp.read(centdir[14])
   total=(total+centdir[12]+centdir[13]+centdir[14])
   x.header_offset=centdir[18]+concat
   (x.create_version,x.create_system,x.extract_version,x.reserved,x.flag_bits,x.compress_type,t,d,x.CRC,x.compress_size,x.file_size)=centdir[1:12]
   x.volume,x.internal_attr,x.external_attr=centdir[15:18]
   x.date_time=((d>>9)+1980,(d>>5)&0xF,d&0x1F,t>>11,(t>>5)&0x3F,(t&0x1F)*2)
   s.filelist.append(x)
   s.NameToInfo[x.filename]=x
  for data in s.filelist:
   fp.seek(data.header_offset,0)
   fheader=s.unpack("<4s2B4H3l2H",fp.read(30))
   data.file_offset=(data.header_offset+30+fheader[10]+fheader[11])
   fname=fp.read(fheader[10])
 def namelist(s):
  l=[]
  for data in s.filelist:l.append(data.filename)
  return l
 def getinfo(s,name):return s.NameToInfo[name]
 def read(s,name):
  zinfo,filepos=s.getinfo(name),s.fp.tell()
  s.fp.seek(zinfo.file_offset,0)
  bytes=s.fp.read(zinfo.compress_size)
  s.fp.seek(filepos,0)
  dc=s.zlib.decompressobj(-15)
  bytes=dc.decompress(bytes)
  ex=dc.decompress('Z')+dc.flush()
  if ex:bytes=bytes+ex
  crc=s.crc32(bytes)
  return bytes
 def write(s,filename,arcname=None):
  st=s.stat(filename)
  mtime=s.localtime(st[8])
  date_time=mtime[0:6]
  if arcname is None:zinfo=ZipInfo(filename,date_time)
  else:zinfo=ZipInfo(arcname,date_time)
  zinfo.external_attr=st[0] << 16
  zinfo.compress_type=s.compression
  fp=open(filename,'rb')
  zinfo.flag_bits=0x00
  zinfo.header_offset=s.fp.tell()
  zinfo.CRC=CRC=0
  zinfo.compress_size=compress_size=0
  zinfo.file_size=file_size=0
  s.fp.write(zinfo.FileHeader())
  zinfo.file_offset=s.fp.tell()
  cmpr=s.zlib.compressobj(s.zlib.Z_DEFAULT_COMPRESSION,s.zlib.DEFLATED,-15)
  while 1:
   buf=fp.read(1024*8)
   if not buf:break
   file_size=file_size+len(buf)
   CRC=s.crc32(buf,CRC)
   buf=cmpr.compress(buf)
   compress_size=compress_size+len(buf)
   s.fp.write(buf)
  fp.close()
  buf=cmpr.flush()
  compress_size=compress_size+len(buf)
  s.fp.write(buf)
  zinfo.compress_size,zinfo.CRC,zinfo.file_size=compress_size,CRC,file_size
  position=s.fp.tell()
  s.fp.seek(zinfo.header_offset + 14,0)
  s.fp.write(s.pack("<lll",zinfo.CRC,zinfo.compress_size,zinfo.file_size))
  s.fp.seek(position,0),s.filelist.append(zinfo)
  s.NameToInfo[zinfo.filename]=zinfo
 def close(s):
  if s.mode=="w":
   count,pos1=0,s.fp.tell()
   for zinfo in s.filelist:
    count,dt=count+1,zinfo.date_time
    dosdate=(dt[0]-1980) << 9 | dt[1] << 5 | dt[2]
    dostime=dt[3] << 11 | dt[4] << 5 | (dt[5] // 2)
    centdir=s.pack("<4s4B4H3l5H2l","PK\001\002",zinfo.create_version,zinfo.create_system,zinfo.extract_version,zinfo.reserved,zinfo.flag_bits,zinfo.compress_type,dostime,dosdate,zinfo.CRC,zinfo.compress_size,zinfo.file_size,len(zinfo.filename),len(zinfo.extra),len(zinfo.comment),0,zinfo.internal_attr,zinfo.external_attr,zinfo.header_offset)
    s.fp.write(centdir),s.fp.write(zinfo.filename),s.fp.write(zinfo.extra),s.fp.write(zinfo.comment)
   pos2=s.fp.tell()
   endrec=s.pack("<4s4H2lH","PK\005\006",0,0,count,count,pos2-pos1,pos1,0)
   s.fp.write(endrec),s.fp.flush()
  if not s._filePassed:s.fp.close()
  s.fp=None
class EPOC:
 def __init__(s):
  import e32posix
  s.os,s.name=e32posix,''
 def exists(s,path):
  try:
   st=s.os.stat(path)
   return 1
  except:return 0
 def isfile(s,path):
  try:
   st=s.os.stat(path)
   return st[0]&0170000==0100000
  except:return 0
 def splitext(s,p):
  root,ext='',''
  for c in p:
   if c in ['/','\\']:root,ext=root+ext+c,''
   elif c=='.':
    if ext:root,ext=root+ext,c
    else:ext=c
   elif ext:ext=ext+c
   else:root=root+c
  return root,ext
 def split(s,p):
    if p[1:2]==':':d,p=p[0:2],p[2:]
    else:d,p='',p
    i=len(p)
    while i and p[i-1] not in '/\\':
     i=i-1
    head,tail=p[:i],p[i:]
    head2=head
    while head2 and head2[-1] in '/\\':
     head2=head2[:-1]
    head=head2 or head
    return d+head,tail
 def makedirs(s,name,mode=0777):
  head,tail=s.split(name)
  if not tail:head,tail=s.split(head)
  if head and tail and not s.exists(head):s.makedirs(head,mode)
  s.os.mkdir(name,mode)
 def is_zipfile(s,filename):
  try:
   fpin=open(filename,'rb')
   fpin.seek(-22,2)
   endrec=fpin.read()
   fpin.close()
   if endrec[0:4]=="PK\005\006" and endrec[-2:]=="\000\000":return 1
  except:None
 def path_and_name(s,path):
  sub=path.count('Series60ProductID')
  if sub:
   sp=path.split('Series60ProductID')
   realpath,name=sp[0]+'C',sp[len(sp)-1]
   s.name=name[:len(name)/sub]
   return realpath
  else:
   realpath,c,e,t='','c:\\','e:\\',path[:i]
   for i in range(len(path),0,-1):
    if not path[i:].count('\\'):
     if s.exists(c+t):
      if s.isfile(c+t):
       realpath,s.name=c+t,t
       break
      else:break
     elif s.exists(e+t):
      if s.isfile(e+t):
       realpath,s.name=e+t,t
       break
      else:break
    else:break
   return realpath+'C'
 def read_path(s,path):
  f,c,e=open(path),'c:\\','e:\\'
  sp,realpath=rus.ur(unicode(f.read(),'utf-8','ignore').replace('\x00','')).split(':\\'),[]
  f.close()
  for i in sp:
   t=i[:-1]
   if i==sp[len(sp)-1]:i=s.path_and_name(i)
   if s.exists(c+t):
    if s.isfile(c+t):realpath.append(c+t)
   elif s.exists(e+t):
    if s.isfile(e+t):realpath.append(e+t)
  realpath.append(path)
  return realpath
 def sis_files(s):
  dir,sp,usp='\\system\\install\\',[],[]
  ps=s.os.listdir('c:'+dir)
  for i in ps:
   if s.isfile('c:'+dir+i):sp.append('c:'+dir+i),usp.append(rus.ru('C: '+s.splitext(i)[0]))
  ps=s.os.listdir('e:'+dir)
  for i in ps:
   if s.isfile('e:'+dir+i):sp.append('e:'+dir+i),usp.append(rus.ru('E: '+s.splitext(i)[0]))
  return sp,usp  
 def srz_files(s):
  dir,sp,usp='e:\\others\\',[],[]
  ps=s.os.listdir(dir)
  for i in ps:
   ext=s.splitext(i)
   if ext[1]=='.srz':sp.append(dir+i),usp.append(rus.ru(ext[0]))
  return sp,usp
 def sis_in_others(s):
  dir,sp,usp='e:\\others\\',[],[]
  ps=s.os.listdir(dir)
  for i in ps:
   ext=s.splitext(i)
   if ext[1]=='.sis':sp.append(dir+i),usp.append(rus.ru(ext[0]))
  return sp,usp
 def unsrz(s):
  dir,sp,usp='\\system\\install\\srz\\',[],[]
  ps=s.os.listdir('c:'+dir)
  for i in ps:
   if s.isfile('c:'+dir+i):sp.append('c:'+dir+i),usp.append(rus.ru('C: '+s.splitext(i)[0]))
  ps=s.os.listdir('e:'+dir)
  for i in ps:
   if s.isfile('e:'+dir+i):sp.append('e:'+dir+i),usp.append(rus.ru('E: '+s.splitext(i)[0]))
  return sp,usp  
 def srz_proects(s):
  try:
   if s.os.listdir('e:\\others\\srz'):return ' есть'
   else:return 'а нет'
  except:return 'а нет'
 def create_srz(s,name,sp):
  f=open(name+'.txt','w')
  f.write(s.name),f.close()
  z=ZipFile('e:/others/'+s.name+'.srz','w')
  for i in sp:
   if i[0]=='c':
    try:z.write(i)
    except:None
   else:
    try:z.write(i,'!'+i[1:])
    except:None
   gui.yld()
  z.write(name+'.txt','name.txt')
  z.close(),s.os.remove(name+'.txt')
  return s.name+'.srz'
 def proverka_srz(s,path):
  try:
   if s.is_zipfile(path):
    z=ZipFile(path)
    try:
     name=z.read('name.txt')
     namelist,provpath=z.namelist(),0
     for i in namelist:
      if i[0]=='!':
       provpath=1
       break
     z.close()
     return name,provpath
    except:return 0,0
   else:return 0,0
  except:return 0,0
 def install_srz(s,dir,path):
  try:
   z=ZipFile(path)
   namelist=z.namelist()
   for i in namelist:
    if i[0]=='!':ext=dir+i[1:]
    else:ext=i
    if ext!='name.txt':
     try:f=open(ext,'w')
     except:
      s.makedirs(s.split(ext)[0])
      f=open(ext,'w')
     f.write(z.read(i)),f.close()
    gui.yld()
   z.close()
   return 1
  except:return 0
 def path_in_sis(s,path):
  rp=''
  try:
   f=open(path)
   sp=rus.ur(unicode(f.read(),'utf-8','ignore')).replace('\x00','').split(':\\')
   f.close()
   for i in sp:
    if i[:6].lower()=='system':
     fnd=i.find('Series60ProductID')
     if fnd>0:rp+=':\\'+i[:fnd]
     else:rp+=':\\'+i[:-1]+'\r\n'
  except:None
  return rp
 def srz_exists(s):
  path=s.os.listdir('e:\\others\\srz')
  for i in path:
   if i.lower() not in ['c','e','!','name.txt','uninstall.txt']:return 1
 def srz_tool(s):
  path,sp,n,u=['e:\\others\\srz'],[],'e:\\others\\srz\\name.txt','e:\\others\\srz\\uninstall.txt'
  for i in path:
   if s.isfile(i):sp.append(i)
   else:
    g=s.os.listdir(i)
    for j in g:path.append(i+'\\'+j)
  if n not in sp:
   name=rus.ur(gui.aw.query(rus.ru('Имя проекта:'),'text'))
   f=open(n,'w')
   f.write(name),f.close()
  else:
   f=open(n)
   name=f.read()
   f.close()
  gui.aw.note(rus.ru('Упаковка проекта'),'info'),gui.yld()
  f,z=open(u,'w'),ZipFile('e:/others/'+name+'.srz','w')
  for i in sp:
   if i not in [n,u]:z.write(i,i[14]+':'+i[15:]),f.write(i[14]+':'+i[15:]+'\n')
  f.close(),z.write(u,'!:\\system\\install\\srz\\'+name+'.txt')
  z.write(n,'name.txt'),z.close()
  gui.aw.note(rus.ru('Проект '+name+' упакован'),'conf')
 def uninstall(s,path):
  f=open(path)
  sp=f.read().split('\n')
  f.close()
  for i in sp:
   try:s.os.remove(i)
   except:None
   try:s.os.rmdir(s.split(i)[0])
   except:None
  s.os.remove(path)
sis=EPOC()
del EPOC
class Interface:
 def __init__(s):
  import _appuifw,e32,sys
  s.aw,s.yld,s.argument=_appuifw,e32.ao_yield,sys.argv
  s.sposis,s.mosis=sis.sis_in_others()
  srz=':\\system\\install\\srz'
  if not sis.exists('c'+srz):sis.makedirs('c'+srz)
  if not sis.exists('e'+srz):sis.makedirs('e'+srz)
 def aktiv(s):[s.sis_files,s.srz_files,s.srztool,s.sis_in_others,s.unsrz,s.about][s.lb.current()]()
 def sis_files(s):
  s.aw.app.body=s.lb=s.aw.Listbox(s.msis,s.create_srz)
  s.aw.app.exit_key_handler=s.main
 def srz_files(s):
  s.aw.app.body=s.lb=s.aw.Listbox(s.msrz,lambda:s.install_srz(0))
  s.aw.app.exit_key_handler=s.main
 def sis_in_others(s):
  s.aw.app.body=s.lb=s.aw.Listbox(s.mosis,s.sis_info)
  s.aw.app.exit_key_handler=s.main
 def unsrz(s):
  s.aw.app.body=s.lb=s.aw.Listbox(s.musrz,s.uninstall)
  s.aw.app.exit_key_handler=s.main
 def about(s):
  s.aw.app.body=s.text=s.aw.Text()
  s.text.color,s.text.focus=0x000000,False
  s.text.set(rus.ru('\tInstantSRZ\n\tv1.6 final\n\t\tby Shrim\n\n\tУниверсальная утилита для работы с установочными файлами\n\n\tНовое:\n Открытие srz архивов по умолчанию\n Создание собственных инсталяшек \n Деинсталлятор\n Сканер sis пакетов\n Пофиксены некоторые баги\n\n\tПоддержка проекта:\n WMR328410070116\n (telepat)\n\n\tРелиз для сайта\n\tDimonVideo.ru\n\n\tС Уважением\n\tShrim')) 
  s.text.set_pos(0)
  s.aw.app.exit_key_handler=s.main
 def main(s):
  s.spsis,s.msis=sis.sis_files()
  s.spsrz,s.msrz=sis.srz_files()
  s.spusrz,s.musrz=sis.unsrz()
  srz_proect=sis.srz_proects()
  s.menu=[(rus.ru('Установленые sis'),rus.ru('всего: ')+str(len(s.spsis))),(rus.ru('Упакованые srz'),rus.ru('всего: ')+str(len(s.spsrz))),(rus.ru('Сборщик srz'),rus.ru('проект'+srz_proect)),(rus.ru('Анализатор sis'),rus.ru('всего: ')+str(len(s.sposis))),(rus.ru('Деинсталлятор srz'),rus.ru('всего: ')+str(len(s.spusrz))),(u'About',rus.ru('о программе'))]
  s.aw.app.body=s.lb=s.aw.Listbox(s.menu,s.aktiv)
  s.aw.app.exit_key_handler=s.aw.app.set_exit
 def create_srz(s):
  ind=s.spsis[s.lb.current()]
  sis.name=sis.splitext(sis.split(ind)[1])[0]
  sp=sis.read_path(ind)
  name=s.aw.query(rus.ru('Имя srz архива:'),'text',rus.ru(sis.name))
  if name:
   s.aw.note(rus.ru('Подождите, идет упаковка архива'),'info')
   sis.name=rus.ur(name)
   name=sis.create_srz(ind,sp)
   s.aw.note(rus.ru('Архив '+name+' сохранён'),'conf') 
 def install_srz(s,ar):
  if ar:ind=s.argument[1]
  else:ind=s.spsrz[s.lb.current()]
  name,provpath=sis.proverka_srz(ind)
  if name:
   if s.aw.query(rus.ru('Установить '+name),'query'):
    if provpath:d=s.aw.popup_menu([rus.ru('диск С'),rus.ru('диск Е')],rus.ru('Выберите память:'))
    else:d=1
    if d in [0,1]:
     dir=['c','e'][d]
     p=sis.install_srz(dir,ind) 
     if p:s.aw.note(rus.ru('Успешно установлено'),'conf')
     else:s.aw.note(rus.ru('При установке произошла ошибка'),'info')
  else:s.aw.note(rus.ru('Файл битый'),'error')
  if ar:s.aw.app.set_exit()
 def sis_info(s):
  ind=s.sposis[s.lb.current()]
  path=sis.path_in_sis(ind)
  if path:
   s.aw.app.body=txt=s.aw.Text()
   txt.color,txt.focus=0x000000,False
   txt.add(rus.ru(path)),txt.set_pos(0)
   s.aw.app.exit_key_handler=s.sis_in_others
  else:s.aw.note(rus.ru('Ошибка анализа файла'),'error')
 def srztool(s):
  if not sis.srz_exists():sis.srz_tool(),s.main()
  else:s.aw.note(rus.ru('Ошибка проекта'),'error')
 def uninstall(s):
  ind=s.spusrz[s.lb.current()]
  name=s.musrz[s.lb.current()]
  if s.aw.query(rus.ru('Удалить ')+name[3:],'query'):s.yld(),sis.uninstall(ind),s.aw.note(rus.ru('Удалено'),'conf'),s.main()
gui=Interface()
del Interface
if len(gui.argument)==1:gui.main()
else:gui.install_srz(1)