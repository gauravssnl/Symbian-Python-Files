import appuifw,e32,keypress,uikludges
from key_codes import*

def ru(x):return x.decode('utf-8')

app_lock=e32.Ao_lock()

round = appuifw.Text()
appuifw.app.screen='normal'
round.set(ru('               by G.F.Ferre'))
appuifw.app.body=round

def exit():
 appuifw.app.set_exit()

def startcam():
 e32.start_exe('z:\\system\\programs\\apprun.exe','z:\\system\\apps\\Camcorder\\Camcorder.app')

uikludges.set_right_softkey_text(ru('Камера'))

def start5():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer5()

def functimer5():
 e32.ao_sleep(5)
 keypress.simulate_key(0xf845,0xf845)
 functimer5()

def start10():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer10()

def functimer10():
 e32.ao_sleep(10)
 keypress.simulate_key(0xf845,0xf845)
 functimer10()

def functimer15():
 e32.ao_sleep(15)
 keypress.simulate_key(0xf845,0xf845)
 functimer15()

def start15():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer15()

def functimer20():
 e32.ao_sleep(20)
 keypress.simulate_key(0xf845,0xf845)
 functimer20()

def start20():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer20()

def functimer25():
 e32.ao_sleep(25)
 keypress.simulate_key(0xf845,0xf845)
 functimer25()

def start25():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer25()

def functimer30():
 e32.ao_sleep(30)
 keypress.simulate_key(0xf845,0xf845)
 functimer30()

def start30():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer30()

def functimer35():
 e32.ao_sleep(35)
 keypress.simulate_key(0xf845,0xf845)
 functimer35()

def start35():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек'))
 e32.ao_sleep(x)
 startcam()
 functimer35()

def functimer40():
 e32.ao_sleep(40)
 keypress.simulate_key(0xf845,0xf845)
 functimer40()

def start40():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer40()

def functimer45():
 e32.ao_sleep(45)
 keypress.simulate_key(0xf845,0xf845)
 functimer()

def start45():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer45()

def functimer50():
 e32.ao_sleep(50)
 keypress.simulate_key(0xf845,0xf845)
 functimer()

def start50():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer50()

def functimer55():
 e32.ao_sleep(55)
 keypress.simulate_key(0xf845,0xf845)
 functimer()

def start55():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer55()

def functimer60():
 e32.ao_sleep(60)
 keypress.simulate_key(0xf845,0xf845)
 functimer()

def start60():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer60()

def functimer2():
 e32.ao_sleep(120)
 keypress.simulate_key(0xf845,0xf845)
 functimer()

def start2():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer2()

def functimer3():
 e32.ao_sleep(180)
 keypress.simulate_key(0xf845,0xf845)
 functimer()

def start3():
 x=appuifw.query(ru('Через сколько времени начать съемку(сек)?'),'number')
 x=(int(x))
 x1=(str(x))
 appuifw.note(ru('Съемка начнется через '+x1+' сек.'))
 e32.ao_sleep(x)
 startcam()
 functimer3()

def info():
 appuifw.note(ru('CamTimer v.1.00 by G.F.Ferre.ICQ:383351149'))

appuifw.app.menu=[(ru('Начать фотосъемку'),((ru('Каждые 5 секунд'),start5),(ru('Каждые 10 секунд'),start10),(ru('Каждые 15 секунд'),start15),(ru('Каждые 20 секунд'),start20),(ru('Каждые 25 секунд'),start25),(ru('Каждые 30 секунд'),start30),(ru('Каждые 35 секунд'),start35),(ru('Каждые 40 секунд'),start40),(ru('Каждые 45 секунд'),start45),(ru('Каждые 50 секунд'),start50),(ru('Каждые 55 секунд'),start55),(ru('Каждую 1 минуту'),start60),(ru('Каждые 2 минуты'),start2),(ru('Каждые 3 минуты'),start3))),(ru('О проге'),info),(ru('Выход'),exit)]

appuifw.app.exit_key_handler=startcam
app_lock.wait()