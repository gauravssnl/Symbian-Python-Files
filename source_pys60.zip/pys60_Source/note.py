# Copyright (c) 2005 Jurgen Scheible
# This script performs notes (pop-up notes) of different types: info, error, conf
# It uses the .note() function of the appuifw module
# appuifw.note(label, type)

# import the application user interface framework module
import appuifw

# info:
appuifw.note(u"Hello", "info")

# error:
appuifw.note(u"file not found", "error")

# conf:
appuifw.note(u"upload done", "conf")
