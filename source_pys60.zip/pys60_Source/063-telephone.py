
import telephone, e32

telephone.dial('+1412345602')
e32.ao_sleep(10)
telephone.hang_up()
