import PyKeyLock
import e32

print PyKeyLock.LockStatus()
PyKeyLock.Lock()
print PyKeyLock.LockStatus()
e32.ao_sleep(5)
PyKeyLock.Unlock()
print PyKeyLock.LockStatus()
