class Logger:
    def __init__(self, log_name):
        self.logfile = log_name
        self.mutex = thread.allocate_lock()
        
    def write(self, obj):
        self.mutex.acquire()
        try:
            log_file = open(self.logfile, 'a')
            log_file.write(obj)
            log_file.close()
        finally:
            self.mutex.release()
        
    def writelines(self, obj):
        self.write(''.join(list))
        
    def flush(self):
        pass
        

class Keyboard(object):
    """Класс работы с клавиатурой. Нагло взят и скопирован из какого-то стандартного приложения"""
    def __init__(self,onevent=lambda:None):
        self._keyboard_state={}
        self._downs={}
        self._onevent=onevent
    def handle_event(self,event):
        if event['type'] == appuifw.EEventKeyDown:
            code=event['scancode']
            if not self.is_down(code):
                self._downs[code]=self._downs.get(code,0)+1
            self._keyboard_state[code]=1
        elif event['type'] == appuifw.EEventKeyUp:
            self._keyboard_state[event['scancode']]=0
        self._onevent()
    def is_down(self,scancode):
        return self._keyboard_state.get(scancode,0)
    def pressed(self,scancode):
        if self._downs.get(scancode,0):
            self._downs[scancode]-=1
            return True
        return False
	
		
class Drow:
	def __init__(self):
		appuifw.app.screen='full'
		self.img=None
		appuifw.app.body=self.canvas=appuifw.Canvas(event_callback=keyboard.handle_event,redraw_callback=self.img_blit)
		self.img=Image.new(self.canvas.size)
		
	def hello(self):
		global bg
		self.img.clear(0xffffff)
		self.img.text((15,22), unicode("Circ v0.0.9", "utf8"),0xcc0000)
		self.img.text((10,33), unicode("Зайдите в настройки", "utf8"),0x000000)
		self.img.text((10,44), unicode("для изменения ника", "utf8"),0x000000)
		self.img.text((90,200), unicode("(с) Cyxapeff", "utf8"),0x000000)
		self.img_blit(())			
			
	def img_blit(self, two):
		if self.img:
			self.canvas.blit(self.img)
			
	def setting_profile(self):
		global selecto
		self.img.clear(0xffffff)
		p=1
		setting=("Ник:", "Пароль", "Хост:","Порт:","Канал:","Сообщение при выходе","Расположение скрина","Расположение лога",)
		self.img.rectangle((0,selecto*12+1,176,selecto*12+14),0xcccccc,fill=0xcccccc)
		for name in setting:
			self.img.text((10,p*12), unicode(name, "utf8"),0x000000,font=u""+config['font'])
			p+=1
		self.img.text((70,12), u""+config['nick'],0x000000,font=u""+config['font'])
		self.img.text((70,35), u""+config['host'],0x000000,font=u""+config['font'])
		self.img.text((70,47), u""+str(config['port']),0x000000,font=u""+config['font'])
		self.img.text((70,59), u""+config['chanal'],0x000000,font=u""+config['font'])
		
		#self.img.text((3,(selecto+1)*12), u"-",0x000000)
		self.img_blit(())
		
	def setting_display(self):
		global selecto
		self.img.clear(0xffffff)
		p=1
		setting=("Кодировка","Цвет фона","Цвет общего чата","Цвет Ваших сообщений","Цвет системных сообщений",
		"Цвет исходящего привата","Цвет входящего привата", "Цвет ошибки", "Цвет /me", "Шрифт", "Выскакивающее оповещение",
		"Popup в чате")
		self.img.rectangle((0,selecto*12+1,176,selecto*12+14),0xcccccc,fill=0xcccccc)
		for name in setting:
			self.img.text((10,p*12), unicode(name, "utf8"),0x000000,font=u""+config['font'])
			p+=1
		self.img.text((70,12), u""+config['encoding'],0x000000,font=u""+config['font'])
		
		#self.img.text((3,(selecto+1)*12), u"-",0x000000)
		self.img_blit(())
		
	def chat(self):
		global config,text,y,font,connect_run,kanal
		#while connect_run==True:
		self.img.clear(config['bg'])
		i=1
		st=1
		howmany=len(text[kanal])
		if howmany>=18:
			x=18
		else: 
			x=howmany
			y=0		
		i=i+y
		while i<=x+y:
			#print u"I="+str(i)+"\nY="+str(y)+"\n"
			if y!=0:
				while howmany<=i-1:
					y-=1
					i-=1
			if len(text[kanal][-i])>32:
				q=0
				while len(text[kanal][-i])/32+1>q:
					temp=text[kanal][-i][q*32:(q*32+32)]
					self.img.text((0,st*11), unicode(temp, config['encoding']),font[kanal][-i],font=u""+config['font'])
					q+=1
					st+=1
					if x>=18: x-1
				i+=1 
			else:
				self.img.text((0,st*11), unicode(text[kanal][-i], config['encoding']),font[kanal][-i],font=u""+config['font'])		
				i+=1
				st+=1
		self.img.line((174,0,174,self.img.size[1]-18),0xcccccc,width=2)
		h=(self.img.size[1]-18)/((len(text[kanal]))/18.0)
		ly2=(self.img.size[1]-18)/((len(text[kanal])+y)/18.0)
		ly1=h-ly2
		self.img.line((174,ly1,174,h+ly1),0x000000,width=1)		
		self.img.rectangle((0,self.img.size[1]-10,176,self.img.size[1]),0xcccccc,fill=0xcccccc)
		self.img.rectangle((1,self.img.size[1]-9,21,self.img.size[1]-1),0x000000,fill=0xcccccc)
		self.img.rectangle((1,self.img.size[1]-9,3*sysinfo.signal(),self.img.size[1]-1),0x000000,fill=0x000000)
		self.img.rectangle((154,self.img.size[1]-9,175,self.img.size[1]-1),0x000000,fill=0xcccccc)
		self.img.rectangle((154,self.img.size[1]-9,154+3*sysinfo.battery(),self.img.size[1]-1),0x000000,fill=0x000000)
		self.img.text((30,self.img.size[1]), u""+str(k+1)+"/"+str(len(text.keys()))+": "+kanal[:15],0x000000,font=u""+config['font'])
		self.img.text((120,self.img.size[1]), unicode(time.strftime("%H:%M",time.localtime(time.time())), config['encoding']),0x000000,font=u""+config['font'])
		self.img_blit(())
		
	def users(self):
		global userlist,config,x
		self.img.clear(0xffffff)
		i=0
		if x<=16:
			self.img.rectangle((0,x*12+1,176,x*12+14),0xcccccc,fill=0xcccccc)
		else:
			self.img.rectangle((0,16*12+1,176,16*12+14),0xcccccc,fill=0xcccccc)
		for name in userlist:
			i+=1
			if x<18:
				self.img.text((12,i*12), unicode(name, config['encoding']),0x000000,font=u""+config['font'])
				if i==17:
					break
			else:
				if i>x-17:
					#print "I:"+str(i)+"-"+str(i-(x-15)+1)
					self.img.text((12,(i-(x-16))*12), unicode(name, config['encoding']),0x000000,font=u""+config['font'])
					if i==x+1:
						break
		self.img_blit(())
		
	def save_screen(self):
		global config
		self.img.save(u"e:\\screen.png")
		appuifw.note(u"Screenshot saving!", "info")
		
	def wait(self):
		self.img.clear(0xffffff)
		self.img.text((30,70), unicode("Подождите...", "utf8"),0x000000,font=u""+config['font'])
		self.img_blit(())
		
	def loading(self, step):
		self.img.clear(0xffffff)
		self.img.text((30,70), unicode("Загрузка...", "utf8"),0x000000)
		self.img.rectangle((29,80,131,100),0x000000)
		self.img.rectangle((30,81,30+10*step,99),0xcccccc,fill=0xcccccc)
		self.img_blit(())
		
class Key:
	def setting(self,maxim):
		global selecto,press,profile_run,display_run
		while profile_run==True or display_run==True:
			if keyboard.is_down(EScancodeDownArrow):
				if maxim>selecto:
					selecto+=1
				e32.ao_sleep(0.2)
			if keyboard.is_down(EScancodeUpArrow):
				if 0<selecto:
					selecto-=1
				e32.ao_sleep(0.2)
			if keyboard.is_down(EScancodeSelect):
				keyboard.__init__()
				press=True
				
	def chat(self):
		global chat_run,y,kanal,k,change
		while chat_run==True:
			if keyboard.is_down(EScancodeDownArrow):
				if len(text[kanal])-1>y:
					y+=1
				e32.ao_sleep(0.1)
			if keyboard.is_down(EScancodeUpArrow):
				if y>0:
					y-=1
					e32.ao_sleep(0.1)
			if keyboard.is_down(EScancodeRightArrow):
				keys=text.keys()
				k+=1
				if len(keys)>k:
					kanal=keys[k];
				else:
					k=0
					kanal=keys[k];
				change=True
				e32.ao_sleep(0.2)
			if keyboard.is_down(EScancodeLeftArrow):
				keys=text.keys()
				k-=1
				if k>=0:
					kanal=keys[k];
				else:
					k=len(keys)-1
					kanal=keys[k];
				change=True
				e32.ao_sleep(0.2)
					
	def users(self):
		global users_run,x,userlist,selecto
		while users_run==True:
			if keyboard.is_down(EScancodeDownArrow):
				if len(userlist)-2>x:
					x+=1
				e32.ao_sleep(0.1)
			if keyboard.is_down(EScancodeUpArrow):
				if 0<x:
					x-=1
				e32.ao_sleep(0.1)
			if keyboard.is_down(EScancodeSelect):
				keyboard.__init__()
				selecto=True
				
class Menu:
	def hello(self):
		appuifw.app.exit_key_handler=exit
		appuifw.app.menu = [(unicode("Соединиться", "utf8"), connect), (unicode("Настройки", "utf8"), ((unicode("Профиль", "utf8"), setting.profile), (unicode("Дисплей", "utf8"), setting.display))), (unicode("Выход", "utf8"), exit)]
	
	def setting(self):
		appuifw.app.exit_key_handler=hello
		appuifw.app.menu = [(unicode("Сохранить", "utf8"), save_config), (unicode("Выход", "utf8"), exit)]
		
	def connect(self):
		appuifw.app.exit_key_handler=hello		
		appuifw.app.menu = [(unicode("Выход", "utf8"), exit)]
		
	def chat(self):
		appuifw.app.exit_key_handler=hello
		appuifw.app.menu = [(unicode("Отправить", "utf8"), send_msg), (unicode("Юзеры", "utf8"), users), (unicode("Зайти на канал", "utf8"), server.connect_chanal), (unicode("Скриншот", "utf8"), drow.save_screen), (unicode("Выход", "utf8"), exit)]
		
	def users(self):
		appuifw.app.exit_key_handler=chat
		appuifw.app.menu = [(unicode("Отправить в приват", "utf8"), server.send_privat), (unicode("Зайти на канал", "utf8"), server.connect_chanal), (unicode("Выход", "utf8"), exit)]
		
class Server:				
	def readline(self,z):
		q=[]
		while 1:
			c=z.recv(1)
			q.append(c)
			if c=='\n':
				break
		return """""".join(q)[:-2]
		
	def connect(self):
		global connect_run,s,config,kanal
		kanal="general"
		echo("open socket...","system","general")
		drow.chat()
		s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		echo("try connect...","system","general")
		drow.chat()
		addr=(config['host'],config['port'])
		try:
			s.connect(addr)
		except socket.error, msg:
			s.close()
			s=None
			hello()
		echo("connected.","system","general")
		drow.chat()
		i=0
		while i<3:
			data = server.readline(s)
			echo("< "+data,"system","general")
			i+=1
		echo("Sent Nick and Ident","system","general")
		drow.chat()
		s.send("PASS "+config['pass']+"\n")
		s.send("NICK "+config['nick']+"\n")
		s.send("USER "+ident+" localhost localhost :"+config['nick']+"\n")
		echo("OK! please wait...","system","general")
		drow.chat()
		i=0
		while i<10:
			data = server.readline(s)
			echo("< "+data,"system","general")
			drow.chat()
			i+=1
		s.send("JOIN "+config['chanal']+"\n")
		echo("try send join","system","general")
		echo("OK! Server (please wait...):","system","general")
		echo(unicode("Вы зашли на канал ","utf8").encode(config['encoding'])+config['chanal'].encode(config['encoding']), "system", config['chanal'])
		drow.chat()

	def chat(self):
		global data,config,chat_run,users2,s
		if chat_run==True:	
			fatal_errors=[401,402,431,432,433,436,444,465]
			errors=[403,405,406,407,408,409,410,411,412,413,414,421,422,423,424,441,442,443,445,446, \
			451,461,462,463,464,467,471,472,473,474,475,481,482,483,491,501,502]
			#print u""+data
			
			part=re.split(":",data)
			if len(part)>3:
				i=3
				while len(part)>i:
					part[2]=part[2]+":"+part[i]
					i+=1
			part1=re.split(" ",part[1])
			if part[0]=="PING ":
				s.send("PONG :"+part[1]+"\n")
			elif part1[1]=="PRIVMSG" and part1[2]!=config['nick']:
				nick=re.split("!",part[1])
				if part[2][1:7]=="ACTION":
					echo("> "+nick[0]+" "+part[2][8:-1],"me",part1[2])
				else:
					echo("> "+nick[0]+": "+part[2],"chat",part1[2])
				if unicode(part[2],config['encoding']).encode("ascii", "ignore").count(config['nick']):
					if config["popup2"]==1: popup()
			elif part1[1]=="PRIVMSG" and part1[2]==config['nick']:
				if config["popup"]==1: popup()
				nick=re.split("!",part[1])
				echo("> "+nick[0]+": "+part[2],"in_privat",nick[0])
			elif part1[1] in fatal_errors:
				echo("> "+part[2],"error","general")
				s.close()
			elif part1[1] in errors:
				echo("> "+part[2],"error","general")
			else:
				echo("> "+data,"system","general")
			e32.ao_sleep(0.01)
			
	def send_privat(self):
		global s,to_privat,config
		my_log.write("send privat\n")
		msg=None
		msg=appuifw.query(unicode("Msg:", "utf8"), "text")
		if msg!=None:
			s.send("PRIVMSG "+to_privat+" :"+msg.encode(config['encoding'])+"\n")
			echo("< "+config['nick']+": "+msg.encode(config['encoding']), "send_privat",to_privat)
		
	def users(self):
		global s,kanal,users2
		my_log.write("server users\n")
		End=False
		users2=[]
		s.send("NAMES "+kanal.encode("ascii", "ignore")+"\n")
		while End==False:
			is_readable = [s]
			is_writable = []
			is_error = []
			r, w, e = select.select(is_readable, is_writable, is_error, 0.3)
			if r:
				data=server.readline(s)
				part=re.split(":",data)
				part1=re.split(" ",part[1])
				if part1[1]=="353":
					users2+=re.split(" ", part[2])
				elif part1[1]=="366":
					End=True
			else:
				drow.wait()
				e32.ao_sleep(0.2)
			
	def connect_chanal(self):
		global s,config
		my_log.write("connect chanal\n")
		msg=appuifw.query(unicode("Введите название канала:", "utf8"), "text")
		if msg!=None:
			s.send("JOIN "+msg.encode(config['encoding'])+"\n")
			echo(unicode("Вы зашли на канал ", "utf8").encode(config['encoding'])+msg.encode(config['encoding']), "system", msg)
		
class Setting:
	def profile(self):
		global hello_run,profile_run,connect_run,chat_run,selecto,press,users_run,display_run
		my_log.write("profile\n")		
		hello_run=False
		profile_run=True
		display_run=False
		connect_run=False
		chat_run=False
		users_run=False
		selecto=0
		press=False
		menu.setting()
		thread.start_new_thread(key.setting,(7,))
		while profile_run==True:
			drow.setting_profile()
			if press==True: setting.edit("profile",selecto)
			e32.ao_sleep(0.2)
			
	def display(self):
		global hello_run,display_run,connect_run,chat_run,selecto,press,users_run,profile_run
		my_log.write("display\n")
		hello_run=False
		display_run=True
		profile_run=False
		connect_run=False
		chat_run=False
		users_run=False
		selecto=0
		press=False
		menu.setting()
		thread.start_new_thread(key.setting,(11,))
		while display_run==True:
			drow.setting_display()
			if press==True: setting.edit("display",selecto)
			e32.ao_sleep(0.2)
			
	def edit(self,screen,i):
		global config,press,fonts,encodings
		my_log.write("edit\n")
		if screen=="profile":
			if i==0: setting.edit_dialog(unicode("Ник:","utf8"), "text", "nick")
			elif i==1: config['pass']=setting.edit_dialog(unicode("Пароль:","utf8"), "text", "pass")
			elif i==2: config['host']=setting.edit_dialog(unicode("Хост:","utf8"), "text", "host")
			elif i==3: config['port']=setting.edit_dialog(unicode("Порт:","utf8"), "text", "port")
			elif i==4: config['chanal']=setting.edit_dialog(unicode("Канал:","utf8"), "text", "chanal")
			elif i==5: config['quit']=setting.edit_dialog(unicode("Сообщение:","utf8"), "text", "quit")
			elif i==6: config['img_save']=setting.edit_dialog(unicode("Папка для скрина:","utf8"), "text", "img_save")
			elif i==7: config['log_path']=setting.edit_dialog(unicode("Путь:","utf8"), "text", "log_path")
		elif screen=="display":
			if i==0: config['encoding']=encodings[appuifw.popup_menu(test_encoding())]
			elif i==1: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "bg")
			elif i==2: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "chat")
			elif i==3: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "send")
			elif i==4: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "system")
			elif i==5: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "send_privat")
			elif i==6: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "in_privat")
			elif i==7: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "error")
			elif i==8: setting.edit_dialog(unicode("Цвет:","utf8"), "number", "me")
			elif i==9: 
				test_font()
				config['font']=fonts[appuifw.popup_menu(test_font())]
			elif i==10: setting.edit_dialog(unicode("Отображать?:","utf8"), "number", "popup")
			elif i==11: setting.edit_dialog(unicode("Отображать?:","utf8"), "number", "popup2")
		press=False
		
	def edit_dialog(self,name, type_,conf):
		global config,press,fonts,encodings
		if type_!="number":
			string=u""+config[conf]
		else:
			string=config[conf]
		enter=appuifw.query(name, type_, string)
		if type_=="text" and enter!=None:
			enter.encode("ascii", "ignore").encode("utf8")
		if enter!=None:
			config[conf]=enter
		return config[conf]

#Пошли основыные функции:
def open_config():
	global config,config_path
	my_log.write("open config\n")
	F=open(config_path,'r')
	configa=F.readlines()
	F.close()
	a=[]
	config={}
	ints=("port","bg","chat","send","system","send_privat","in_privat","error","me","popup","popup2")
	for string in configa:
		a=re.split("=", string)
		#print u""+a[1][:-1]
		if a[0] in ints: config[a[0]]=int(a[1][:-1])
		else: config[a[0]]=a[1][:-1]
			
def hello():
	global hello_run,profile_run,display_run,connect_run,chat_run,users_run,s
	my_log.write("hello\n")
	hello_run=True
	profile_run=False
	display_run=False
	connect_run=False
	chat_run=False
	users_run=False
	
	menu.hello()
	if s!=None:
		s.send("QUIT :"+config["quit"]+"\n")
	while hello_run==True:
		drow.hello()
		e32.ao_sleep(0.1)
			
def exit():
	global hello_run,profile_run,display_run,connect_run,chat_run,users_run,s
	hello_run=False
	profile_run=False
	display_run=False
	connect_run=False
	chat_run=False
	users_run=False
	if s!=None:
		s.send("QUIT :"+config["quit"]+"\n")
		s.close()
	my_log.write("exit\n")
	appuifw.app.set_exit()
			
def connect():
	global hello_run,profile_run,display_run,connect_run,chat_run,s,config,ident,users_run
	my_log.write("start connect\n")	
	hello_run=False
	profile_run=False
	display_run=False
	connect_run=True
	chat_run=False
	users_run=False
	menu.connect()
	server.connect()
	chat()
	
def chat():
	global hello_run,profile_run,display_run,connect_run,chat_run,s,config,data,users_run,mess,bg,change,to_privat,y
	my_log.write("start chat\n")
	hello_run=False
	profile_run=False
	display_run=False
	connect_run=False
	chat_run=True
	users_run=False
	menu.chat()
	thread.start_new_thread(key.chat,())
	while chat_run==True:
		    is_readable = [s]
		    is_writable = []
		    is_error = []
		    r, w, e = select.select(is_readable, is_writable, is_error, 0.3)
		    if r:
			data=server.readline(s)
			server.chat()
			drow.chat()
		    else:
			drow.chat()
		    appuifw.app.focus=cb
		    if change==True:
			    y=0
			    if kanal!="general" and kanal[0:1]!="#":
				    to_privat=kanal
				    appuifw.app.menu = [(unicode("Отправить", "utf8"), server.send_privat), (unicode("Зайти на канал", "utf8"), server.connect_chanal), (unicode("Скриншот", "utf8"), drow.save_screen),(unicode("Выход", "utf8"), exit)]
			    elif kanal=="general":
				    appuifw.app.menu = [(unicode("Зайти на канал", "utf8"), server.connect_chanal),(unicode("Скриншот", "utf8"), drow.save_screen),(unicode("Выход", "utf8"), exit)]
			    else:
				    appuifw.app.menu = [(unicode("Отправить", "utf8"), send_msg), (unicode("Юзеры", "utf8"), users), (unicode("Зайти на канал", "utf8"), server.connect_chanal), (unicode("Скриншот", "utf8"), drow.save_screen), (unicode("Выход", "utf8"), exit)]
			    change=False
		    if bg==False and mess==True:
			    pfg.unset()
			    mess=False
			    
		
def send_msg():
	my_log.write("send msg\n")
	msg=appuifw.query(unicode("Сообщение:","utf8"), "text")
	if msg!=None:
		s.send("PRIVMSG "+kanal+" :"+msg.encode(config['encoding'])+"\n")
		echo("< "+config['nick']+": "+msg.encode(config['encoding']),"send",kanal)
		
def echo(textf,typet,kanall):
	global text,font,change,kanal
	if typet=="chat": color=config['chat']
	elif typet=="send": color=config['send'] 
	elif typet=="system": color=config['system']
	elif typet=="send_privat": color=config['send_privat']
	elif typet=="in_privat": color=config['in_privat']
	elif typet=="error": color=config['error']
	elif typet=="me": color=config['me']
	kanall=kanall.lower()
	if kanall in text.keys():
		text[kanall].append(textf)
		font[kanall].append(color)
	else:
		text[kanall]=[]
		font[kanall]=[]
		text[kanall].append(textf)
		font[kanall].append(color)
		kanal=kanall
		change=True
				
def save_config():
	global config_path,config
	my_log.write("save config\n")
	F=open(config_path,'w')
	ints=("port","bg","chat","send","system","send_privat","in_privat","error","me","popup","popup2")
	for key in config.keys():
		if key in ints: F.write(key+"="+str(config[key])+"\n")
		else: F.write(key+"="+config[key]+"\n")
	F.close()
	appuifw.note(unicode("Сохранено!","utf8"), "info")
	
def users():
	global hello_run,profile_run,display_run,connect_run,chat_run,users2,users_run,x,to_privat,userlist,selecto
	my_log.write("start users\n")
	hello_run=False
	profile_run=False
	display_run=False
	connect_run=False
	chat_run=False
	users_run=True
	selecto=False
	menu.users()
	userlist=[]
	x=0
	e32.ao_sleep(0.1)
	server.users()
	thread.start_new_thread(key.users,())
	for user in users2:
		if user[0:1]=="@": user=user[1:]
		userlist.append(user)
	while users_run==True:
		drow.users()
		e32.ao_sleep(0.1)
		if selecto==True:
			to_privat=userlist[x]
			server.send_privat()
			selecto=False
			users_run=False
			chat()
	
def cb(fg):
	global bg
	if fg:
		bg=False
	else:
		bg=True

def popup():
	global bg,pimg,ptext,pfg,mess
	if bg==True:
		pimg.clear((255, 255, 255))
		pimg.text((1, 10), ptext, 0)
		pfg.set(70, 44, pimg._bitmapapi())
		e32.ao_sleep(0.2) # 200 ms sleep
		mess=True
		
def test_encoding():
	global encodings
	files=os.listdir("e:\\System\\Libs\\encodings")
	for name in files:
		encodings.append(u""+name[:-3])
	return encodings
			
def test_font():
	global fonts
	fonts=appuifw.available_fonts()
	return fonts
	
def report():
	global p
	F1=open(p+"\\debug2.txt",'r')
	dat1=F1.read()
	F1.close()	
	F2=open(p+"\\debug.txt",'r')
	dat2=F2.read()
	F2.close()	
	s1=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	addr=('smtp.mail.ru',25)
	appuifw.note(unicode("Пожалуйста подождите","utf8"), "info")
	s1.connect(addr)
	data = server.readline(s1)
	s1.send('HELO mail\r\n')
	data = server.readline(s1)
	s1.send('AUTH LOGIN\r\n')
	data = server.readline(s1)
	s1.send('cHlzNjBfY2lyYw==\r\n')
	data = server.readline(s1)
	s1.send('cXdlYXNk\r\n')
	data = server.readline(s1)
	s1.send('MAIL FROM:pys60_circ@mail.ru\r\n')
	data = server.readline(s1)
	s1.send('RCPT TO:cyxapeff@plotinka.ru\r\n')
	data = server.readline(s1)
	s1.send('DATA\r\n')
	data = server.readline(s1)
	s1.send('Message from Circ v0.0.9 (rc2)\r\n')
	s1.send(dat1+"\r\n\r\n"+dat2+'\r\n')
	s1.send('\r\n.\r\n')
	data = server.readline(s1)
	s1.send('QUIT\r\n')
	data = server.readline(s1)
	s1.close()
	os.remove(p+"\\debug2.txt")

#Запуск этого всего дела:
#print "start irc \n"
from graphics import *
from key_codes import * 
import appuifw

keyboard=Keyboard()	
drow=Drow()

drow.loading(1)

text={}
font={}
y=0

hello_run=False
profile_run=False
display_run=False
connect_run=False
chat_run=False
users_run=False

hello_run=False
setting_run=False
connect_run=False
chat_run=False
bg=False
mess=False
change=False
ident="Python"
encodings=[]
fonts=[]
kanal="general"
k=0
s=None
import e32

drow.loading(2)
	
import socket	
drow.loading(3)

import re	
drow.loading(4)

import thread	
drow.loading(5)

import select
drow.loading(5)

import os
drow.loading(6)

import sysinfo
drow.loading(7)

import time
drow.loading(8)

import fgimage
e32.ao_yield()
drow.loading(9)

if os.path.exists("e:\\system\\apps\\circ\\irc.conf"):
	p="e:\\System\\Apps\\circ"
elif os.path.exists("c:\\system\\apps\\circ\\irc.conf"): 
	p="c:\\System\\Apps\\circ"
else:
	appuifw.note(unicode("Файл конфигурации не найден!","utf8"), "info")
	exit()

my_log = Logger(os.path.join(p, u"debug.txt"))

config_path=p+"\\irc.conf"
	
key=Key()
menu=Menu()

server=Server()
setting=Setting()

pimg = Image.new((110, 12))
pfg = fgimage.FGImage()

ptext = unicode("Новое сообщение", "utf8")
		
open_config()

e32._stdo(u""+p+'\\debug2.txt')
	
drow.loading(10)

if os.path.exists(p+"\\debug2.txt"):
	appuifw.note(unicode("В прошлый раз скрипт завершился некорректно!","utf8"), "info")
	appuifw.note(unicode("Пожалуйста, отправьте репорт об ошибке разработчику","utf8"), "info")	
	what=0
	what=appuifw.popup_menu([unicode("Да", "utf8"), unicode("Нет", "utf8")],unicode("Отправить?", "utf8"))
	if what==0:
		report()
		
os.remove(p+"\\debug.txt")

hello()