#by Albert927
import e32,appuifw,uikludges,rusos#use rusos by Shrim
a=appuifw
abt=a.Text
abl=a.Listbox
an=a.note
aq=a.query
ln,cn,ab,al=[],0,0,e32.Ao_lock()
def ag(n=-1):
 global ln,cn,ll,la
 if n==-1:n=ln.pop()
 else:ln.append(cn)
 cn,a.app.screen,a.app.menu,a.app.exit_key_handler,t=n,la[n][0],ll[n],ll[n][-1][1],uikludges.set_right_softkey_text(ll[n][-1][0])
 ar()
def ar():
 global la,cn,ab
 a.app.body=ab=la[cn][1]()
def ae():
 al.signal()
 a.app.set_exit()
def amq(m):return aq(m,'query')
def amt(m,d=''):return str(aq(m,'text',d))
def amo():an(u'\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u043e')
def ame():an(u'\u041e\u0448\u0438\u0431\u043a\u0430','error')
#
import os,time
class E:
 def __init__(s,d,e):s.d,s.e,s.f,s.l=d,e,'',[]
e=0
#
def ge():e.f=e.d+e.l[ab.current()]+e.e
def df():
 ge()
 try:os.remove(e.f)
 except:return ame()
 ar()
def daf():
 for i in e.l:
  try:os.remove(e.d+i+e.e)
  except:ame()
 ar()
#
def scbl():
 global e
 e=E('E:\\others\\scaner\\','.txt')
 try:os.makedirs(e.d)
 except:pass
 e.l=[]
 for i in os.listdir(e.d):
  if i.lower().endswith(e.e):e.l.append(i[:-len(e.e)])
 if len(e.l)==0:e.l.append('')
 L=abl(map(unicode,e.l),sclc)
 L.bind(8,df) 
 return L
#
def scd(d):
 f=scfn()
 if f=='None':return
 r=[]
 scg(d+':',r)
 scs(f+'_'+d+'_all',r)
 ar()

def scbd():
 f=scfn()
 if f=='None':return
 r=[]
 scg('C:',r)
 scg('E:',r)
 scs(f+'_all',r)
 ar()
#
def scrs():
 ge()
 if e.f[-8:-4]!='_all': return an(u'\u041d\u0443\u0436\u0435\u043d *_all')
 f=scfn()
 if f=='None':return
 r1,r2,d=scl(),[],e.f[-9]
 if d=='C' or d=='E':
  scg(d+':',r2)
  d='_'+d
 else:
  d=''
  scg('C:',r2)
  scg('E:',r2)
 rd,rn=[],[]
 for i in r1:
  if i not in r2:rd.append(i)
 for i in r2:
  if i not in r1:rn.append(i)
 md,mn,ld,ln='','',len(rd),len(rn)
 if ld!=0:
  md=u'\u0443\u0434\u0430\u043b\u0435\u043d\u043d\u044b\u0445 - '+unicode(str(ld))+u'\n'
  scs(f+d+'_del',rd)
 if ln!=0:
  mn=u'\u043d\u043e\u0432\u044b\u0445 - '+unicode(str(ln))
  scs(f+d+'_new',rn)
 if (ln+ld)!=0:
  an(u'\u041d\u0430\u0439\u0434\u0435\u043d\u043e:\n'+md+mn)
  ar()
 else:an(u'\u0418\u0437\u043c\u0435\u043d\u0435\u043d\u0438\u0439 \u043d\u0435\u0442')
#
def scg(d,r):
 r.append(d)
 if os.path.isdir(d):
  for i in os.listdir(d):scg(d+'\\'+i,r)

def scs(f,r):
 f=open(e.d+f+e.e,'w')
 for i in r:f.write(i+'\n\n')
 f.close()

def scl():
 s=open(e.f)
 r=s.read().split('\n\n')[:-1]
 s.close()
 return r

def scfn():return amt(u'\u0418\u043c\u044f \u0444\u0430\u0439\u043b\u0430',unicode(time.strftime('%m%d%H%M%S')))
#
def sclc():
 ge()
 try:f=open(e.f)
 except:return ame()
 t=f.read()
 f.close()
 ff=u'\u041d\u0430\u0439\u0434\u0435\u043d\u043e: '+unicode(str(len(t.split('\n\n'))-1))+u'\n\n'
 if e.f[-8:-4]=='_all':return an(ff)
 ag(1)
 ab.color=(0,0,0)
 ab.set(ff+rusos.ru(t))
 ab.set_pos(0)
 ab.focus=False
#
la=[
['normal',scbl],
['large',abt]]
ll=[
[(u'\u0421\u043a\u0430\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c',((u'\u043e\u0431\u0430 \u0434\u0438\u0441\u043a\u0430',scbd),(u'\u0434\u0438\u0441\u043a C:',lambda:scd('C')),(u'\u0434\u0438\u0441\u043a E:',lambda:scd('E')))),
(u'\u041f\u043e\u0432\u0442\u043e\u0440\u043d\u043e\u0435 \u0441\u043a\u0430\u043d-\u0438\u0435',scrs),
(u'\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0441\u0435',daf),
(u'\u0412\u044b\u0445\u043e\u0434',ae)],
[(u'\u041d\u0430\u0437\u0430\u0434',ag)]]
#
ag(0)
al.wait()