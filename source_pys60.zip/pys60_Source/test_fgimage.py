import e32
from graphics import *
import fgimage

img = Image.new((100, 16))
fg = fgimage.FGImage()
text = u"hello world, how are you doing"

# lets do simple scrolling

i = 0
while i < len(text):
    
    img.clear((0, 255, 255))
    img.text((0, 14), text[i:], 0)
    fg.set(0, 40, img._bitmapapi())
    e32.ao_sleep(0.2) # 200 ms sleep
    i += 1
    
fg.unset()


