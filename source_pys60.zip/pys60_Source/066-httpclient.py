
import urllib
page = urllib.urlopen("http://www.python.org").read()
print page
