#
# AOQueue.py
# 
# Copyright 2004 Helsinki Institute for Information Technology (HIIT)
# and the authors.  All rights reserved.
# 
# Authors: Ken Rimey <rimey@hiit.fi>
#

# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
A multi-producer, SINGLE-consumer queue.

AOQueue is like Queue, except that it assumes that get() only ever
gets called from the same thread that created the queue.  This thread
must have an associated active scheduler, and get() blocks on an
active-scheduler-aware lock instead of a normal Python thread lock.
"""

from Queue import Queue as _Queue
from Queue import Empty, Full

from AOLock import AOLock as _AOLock

class AOQueue(_Queue):
    def __init__(self, maxsize=0):
        import thread
        self._init(maxsize)
        self.mutex = thread.allocate_lock()
        self.esema = _AOLock()
        self.esema.acquire()
        self.fsema = thread.allocate_lock()

if __name__ == '__main__':
    import thread
    import time

    def get_nowait(q):
        try:
            return q.get(0)
        except Empty:
            return None

    def putter(q):
        time.sleep(0.1)
        q.put(1)
        q.put(2)
        q.put(3)
        q.put(4)
        time.sleep(0.1)
        for i in range(5, 1000):
            q.put(i)

    q = AOQueue()
    thread.start_new_thread(putter, (q,))
    assert get_nowait(q) == None
    assert q.get() == 1
    assert q.get() == 2
    time.sleep(0.1)
    assert q.get() == 3
    assert get_nowait(q) == 4
    assert get_nowait(q) == None
    for i in range(5, 1000):
        assert q.get() == i
    print "OK"
