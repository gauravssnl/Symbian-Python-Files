# пишите скрипты в utf8!!! это избавит вас от лишней головной боли!
# этот флаг будет отвечать за то, где мы запускаем программу. 
# В питоне или из-под отдельного апп. Если из питона - ставим False, иначе - ставим True.
# Таким образом, меняя только этот флаг. получаем скрипт для релиза или для отладки =)
# В ЭТОЙ ВЕРСИИ ЭТОТ ФЛАГ ОПРЕДЕЛЯЕТСЯ САМОСТОЯТЕЛЬНО!
# Шаблон создан Atrant при колоссальном содействии Shrim. Благодарности на atrant@front.ru
runninginstandaloneapp = True

import appuifw
import e32
import os
import sys

# О, Shrim, о, отец! куда без этих функций?!!!
def ru(x):
  return x.decode('utf-8')
def ur(x):
  return x.encode('utf-8')

# вывод сообщений, замена print если запускаем под отдельным апп
def printout(mess):
  appuifw.app.body.add(mess)
  appuifw.app.body.add(u"\n")

# так удобнее выводить сообщения
def anote(mess):
  appuifw.note(mess,"info")
def aerror(mess):
  appuifw.note(mess,"error")

# функцию выдрал из погоды от [kab]. Примите ее как есть
def print_exception():
  import sys
  import traceback
  type, value, tb = sys.exc_info()
  sys.last_type = type
  sys.last_value = value
  sys.last_traceback = tb
  tblist = traceback.extract_tb(tb)
  del tblist[:1]
  list = traceback.format_list(tblist)
  if list:
    list.insert(0, u"Trace:\n")
  list[len(list):] = traceback.format_exception_only(type, value)
  tblist = tb = None
  printout(unicode(str(list).replace("\\n","\n")))

def Test():
  try:
    anote(ru("Тест! Вызовем ошибку деления на ноль!"))
    a = 6 / 0 # вызываем ошибку деления на ноль
  except:
    aerror(ru("Косяк в проге, однако! =)"))
    print_exception()

def Exit():
  global script_lock
  script_lock.signal()
  if runninginstandaloneapp == True:
    appuifw.app.set_exit()

# определяем откуда запущен скрипт
app_path = ru(os.path.split(sys.argv[0])[0]+"\\")
if app_path.find(ru("Python")) != -1 or app_path.find(ru("Tower")) != -1:
  runninginstandaloneapp = False

if runninginstandaloneapp == True:
  appuifw.app.body = appuifw.Text()

printout(ru("Можно пробовать"))

appuifw.app.menu = [(ru("Тест"), Test),(ru("Выход"), Exit)]

script_lock = e32.Ao_lock()
if runninginstandaloneapp == False:
  old_handler = appuifw.app.exit_key_handler
  appuifw.app.exit_key_handler = Exit
  script_lock.wait() # здесь мы зависаем, пока не нажмут "выход"
  # возвращаем на место функцию под правой софт-клавишей
  appuifw.app.exit_key_handler = old_handler
print "exiting"