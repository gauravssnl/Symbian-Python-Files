# script by Dimontrans
# www.dimonvideo.ru
import appuifw
import uikludges
import e32
from key_codes import *
def ru(x):return x.decode('utf-8')
def ur(y):return y.decode('charset')
appuifw.app.title=ru('Keyboard')
appuifw.app.body=can=appuifw.Canvas()
dis=10
key_x1=4
key_y1=144-14
key_x2=key_x1-1+dis
key_y2=144-4
text_x=6
text_y=144-5
key_color=0xfff800
edge_color=0xff0000
cursor_x1=key_x1-1
cursor_y1=key_y2-dis-1
cursor_x2=key_x2+1
cursor_y2=cursor_y1+dis+2
hor=0
vert=0
numh=8
numv=30
uikludges.set_right_softkey_text(ru('Notes'))
def ntpd():
 e32.start_exe('z:\\system\\programs\\apprun.exe','z:\\system\\apps\\notepad\\notepad.app')
def board():
 can.rectangle((0,0,176,115),0x0)
 can.rectangle((1,1,175,114),0x00ff00)
 can.rectangle((2,2,174,113),0x00ff00)
 can.rectangle((3,3,173,112),0x0)
 can.rectangle((4,4,172,111),0x0)
 can.rectangle((4,53,172,111),0x0)
 can.rectangle((0,115,176,144),0x0,fill=0x00ff00)
 can.rectangle((key_x1,key_y1,key_x2,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis,key_y1,key_x2+dis,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*2,key_y1,key_x2+dis*2,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*3,key_y1,key_x2+dis*3,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*4,key_y1,key_x2+dis*4,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*5,key_y1,key_x2+dis*5,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*6,key_y1,key_x2+dis*6,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*7,key_y1,key_x2+dis*7,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*8,key_y1,key_x2+dis*8,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*9,key_y1,key_x2+dis*9,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*10,key_y1,key_x2+dis*10,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*11,key_y1,key_x2+dis*11,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*12,key_y1,key_x2+dis*12,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*13,key_y1,key_x2+dis*13,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*14,key_y1,key_x2+dis*14,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*15,key_y1,key_x2+dis*15,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*16,key_y1,key_x2+dis*16,key_y2),(edge_color),fill=(key_color))
 can.rectangle((key_x1,key_y1-dis-1,key_x2,key_y2-dis-1),(edge_color),fill=(edge_color))
 can.rectangle((key_x1+dis,key_y1-dis-1,key_x2+dis,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*2,key_y1-dis-1,key_x2+dis*2,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*3,key_y1-dis-1,key_x2+dis*3,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*4,key_y1-dis-1,key_x2+dis*4,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*5,key_y1-dis-1,key_x2+dis*5,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*6,key_y1-dis-1,key_x2+dis*6,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*7,key_y1-dis-1,key_x2+dis*7,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*8,key_y1-dis-1,key_x2+dis*8,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*9,key_y1-dis-1,key_x2+dis*9,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*10,key_y1-dis-1,key_x2+dis*10,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*11,key_y1-dis-1,key_x2+dis*11,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*12,key_y1-dis-1,key_x2+dis*12,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*13,key_y1-dis-1,key_x2+dis*13,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*14,key_y1-dis-1,key_x2+dis*14,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*15,key_y1-dis-1,key_x2+dis*15,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((key_x1+dis*16,key_y1-dis-1,key_x2+dis*16,key_y2-dis-1),(edge_color),fill=(key_color))
 can.rectangle((cursor_x1,cursor_y1,cursor_x2,cursor_y2),0x0)
board()
def reading():
 global numv
 import os
 can.rectangle((4,4,172,54),0x0,fill=0xffffff)
 file=open('e:\\system\\apps\\equotation\\temp.txt','rb')
 text=file.read()
 size=os.path.getsize('e:\\system\\apps\\equotation\\temp.txt')
 if size>30:
  copying()
 can.text((numh,numv),unicode(text))
def bttns():
 can.text((text_x,text_y),ru('.'))
 can.text((text_x+dis,text_y),ru(','))
 can.text((text_x+dis*2,text_y),ru('+'))
 can.text((text_x+dis*3,text_y),ru('-'))
 can.text((text_x+dis*4,text_y),ru('*'))
 can.text((text_x+dis*5,text_y),ru('/'))
 can.text((text_x+dis*6,text_y),ru('='))
 can.text((text_x+dis*7,text_y),ru('≈'))
 can.text((text_x+dis*8,text_y),ru('≠'))
 can.text((text_x+dis*9,text_y),ru('<'))
 can.text((text_x+dis*10,text_y),ru('≤'))
 can.text((text_x+dis*11,text_y),ru('>'))
 can.text((text_x+dis*12,text_y),ru('≥'))
 can.text((text_x+dis*13,text_y),ru('√'))
 can.text((text_x+dis*14,text_y),ru('±'))
 can.text((text_x+dis*15,text_y),ru('∫'))
 can.text((text_x+dis*16,text_y),ru('∑'))
 can.text((text_x,text_y-dis-1),ru('O'))
 can.text((text_x+2,text_y-dis-1),ru('|'))
 can.text((text_x+dis,text_y-dis-1),ru('C'))
 can.text((text_x+dis*2,text_y-dis-1),ru('%'))
 can.text((text_x+dis*3,text_y-dis-1),ru('‰'))
 can.text((text_x+dis*4,text_y-dis-1),ru('½'))
 can.text((text_x+dis*5,text_y-dis-1),ru('¼'))
 can.text((text_x+dis*6,text_y-dis-1),ru('ª'))
 can.text((text_x+dis*7,text_y-dis-1),ru('º'))
 can.text((text_x+dis*8,text_y-dis-1),ru('¹'))
 can.text((text_x+dis*9,text_y-dis-1),ru('²'))
 can.text((text_x+dis*10,text_y-dis-1),ru('³'))
 can.text((text_x+dis*11,text_y-dis-1),ru('ⁿ'))
 can.text((text_x+dis*12,text_y-dis-1),ru('∞'))
 can.text((text_x+dis*13,text_y-dis-1),ru('№'))
 can.text((text_x+dis*14,text_y-dis-1),ru('Ω'))
 can.text((text_x+dis*15,text_y-dis-1),ru('ω'))
 can.text((text_x+dis*16,text_y-dis-1),ru('Δ'))
bttns()
def down():
 global cursor_y1,cursor_y2,vert
 cursor_y1+=dis+1
 cursor_y2+=dis+1
 vert-=1
 board()
 bttns()
def up():
 global cursor_y1,cursor_y2,vert
 cursor_y1-=dis+1
 cursor_y2-=dis+1
 vert+=1
 board()
 bttns()
def right():
 global cursor_x1,cursor_x2,hor
 cursor_x1+=dis
 cursor_x2+=dis
 hor+=1
 board()
 bttns()
def left():
 global cursor_x1,cursor_x2,hor
 cursor_x1-=dis
 cursor_x2-=dis
 hor-=1
 board()
 bttns()
def delete():
 file=open('e:\\system\\apps\\equotation\\temp.txt','w')
 del file
 reading()
def select():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 if hor==0:
  if vert==0:
   file.write(ru('.'))
 if hor==1:
  if vert==0:
   file.write(ru(','))
 if hor==2:
  if vert==0:
   file.write(ru('+'))
 if hor==3:
  if vert==0:
   file.write(ru('-'))
 if hor==4:
  if vert==0:
   file.write(ru('*'))
 if hor==5:
  if vert==0:
   file.write(ru('/'))
 if hor==6:
  if vert==0:
   file.write(ru('='))
 if hor==7:
  if vert==0:
   file.write(ru('≈'))
 if hor==8:
  if vert==0:
   file.write(ru('≠'))
 if hor==9:
  if vert==0:
   file.write(ru('<'))
 if hor==10:
  if vert==0:
   file.write(ru('≤'))
 if hor==11:
  if vert==0:
   file.write(ru('>'))
 if hor==12:
  if vert==0:
   file.write(ru('≥'))
 if hor==13:
  if vert==0:
   file.write(ru('√'))
 if hor==14:
  if vert==0:
   file.write(ru('±'))
 if hor==15:
  if vert==0:
   file.write(ru('∫'))
 if hor==16:
  if vert==0:
   file.write(ru('∑'))
 if hor==0:
  if vert==1:
   exit()
 if hor==1:
  if vert==1:
   copying()
 if hor==2:
  if vert==1:
   file.write(ru('%'))
 if hor==3:
  if vert==1:
   file.write(ru('‰'))
 if hor==4:
  if vert==1:
   file.write(ru('½'))
 if hor==5:
  if vert==1:
   file.write(ru('¼'))
 if hor==6:
  if vert==1:
   file.write(ru('ª'))
 if hor==7:
  if vert==1:
   file.write(ru('º'))
 if hor==8:
  if vert==1:
   file.write(ru('¹'))
 if hor==9:
  if vert==1:
   file.write(ru('²'))
 if hor==10:
  if vert==1:
   file.write(ru('³'))
 if hor==11:
  if vert==1:
   file.write(ru('ⁿ'))
 if hor==12:
  if vert==1:
   file.write(ru('∞'))
 if hor==13:
  if vert==1:
   file.write(ru('№'))
 if hor==14:
  if vert==1:
   file.write(ru('Ω'))
 if hor==15:
  if vert==1:
   file.write(ru('ω'))
 if hor==16:
  if vert==1:
   file.write(ur('Δ'))
 file.close()
 board()
 bttns()
 reading()
can.bind(EKeyRightArrow,lambda:right())
can.bind(EKeyLeftArrow,lambda:left())
can.bind(EKeySelect,lambda:select())
can.bind(EKeyUpArrow,lambda:up())
can.bind(EKeyDownArrow,lambda:down())
can.bind(EKeyBackspace,lambda:delete())
can.bind(EKeyEdit,lambda:copying())
can.bind(EKey0,lambda:zero())
can.bind(EKey1,lambda:one())
can.bind(EKey2,lambda:two())
can.bind(EKey3,lambda:three())
can.bind(EKey4,lambda:four())
can.bind(EKey5,lambda:five())
can.bind(EKey6,lambda:six())
can.bind(EKey7,lambda:seven())
can.bind(EKey8,lambda:eight())
can.bind(EKey9,lambda:nine())
def zero():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('0'))
 file.close()
 board()
 bttns()
 reading()
def one():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('1'))
 file.close()
 board()
 bttns()
 reading()
def two():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('2'))
 file.close()
 board()
 bttns()
 reading()
def three():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('3'))
 file.close()
 board()
 bttns()
 reading()
def four():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('4'))
 file.close()
 board()
 bttns()
 reading()
def five():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('5'))
 file.close()
 board()
 bttns()
 reading()
def six():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('6'))
 file.close()
 board()
 bttns()
 reading()
def seven():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('7'))
 file.close()
 board()
 bttns()
 reading()
def eight():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('8'))
 file.close()
 board()
 bttns()
 reading()
def nine():
 file=open('e:\\system\\apps\\equotation\\temp.txt','a')
 file.write(ru('9'))
 file.close()
 board()
 bttns()
 reading()
def exit():
 copying()
 appuifw.app.set_exit()
def copying():
 import clipboard
 file=open('e:\\system\\apps\\equotation\\temp.txt','rb')
 text=file.read()
 clipboard.Set(text)
 can.text((numh,numv+55),ru('Copied to clipboard'))
 e32.ao_sleep(0.5)
 can.rectangle((4,53,172,111),0x0,fill=0xffffff)
appuifw.app.exit_key_handler=ntpd
delete()
def about():
 appuifw.note(ru('Dimontrans ICQ: 412580384\nDimonVideo.ru'))
appuifw.app.menu=[(ru('About'),about)]