#script by _virtual_machine_

import e32,e32posix,_appuifw

def ru(t):return t.decode('utf-8')
def ur(t):return t.encode('utf-8')

class main:
	def __init__(self):
		#self.lock=e32.Ao_lock()#
		self.path=_appuifw.app.full_name()[0]+':\\System\\Apps\\AppOFF\\'#:\\nokia\\scripts\\
		self.papp=':\\system\\apps\\'
		self.app_set(0)
		_appuifw.app.menu=[
		 (ru('Список'),(
		  (ru('инвертировать'),self.app_exc),
		  (ru('включить все'),lambda:self.app_for(self.app_on)),
		  (ru('отключить все'),lambda:self.app_for(self.app_off)))),
		 (ru('Помощь'),(
		  (ru('о программе'),lambda:self.help_name('about')),
		  (ru('упр-ие списком'),lambda:self.help_name('apps')))),
		 (ru('Выход'),_appuifw.app.set_exit)]
		_appuifw.app.exit_key_handler=_appuifw.app.set_exit#self.lock.signal
		#self.lock.wait()#
	def get_driver(self):
		try:
		    e32posix.stat('e'+self.papp)
		    return ['c','e']
		except:return ['c']
	def app_set(self,mode=1):
		if mode:index=_appuifw.app.body.current()
		self.apps=[]
		for driver in self.get_driver():
		    for app in e32posix.listdir(driver+self.papp):
		        if app[-4:]=='_off':self.apps.append(ru('+ | '+driver+': | '+app[:-4]))
		        else:self.apps.append(ru('- | '+driver+': | '+app))
		self.apps.insert(0,ru('Программ: '+str(len(self.apps))).center(21))
		if mode:_appuifw.app.body.set_list(self.apps,index)
		else:_appuifw.app.body=_appuifw.Listbox(self.apps,self.app_exc)
	def app_for(self,mode):
		for driver in self.get_driver():
		    for app in e32posix.listdir(driver+self.papp):mode(driver+self.papp+app)
		self.app_set()		
	def app_on(self,path):
		if path[-4:]=='_off':
		    try:e32posix.rename(path,path[:-4])
		    except:pass
	def app_off(self,path):
		if path[-4:]!='_off':
		    try:e32posix.rename(path,path+'_off')
		    except:pass
	def app_exc(self):
		index=_appuifw.app.body.current()
		if index!=0:
			path=self.apps[index][4]+self.papp+self.apps[index][9:]
			try:
				if self.apps[index][0]=='-':e32posix.rename(path,path+'_off')
				else:e32posix.rename(path+'_off',path)
			except:pass
		self.app_set()
	def help_exit(self):
		_appuifw.app.body,_appuifw.app.menu=self.old_body,self.old_menu
		self.app_set()
	def help_name(self,name):
		self.old_body,self.old_menu=_appuifw.app.body,_appuifw.app.menu
		_appuifw.app.body=_appuifw.Text()
		_appuifw.app.body.color=0
		_appuifw.app.body.focus=False
		if name=='about':_appuifw.app.body.set(ru('           О программе.\n\nНазвание: AppOFF 1.00\nАвтор: _virtual_machine_\nМесто жительства:\n   www.dimonvideo.ru\nВозможности программы:\n  -"отключение"\\\n"включение" программ.'))
		else:
		    file=open(self.path+'helps\\'+name+'.txt','r')
		    _appuifw.app.body.set(ru(file.read()))
		    file.close()
		_appuifw.app.body.set_pos(0)
		_appuifw.app.body.set_pos(170)
		_appuifw.app.menu=[(ru('Назад'),self.help_exit)]

main()