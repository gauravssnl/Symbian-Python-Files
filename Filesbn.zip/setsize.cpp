
static PyObject* SetFileSize(PyObject* /*self*/, PyObject *args) 

{ 
 char* fname;
 TInt size;
 RFs aFileServerSession;

 aFileServerSession.Connect();

 RFile afile;
 TBool isopen=false;

if (!PyArg_ParseTuple(args, "si", &fname,&size))
        {
        return 0;
        }
 TFileName *filename=new(ELeave)TFileName;
 CleanupStack::PushL(filename);
 TPtrC8 afnm;
 afnm.Set((const TUint8*)fname,strlen(fname));
 filename->Copy(afnm);
 aFileServerSession.IsFileOpen(*filename,isopen);
 if (isopen){
 CleanupStack::PopAndDestroy(filename);
 return Py_BuildValue("i",1);
 }
 TInt err=afile.Open(aFileServerSession, *filename, EFileWrite);
 CleanupStack::PopAndDestroy(filename);
 if (err!=KErrNotFound){
    err=afile.SetSize((TInt) size);
 }
 else err=1;
 afile.Close();
 aFileServerSession.Close();
 return Py_BuildValue("i",err);

}
