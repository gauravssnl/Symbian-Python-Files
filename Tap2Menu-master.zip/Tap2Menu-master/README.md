Tap2Menu
========

A virtual on-screen  menu button for symbian phones
