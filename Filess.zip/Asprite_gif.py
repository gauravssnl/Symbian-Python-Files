import appuifw as aw
import e32
import asprite

position =100, 150
sprite = asprite.New()
cd = sprite.load([u'e:\\smeh.gif'], [0.2])
spr = sprite.NewSprite(cd, 0)
sprite.target(spr, position)
sprite.activate()

lk = e32.Ao_lock()
def stop():
    lk.signal()
    sprite.close(spr)

aw.app.exit_key_handler = stop
lk.wait()
