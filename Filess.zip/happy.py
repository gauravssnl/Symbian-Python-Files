#^(OO)^HaPpy编制
import e32
import graphics
import appuifw
appuifw.app.set_exit()
from graphics import Image

appuifw.app.screen='full'
img=graphics.Image.open(u"e:\python\i.png")#所要打开的图片


appuifw.app.body=can=appuifw.Canvas()
can.blit(img)
g=0
i=0
while g<195:
    k=i
    appuifw.app.body.line([(30,297),(21+k,297)],(0xff00ff))
    appuifw.app.body.line([(30,298),(21+k,298)],(0xff0000))
    appuifw.app.body.line([(30,299),(21+k,299)],(0xff0000))
    appuifw.app.body.line([(30,300),(21+k,300)],(0xff0000))
    appuifw.app.body.line([(30,301),(21+k,301)],(0xff0000))
    appuifw.app.body.line([(30,302),(21+k,302)],(0xff0000))
    appuifw.app.body.line([(30,303),(21+k,303)],(0xff0000))
    appuifw.app.body.line([(30,304),(21+k,304)],(0xff0000))
    appuifw.app.body.line([(30,305),(21+k,305)],(0xff0000))
    appuifw.app.body.line([(30,306),(21+k,306)],(0xff0000))
    appuifw.app.body.line([(30,307),(21+k,307)],(0xff0000))
    appuifw.app.body.line([(30,308),(21+k,308)],(0xff0000))
    appuifw.app.body.line([(30,309),(21+k,309)],(0xff00f0))
    g=g+1
    i=i+1
    e32.ao_sleep(0.015)
e32.ao_sleep(0.5)