import appuifw
from graphics import *
import e32,math,os
from random import cunifvariate
import mcs 

m=mcs.New(u"e:\\python\\wav\\sample.wav",5)

t=[ m.load(u"e:\\python\\wav\\%s.wav"%i) for i in range(1,8)]

m.volume(20)
m.start()

appuifw.app.screen='full'
canvas=appuifw.Canvas()
appuifw.app.body=canvas
we,he=canvas.size
img=Image.new((we,he))

class Ball:
 def __init__(self,xy,c,s):
  self.xl=xy[0]; self.yl=xy[1]
 
  self.angle=cunifvariate(0,3.14)
  self.vx=math.sin(self.angle)
  self.vy=math.cos(self.angle)
  self.x=xy[0]; self.y=xy[1]
  self.speed=s 
  self.radius=4
  self.color=c
  self.co=0
  self.func=lambda x,x1,x2,p:  ((x >= x1  and p >0)and -p) or ((x <= x2 and p<0)and abs(p) ) 

 def mov(self):
  for i in al:
   if math.hypot((i[0]-self.x),(i[1]-self.y)) <= self.radius+i[2]/2:

    m.play(t[al.index(i)],10 )
    
    img.point((i[0],i[1]),i[3],width=i[2]+3)
    angle=math.atan2(self.x-i[0],self.y-i[1]) 
    pp=angle-math.atan(self.vx/self.vy)
    self.vx=math.sin(pp)
    self.vy=math.cos(pp)

 # границы окна
  f=self.func(self.x, we-self.radius, self.radius, self.vx)
  if f: self.vx=f; self.xl=self.x; self.yl=self.y   
  f=self.func(self.y, he-self.radius, self.radius, self.vy)
  if f: self.vy=f; self.xl=self.x; self.yl=self.y 

  self.x+=self.vx *self.speed
  self.y+=self.vy *self.speed

  img.point((self.x,self.y),self.color,width=self.radius*2)


ball=Ball([50,50],0xffffff,1.6)
ball1=Ball([90,50],0x00ff00,1.9)
ball2=Ball([50,90],0xff0000,1)
 
al=[[30,30,35,0xffff55],[20,80,40,0x008800],[80,120,40,0xff9933],[150,100,40,0xcc33cc],[110,50,40,0x880000],[40,180,44,0x009999],[140,160,34,0xbbcc77]]
 
run=1
paus=1

def pause(f):
 global m, paus
 if f: m.start(); paus=1
 else: m.pause(); paus=0

def endrun():
 global run,m
 del m; run=0

appuifw.app.exit_key_handler=endrun
appuifw.app.focus=pause

while run:
 if paus:
  img.clear(0)
  for i in al: img.point((i[0],i[1]),i[3],width=i[2])
  ball.mov()
  ball1.mov()
  ball2.mov()
  canvas.blit(img)
 e32.ao_sleep(0.04)

appuifw.app.focus=None