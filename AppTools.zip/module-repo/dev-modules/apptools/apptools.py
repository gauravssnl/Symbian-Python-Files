#
# apptools.py
# v1.0.0
import e32

if e32.s60_version_info>=(3,0):
    import imp
    _apptools= imp.load_dynamic('_apptools', 'kf_apptools.pyd')
    
else:
    import _apptools

del e32, imp

##appswitch

def switch_to_foreground(arg):
	#arg is application's caption#
    return _apptools.switch_to_fg(arg)

def switch_to_background(arg):
	#arg is application's caption#
    return _apptools.switch_to_bg(arg)

def end_app(arg):
    return _apptools.end_app(arg)

def kill_app(arg): 
    return _apptools.kill_app(arg)

def list_running_applications(ehidden=0,esystem=0):
    return _apptools.application_list(ehidden,esystem)

##applist

def list_installed_applications():
    return _apptools.applist()

def launch_application(AppUID):
    return _apptools.applaunch(AppUID)

#Many thanks to SajiSoft for providing help with converting C++ icon to Python Icon :D
import graphics
def get_icon(AppUID,size=48):
    img_ptr= _apptools.fetchicon(AppUID,size,1)
    return graphics.Image.from_cfbsbitmap(img_ptr)
    
def get_icon_mask(AppUID,size=48):
    img_ptr= _apptools.fetchicon(AppUID,size,2)
    return graphics.Image.from_cfbsbitmap(img_ptr)

##apptools

def new_sms(recipient,alias=""):
	#launches native sms editor, with 'recipient' number#
	return _apptools.launchsms(unicode(recipient),unicode(alias))


KMsgViews={'inbox':0x1002,'outbox':0x1003,'drafts':0x1004,'sent':0x1005}
	
def launch_messaging(view=1):
	if KMsgViews.has_key(view):
		view=KMsgViews[view]
	else:
		view=1
	return _apptools.launchinbox(view)
	
def launch_missed_calls():
	return _apptools.missed_calls_log()