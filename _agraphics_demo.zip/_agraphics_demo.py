import appuifw,math,time,e32,agraphics
from graphics import *

img=0
def redraw(rect): 
  if img: canvas.blit(img)

canvas=appuifw.Canvas(redraw_callback=redraw)
appuifw.app.screen="full"
appuifw.app.body=canvas

img=Image.new(canvas.size)

run=1
def exit():
   global run
   run=0

appuifw.app.exit_key_handler = exit

we,he=canvas.size
we,he=we/2,he/2
temp=-1
flag=1

def arrow(s,k):
  angle=s*math.pi/180
  x=k*math.sin(angle)+we
  y=k*math.cos(angle)+he
  return x,y

def switch():
  global flag
  flag^=1

canvas.bind(63557,switch)

while run:
  h,m,s=time.localtime()[3:6]
  if temp==s:  
     e32.ao_sleep(0.1)
     continue
  temp=s
  img.clear(0xeeeeee)

  for i in range(0,360,6):
     if  i%10: a=105
     else: a=90
     x,y=arrow(i,110)
     x2,y2=arrow(i,a)
     if flag: 
        agraphics.line(img,(x,y,x2,y2),0,(not i%90 and 3 or 1))
     else: 
        img.line((x,y,x2,y2),0,width=(not i%90 and 3 or 1))

  x,y=arrow((180-(h*30+m/2)),80)
  x1,y1=arrow((180-m*6),90)
  x2,y2=arrow((180-s*6),100)
 
  if (x2<=we): t=-6.0
  else: t=6.0
  k = ( y2-he)/ ((x2-we) and (x2-we) or -0.001)

  temp1=pow(k, 2)
  temp2=math.sqrt(1.0+temp1)
  a=t/temp2

  x4= x2 - (1.0+k)*a
  y4= y2 + (1.0-k)*a
  x5= x2 - (1.0-k)*a
  y5= y2 - (1.0+k)*a

  if flag:
     agraphics.ellipse(img,(we-111,he-111,we+111,he+111), 0x997722)
     agraphics.line(img,(x,y,we,he),0x000088,5)
     agraphics.line(img,(x1,y1,we,he),0x005500,2)
     agraphics.line(img,(x2,y2,we,he),0x992222,1)
     agraphics.polygon(img,[x2,y2, x4,y4, x5,y5],0x992222,1)
     agraphics.point(img,(we,he), 0x992222,7)

  else: 
     img.ellipse((we-111,he-111,we+111,he+111), 0x997722)
     img.line((x,y,we,he),0x000088,width=5)
     img.line((x1,y1,we,he),0x005500,width=2)
     img.line((x2,y2,we,he),0x992222)
     img.polygon((x2,y2,x4,y4,x5,y5),0x992222,0x992222)
     img.point((we,he), 0x992222,width=7)

  redraw(())