The `glob` and `fnmatch` Python modules packaged as a SIS file.

http://new.contextlogger.org/fnmatch-python/
