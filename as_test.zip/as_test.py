import audiostream, e32, appuifw
import TopWindow
from graphics import*


win=TopWindow.TopWindow()
win.size = (80,20)
win.position = (0,0)
img = Image.new(win.size)

appuifw.app.focus=lambda x:x and (win.show() or 1) or win.hide()

def func(num):
  img.clear(0xfefedd)
  img.text((5,15),({ 0:u'stop', 1:u'connected', 2:u'connect', 3:u'play' }[num]))
  win.add_image(img,(0,0))


st=audiostream.New(func)
st.play(u"http://radio.goha.ru:8000/grind.fm")

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit

app_lock.wait()
st.stop()
e32.ao_sleep(2)
del win,st
appuifw.app.focus=None
