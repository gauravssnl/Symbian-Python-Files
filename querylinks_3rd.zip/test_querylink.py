import querylinks,e32

def cb(x): print x

tone = 1 # 1-ConfirmationTone  2-WarningTone  3-ErrorTone else ENoTone

print querylinks.infobox(u"",u"[link]\n[link]\n[link1]\n[link2]\n[link3]\n[link4]",cb,tone)

