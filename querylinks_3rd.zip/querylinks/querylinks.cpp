#include <aknmessagequerydialog.h> //CAknMessageQueryDialog
#include <aknnotewrappers.h> //CAknInformationNote
#include <badesca.h>

#include "Python.h"
#include "symbian_python_ext_util.h"


//--------------------------------------------------------------------------

LOCAL_C TInt OpenLink(TAny* aVal)
{
	PyEval_CallObject((PyObject*)Dll::Tls(), Py_BuildValue("(i)", aVal));
	return EFalse;
}

//--------------------------------------------------------------------------

static PyObject* Info(PyObject* /*self*/,PyObject* args)
{
 PyObject* obj_header;
 PyObject* obj_text;
 PyObject* obj_callback;
 TUint8 _tone=0;
 
 if (!PyArg_ParseTuple(args, "UUO|i", &obj_header, &obj_text, &obj_callback, &_tone))
    return NULL;


 TPtrC header((TUint16*) PyUnicode_AsUnicode(obj_header),
                           PyUnicode_GetSize(obj_header));


 TPtrC text((TUint16*) PyUnicode_AsUnicode(obj_text),
                           PyUnicode_GetSize(obj_text));
                           


 Dll::SetTls((TAny*)obj_callback);
 CDesC16ArrayFlat*  listlink = new (ELeave) CDesC16ArrayFlat(1);

 RBuf buf;
 buf.CreateL(text.Length());
 buf.Copy(text);
 TInt start, end, pos;
 _LIT(KSl, "[");
 _LIT(KSr, "]");

 while( (start = buf.Find(KSl)) != -1 )
 {
   end = buf.Right(buf.Length()-start).Find(KSr);
   if (end != -1)
   {
     buf.Delete(start,1);
     buf.Delete(start+end-1,1);
     
     TFileName link;
     link.Copy(buf.Mid(start,end-1));
     if(listlink->Find(link,pos)) //no matching
       listlink->AppendL(link);
   }
   else break;
 }

 CAknQueryDialog::TTone tone = _tone==1?CAknQueryDialog::EConfirmationTone:
                               _tone==2?CAknQueryDialog::EWarningTone:
                               _tone==3?CAknQueryDialog::EErrorTone:
                               CAknQueryDialog::ENoTone;
   
 CAknMessageQueryDialog* dialog = CAknMessageQueryDialog::NewL(buf,tone);
	CleanupStack::PushL(dialog);
 dialog->SetHeaderText(header);

 for(TInt i=0; i < listlink->Count(); i++)
	{
    TCallBack callback(OpenLink, (TAny*)i);
    dialog->SetLink( callback );
    dialog->SetLinkTextL((*listlink)[i]);
	}

 CleanupStack::Pop(dialog);
	TInt ret = dialog->ExecuteLD(R_AVKON_MESSAGE_QUERY_DIALOG);

 listlink->Reset();
 delete listlink;
 buf.Close();
 
	return  Py_BuildValue("i",ret);
  
}

//--------------------------------------------------------------------------

static const PyMethodDef geticon_met[] = {
    {"infobox", (PyCFunction)Info, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("querylinks", geticon_met);
}

//--------------------------------------------------------------------------
