import txtfield,sys,e32,appuifw

sys.setdefaultencoding("utf-8")

canvas=appuifw.Canvas()
appuifw.app.screen="full"
appuifw.app.body=canvas
canvas.clear(0)

font=txtfield.LoadFont(u"e:\\python\\abc.gdr")
txt=txtfield.New((5,5,170,150),cornertype=txtfield.ECorner5)
txt.bgcolor(0xfefeee)
txt.textstyle(u"abc", color=0x881111, style=u"bold")
txt.add(unicode(str(copyright)))

app_lock = e32.Ao_lock() 
def exit(): app_lock.signal()
appuifw.app.exit_key_handler = exit

app_lock.wait()

del txt
txtfield.RemoveFont(font) 