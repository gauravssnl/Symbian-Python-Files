swtools_API.txt - the use of the module.
Module-repo folder placed in the same folder as the wrapper for Python 2.0.0, so that the directory module has got in there being a repository of modules.
