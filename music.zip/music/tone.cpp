//
// Tone adapter extension example.
// Based on the tone adapter example from http://www.newlc.com/article.php3?id_article=196
//

#include <MdaAudioTonePlayer.h>
#include "Python.h"
#include "symbian_python_ext_util.h"

class CToneAdapter : public CBase, public MMdaAudioToneObserver {
public:
// Standard two-phase construction
static CToneAdapter* NewL(TInt aFrequency, const TTimeIntervalMicroSeconds& aDuration);
static CToneAdapter* NewLC(TInt aFrequency, const TTimeIntervalMicroSeconds& aDuration);
~CToneAdapter();
void PlayL(); // Call this from somewhere else in your code to play the current note
TInt MaxVolume();
void SetVolume(TInt aVolume);

public: // inherited from MMdaAudioToneObserver
void MatoPrepareComplete(TInt aError);
void MatoPlayComplete(TInt aError);
   
private:
CToneAdapter(TInt aFrequency, const TTimeIntervalMicroSeconds& aDuration);
void ConstructL();
TInt iFrequency;
TTimeIntervalMicroSeconds iDuration;
TInt iVolume;
CMdaAudioToneUtility* iMdaAudioToneUtility;
};


// Frequency and duration of the tone to be played
CToneAdapter::CToneAdapter(TInt aFrequency, const TTimeIntervalMicroSeconds& aDuration)
                : iFrequency(aFrequency), iDuration(aDuration), iVolume(-1)
   {
   }

CToneAdapter* CToneAdapter::NewL(TInt aFrequency, const TTimeIntervalMicroSeconds& aDuration)
   {
   CToneAdapter* self = NewLC(aFrequency, aDuration);
   CleanupStack::Pop(); // self
   return self;
   }

CToneAdapter* CToneAdapter::NewLC(TInt aFrequency, const TTimeIntervalMicroSeconds& aDuration)
   {
   CToneAdapter* self = new(ELeave)CToneAdapter(aFrequency, aDuration);
   CleanupStack::PushL(self);
   self->ConstructL();
   return self;
   }

void CToneAdapter::ConstructL()
   {
   iMdaAudioToneUtility = CMdaAudioToneUtility::NewL(*this);

   }

CToneAdapter::~CToneAdapter()
   {
   delete iMdaAudioToneUtility;    
   }

TInt CToneAdapter::MaxVolume()
   {
	   return iMdaAudioToneUtility->MaxVolume();
   }

void CToneAdapter::SetVolume(TInt aVolume)
{
	if (aVolume<=MaxVolume()) iVolume = aVolume;
	else iVolume = MaxVolume();
}

// Note that this implementation of the virtual function does not leave.
void CToneAdapter::PlayL()
{
   // if iVolume has been set (not -1) then call SetVolume
   if (iVolume > -1) iMdaAudioToneUtility->SetVolume(iVolume);
	// Configure the audio tone utility to play a single tone
   iMdaAudioToneUtility->PrepareToPlayTone(iFrequency, TTimeIntervalMicroSeconds(iDuration));
}


// from MMdaAudioToneObserver
void CToneAdapter::MatoPrepareComplete(TInt /*aError*/)
{
    iMdaAudioToneUtility->Play();
}

// from MMdaAudioToneObserver
void CToneAdapter::MatoPlayComplete(TInt /*aError*/)
{
  delete this;
}

static TInt DoGetMaxVolume()
{
  TTimeIntervalMicroSeconds duration((TInt64)10);
  CToneAdapter* tone_adapter = CToneAdapter::NewLC(10,duration); // arg vals don't matter
  TInt maxVolume = tone_adapter->MaxVolume();
  CleanupStack::PopAndDestroy();
  return maxVolume;
}

static void DoPlayToneL(TInt aFrequency, const TTimeIntervalMicroSeconds& aDuration, TInt& aVolume)
{
	CToneAdapter* tone_adapter = CToneAdapter::NewL(aFrequency,aDuration);
	tone_adapter->SetVolume(aVolume);
	tone_adapter->PlayL();
}

///////////////////////////////////////////
//// PYTHON INTEGRATION CODE //////////////
///////////////////////////////////////////

static PyObject* play_tone(PyObject* /*self*/, PyObject* args)
{
  TInt freqInt, durationInt, volumeInt;
  if (!PyArg_ParseTuple(args, "iii", &freqInt, &durationInt, &volumeInt))
  {
    return NULL;
  }
  TInt64 durationInt64 = durationInt;
  TTimeIntervalMicroSeconds duration(durationInt64);

  TUint16 freq = static_cast<TUint16>(freqInt);
  if ((freq <= 0) ||
      ((durationInt < 0 || durationInt > 20000)))  // 20 second limit
      return SPyErr_SetFromSymbianOSErr(KErrArgument);

  TInt error;
  Py_BEGIN_ALLOW_THREADS;
  TRAP(error, DoPlayToneL(freq, duration, volumeInt));
  Py_END_ALLOW_THREADS;
  if (error)
      return SPyErr_SetFromSymbianOSErr(error);
  return Py_BuildValue("i", 1);
}

static PyObject* get_max_volume(PyObject* /*self*/, PyObject* /*args*/)
{
  TInt error;
  TInt maxVolume = 0;
  Py_BEGIN_ALLOW_THREADS;
  TRAP(error, maxVolume = DoGetMaxVolume());
  Py_END_ALLOW_THREADS;
  if (error)
      return SPyErr_SetFromSymbianOSErr(error);
  return Py_BuildValue("i", maxVolume);
}

static const PyMethodDef tone_methods[] = {
/*******************************************************/
    {"tone", (PyCFunction)play_tone, METH_VARARGS, "plays a tone."},
	{"loudest", (PyCFunction)get_max_volume, METH_VARARGS, "returns max volume."},
    {0, 0}
};

DL_EXPORT(void) MODULE_INIT_FUNC()
{
  /* PyObject* module = */
    Py_InitModule("music", tone_methods);
}

/*******************************************************
 This function is mandatory in Symbian DLL's. */

GLDEF_C TInt E32Dll(TDllReason)
{
  return KErrNone;
}

