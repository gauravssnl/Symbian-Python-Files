
import mcs,keycapture,appswitch,e32
def ru(x):return x.decode('utf-8')
m=mcs.New()
t0=m.load(u'c:\\0.wav')
t1=m.load(u'c:\\1.wav')
t2=m.load(u'c:\\2.wav')
t3=m.load(u'c:\\3.wav')
t4=m.load(u'c:\\4.wav')
t5=m.load(u'c:\\5.wav')
t6=m.load(u'c:\\6.wav')
t7=m.load(u'c:\\7.wav')
t8=m.load(u'c:\\8.wav')
t9=m.load(u'c:\\9.wav')
def d(keycode): 
 x=appswitch.application_list(1 )[0] 
 if x not in map(ru, ('Телефон', 'Реж. ожидан.')): return 
 if keycode==48:
  m.play(t0,15)
 elif keycode==49:
  m.play(t1,15)
 elif keycode==50:
  m.play(t2,15)
 elif keycode==51:
  m.play(t3,15)
 elif keycode==52:
  m.play(t4,15)
 elif keycode==53:
  m.play(t5,15)
 elif keycode==54:
  m.play(t6,15)
 elif keycode==55:
  m.play(t7,15)
 elif keycode==56:
  m.play(t8,15)
 elif keycode==57:
  m.play(t9,15)
k=keycapture.KeyCapturer(d)
k.keys=[48,49,50,51,52,53,54,55,56,57]
m.volume(100)
k.forwarding=1
m.start() 
k.start()
e32.start_exe('phone.exe','')
lock=e32.Ao_lock()
lock.wait()