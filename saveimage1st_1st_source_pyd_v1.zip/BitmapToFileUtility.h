#ifndef IMAGESAVER1ST_H
#define IMAGESAVER1ST_H

#include <MdaImageConverter.h>
#include <fbs.h>


class CImageSaver : public CBase, public MMdaImageUtilObserver
 {
public:
 static CImageSaver* NewL(CFbsBitmap& aBitmap);
 static CImageSaver* NewLC(CFbsBitmap& aBitmap);
 ~CImageSaver();

protected:
 void MiuoConvertComplete(TInt aError);
 void MiuoCreateComplete(TInt aError);
 void MiuoOpenComplete(TInt aError);

private:
 void ConstructL();
 CImageSaver(CFbsBitmap& aBitmap);

public:
 void Save(const TFileName& aFileName,TMdaClipFormat* format);

private:
 CMdaImageBitmapToFileUtility* iFileSaver;
 CActiveSchedulerWait* iWait;
 CFbsBitmap& iBitmap;
 };


#endif

