#include "BitmapToFileUtility.h"

//-------------------------------------------------------------------------

CImageSaver::CImageSaver(CFbsBitmap& aBitmap):iBitmap(aBitmap){}

//-------------------------------------------------------------------------

CImageSaver::~CImageSaver()
{
  delete iFileSaver;
  delete iWait;
}

//-------------------------------------------------------------------------

CImageSaver* CImageSaver::NewL(CFbsBitmap& aBitmap)
{
  CImageSaver* self = CImageSaver::NewLC(aBitmap);
  CleanupStack::Pop( self );
  return self;
}

//-------------------------------------------------------------------------

CImageSaver* CImageSaver::NewLC(CFbsBitmap& aBitmap)
{
  CImageSaver* self = new ( ELeave ) CImageSaver(aBitmap);
  CleanupStack::PushL( self );
  self->ConstructL();
  return self;
}

//-------------------------------------------------------------------------

void CImageSaver::ConstructL()
{
  iFileSaver = CMdaImageBitmapToFileUtility::NewL(*this);
  iWait = new (ELeave) CActiveSchedulerWait();
}


//-------------------------------------------------------------------------

void CImageSaver::Save(const TFileName& aFileName,TMdaClipFormat* format)
{
  iFileSaver->CreateL(aFileName, format, NULL, NULL);
  iWait->Start();
}

//-------------------------------------------------------------------------

void CImageSaver::MiuoConvertComplete(TInt aError)
{
  iWait->AsyncStop();
}

//-------------------------------------------------------------------------

void CImageSaver::MiuoCreateComplete(TInt aError)
{
  if (aError == KErrNone){
     iFileSaver->ConvertL(iBitmap);
     }
  else{
     iWait->AsyncStop();
     }
}

//-------------------------------------------------------------------------

void CImageSaver::MiuoOpenComplete(TInt aError)
{

}
