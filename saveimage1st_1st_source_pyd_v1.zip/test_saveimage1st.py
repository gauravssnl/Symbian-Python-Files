import SaveImage1st,e32
from graphics import *

img=Image.new((50,50))
img.rectangle((0,0,50,50),0x66dd22,0x66dd22)
img.line((0,0,50,50),0xffffff)

#1-jpg 2-png 3-gif (not compatible with Ngage)
# NEW
#4-bmp 5-mbm 6-wbmp 7-wmf 8-Apmwmf 9-wmfclp 10-ota
SaveImage1st.save(img,u'e:\\test.jpg',1) # save img to jpg

SaveImage1st.save(img,u'e:\\test.png',2) # save img to png

