#include "BitmapToFileUtility.h"
#include "Python.h"
#include "symbian_python_ext_util.h"
//#include <MediaClientImage.h>
#include <mdaimageconverter.h>

// http://flylib.com/books/en/2.338.1.113/1/

//--------------------------------------------------------------------------

static PyObject* Save(PyObject* /*self*/,PyObject* args)
{
 
 PyObject* obj_img;
 PyObject* obj_filename;
 TInt num_format;  //1-jpg 2-png else gif
 
 if (!PyArg_ParseTuple(args, "OUi", &obj_img, &obj_filename,&num_format))
    return NULL;

 TPtrC filename((TUint16*) PyUnicode_AsUnicode(obj_filename),
                           PyUnicode_GetSize(obj_filename));

 CFbsBitmap *bitmap = (CFbsBitmap*)PyCObject_AsVoidPtr(
                       PyObject_CallObject(PyObject_GetAttrString(
                       obj_img,"_bitmapapi"),NULL));

 CImageSaver* imgsaver = CImageSaver::NewL(*bitmap);
 
 TMdaClipFormat* format ;

/*
2nd
   format = new (ELeave) TMdaGif89aClipFormat;

*/
 
 if(num_format == 1)
   format = new (ELeave) TMdaJfifClipFormat;
 else if(num_format == 2)
   format = new (ELeave) TMdaPngClipFormat;
 else if(num_format == 4)
   format = new (ELeave) TMdaBmpClipFormat;
 else if(num_format == 5)
   format = new (ELeave) TMdaMbmClipFormat;
 else if(num_format == 6)
   format = new (ELeave) TMdaWbmpClipFormat;
 else if(num_format == 7)
   format = new (ELeave) TMdaWmfClipFormat;
 else if(num_format == 8)
   format = new (ELeave) TMdaWmfApmClipFormat;
 else if(num_format == 9)
   format = new (ELeave) TMdaWmfClpClipFormat;
 else
   format = new (ELeave) TMdaOtaClipFormat;
 
 
 
 imgsaver->Save(filename,format);
 
 delete imgsaver;
 delete format;

	Py_INCREF(Py_None);
	return Py_None;
}

//--------------------------------------------------------------------------

static const PyMethodDef image1st_met[] = {
    {"save", (PyCFunction)Save, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("SaveImage1st", image1st_met);
}
//--------------------------------------------------------------------------

GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
  
}  
//--------------------------------------------------------------------------

