This is `pytwink`, a Python for S60 extension that is somewhat like
the Miso extension in being a somewhat random collection of utility
functions and classes, except that `pytwink` is only for S60 3rd
Edition and higher, and is even more liberal in what it contains. Some
of the functionality here is strictly experimental, and everything and
anything is subject to change without notice.

Only PyS60 1.4.x series is supported by this extension.
