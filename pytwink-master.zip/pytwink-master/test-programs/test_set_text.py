import pytwink
import e32

pytwink.set_softkey_text(3009, u"MyText")
e32.ao_sleep(3)
print "all done"
