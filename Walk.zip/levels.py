# -*- coding: cp1251 -*-
level1 = ('grass', # �� ����� �����
    [              # �� �����...  :)
    '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%',
    '%    v y   y       x            y %',
    '%    v                            %',
    '%    vy x   y x     y      x      %',
    '%4hwh2           @                %',
    '%v  x      y                 x    %',
    '%v       y            x           %',
    '%2             x              4hhh%',
    '%     x         y           x v   %',
    '%  x  y     x         4hhhwhhh2   %',
    '%          y        y v           %',
    '%   y x               v    y      %',
    '%      y   x          v  x x x    %',
    '%       x       yx    m           %',
    '%                     v x x x   y %',
    '%                     v         y %',
    '%   x                 v           %',
    '%         y           3hhhh1      %',
    '%                x         v      %',
    '%       y         y   y    v      %',
    '%   y              y       v      %',
    '%      x                   vy  xy %',
    '%                          v      %',
    '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'
    ])
