#! /usr/bin/env python
# -*- coding: cp1251 -*-
#
#   W a l k . p y
#
# by Gregory Dryapak
# on Jan 09 2005 

import os
import sys
import glob
from random import randint, randrange

import pygame
from pygame.locals import *


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# �������� ������ ��� �������� ���
# ��������� �� ���� Ole Martin Bjorndalen

FPS = 30
datadir = os.path.join(os.path.split(sys.argv[0])[0], 'data')

# z-sorted rendering 
class RenderZSort(pygame.sprite.RenderUpdates):
    def draw(self, surface):
        "draw all sprites onto a surface in z order (lowest z first)"
        spritedict = self.spritedict
        items = spritedict.items()
        items.sort(lambda a,b: cmp(a[0].z,b[0].z))
        surface_blit = surface.blit
        dirty = self.lostsprites
        self.lostsprites = []
        dirty_append = dirty.append

        for s, r in items:
            newrect = surface_blit(s.image, s.rect)
            #s.post_draw(surface)
            surface_blit(s.image, s.rect)
            if r is not 0:
                dirty_append(newrect.union(r))
            else:
                dirty_append(newrect)
            spritedict[s] = newrect
        return dirty

# base class for games
class BaseGame:
    def __init__(self, *args, **kwargs):
        self.screen = pygame.display.get_surface()
        self.background = pygame.Surface(self.screen.get_size())
        self.rect = self.screen.get_rect()
        self.objects = RenderZSort()
        self.images = {}
        self.sounds = {}
        self.init(*args, **kwargs)
        self.blit_background()
        self.stoped = True

    def blit_background(self, *args):
        self.screen.blit(self.background, (0, 0))
        pygame.display.update()
        
    def load_images(self, *args):
        "Loads images from data dir using patterns given in args"
        for pattern in args:
            for name in glob.glob(os.path.join(datadir, pattern)):
                try: img = pygame.image.load(name).convert_alpha()
                except: continue
                key = os.path.splitext(os.path.basename(name))[0]
                self.images[key] = img

    def load_sounds(self, *args):
        "Loads sounds from data dir using patterns given in args"
        for pattern in args:
            for name in glob.glob(os.path.join(datadir, pattern)):
                try: snd = pygame.mixer.Sound(name)
                except: continue
                key = os.path.splitext(os.path.basename(name))[0]
                self.sounds[key] = snd

    def _redraw(self):
        self.objects.clear(self.screen, self.background)
        events = pygame.event.get()
        self.update(events)
        self.objects.update()
        dirty = self.objects.draw(self.screen)
        pygame.display.update(dirty)

    def go(self):
        self.stoped = False
        clock = pygame.time.Clock()
        while not self.stoped:
                self._redraw()
                clock.tick(FPS)        
        
    def stop(self):
        self.stoped = True

    def init(self):
        "Called at init time. Put initialization code for the game here."
        pass

    def update(self, events):
        "Handles events and updates the objects. Called every frame."
        pass


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

screensize = (640, 480) 
bg_color = (0, 0, 0)
WORLD_LAYER = 0
HERO_LAYER = 1
A = 16                  # ������ �������� 16x16
solid = '%xyvh1234'     # �������, �� ������� ������ ������

table = {'%': 'ground', # ������������ �������� �� ����� c
         'x': 'tree',   # ������� �����������
         'y': 'tree2',
         'm': 'mosth',
         'w': 'mostv',
         'v': 'riverv',
         'h': 'riverh',
         '1': 'river1',
         '2': 'river2',
         '3': 'river3',
         '4': 'river4'}
         
         

# ������ ��� ����� ���������� ����
class StaticWorld(pygame.sprite.Sprite):
    def __init__(self, game, image):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (0, 0)
        self.z = WORLD_LAYER
        self.add([self.game.objects])

# ����� ����
class Hero(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.images = {}
        
        self.images['r'] = (self.game.images['heror1'], self.game.images['heror2'])        
        self.images['l'] = (self.game.images['herol1'], self.game.images['herol2'])        
        self.images['f'] = (self.game.images['herof1'], self.game.images['herof2'])        
        self.images['b'] = (self.game.images['herob1'], self.game.images['herob2'])
        
        self.mode = 'f'
        self.imgnum = 0
        self.image = self.images[self.mode][self.imgnum]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.z = HERO_LAYER
        self.add([self.game.objects])
        self.moving = False
        self.movingto = [x,y]
        self.counter = 0

    def update(self):            
        if self.moving:
            # ������ ����������� ������ 5 ������
            self.counter = (self.counter + 1) % 5
            if self.counter==0:
                self.imgnum = (self.imgnum +1) %2  # ����� ��� �����������
                self.image = self.images[self.mode][self.imgnum]

            # ���������� � ������ �������
            dx = dy = 0
            if self.rect.x - self.movingto[0] < 0: dx = 1
            elif self.rect.x - self.movingto[0] > 0: dx = -1
            if self.rect.y - self.movingto[1] < 0: dy = 1
            elif self.rect.y - self.movingto[1] > 0: dy = -1
            self.rect.x += dx
            self.rect.y += dy
            
            # ����� ��� �� �����
            if (abs(self.rect.x - self.movingto[0])<=1 and 
                abs(self.rect.y - self.movingto[1])<=1):
                self.rect.x = self.movingto[0]
                self.rect.y = self.movingto[1]
                self.moving = False

    def setmode(self, mode):
        self.mode = mode
        self.image = self.images[self.mode][self.imgnum]
        


class GameLevel(BaseGame):
    def init(self, fill, map):
        """ fill - ��� ����������� ��� ���������� �����
            ������ ������������� ����� map  """
        
        self.load_images('*.png')
        self.background.fill(bg_color)
        self.blit_background()
        
        self.map = map
        self.maph = len(self.map)
        self.mapw = len(self.map[0])
        self.screenw = screensize[0]
        self.screenh = screensize[1]
        
        surf = pygame.Surface((self.mapw*A, self.maph*A))
        for i in range(self.mapw):
            for j in range(self.maph):
                a = self.map[j][i]
                surf.blit(self.images[fill], (i*A, j*A))
                if a in table:
                    surf.blit(self.images[table[a]], (i*A, j*A))
                elif a == '@':
                    self.hero = Hero(self, i*A + A//2, j*A + A//2)

        self.static = StaticWorld(self, surf)

        self.basex = (self.screenw - self.mapw*A)//2
        self.basey = (self.screenh - self.maph*A)//2
        for o in self.objects.sprites():
            o.rect.x += self.basex
            o.rect.y += self.basey


    def screentomap(self, x, y):
        """ ��������� ���������� ������ � ������� �� ����� """
        i = (x - self.basex)//A
        j = (y - self.basey)//A
        return i, j
                
    def update(self, events):
        if self.hero.rect.x < self.screenw // 4:
            self.basex += 1
            for o in self.objects.sprites():
                o.rect.x += 1
            self.hero.movingto[0] += 1

        if self.hero.rect.x > self.screenw * 3 // 4:
            self.basex -= 1
            for o in self.objects.sprites():
                o.rect.x -= 1
            self.hero.movingto[0] -= 1

        if self.hero.rect.y < self.screenh // 4:
            self.basey += 1
            for o in self.objects.sprites():
                o.rect.y += 1
            self.hero.movingto[1] += 1

        if self.hero.rect.y > self.screenh * 3 // 4:
            self.basey -= 1
            for o in self.objects.sprites():
                o.rect.y -= 1
            self.hero.movingto[1] -= 1

        for e in events:
            if e.type == KEYDOWN:
                if e.key == K_ESCAPE:
                    self.stop()

            elif e.type == QUIT:
                sys.exit()

        pressed = pygame.key.get_pressed()
        if pressed[K_RIGHT]:
            nx = self.hero.rect.x + A 
            ny = self.hero.rect.y
            i,j = self.screentomap(nx, ny)
            if not(self.hero.moving) and not(self.map[j][i] in solid):
                self.hero.moving = True
                self.hero.movingto = [nx, ny]
                self.hero.setmode('r')
                
        if pressed[K_LEFT]:
            nx = self.hero.rect.x - A
            ny = self.hero.rect.y
            i,j = self.screentomap(nx, ny)
            if not(self.hero.moving) and not(self.map[j][i] in solid):
                self.hero.moving = True
                self.hero.movingto = [nx, ny]
                self.hero.setmode('l')
                
        if pressed[K_UP]:
            nx = self.hero.rect.x
            ny = self.hero.rect.y - A
            i,j = self.screentomap(nx, ny)
            if not(self.hero.moving) and not(self.map[j][i] in solid):
                self.hero.moving = True
                self.hero.movingto = [nx, ny]
                self.hero.setmode('b')
                
        if pressed[K_DOWN]:
            nx = self.hero.rect.x
            ny = self.hero.rect.y + A
            i,j = self.screentomap(nx, ny)
            if not(self.hero.moving) and not(self.map[j][i] in solid):
                self.hero.moving = True
                self.hero.movingto = [nx, ny]
                self.hero.setmode('f')


import levels

pygame.init()
pygame.display.set_mode(screensize, FULLSCREEN)
pygame.display.set_caption("my game")
pygame.mouse.set_visible(False)

game = GameLevel(*levels.level1)
game.go()
