from bottle import route, request, post, get, run, template, error, response, static_file, TEMPLATE_PATH, default_app, debug
import os,sys,fqlquery
debug(mode=True)
mydir=os.path.dirname(os.path.realpath(__file__))
TEMPLATE_PATH.append(os.path.join(mydir,"template"))
@error(404)
def kesasar(err):
  return "Lo kesasar bro, apa yang lo cari tidak ditemukan"
@error(500)
def rusak(err):
  return "Kayaknya script lo error deh bro, cek output console"

# static file
@route('/lib/<filename:path>')
def getfile(filename):
  return static_file(filename,os.path.join(mydir,"lib"))
@get('/')
def index():
  return template("main.html",data=[],katas="Tulis nama")
@post('/cari.py')
def cari():
  kata=request.forms.get("kata")
  fql = fqlquery.FQL("ISI_TOKEN_DISINI")
  dat = fql.query("SELECT name,uid FROM user WHERE uid IN (SELECT uid FROM group_member WHERE gid = '376405625706616' LIMIT 0,99999) AND strpos(lower(name),lower('%s'))>0"%kata)
  ##esponse.set_header('content-type','application/json')
  return template("main.html",data=dat,katas=kata)
application=default_app()
