''' fqlquery.py
  Allow you to execute Facebook Query Language (FQL) with Python
 Support: fql.query dan multiquery

  Author: Agus Ibrahim
  fb.me/mynameisagoes
'''
from urllib import urlopen,urlencode,quote
true=True
false=False
null=None
class FQL:
 def __init__(self,token,format='json'):
  self.url='https://api-read.facebook.com/method/fql.query'
  self.url2='https://api.facebook.com/method/fql.multiquery'
  self.format=format
  self.token=token
 def query(self,query):
  res=urlopen(self.url,urlencode({'format':self.format,'access_token':self.token,'query':query})).read()
  return eval(res)
 def multiquery(self,queries):
  res=urlopen(self.url2,urlencode({'format':self.format,'access_token':self.token,'queries':str(queries)})).read()
  return eval(res)
def joinlist(d):
 dat={}
 if type(d)!=list:d=eval(d)
 for dct in d:
  for k,v in dct.items():
   if not k in dat:
    dat[k]=[v]
   else:dat[k].append(v)
 return dat
