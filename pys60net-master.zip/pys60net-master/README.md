pys60net
========

PyS60 group control panel<br>
Gunakan ini untuk redhat cloud,<br>
PENGGUNAAN:<br>
Edit access token pada wsgi/main.py
<br>
Cara deploy:<br>
Pastikan kamu telah memasang rhc toolkit dan dalam keadaan login<br>
Buka terminal, ketik:<br>
<code>rhc app create pys60net python-2.7 --from-code https://github.com/pymobile/pys60net.git</code><br>

Clone aplikasimu diatas dengan cara:<br>
<code>rhc git-clone pys60net
cd pys60net</code><br>

Pada folder pys60net  hasil clone, silahkan edit Access tokennya di wsgi/main.py<br>
Setelah semua selesai, ketik:<br>
<code>git add wsgi/main.py
git commit -m "aplikasi pys60net saya"
git push</code><br>

<b>SELESAI</b>, silahkan test






