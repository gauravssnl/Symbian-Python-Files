#

import marshal as m
file='c:\\hasil.dat'
value='isi teks panjang'

#dumps
hasil= m.dumps(value)
print 'hasil dumps:', hasil

#loads
value= hasil
print 'hasil loads:', m.loads(value)

#dump
m.dump(value, open(file, 'wb'))

#load
print 'hasil load:', m.load(open(file,'rb'))
