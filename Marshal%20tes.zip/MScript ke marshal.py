#marshal script
#emjebe

import marshal as m

default=open('c:\\default.py').read()
value=default.replace('\r\n', '\n')
file='c:\\hasil.dat'

#membuat file baru hasil.dat
new=open(file, 'wb')
m.dump(value,new)
new.close()

#menjalankan file hasil.dat
jalan=open(file,'rb')
scrip=m.load(jalan)
jalan.close()
exec(scrip)
