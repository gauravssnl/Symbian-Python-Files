#include <CPhCltUssd.h>	

#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Send(PyObject* /*self*/,PyObject* args)
{
  
  PyObject* obj_str;
  TInt show=1;
  
  if (!PyArg_ParseTuple(args, "U|i", &obj_str, &show))
    return NULL;

  TPtrC str((TUint16*) PyUnicode_AsUnicode(obj_str),
                           PyUnicode_GetSize(obj_str));

  CPhCltUssd* ussdClient = CPhCltUssd::NewL( (TBool)show );
  CleanupStack::PushL( ussdClient );

  TInt result = ussdClient->SendUssd( str );

  CleanupStack::PopAndDestroy( ussdClient );
  
  return Py_BuildValue("i", result);

}
 
//--------------------------------------------------------------------------

static const PyMethodDef connmon_met[] = {
    {"send", (PyCFunction)Send, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
    Py_InitModule("ussd3r2n", connmon_met);
}

//--------------------------------------------------------------------------

