import soundsystem,e32

for i in range(1001,1035):
  soundsystem.play(i)
  e32.ao_sleep(1)