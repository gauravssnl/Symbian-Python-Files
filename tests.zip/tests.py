import os, e32dbm, contacts, time

print 'start'
time1 = time.time()
contactsDb=e32dbm.open('e:\\contacts', 'c')
db=contacts.open()
for i in db.keys():
    a=[]
    for i1 in [u'first_name', u'last_name']:
        if db[i].find(type=i1) and db[i].find(type=i1)[0].value is not None:
            a.append(db[i].find(type=i1)[0].value)
    b=[]
    if len(a):
        for i1 in [u'mobile_number', u'phone_number']:
            for i2 in ['none', 'home', 'work']:
                if db[i].find(type=i1, location=i2) and db[i].find(type=i1, location=i2)[0].value is not None:
                    b.append(db[i].find(type=i1, location=i2)[0].value)
        if len(b):
            contactsDb[' '.join(a).encode('utf-8')]=','.join(b)
            if len(a)>1:
                contactsDb[' '.join([a[1], a[0]]).encode('utf-8')]=','.join(b)
print time1-time.time()
contactsDb.close()
os.remove('e:\\contacts.e32dbm')
print 'done'