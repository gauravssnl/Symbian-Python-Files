#! /usr/bin/python
# -*- coding: cp1251 -*-

import sys
import pygame
from pygame.locals import *					# импорт

pygame.init()
k=pygame.display.set_mode((800,600),FULLSCREEN)		# создаем окно во весь экран)))

pygame.mouse.set_visible(False)					# скрыли мышу


cur=pygame.image.load("cursor.png").convert()			# грузим картинку
cur.set_colorkey(cur.get_at((0,0)),RLEACCEL)			# прозрачность
global curx,cury
curx,cury=0,0

def keyget():
    global curx,cury
    keys=pygame.key.get_pressed()				# получаем состояние клавиш
    if keys[K_LEFT]:curx-=3
    if keys[K_RIGHT]:curx+=3
    if keys[K_UP]:cury-=3
    if keys[K_DOWN]:cury+=3
    if keys[K_ESCAPE]:sys.exit()

def draw():
	k.fill((200,0,0))					# заливка буфера
	pygame.draw.line(k,(200,200,200),(0,0),(800,600),10)	# рисуем линию
	k.blit(cur,(curx,cury))					# выводим картинку
	pygame.display.flip()					# меняем буфер
	
clock=pygame.time.Clock()					# объект, следящий за фпс

pygame.mixer.music.load('1.wav')
pygame.mixer.music.play()
#pygame.mixer.music.pause()
#pygame.mixer.music.unpause()					# звук


while 1:
    keyget()
    draw()
    clock.tick(30)						# проверка фпс
    for event in pygame.event.get():
        if event.type==QUIT:
            sys.exit()
        if event.type==MOUSEBUTTONDOWN:
            if event.button==1:			# проверка кнопок мыши 1-левая
        	curx,cury=0,0
            if event.button==2:			# проверка кнопок мыши 2-колесико
        	curx,cury=100,100
            if event.button==3:			# проверка кнопок мыши 3-правая
        	curx,cury=0,500
            if event.button==4:			# проверка колеса мыши 4-вверх
        	curx,cury=500,0
            if event.button==5:			# проверка колеса мыши 5-вниз
        	curx,cury=500,500
        if event.type==MOUSEMOTION:		# положение мыши при перемещении
            curx,cury=event.pos
        print event
        
        
        
        