/*
 * const.h
 *
 *  Created on: 19.02.2011
 *      Author: mvideo
 */

#ifndef CONST_H_
#define CONST_H_

_LIT(KSkinsPath,"C:\\System\\Apps\\TopBattery\\Skins\\");
_LIT(KSettingPath,"C:\\System\\Apps\\TopBattery\\config.ini");
_LIT(KExceptionsPath,"C:\\System\\Apps\\TopBattery\\apps.ini");
_LIT(KFirstStartFile,"C:\\system\\apps\\TopBattery\\firststart");

_LIT(KPosXP,"0");
_LIT(KPosYP,"0");
_LIT(KPosXL,"0");
_LIT(KPosYL,"0");
_LIT(KZoom,"100");
_LIT(KSkin,"Skin1");

#endif /* CONST_H_ */
