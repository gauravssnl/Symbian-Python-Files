TopBattery
==========

A symbian app to show a battery state over all apps
