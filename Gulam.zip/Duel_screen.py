import asprite,e32,appuifw
file=u'e:\\onepiece.gif'
pos=(0,0)
sp=asprite.New()
gbr=sp.load(file)
pict=sp.NewSprite(gbr,1)
sp.activate()
sp.target(pict,pos)

l=e32.Ao_lock()
def quit():
  global sp
  l.signal()
  del sp
appuifw.app.exit_key_handler=quit
l.wait()