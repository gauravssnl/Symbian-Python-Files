#
# profiles.py
# (c) the86hitman
# www.drhtailor.com/pys60
#
import e32

if e32.s60_version_info>=(3,0):
    import imp
    _profiles = imp.load_dynamic('_profiles', 'kf_profiles.pyd')
    
else:
    import _profiles

del e32, imp
from _profiles import *
del _profiles