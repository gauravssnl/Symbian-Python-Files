/*
 * sms.h
 *
 *  Created on: 25.12.2010
 *      Author: mvideo
 */

#ifndef SMS_H_
#define SMS_H_


#endif /* SMS_H_ */
