import appuifw, e32
import lb_utils

app_lock = e32.Ao_lock() 

def current():
    x = lb.current()

arr=[(u'item 1'),(u'item 2'),(u'item 3'),(u'item 4'),(u'item 5')]

lb=appuifw.Listbox(arr,current)
appuifw.app.body=lb

w1=lb_utils.measure_text(lb,u'test')
w2=lb_utils.get_width(lb)
lb_utils.set_font(lb,"dense")# normal title dense annotation legend symbol


appuifw.app.exit_key_handler = app_lock.signal
app_lock.wait()
