#include <eiklbx.h>
#include <gulicon.h> 
#include <eikclbd.h>
#include <aknlists.h>

#include "Python.h"
#include "symbian_python_ext_util.h"


enum ListboxType {ESingleListbox, EDoubleListbox, ESingleGraphicListbox, EDoubleGraphicListbox };

#define Listbox_type ((PYTHON_GLOBALS->tobj).t_Listbox)

class CListBoxCallback;
class CAppuifwEventBindingArray;

//--------------------------------------------------------------------------
struct Listbox_object {
  PyObject_VAR_HEAD
  CEikListBox* ob_control;
  CAppuifwEventBindingArray* ob_event_bindings;
  ListboxType ob_lb_type;
  CListBoxCallback* ob_listbox_callback;
  CArrayPtrFlat<CGulIcon>* ob_icons;
};

//--------------------------------------------------------------------------
static PyObject* MeasureText(PyObject* ,PyObject* args)
{
  Listbox_object* obj_listbox;
  PyObject* obj_string;
  TUint8 item=1;

  if (!PyArg_ParseTuple(args, "O!U|i", &Listbox_type, &obj_listbox, &obj_string, &item))
    return NULL;

  if(item<1) item=1;

  TPtrC str((TUint16*) PyUnicode_AsUnicode(obj_string),
                            PyUnicode_GetSize(obj_string));

  TInt inpix(0);
  TListItemProperties prop;

  if (obj_listbox->ob_lb_type == ESingleListbox)
     inpix =((CAknSingleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ColumnData()->Font( prop, item)->MeasureText(str);

  else if (obj_listbox->ob_lb_type == EDoubleListbox)
     inpix =((CAknDoubleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ColumnData()->Font( prop, item)->MeasureText(str);

  else if (obj_listbox->ob_lb_type == ESingleGraphicListbox)
    inpix =((CAknColumnListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ColumnData()->Font( prop, item)->MeasureText(str);

  else //EDoubleGraphicListbox
     inpix =((CAknDoubleLargeStyleListBox*)obj_listbox->ob_control)->
            ItemDrawer()->ColumnData()->Font( prop, item)->MeasureText(str);


 return  Py_BuildValue("i",inpix);
}

//--------------------------------------------------------------------------

static PyObject* GetWidth(PyObject* ,PyObject* args)
{
  Listbox_object* obj_listbox;
  TUint8 item=1;

  if (!PyArg_ParseTuple(args, "O!|i", &Listbox_type, &obj_listbox, &item))
    return NULL;
    
  if(item<1) item=1;
  
  TInt inpix;

  if (obj_listbox->ob_lb_type == ESingleListbox)
     inpix =((CAknSingleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ItemWidthInPixels(item);

  else if (obj_listbox->ob_lb_type == EDoubleListbox)
     inpix =((CAknDoubleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ItemWidthInPixels(item);

  else if (obj_listbox->ob_lb_type == ESingleGraphicListbox)
    inpix =((CAknColumnListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ItemWidthInPixels(item);

  else //EDoubleGraphicListbox
     inpix =((CAknDoubleLargeStyleListBox*)obj_listbox->ob_control)->
            ItemDrawer()->ItemWidthInPixels(item);
            

 return  Py_BuildValue("i",inpix);
}

//--------------------------------------------------------------------------

static PyObject* SetFont(PyObject* ,PyObject* args)
{
  Listbox_object* obj_listbox;
  TUint8 item=1;
  char *type = NULL;
  TInt i_type = 0;
  
  if (!PyArg_ParseTuple(args, "O!s#|i", &Listbox_type, &obj_listbox,&type,&i_type, &item))
    return NULL;

  if(item<1) item=1;

  TPtrC8 type_font((TUint8*)type, i_type);
  const CFont *font=NULL;
  
  if (type_font.Compare(_L8("normal")) == 0)
        font = CEikonEnv::Static()->NormalFont();
  else if (type_font.Compare(_L8("title")) == 0)
        font = CEikonEnv::Static()->TitleFont();
  else if (type_font.Compare(_L8("dense")) == 0)
        font = CEikonEnv::Static()->DenseFont();
  else if (type_font.Compare(_L8("annotation")) == 0)
        font = CEikonEnv::Static()->AnnotationFont();
  else if (type_font.Compare(_L8("legend")) == 0)
        font = CEikonEnv::Static()->LegendFont();
  else if (type_font.Compare(_L8("symbol")) == 0)
        font = CEikonEnv::Static()->SymbolFont();
  else {
        PyErr_SetString(PyExc_ValueError, "Invalid font label");
        return 0;
    }

  if (obj_listbox->ob_lb_type == ESingleListbox)
     ((CAknSingleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ColumnData()->SetColumnFontL(item,font);

  else if (obj_listbox->ob_lb_type == EDoubleListbox)
     ((CAknDoubleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ColumnData()->SetSubCellFontL(item,font);

  else if (obj_listbox->ob_lb_type == ESingleGraphicListbox)
    ((CAknColumnListBox*)obj_listbox->ob_control)->
          ItemDrawer()->ColumnData()->SetColumnFontL(item,font);

  else //EDoubleGraphicListbox
     ((CAknDoubleLargeStyleListBox*)obj_listbox->ob_control)->
            ItemDrawer()->ColumnData()->SetSubCellFontL(item,font);

  
  obj_listbox->ob_control->DrawNow();
  
 Py_INCREF(Py_None);
	return Py_None;
}
//--------------------------------------------------------------------------
 /*
static PyObject* SetItemHeight(PyObject* ,PyObject* args)
{
  Listbox_object* obj_listbox;
  TUint8 r,g,b;

  if (!PyArg_ParseTuple(args, "O!(iii)", &Listbox_type, &obj_listbox,&r, &g ,&b))
    return NULL;

   
  if (obj_listbox->ob_lb_type == ESingleListbox)
     ((CAknSingleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->SetHighlightedTextColor(TRgb(r,g,b));

  else if (obj_listbox->ob_lb_type == EDoubleListbox)
      ((CAknDoubleStyleListBox*)obj_listbox->ob_control)->
          ItemDrawer()->SetHighlightedTextColor(TRgb(r,g,b));

  else if (obj_listbox->ob_lb_type == ESingleGraphicListbox)
    ((CAknColumnListBox*)obj_listbox->ob_control)->
          ItemDrawer()->SetHighlightedTextColor(TRgb(r,g,b));

  else //EDoubleGraphicListbox
     ((CAknDoubleLargeStyleListBox*)obj_listbox->ob_control)->
         ItemDrawer()->SetHighlightedTextColor(TRgb(r,g,b));

  obj_listbox->ob_control->DrawNow();
  
  Py_INCREF(Py_None);
	 return Py_None;
}
 */
//--------------------------------------------------------------------------

static const PyMethodDef lb_utils_met[] = {
    {"measure_text", (PyCFunction)MeasureText, METH_VARARGS},
    //{"set_highlig_color", (PyCFunction)SetItemHeight, METH_VARARGS},
    {"get_width", (PyCFunction)GetWidth, METH_VARARGS},
    {"set_font", (PyCFunction)SetFont, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("lb_utils", lb_utils_met);
}

//--------------------------------------------------------------------------
