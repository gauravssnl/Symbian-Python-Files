import struct

path= '!:\\sys\\bin\\' #do not touch

name= 'test.exe' #the name of your application

uid= '20040556' #the uid of your application

data='\x6b\x4a\x1f\x10\x00\x00\x00\x00\x00\x00\x00\x00\x19\xfd\x48\xe8\x01' + chr(32+len(name)*2) + '\x00\x01\x00\x02\x00' + chr(len(path)+len(name))*2 + path + name + '\x08\x00\x00\x00\x00\x00\x00\x00\x00\x14\x00' + chr(45+len(name)) + '\x00'

fo=open(u'e:\\['+uid+'].rsc','wb')
for i in data:
  fo.write(struct.pack('c',i ) )
fo.close()

#file [uid].rsc must be in c:\private\101f875a\import\
