
cellz= [        # some CELLS you can name with Names..
    ('20063','home'),
    ('20066','home')]

uin1 = 'x' #main ICQ number and password
pas1 = 'x'
uin2 = 'x' #there to send CIDs (icq number)
scaner = 5  # interval of scanning (minutes)

serv_icq = u'login.icq.com' #dont change
port_icq = '5190' #dont change


import os
import e32
import string
import socket
import struct
import select
import thread
import location
import time

TLV_UIN		= 0x01 # TLV codes
TLV_PWD		= 0x02
TLV_REDIR	= 0x05
TLV_COOKIE	= 0x06
CLIENT_	= 'AOL Instant Messenger'
s=''
chain=''
seq=''
sequ=0
runn=0
total_send=0
total_recv=0
xor_table = [0xf3, 0x26, 0x81, 0xc4, 0x39, 0x86, 0xdb, 0x92, 0x71, 0xa3, 0xb9, 0xe6, 0x53, 0x7a, 0x95, 0x7c]
AIM_RAW_RATE_ACK='\x00\x01\x00\x02\x00\x03\x00\x04'
AIM_RAW_SET_INFO	= '''\
\x00\x00\x00\x00\x00\x03\x1f\x40\x03\xe7\x03\xe7\x00\x00\x00\
'''
AIM_RAW_HASH		= '''\
\x00\x10\xd4\x1d\x8c\xd9\x8f\x00\
\xb2\x04\xe9\x80\x09\x98\xec\xf8\
\x42\x7e\
'''
AIM_RAW_23		= '''\
\x00\x01\x00\x03\x00\x02\x00\x01\
\x00\x03\x00\x01\x00\x04\x00\x01\
\x00\x06\x00\x01\x00\x08\x00\x01\
\x00\x09\x00\x01\x00\x0a\x00\x01\
\x00\x0b\x00\x02\x00\x0c\x00\x01\
\x00\x13\x00\x01\x00\x15\x00\x01\
'''
AIM_RAW_READY		= '''\
\x00\x01\x00\x03\x00\x04\x06\x86\
\x00\x02\x00\x01\x00\x04\x00\x01\
\x00\x03\x00\x01\x00\x04\x00\x01\
\x00\x04\x00\x01\x00\x04\x00\x01\
\x00\x09\x00\x01\x00\x04\x00\x01\
\x00\x0a\x00\x01\x00\x04\x00\x01\
\x00\x0b\x00\x01\x00\x04\x00\x01\
'''

def encode_password(pwd):
    list = map(lambda x,y: chr(x^ord(y)), xor_table[:len(pwd)], pwd)
    return string.join(list,'')

def get_hexstring(pole):
    sm=''
    llen1=llen2=len(pole)
    if llen1 != 0:
        while llen1:
            symb=pole[llen2-llen1]
            if type(symb)==type(0x01):
                sm=sm+(str((hex((pole[llen2-llen1])))))+','
            if type(symb)==type((1,1)):
                sm=sm+(str((((pole[llen2-llen1])))))+','
            if type(symb)==type('A'):
                sm=sm+(str((hex(ord(pole[llen2-llen1])))))+','
            llen1=llen1-1
    return sm

def tlv_make(type, value):
    l = len(value)
    fmt = '!hh %ds' % l
    return struct.pack(fmt, type, l, value)

def connect_icq(srv,prt):
    global s
    addr=(srv,int(prt))
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect(addr)
##    s = iapconnect.Connection()
##    s.connect(serv_icq,int(port_icq),1)
    return s

def send_FLAP(chain,chan):
    global total_send
    global s
    global sequ
    if chan==1:
        chain = '\x00\x00\x00\x01'+chain
    fmt='!BBHH'
    buf1=struct.pack(fmt,0x2a,chan,sequ,len(chain))
    sequ=sequ+1
    if sequ >= 0x8000:
        sequ=0x1000
    s.send((buf1+chain))
    total_send=total_send+len((buf1+chain))
    return

def send_HELO():
    global s
    global sequ
    sequ=22784 #must be random(0x1000-0x8000)
    chain	= \
        tlv_make(1,uin1)+\
        tlv_make(2,encode_password(pas1))+\
        tlv_make(3,CLIENT_)+\
        tlv_make(0x16, '\x01\x0a') + \
        tlv_make(0x17, '\x00\x04') + \
        tlv_make(0x18, '\x00\x3c') + \
        tlv_make(0x19, '\x00\x01') + \
        tlv_make(0x1a, '\x0c\x0e') + \
        tlv_make(0x14, '\x00\x00\x00\x55') + \
        tlv_make(0xe,'us') + tlv_make(0xf,'en')
    send_FLAP(chain,01)

def get_PLAP():
    global total_recv
    global s
    res1=s.recv(6)
    total_recv=total_recv+6
    if (len(res1)==6):
        dlina=struct.unpack('!h',res1[4:6])
        del res1
        res1=s.recv(dlina[0])
        total_recv=total_recv+dlina[0]
    return res1

def proc_tlv(dat3):
    ret_val = {}
    while 1:
        if len(dat3) < 4:
            break
        iden,l	= struct.unpack('!hh', dat3[:4])
        content	= dat3[4:(l+4)]
        ret_val[iden] = content
        dat3 = dat3[4+l:]
    return ret_val

def msg_in(data):
    uin_len = struct.unpack('B', data[20])[0]
    uin = struct.unpack('%ds'%uin_len, data[21:21+uin_len])[0]
    from1=20+uin_len+70 # ???
    mes_len = struct.unpack('!h', data[from1:from1+2])[0]-4
    mesaga='GETP' # cmd on default
    if mes_len < 8:
        mesaga = struct.unpack('%ds'%mes_len, data[from1+6:from1+6+mes_len])[0]
    return uin,mesaga

def proc_mess(uin,msg):
    ret_val=1
    cmd=string.upper(msg[:4])
    if cmd == 'EXIT':
        print '!EXIT! Exiting..'
        ret_val=0
    if (cmd == 'GETP') or (cmd=='1'):
        mcc, mnc, lac, cellid = location.gsm_location()
        dat1 = "CID="+is_cell_named(cellid)
        msg_out(uin,dat1)
    else:
        mcc, mnc, lac, cellid = location.gsm_location()
        dat1 = "CID="+is_cell_named(cellid)
        msg_out(uin,dat1)
    return ret_val

def msg_out(uin,msg):
    global total_send
    msg=str(msg)+time.strftime(" (%H:%M)", time.localtime())
    fmt = '!LLH B %ds H H 7s  H  L %ds'
    uin_len = len(uin)
    msg_len = len(msg)
    fmt = fmt % (uin_len, msg_len)
    packet = struct.pack(fmt,0,0,1,uin_len,uin,2,msg_len + 0xd,
			'\x05\x01\x00\x01\x01\x01\x01',
			msg_len + 0x4,0x0,msg )
    packet='\x00\x04\x00\x06\x00\x00\x00\x00\x00\x00'+packet
    send_FLAP(packet,02)
    total_send=total_send+len(packet)
    print msg
    return 1

def is_cell_named(cid):
    global cellz
    ret_val=str(cid)
    l=len(cellz)
    while l != 0:
        l=l-1
        if cellz[l][0] == str(cid):
            ret_val=str(cid)+'-'+cellz[l][1]
    return ret_val

def m_exit():
    runn=0
    appuifw.app.set_exit()

def m_right():
    runn1=0

def save_optionz():
    global uin1
    global pas1
    global scaner
    global uin2
    uin1=str(uin1)
    uin2=str(uin2)
    pas1=str(pas1)
    scaner=int(scaner)
    APP_DIR1='e:\\system\\Apps\\ztracker'
    if not os.path.isdir(APP_DIR1):
        os.makedirs(APP_DIR1)
    CFG_FILE=os.path.join(APP_DIR1,'optionz.dat')
    config={}
    config['UIN1']= uin1
    config['PAS1']= pas1
    config['UIN2']= uin2
    config['INTE']= scaner
    f=open(CFG_FILE,'wt')
    f.write(repr(config))

def read_config():
    global uin1
    global pas1
    global scaner
    global uin2
    APP_DIR1='e:\\system\\Apps\\ztracker'
    if not os.path.isdir(APP_DIR1):
        os.makedirs(APP_DIR1)
    CFG_FILE=os.path.join(APP_DIR1,'optionz.dat')
    errr=0
    try:
        f=open(CFG_FILE,'rt')
        try:
            content1=f.read()
            config=eval(content1)
            f.close()
            uin1 = str(config['UIN1'])
            pas1 = str(config['PAS1'])
            uin2 = str(config['UIN2'])
            scaner = int(config['INTE'])
        except:
            errr=1
    except:
        errr=1
    if errr==1:
        m_seticqfrom1()
        m_seticqto1()
        m_interval1()
    uin1=str(uin1)
    uin2=str(uin2)
    pas1=str(pas1)
    scaner=int(scaner)

def m_seticqto1():
    global uin2
    uin2 = appuifw.query(u'Send to ICQ:','number',uin2)
    save_optionz()
    
def m_interval1():
    global scaner
    scaner = appuifw.query(u'Set interval(min):','number',scaner)
    save_optionz()

def m_seticqfrom1():
    global uin1
    global pas1
    uin1,pas1 = appuifw.multi_query(u'MAIN ICQ number:',u'MAIN ICQ passwrd:')
    save_optionz()

appuifw.app.exit_key_handler=m_right
appuifw.app.menu = [(u"SET ICQ-FROM number", m_seticqfrom1),
                    (u"SET ICQ-TO number", m_seticqto1),
                    (u"SET Interval (min)", m_interval1),
                    (u"EXIT", m_exit)]
##
appuifw.app.screen='large'
appuifw.app.body.clear()
read_config()
print ' '
print '-== ZoFF-TRACKER v.2=--'
print ' zimenkov@ntci.nnov.ru'
print ' '
    
print 'connecting icq ..'
s=connect_icq(serv_icq,port_icq)  #connect to server
buf=get_PLAP()                  #conection ok?
send_HELO()         # send HELO to server
buf=get_PLAP()      # serv returns real BOS-server
s.close()           # close connetion(we must connect BOS)
tlv_chain=proc_tlv(buf)
cookie=tlv_chain[TLV_COOKIE]
h,p = string.split(tlv_chain[TLV_REDIR],':')
s=connect_icq(h,p)    #connect to BOS server
send_FLAP(tlv_make(TLV_COOKIE,cookie),01) #send CLI_COOKIE
print 'connected: OK'

C=1
while C==1:
    dat1=get_PLAP()
    if len(dat1) < 4:
        continue
    snac_family,snac_command = struct.unpack('!hh', dat1[0:4])
    ##
    if snac_family==1 and snac_command==3:      # 'server-ready'
        
        # send our capabililties
        z1=struct.pack('!hhhl',1,23,0,0)    #SNAC(01,0x17)
        send_FLAP(z1+AIM_RAW_23,02)         #send CLI_FAMILIES_VERSIONS
        
        # request rate information
        z1=struct.pack('!hhhl',1,6,0,0)     #SNAC(01,0x06)
        send_FLAP(z1,02)                    #send CLI_RATES_REQUEST
    ##
    elif snac_family==1 and snac_command==7:    # 'server-rate-response'
        # ack(accept) rate response
        z1=struct.pack('!hhhl',1,8,0,0)     #SNAC(01,0x08)
        send_FLAP(z1+AIM_RAW_RATE_ACK,02)   #send CLI_RATES_ACK

        # request clientinfo
        z1=struct.pack('!hhhl',1,0x0E,0,0)  #SNAC(01,0x0E)
        send_FLAP(z1,02)                    #send CLI_REQ_SELFINFO
        # request rights info
        z1=struct.pack('!hhhl',2,0x02,0,0)  #SNAC(02,0x02)
        send_FLAP(z1,02)                    #send CLI_LOCATION_RIGHTS_REQ
        
        # set user information
        z1=struct.pack('!hhhl',2,0x04,0,0)  #SNAC(02,0x04)
        z2=tlv_make(1, 'text/x-aolrtf; charset="us-asci"')+\
            tlv_make(2, 'hello world')+ \
            tlv_make(3, 'text/x-aolrtf; charset="us-asci"' + \
            tlv_make(4, 'my away message')) + \
            tlv_make(5, '\x09\x46\x13\x46\x4c\x7f\x11\xd1' + \
                        '\x82\x22\x44\x45\x53\x54\x00\x00' + \
                        '\x09\x46\x13\x41\x4c\x7f\x11\xd1' + \
                        '\x82\x22\x44\x45\x53\x54\x00\x00' + \
                        '\x09\x46\x13\x45\x4c\x7f\x11\xd1' + \
                        '\x82\x22\x44\x45\x53\x54\x00\x00' + \
                        '\x74\x8f\x24\x20\x62\x87\x11\xd1' + \
                        '\x82\x22\x44\x45\x53\x54\x00\x00' )
        send_FLAP(z1+z2,02)                 #send CLI_SET_LOCATION_INFO

        # request buddy list rights info
        z1=struct.pack('!hhhl',3,0x02,0,0)  #SNAC(03,0x02)
        send_FLAP(z1,02)                    #send CLI_BUDDYLIST_RIGHTS_REQ
        # set user info
        z1=struct.pack('!hhhl',2,0x04,0,0)  #SNAC(02,0x04)
        send_FLAP(z1+AIM_RAW_SET_INFO,02)   #send CLI_SET_LOCATION_INFO 
        # request messaging parameter info
        z1=struct.pack('!hhhl',4,0x04,0,0)  #SNAC(04,0x04)
        send_FLAP(z1,02)                    #send CLI_ICBM_PARAM_REQ
        # request BOS rights
        z1=struct.pack('!hhhl',9,0x02,0,0)  #SNAC(09,0x02)
        send_FLAP(z1,02)                    #send CLI_PRIVACY_RIGHTS_REQ
        # set BOS permission mask
        z1=struct.pack('!hhhl',9,0x04,0,0)  #SNAC(09,0x04)
        send_FLAP(z1,02)                    #send CLI_SET_GROUPMASK
        # set privacy flags
        z1=struct.pack('!hhhl',1,0x14,0,0)  #SNAC(01,0x14)
        send_FLAP(z1,02)                    #send CLI_SET_PRIVACY
        
        # mark ready
        z1=struct.pack('!hhhl',1,2,0,0)     #SNAC(01,02)
        send_FLAP(z1+AIM_RAW_READY,02)      #send CLI_READY
        
    elif snac_family==1 and snac_command==31:   # 'hash-request'
        # send hash response back
        z1=struct.pack('!hhhl',1,0x20,0,0)  #SNAC(01,0x20)
        send_FLAP(z1+AIM_RAW_HASH,02)       #send CLI_READY
        
    elif snac_family==1 and snac_command==1:   # 'error'
        aa=1

    elif snac_family==4 and snac_command==7:   # 'msg-in'
        uin,mess=msg_in(dat1)
        c=proc_mess(uin,mess)
        if c==0:
            break
    elif snac_family==0 and snac_command==1:   # 'helo ok'
        aa=2
        
    elif snac_family==11:    # 'proceeeeed here'
        runn=1
        l_cid='1'
        print 'started tracing ..'
        print ' '
        while runn==1:
            mcc, mnc, lac, cellid = location.gsm_location()
            dat1 = "CID="+is_cell_named(cellid)
            if l_cid != cellid:
                l_cid = cellid
                msg_out(uin2,dat1)
            e32.ao_sleep( scaner *62)  # 1 minuta!
        break
#lets EXIT icq
s.close()       # close connetion
del s
