
#include <e32base.h>
#include <w32std.h>  
#include <apgwgnam.h> 
#include <avkon.hrh>

#include "Python.h"
#include "symbian_python_ext_util.h"
  

class RWindowGroup;
class CApaWindowGroupName;
//---------------------------------------------------------------------------

const TUint KScanCode = 0xE3;
const TUint KKeyCode = 0xF883;

class CGlobCapture : public CActive 
{
   
 public:
    CGlobCapture();
    ~CGlobCapture();
    void ConstructL();
    void CallPy(TInt aVal, TInt aKey, TInt aMod);
    void Stop();
    void Start();
    void Start(PyObject* aList);

 private:
    void RunL();
  
	protected:
		virtual void DoCancel();
  
	private:
		RWsSession iWsSession;
		RWindowGroup* iWindowGroup;
		CApaWindowGroupName* iWindowGroupName;
  
  RArray<TInt32> iArrayCapture;
  RArray<TInt32> iArrayCaptureUd;
  RArray<TInt32> iArrayCaptureLong;
  
 public:
  PyObject *iCb;
                         
    
};
 
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------  
//----------------------------------------------------------------------------

void CGlobCapture::ConstructL()
{ 
	 User::LeaveIfError( iWsSession.Connect() );

	 iWindowGroup = new (ELeave) RWindowGroup ( iWsSession );
	 iWindowGroup->Construct( (TUint32)iWindowGroup, EFalse );

	 iWindowGroup->SetOrdinalPosition(-1);
	 iWindowGroup->EnableReceiptOfFocus( EFalse );
	 iWindowGroupName = CApaWindowGroupName::NewL( iWsSession );
	 iWindowGroupName->SetHidden(ETrue);
	 iWindowGroupName->SetWindowGroupName( *iWindowGroup );
	 CActiveScheduler::Add( this );
}
 
 
//----------------------------------------------------------------------------
CGlobCapture::CGlobCapture():CActive( EPriorityNormal ),iCb(NULL)
{
 
}

//---------------------------------------------------------------------------
CGlobCapture::~CGlobCapture()
{ 

  iWsSession.EventReadyCancel();
  Cancel();
	 delete iWindowGroupName;
	 delete iWindowGroup;
	 iWsSession.Close();
  Py_XDECREF(iCb);

  iArrayCapture.Reset();
  iArrayCaptureUd.Reset();
  iArrayCaptureLong.Reset();
}

//---------------------------------------------------------------------------

void CGlobCapture::DoCancel()
{
  for (TInt i=0; i<iArrayCapture.Count(); i++)
  {
    iWindowGroup->CancelCaptureKey(iArrayCapture[i]);
    iWindowGroup->CancelCaptureKeyUpAndDowns(iArrayCaptureUd[i]);
    iWindowGroup->CancelCaptureLongKey(iArrayCaptureLong[i]);
  }

}


//---------------------------------------------------------------------------

void CGlobCapture::CallPy(TInt aVal, TInt aKey, TInt aMod)
{  
  PyObject *arglist;
  arglist = Py_BuildValue("({i:(i,i)})",aKey, aVal, aMod);
  PyEval_RestoreThread(PYTHON_TLS->thread_state);
  PyEval_CallObject(iCb, arglist);
  PyEval_SaveThread(); 
  Py_DECREF(arglist);
}


//---------------------------------------------------------------------------
void CGlobCapture::RunL()
	{
	if( iStatus == KErrNone ) 
		{
		  TWsEvent we;
		  iWsSession.GetEvent( we );
  
    if( we.Key()->iRepeats>0 )
      CallPy(4, we.Key()->iCode, we.Key()->iModifiers);
    else if( we.Type() ==  EEventKeyDown )
      CallPy(1, we.Key()->iScanCode, we.Key()->iModifiers);
    else if  ( we.Type() ==  EEventKeyUp )
      CallPy(3, we.Key()->iScanCode, we.Key()->iModifiers);
    else if  ( we.Type() ==  EEventKey )
      CallPy(2, we.Key()->iCode, we.Key()->iModifiers);
      
			 TInt foregroundAppId = iWsSession.GetFocusWindowGroup();
			 iWsSession.SendEventToWindowGroup( foregroundAppId, we );


			 iWsSession.EventReady( &iStatus );
			 SetActive();
		} 

	}
//---------------------------------------------------------------------------

void CGlobCapture::Start(PyObject* aList)
{
  PyObject *item=NULL;
  PyObject *temp=NULL;
  TInt count = PyList_Size(aList);
  TInt key;
  
  for (TInt i=0; i<count; i++)
  {
    item = PyList_GetItem(aList, i);
    
    temp = PyList_GetItem(item, 0);
    key = PyInt_AsLong(temp);
    iArrayCapture.Append(iWindowGroup->CaptureKey(key,0,0));
    iArrayCaptureLong.Append(iWindowGroup->CaptureLongKey(key,key,0,0,0,0));

    temp = PyList_GetItem(item, 1);
    key = PyInt_AsLong(temp);
    iArrayCaptureUd.Append(iWindowGroup->CaptureKeyUpAndDowns(key,0,0));

  }

  iWsSession.EventReady( &this->iStatus );
	 SetActive();
}

//---------------------------------------------------------------------------
 
void CGlobCapture::Start()
{
	 iArrayCapture.Append(iWindowGroup->CaptureKey(KKeyCode,0,0));
  iArrayCaptureUd.Append(iWindowGroup->CaptureKeyUpAndDowns(KScanCode,0,0));
  iArrayCaptureLong.Append(iWindowGroup->CaptureLongKey(KKeyCode,KKeyCode,0,0,0,0));
   
  iWsSession.EventReady( &this->iStatus );
	 SetActive();
}


//---------------------------------------------------------------------------

void CGlobCapture::Stop()
{
  iWsSession.EventReadyCancel();
	 Cancel();
}


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#define GCapture_type ((PyTypeObject*)SPyGetGlobalString("GlobCapture"))
struct obj_GCapture {
  PyObject_VAR_HEAD  // PyObject_HEAD;
  CGlobCapture* iGCapture;
};


//---------------------------------------------------------------------------

static PyObject* New_GlobCapture(obj_GCapture* self, PyObject* args)
{
    PyObject *c = NULL;

    if (!PyArg_ParseTuple(args, "O:set_callback", &c))
    return NULL;


    obj_GCapture *ir = PyObject_New(obj_GCapture, GCapture_type);
    if (!ir) return NULL;

    ir->iGCapture = 0;
    TRAPD(err,
          ir->iGCapture  = new CGlobCapture(); 
          ir->iGCapture->ConstructL();
          ir->iGCapture->iCb = c;
          Py_XINCREF(ir->iGCapture->iCb);

         );

    if (err)
    {
      PyObject_Del(ir);
      return SPyErr_SetFromSymbianOSErr(err);
    }
 

  return (PyObject*)ir;
}

//---------------------------------------------------------------------------

static PyObject* Start(obj_GCapture* self, PyObject* args)
{
  PyObject* list=NULL;
  PyArg_ParseTuple(args, "|O",  &list );

  if( list != NULL)
  {
    if(!PyList_Check(list))
    {
      PyErr_SetString(PyExc_ValueError, "argument is not list");
      return NULL;
    }
    else
      self->iGCapture->Start(list);
  }
  else
    self->iGCapture->Start();
  
  Py_INCREF(Py_None);
  return Py_None;
}


//---------------------------------------------------------------------------
 /*
static PyObject* Start(obj_GCapture* self, PyObject*)
{
  self->iGCapture->Start();
  Py_INCREF(Py_None);
  return Py_None;
}
 */
//---------------------------------------------------------------------------

static PyObject* Stop(obj_GCapture* self, PyObject*)
{
  self->iGCapture->Stop(); 
  Py_INCREF(Py_None);
  return Py_None;
}

//---------------------------------------------------------------------------

static void dealloc_GlobCapture(obj_GCapture* aCapture)
{ 
  delete aCapture->iGCapture;
  aCapture->iGCapture = NULL;
  PyObject_Del(aCapture);    
}
 
static const PyMethodDef GlobCapture_methods[] =
  {
    {"start", (PyCFunction)Start, METH_VARARGS},
    {"stop", (PyCFunction)Stop, METH_NOARGS},
    {NULL, NULL} /* sentinel */
  };

static PyObject *getattr_GlobCapture(PyObject *self, char *name)
{
  return Py_FindMethod(const_cast<PyMethodDef*>(&GlobCapture_methods[0]), self, name);
}


static const PyTypeObject type_template_GlobCapture = {
    PyObject_HEAD_INIT(0)   
    0,                 /*ob_size*/
    "_globcapture.New",            /*tp_name*/
    sizeof(obj_GCapture), /*tp_basicsize*/
    0,                 /*tp_itemsize*/
    /* methods */
    (destructor)dealloc_GlobCapture, /*tp_dealloc*/
    0, /*tp_print*/
    (getattrfunc)getattr_GlobCapture,

}; 




static const PyMethodDef globcapture_methods[] =
{
  {"New", (PyCFunction)New_GlobCapture, METH_VARARGS},
  {0, 0} 
};


#define DEFTYPE(name,type_template)  do {\
    PyTypeObject* tmp = PyObject_New(PyTypeObject, &PyType_Type);\
    *tmp = (type_template);\
    tmp->ob_type = &PyType_Type;\
    SPyAddGlobalString((name), (PyObject*)tmp);\
  } while (0)
 


extern "C" {

 DL_EXPORT(void) initaudiostream(void)
 {
    PyObject *m;
    DEFTYPE("GlobCapture",type_template_GlobCapture);
    m = Py_InitModule("_globcapture", (PyMethodDef*)globcapture_methods);
    PyModule_GetDict(m);    
 }
        

} 

GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
  
}












