import powlite_fm,appuifw,os,uikludges,audio,e32,appswitch,time,switchoff
def ru(x):return x.decode('utf-8')
os.sys.setdefaultencoding('utf-8')
SDS,fm='E:/Sounds/',powlite_fm.manager()
def START():
 appuifw.app.body=appuifw.Text()
 global l
 appuifw.app.menu,appuifw.app.exit_key_handler,l=[(ru('Плейлист'),((ru('Добавить'),ALLFOLD),(ru('Выбрать'),FILES),(ru('Изменить'),EDIT))),(ru('Вырезать песни'),SHORT),(ru('Изменить метки'),TEGED),(ru('Таймер'),((ru('Закрыть плеер'),SLEEP),(ru('Выключить телефон'),OFF))),(ru('Главная'),EXIT)],EXIT,[]
 uikludges.set_right_softkey_text(ru('Выйти'))
def ALLFOLD():
 dir=fm.AskUser(SDS,find='dir')
 r='#EXTM3U\n'
 for x in os.listdir(dir):
  if x[-4:]=='.mp3' or x[-4:]=='.Mp3' or x[-4:]=='.MP3':r=r+str(dir)+x+'\n'
 open(SDS+appuifw.query(ru('Название плейлиста:'),'text')+'.m3u','w').write(str(r))
 appuifw.note(ru('Добавлено'))
def ADD():
 global l
 fl=fm.AskUser(SDS,ext=['.mp3'])
 if fl==None:return
 l.append(fl)
 FILES()
def ADDF():
 global l
 dir=fm.AskUser(SDS,find='dir')
 for x in os.listdir(dir):
  if x[-4:]=='.mp3' or x[-4:]=='.Mp3' or x[-4:]=='.MP3':l.append(str(dir)+ru(x))
 FILES()
def DEL():
 global l
 ix=listbox.current()
 del l[ix]
 FILES()
def MOVEUP():
 global l
 ix=listbox.current()
 st=l[ix]
 l.remove(st)
 l.insert(ix-1,st)
 FILES()
def MOVEDOWN():
 global l
 ix=listbox.current()
 st=l[ix]
 l.remove(st)
 l.insert(ix+1,st)
 FILES()
def SAVE():
 r='#EXTM3U\n'
 for x in l:r=r+x+'\n'
 n=appuifw.query(ru('Название плейлиста:'),'text')
 if n==None:return
 open(SDS+n+'.m3u','w').write(str(r))
 appuifw.note(ru('Успешно сохранено'))
def LOOK():appuifw.query(l[listbox.current()],'query')
def ACTION():[ADD,ADDF][appuifw.popup_menu([ru('Добавить файл'),ru('Добавить папку')],ru('Функции:'))]()
def ACTIONO():[ADD,ADDF,DEL,MOVEUP,MOVEDOWN,LOOK,SAVE][appuifw.popup_menu([ru('Добавить файл'),ru('Добавить папку'),ru('Удалить из списка'),ru('Переместить файл'),ru('Переместить вниз'),ru('View Details'),ru('Сохранить список')],ru('Функции:'))]()
def FILES():
 global listbox
 if len(l)==0:appuifw.app.body=listbox=appuifw.Listbox([ru('Пусто')],ACTION)
 else:
  appuifw.app.body=listbox=appuifw.Listbox(l,ACTIONO)
  listbox.bind(0x8,DEL)
 appuifw.app.menu,appuifw.app.exit_key_handler=[(ru('Назад'),START)],START
 uikludges.set_right_softkey_text(ru('Назад'))
def EDIT():
 global l
 fl=fm.AskUser(SDS,ext=['.m3u'])
 t=open(fl,'r').readlines()
 for x in t:
  x=x.replace('\r\n','').replace('\n','')
  if x=='#EXTM3U':pass
  else:l.append(ru(x))
 FILES()
def SHORT():
 fl=fm.AskUser(path=SDS,ext=['.mp3'])
 c=audio.Sound.open(fl).duration()
 f=open(fl)
 st=appuifw.query(ru('Время начала'),'time')/6*100000
 srt=st/c*os.path.getsize(fl)
 fs=appuifw.query(ru('Время окончания'),'time')/6*100000
 if fs<st:
  appuifw.note(ru('Неверное время'),'error')
  return
 else:fns=fs/c*os.path.getsize(fl)
 f.seek(srt)
 if appuifw.query(ru('Сохранить в эту папку?'),'query'):n=open(fm.AskUser(SDS,find='dir')+appuifw.query(ru('Имя входного файла:'),'text')+'.mp3','w',fns-srt)

 else:n=open(fl[:-4]+'_short.mp3','w',fns-srt)
 appuifw.note(ru('Пожалуйста, подождите...'))

 n.write(f.read(fns-srt))
 appuifw.note(ru('Успешно сохранено'))
def SLEEP():
 i=appuifw.popup_menu([ru('Введите время (минуты)'),ru('Перерыв')],'')
 if i==None:return
 if i==0:
  e32.ao_sleep(appuifw.query(ru('Через сколько минут?'),'number')*60)
  appswitch.kill_app(ru('Программа'))
  appuifw.note(ru('Программа была закрыто!'),'info',1)
 if i==1:
  t=appuifw.query(ru('Время закрытия программы'),'time')
  if t==None:return
  appuifw.note(ru('Настройки сохранены'))
  a=t/3600
  b=(int(t)-int(a)*3600)/60
  while 1:
   r=time.localtime(time.time())
   if int(a)==int(r[3]) and int(b)==int(r[4]):
    appswitch.kill_app(ru('Игроки'))
    appuifw.note(ru('Программа была закрыта'),'info',1)
    os.abort()
   e32.ao_sleep(1)
def OFF():
 i=appuifw.popup_menu([ru('Введите время (минуты)'),ru('Перерыв')],'')
 if i==None:return
 if i==0:
  e32.ao_sleep(appuifw.query(ru('Через сколько минут?'),'number')*60)
  switchoff.Shutdown()
 if i==1:
  t=appuifw.query(ru('Введите время выключения телефона'),'time')
  if t==None:return
  appuifw.note(ru('Настройки сохранены'))
  a=t/3600
  b=(int(t)-int(a)*3600)/60
  while 1:
   r=time.localtime(time.time())
   if int(a)==int(r[3]) and int(b)==int(r[4]):
    switchoff.Shutdown()
   e32.ao_sleep(1)
def HX(a):
 s,c=['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'],'0'*4
 if a/16>15:
  if a/256>15:return c+s[a/4096]+s[(a%4096)/256]+s[((a%4096)%256)/16]+s[a%16]+c+'01'
  return c+'0'+s[a/256]+s[(a%256)/16]+s[a%16]+c+'01'
 return c+'00'+s[a/16]+s[a%16]+c+'01'
def TEGED():
 fl=fm.AskUser(SDS,ext=['.mp3'])
 if fl==None:return
 ar=appuifw.query(ru('Исполнитель'),'text')
 if ar==None:return
 ti=appuifw.query(ru('Название'),'text')
 if ti==None:return
 tg='ID3'+('03'+'0'*8+'5f77').decode('hex')+'TPE1'+(HX(len(ar)*2+3)).decode('hex')+ar.encode('UTF-16')+'TIT2'+(HX(len(ti)*2+3)).decode('hex')+ti.encode('UTF-16')+'0'+('0'*1024).decode('hex')
 try:
  file(fl,'r+').write(tg)
  appuifw.note(ru('Изменено.'))
 except:appuifw.note(ru('Изменить файл'),'error')

def EXIT():
 if appuifw.query(ru('Вы хотите выйти из этой программы?'),'query'):lilipy()
START()