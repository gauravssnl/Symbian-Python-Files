import os
import e32
import audio
from key_codes import *
from graphics import *
import appuifw
from appuifw import *

def ru(x):
    x.decode('utf-8')


ao = e32.Ao_lock()

def vyhod():
    appuifw.app.set_exit()


appuifw.app.screen = 'full'

def handle_redraw(rect):
    canvas.blit(img)


canvas = appuifw.Canvas(event_callback=None, redraw_callback=handle_redraw)
appuifw.app.body = canvas
path1 = 'e:/others/'
path = path1.decode('utf-8')
mask = [u'.ogg',
 u'.mp3',
 u'.wav',
 u'.amr',
 u'wma']
spisok = []
chisl = 10

def in_spisok(path):
    global spisok
    spisok = []
    z = path.encode('utf-8')
    try:
        x = os.listdir(z)
    except:
        x = []
    flag = 1
    for t in range(len(x)):
        w = x[t].decode('utf-8')
        if (w.count(u'.') == 0):
            spisok.append((u'>' + w))
        if (w.count(u'.') > 0):
            tat = 0
            for p in mask:
                if w.endswith(p):
                    tat = 1

            if (tat == 1):
                spisok.append(w)

    if (len(spisok) < 1):
        spisok.append(u'...empty...')
    spisok.sort()



def galki():
    for i in xrange(0, chisl):
        if (spisok[(i + nach)][0] == u'>'):
            p = 1
        else:
            x_path = (path + spisok[(i + nach)])
            for t in new:
                if (t == x_path):
                    y = ((i * 15) + 40)
                    img.line((161,
                     y,
                     165,
                     (y + 5)), 0, width=4)
                    img.line((165,
                     (y + 5),
                     170,
                     (y - 5)), 0, width=4)





def draw(path, list, nach, kurs):
    global flag_out
    global flag_in
    global chisl
    global img
    img = Image.new((176,
     208))
    img.rectangle((2,
     2,
     175,
     140), 7851093, width=200)
    flag = 0
    img.line((12,
     ((kurs * 15) + 25),
     150,
     ((kurs * 15) + 25)), 16711680, width=14)
    img.line((125,
     200,
     168,
     200), 3381521, width=12)
    img.line((6,
     200,
     110,
     200), 3381521, width=12)
    img.line((7,
     6,
     168,
     6), 3381521, width=12)
    img.text((10,
     12), 'Playlist ver.0.8 by \xd0\x98\xd0\xb3\xd0\xbe\xd1\x80\xd1\x8c.kAIST'.decode('utf-8'), 16777215)
    img.text((130,
     206), u'vol', 0)
    for w in range(0, vol):
        img.line((((2 * w) + 145),
         206,
         ((2 * w) + 145),
         (206 - w)), 16711680, width=1)

    if state_sound:
        img.text((10,
         206), in_play[0:18], 0)
    if (nach == 0):
        img.text((10,
         30), path, 0)
        flag_in = 1
        img.point((2,
         25,
         2,
         25), 0, width=5)
    else:
        flag_in = 0
        img.text((10,
         30), u'. . . .', 0)
        img.line((2,
         30,
         2,
         15), 0, width=1)
        img.line((2,
         25,
         7,
         25), 0, width=1)
    chisl = 10
    flag_out = 1
    if (len(spisok) < (10 + nach)):
        flag_out = 0
        chisl = (len(spisok) - nach)
    if (flag_out == 1):
        img.text((10,
         ((15 * 13) - 2)), u'. . . .', 0)
        img.line((2,
         190,
         7,
         190), 0, width=1)
        img.line((2,
         170,
         2,
         190), 0, width=1)
    for i in xrange(0, chisl):
        y = ((i * 15) + 45)
        img.text((10,
         y), spisok[(i + nach)][0:20], 0, font='legend')
        img.line((2,
         (y - 5),
         7,
         (y - 5)), 0, width=1)
        img.line((2,
         (y - 5),
         2,
         (y - 20)), 0, width=1)

    galki()
    handle_redraw(())



def Up():
    global nach
    global kurs
    if (kurs > 0):
        kurs = (kurs - 1)
    if ((flag_in == 0) and (kurs == 0)):
        nach = (nach - 10)
        kurs = 10



def Down():
    global nach
    global kurs
    if ((flag_out == 1) and (kurs == 10)):
        nach = (nach + 10)
        kurs = 1
    elif (kurs < chisl):
        kurs = (kurs + 1)



def stop():
    global state
    state = 0
    x = 'new_playlist'.decode('utf-8')
    nazv = u' '
    x = query('\xd0\xa1\xd0\xbe\xd1\x85\xd1\x80\xd0\xb0\xd0\xbd\xd0\xb8\xd1\x82\xd1\x8c \xd0\xba\xd0\xb0\xd0\xba:'.decode('utf-8'), 'text', u'new_playlist')
    save_path = ((path + x) + '.m3u'.decode('utf-8'))
    dad = save_path.encode('utf-8')
    t = open(dad, 'w')
    t.write(u'#EXTM3U\r\n')
    for m in range(1, len(new)):
        tar = new[m].encode('utf-8')
        for j in range(2, len(tar)):
            if (tar[(len(tar) - j)] == '/'):
                path2 = tar[((len(tar) - j) + 1):len(tar)]
                break

        path3 = path2
        t.write((('#EXTINF:-1,' + path3) + '\r\n'))
        tar2 = tar
        x = tar2.replace('/', '\\ppppp')
        y = x.replace('ppppp', '')
        t.write(y)
        t.write(u'\r\n')

    t.close()
    note(('\xd0\xa1\xd0\xbe\xd1\x85\xd1\x80\xd0\xb0\xd0\xbd\xd0\xb5\xd0\xbd\xd0\xbe \xd0\xb2:\n'.decode('utf-8') + path))
    state = 0



def galka_on():
    if (spisok[((kurs + nach) - 1)][0] == u'>'):
        p = 1
    else:
        zet = 0
        for m in range(len(new)):
            x_path = (path + spisok[((kurs + nach) - 1)])
            if (x_path == new[m]):
                zet = 1
                break

        if (zet == 1):
            del new[m]
        else:
            new.append(x_path)



def ok(mad):
    global path
    global nach
    global kurs
    path1 = u' '
    x = ((nach + kurs) - 1)
    elem = spisok[x]
    if (mad == 0):
        galka_on()
    if ((elem[0] == u'>') and ((kurs > 0) and ((mad == 0) or (mad == 2)))):
        path1 = elem[1:len(elem)]
        path = ((path + path1) + u'/')
        in_spisok(path)
        kurs = 1
        nach = 0
    ma = 0
    if ((kurs == 0) or (mad == 1)):
        for j in range(2, len(path)):
            if (path[(len(path) - j)] == u'/'):
                path2 = path[0:((len(path) - j) + 1)]
                path = path2
                in_spisok(path)
                nach = 0
                break



vol = 5
state_sound = 0
in_play = u'....'

def play():
    global in_play
    global j
    global state_sound
    if (state_sound == 0):
        in_play = spisok[((kurs + nach) - 1)]
        c = (path + in_play)
        x = c.replace('/'.decode('utf-8'), '\\ppppp'.decode('utf-8'))
        y = x.replace('ppppp'.decode('utf-8'), ''.decode('utf-8'))
        j = audio.Sound.open(y)
        j.play()
        j.set_volume(vol)
        state_sound = 1
    else:
        j.stop()
        state_sound = 0



def zvuk_up():
    global vol
    if (vol < 11):
        vol = (vol + 1)
    if (state_sound == 1):
        j.set_volume(vol)



def zvuk_down():
    global vol
    if (vol > 0):
        vol = (vol - 1)
    if (state_sound == 1):
        j.set_volume(vol)



def new():
    global path
    global state
    global kurs
    global nach
    global new
    path1 = 'e:/'
    path = path1.decode('utf-8')
    kurs = 1
    state = 1
    shisl = 5
    new = [u'#EXTM3U']
    in_spisok(path)
    nach = 0
    canvas.bind(EKey0, lambda :stop()
)
    canvas.bind(EKeyUpArrow, lambda :Up()
)
    canvas.bind(EKeyDownArrow, lambda :Down()
)
    canvas.bind(EKeySelect, lambda :ok(0)
)
    canvas.bind(EKeyLeftArrow, lambda :ok(1)
)
    canvas.bind(EKeyRightArrow, lambda :ok(2)
)
    canvas.bind(EKey5, lambda :play()
)
    canvas.bind(EKey4, lambda :zvuk_down()
)
    canvas.bind(EKey6, lambda :zvuk_up()
)
    while state:
        draw(path, spisok, nach, kurs)
        e32.ao_sleep(1E-04)



new()

