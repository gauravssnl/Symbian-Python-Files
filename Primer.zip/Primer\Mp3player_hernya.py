import appuifw
import e32
import audio

######  Начало  ######

appuifw.app.screen='full' 
#дeлaeм пoлный экpaн

def ru(x):
  return x.decode('utf-8')
#пишeм нa pyccкoм языкe

def playing_start():
  global s
  try:
    s=audio.Sound.open('c:\\system\\apps\\player\\audio\\sound.wav')
    s.play()
  except:
    s=audio.Sound.open('e:\\system\\apps\\player\\audio\\sound.wav')
    s.play()

def playing(x):
  global S
  try:
    S=audio.Sound.open('e:\\sounds\\mp3\\player\\'+str(x))
    S.play()
  except:
    appuifw.note(ru('Ошибка'),'info')
    menu_ng()

def exit_key_handler():
  app_lock.signal()
# зaдaeм кнoпкy выxoдa
app_lock=e32.Ao_lock

######  OKHA  ######

def scr():
  appuifw.app.body=k=appuifw.Canvas()
  k.clear(0x333bbb)
  k.line((1,10,176,10),0xffffff)
  k.line((0,200,176,200),0xffffff)
  k.text((10,30),ru('1-Трек 1'),0xffffff)
  k.text((10,40),ru('2-Трек 2'),0xffffff)
  k.text((10,50),ru('3-Tрек 3'),0xffffff)
  k.text((10,60),ru('4-Трек 4'),0xffffff)
  k.text((10,70),ru('5-Трек 5'),0xffffff)
  k.text((10,80),ru('6-Трек 6'),0xffffff)
  k.text((10,90),ru('7-Трек 7'),0xffffff)
  k.text((10,100),ru('8-Трек 8'),0xffffff)
  k.text((10,110),ru('9-Трек 9'),0xffffff)
  k.text((80,190),ru('0-Назад'),0xffffff)
  k.bind(49,pl1)
  k.bind(50,pl2)
  k.bind(51,pl3)
  k.bind(52,pl4)
  k.bind(53,pl5)
  k.bind(54,pl6)
  k.bind(55,pl7)
  k.bind(56,pl8)
  k.bind(57,pl9)
  k.bind(48,menu_ng)
  playing_start()

def pl1():
  playing('1.Mp3')

def pl2():
  playing('2.Mp3')

def pl3():
  playing('3.Mp3')

def pl4():
  playing('4.Mp3')

def pl5():
  playing('5.Mp3')

def pl6():
  playing('6.Mp3')

def pl7():
  playing('7.Mp3')

def pl8():
  playing('8.Mp3')

def pl9():
  playing('9.Mp3')

def menu_ng():
  appuifw.app.body=k=appuifw.Canvas()# nado!
  k.clear(0x000055)
  k.line((1,10,176,10),0xffffff)
  k.line((0,200,176,200),0xffffff)
  k.text((50,40),ru('>Играть'),0x000fff)
  k.text((50,60),ru('Помощь'),0xaaa000)
  k.text((50,80),ru('Выход'),0xbbbaaa)
  k.bind(50,menu_exit)
  k.bind(53,scr)
  k.bind(56,menu_about)
  playing_start()

def menu_about():
  appuifw.app.body=k=appuifw.Canvas()
  k.clear(0x000055)
  k.line((1,10,176,10),0xffffff)
  k.line((0,200,176,200),0xffffff)
  k.text((50,40),ru('Играть'),0x000fff)
  k.text((50,60),ru('>Помощь'),0xaaa000)
  k.text((50,80),ru('Выход'),0xbbbaaa)
  k.bind(50,menu_ng)
  k.bind(53,about)
  k.bind(56,menu_exit)
#Сдeлaли пpивязкy к клaвишaм
  playing_start()

def menu_exit():
  appuifw.app.body=k=appuifw.Canvas()
  k.clear(0x000055)
  k.line((1,10,176,10),0xffffff)
  k.line((0,200,176,200),0xffffff)
  k.text((50,40),ru('Играть'),0x000fff)
  k.text((50,60),ru('Помощь'),0xaaa000)
  k.text((50,80),ru('>Выход'),0xbbbaaa)
  k.bind(53,exit)
  k.bind(50,menu_about)
  k.bind(56,menu_ng)
  playing_start()

def about():
  appuifw.app.body=k=appuifw.Canvas()
  k.clear(0x000055)
  k.text((80,15),ru('Мр3'),0x005555)
  k.text((3,30),ru('Простой Мр3-плейер для смарта,'),0x005555)
  k.text((3,40),ru('играет на полную громкость.'),0x005555)
  k.text((3,50),ru('Треки переключаются кн. 1-9,'),0x005555)
  k.text((3,60),ru('выход в главное меню-0'),0x005555)
  k.text((3,90),ru('Вопросы по асе 460027814'),0x005555)
  k.text((30,140),ru('5ноября 2007г   <cvеаrtoоl>'),0x005555)
  k.rectangle((1,1,175,219),0x424242)
  k.bind(53,menu_about)
  playing_start()

def exit():
    appuifw.app.set_exit()
#вызывaeм выxoд из пpoгpaммы

# Bсе, теперь поехали
menu_ng()
appuifw.app.exit_key_handler = exit_key_handler
#