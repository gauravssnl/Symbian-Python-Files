
formats = ['mp3','wav','m4a','3gp','mp4','amr','wma','awb']

k = []
ss = 0
gr_par = 0
proskok = 100000
#####################
from e32 import Ao_lock, ao_sleep
from audio import Sound, EOpen
from appuifw  import app, Listbox, note, query
from appswitch import switch_to_bg
from os import listdir, abort, stat, makedirs
from sys import setdefaultencoding
from random import randint
from keycapture import KeyCapturer

dir_settings = app.full_name()[0] + u':\\system\\apps\\cylili\\data\\'
settings = dir_settings + u'player.ini'


def ru(x):return x.decode("utf-8")

def ur(x):return x.encode("utf-8")

def pl(x, y):
 i = 0
 while i < len(x):
  try:
   lb = listdir(y + x[i])
   pl(lb, y + x[i] + '\\')
  except:
   if (x[i][-3:]).lower() in formats:
    fn.append(ru(x[i]))
    fd.append(y + x[i])
  i += 1

def playing(prev, cur, err):
 if cur == EOpen:  lock.signal()

def rand():
 global k
 pr = len(fd)
 par = 10
 r = randint(0, pr)
 if pr >= par:
   par = pr - 1
 while r in k:
   r += randint(0, pr)
   if r>par: r = r - par
 if len(k) >= par: k = k[1:par]
 k.append(r)
 app.body.set_list(fn, r)
 return r

def select(x = 0):
   global a, ss
   s = app.body.current()
   if ss == s and x == 0: s = rand()
   a = Sound.open(fd[s])
   a.play(callback = playing)
   app.title = fn[s]
   ss = s
   setvup()
   lock.wait()
   stop()
   app.title = u'Player'
   select()

def stop():
  try: setvdown()
  except:pass
  try:
   a.stop()
   a.close()
  except:pass

def vupp():
 global v
 if v >= a._player.max_volume():
  v = a._player.max_volume()
 else: v = v + 1
 a.set_volume(v)

def vdown():
 global v
 if v <= 0: v = 0
 else: v = v - 1
 a.set_volume(v)

def forward():
     global proskok,rep
     global posn
     dur=a.duration()
     posn=a.current_position()
     stat=a.state()
     if stat==2:a.stop()
     if posn<dur-proskok:posn+=proskok
     a.set_position(posn+5000000)
     if stat==2:a.set_position(posn+5000000),a.play(),a.set_volume(v)

def rewers():
     global proskok,rep
     global posn
     posn=a.current_position()
     stat=a.state()
     if stat==2:a.stop()
     if posn>proskok:posn-=proskok
     a.set_position(posn-5000000)
     if stat==2:a.set_position(posn-5000000),a.play(),a.set_volume(v)

def pause():
   global pos
   global stat
   try:  stat = a.state()
   except: stat = 0
   if stat==2:
     pos=a.current_position()/100000
     a.stop()
   if stat==1:
     a.set_position(pos*100000)
     a.play()
     a.set_volume(v)
     pos=0
   if stat==0:
     select(1)

def exit(): 
  f1=open(settings,'wb')
  f1.write(p + '\n' + str(v) + '\n'+str(setsoftvol)+ '\n')
  f1.close()
  stop()
  abort()

def joystick():
  if ss == app.body.current(): pause()
  else: select()

def setvdown():
  if v > 1 and setsoftvol == 1:
    for v0 in range(-v, 0):
      a.set_volume(-v0)
      ao_sleep(0)

def setvup(x = 0.1):
  if v > 1 and setsoftvol == 1:
   for v0 in range(0,v):
     a.set_volume(v0)
     ao_sleep(x)
  else:  a.set_volume(v)

def new_pl():
  stop()
  r.set_list([ru('Поиск музыки ...')])
  ao_sleep(0)
  global fn, fd
  fn, fd = [], []
  try:
    stat(p)
    pl(listdir(p), p)
    note(ru('Найти музыкальные дорожки' + str(len(fn)) + 'us'),'conf',1)
  except: note(ru('Установить папку после запуска программы'),'error')
  if len(fn) < 1: fn.append(ru('Музыкальные треки не найдены')),fd.append(None)
  r.set_list(fn)

def green(key = None):
  global gr_par
  if gr_par == 0:
    keys.start()
    gr_par = 1
    note(ru('Выключено'),'conf',1)
  else:
    keys.stop()
    gr_par = 0
    note(ru('Включено'),'error',1)

def key_funcs(x):
  if x == 48: vdown()
  if x == 49: pause()
  if x == 50: stop()
  if x == 52: select()
  if x == 53: joystick()
  if x == 54: select()
  if x == 55: rewers()
  if x == 56: vupp()
  if x == 57: forward()

def switch():  appuifw.e32.start_exe('z:\\sys\\bin\\phone.exe','')(u'Player')

def enter_p():
  global p
  pp = query(ru('Сканирование файлов:'), 'text', ru(p))
  if pp != None: 
    p = ur(pp)
    new_pl()

def ssv():
  global setsoftvol
  if setsoftvol == 1:
    setsoftvol = 0
    note(ru('Повторять одну'),'conf')
  else:
    setsoftvol = 1
    note(ru('Повторять все'),'conf')

def trackinfo(): note(fn[ss])


#####################

try:
  stat(dir_settings)
except:
 makedirs(dir_settings)

try:
  f = open(settings)
  sets = f.readlines()
  f.close()
except:pass
try: p = sets[0][:-1]
except: p = 'e:\\sounds\\digital\\'
try: v = long(sets[1][:-1])
except: v = 10
try: setsoftvol = long(sets[2][:-1])
except: setsoftvol = 1

kc = KeyCapturer(green)
kc.keys = [0xf862]
kc.forwarding = 1
kc.start()

keys = KeyCapturer(key_funcs)
keys.keys = [48,49,50,52,53,54,55,56,57]
keys.forwarding = 0

lock = Ao_lock()
setdefaultencoding("UTF-8")
app.body = r = Listbox([ru('Поиск ...')], joystick)
new_pl()
app.menu=[(ru('Управление'),((ru('Играть / Пауза (ОК, 5)'), joystick), (ru('Играть / Пауза (1)'), pause), (ru('Стоп (2)'), stop))),(ru('Композиции'),((ru('Следующая (6)'),select),(ru('Предыдущая (4)'),select))), (ru('Прокрутка'),((ru('Вперед (9)'),forward), (ru('Назад (7)'),rewers))),  (ru('Громкость'),((ru('Увеличение (8)'),vupp), (ru('Уменьшить (0)'),vdown))),(ru('Функции'),((ru('Клавиши (вкл / выкл)'),green),(ru('Повтор треков'),ssv), (ru('Обновить плейлист'), new_pl),(ru('Папка сканирования'),enter_p), (ru('О первом треке (C)'),trackinfo), (ru('Скрыть (#)'), switch), (ru('Эквалайзер'), lambda: note(ru('В разработке. . .')))))]
r.bind(48, vdown)
r.bind(49, pause)
r.bind(50, stop)
r.bind(52, select)
r.bind(53, joystick)
r.bind(54, select)
r.bind(55, rewers)
r.bind(56, vupp)
r.bind(57, forward)
r.bind(63496, vupp)
r.bind(63495, vdown)
r.bind(35, switch) 
r.bind(8, trackinfo)
app.exit_key_handler=exit
