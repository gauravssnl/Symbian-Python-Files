import e32,appuifw
from graphics import *
import geticon

canvas=appuifw.Canvas()
appuifw.app.screen="full"
appuifw.app.body=canvas

canvas.clear(0xeeeeee)

uid=0xa89fd974
_img=geticon.get(uid,(50,50))
img=Image.from_cfbsbitmap(_img[0])
img_mask=Image.from_cfbsbitmap(_img[1])
canvas.blit(img,mask=img_mask)

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit

app_lock.wait()
