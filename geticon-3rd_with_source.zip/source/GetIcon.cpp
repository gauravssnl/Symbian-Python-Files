#include <fbs.h> //CFbsBitmap
#include <aknsskininstance.h> //MAknsSkinInstance
#include <aknsutils.h> //AknsUtils

#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Get(PyObject* /*self*/,PyObject* args)
{
 TUint uid;
 TUint width;
 TUint height;
 if (!PyArg_ParseTuple(args, "i(ii)", &uid, &width, &height))
    return NULL;
  
 const TUid UID = {uid};
 CFbsBitmap*	img(NULL);
 CFbsBitmap*	img_mask(NULL);

 MAknsSkinInstance* skin = AknsUtils::SkinInstance();
	AknsUtils::CreateAppIconLC(skin, UID, EAknsAppIconTypeContext, img, img_mask);
	CleanupStack::Pop(2);

 AknIconUtils::SetSize(img, TSize(width, height));
 AknIconUtils::SetSize(img_mask, TSize(width, height));

 PyObject* arr = PyList_New(2);
 PyList_SetItem( arr, 0, Py_BuildValue("O",PyCObject_FromVoidPtr(img, NULL)));
 PyList_SetItem( arr, 1, Py_BuildValue("O",PyCObject_FromVoidPtr(img_mask, NULL)));
 
 return arr;
}
 
//--------------------------------------------------------------------------

static const PyMethodDef geticon_met[] = {
    {"get", (PyCFunction)Get, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("geticon", geticon_met);
}

//--------------------------------------------------------------------------
