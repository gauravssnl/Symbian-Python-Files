import py_compile,SisManFMM2,os

fileman=SisManFMM2.manager()

#print str(py_compile)

#print dir(py_compile)
filepath = fileman.AskUser(find='dir')#,ext=['.py'])
if filepath!=None:
    M=os.listdir(filepath[:-1].encode('utf8'))
    for i in M:
        if i.lower().endswith('.py'):
            py_compile.compile(filepath.encode('utf8')+i)
    print 'ok'