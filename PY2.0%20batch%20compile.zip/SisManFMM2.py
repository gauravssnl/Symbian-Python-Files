#coding:utf8
def ru(x):
    return x.decode("utf8")
def ur(x):
    return x.encode("utf8")

class manager:
    def __init__(self):
        from _e32 import Ao_lock,drive_list
        from posix import listdir,stat
        from cfileman import FileMan
        from _appuifw import app,Listbox
        from globalui import global_msg_query
        self.__msg=global_msg_query
        self.__filemaner=FileMan()
        self.__lock=Ao_lock()
        self.__listt=listdir
        self.__Listbox=Listbox
        self.__Dr=drive_list()
        self.__ui=app;self.__ex=stat
        del app,stat,Ao_lock,Listbox,listdir,FileMan,drive_list,global_msg_query
    def __listdir(self,dir):
        dir=ur(dir)
        if dir[-1]!='\\':
            dir+='\\'
        d,f=[],[]
        def __F(N):
            if self.isfile(dir+N):self.__N+=1;return [1,ru(N)]
            else:return [2,ru(N)]
        def __G(a,b):
            if a[0]>b[0]:return 0
            if a[0]<b[0]:return -1
            return -(unicode(a[1]).lower()<unicode(b[1]).lower())
        try:L=self.__listt(dir)
        except:return [d,f]
        self.__N=0
        if L:
            L=map(__F,L)
            L.sort(__G)
            L=map(lambda x:x[1],L)
            d=L[:self.__N];f=L[self.__N:]
        del L
        return [d,f]
    def exists(self,path):
        try:
            if path[:-1] in self.__Dr:return 1
            return self.__filemaner.exists(path)
        except:
            return 0
    def isfile(self,path):
        try:
            return self.__filemaner.is_dir(ru(path))
        except:
            return 1
    def AskUser(self,path=u'',find='file',ext=[],mark=False,recent=None,title=None):
        self.__old=(
            self.__ui.body,
            self.__ui.menu,
            self.__ui.screen,
            self.__ui.exit_key_handler,
            self.__ui.focus,
            self.__ui.title)
        self.__ext=map(lambda i:i.replace('.','').lower(),ext)
        self.__find=find
        self.__Mark=mark
        self.__MarkL=[]
        self.__recent=recent
        self.__Path=path
        self.__Endpath=u''
        if self.__Path:
            if not self.exists(self.__Path):
                self.__Endpath,self.__Path='C:',u''
            elif self.isfile(self.__Path):
                p=self.__Path.split('\\')
                self.__Path='\\'.join(p[:-1])+'\\'
                self.__Endpath=p[-1];del p
            else:
                if self.__Path[-1]!='\\':self.__Path+='\\'
        if not title:
            if self.__Mark:
                self.__title=ru('Mark file')
            elif self.__find is 'file':
                self.__title=ru('Choose file')
            elif self.__find is 'dir':
                self.__title=ru('Choose folder')
        else:self.__title=title
        self.__ui.title=self.__title
        self.__ui.body=self.__Body=self.__Listbox([ru('Please wait')],lambda:self.__Move(3))
        self.__ui.exit_key_handler=self.__Exit
        if self.__recent:
            if not self.exists(self.__recent):
                try:self.__filemaner.mkdir('\\'.join(self.__recent.split('\\')[:-1])+'\\',1)
                except:pass
                f=open(ur(self.__recent),'w')
                f.write(repr([[],[]]))
                f.close()
            f=open(ur(self.__recent),'r')
            self.__R=eval(f.read())
            f.close()
            self.__R[0]=filter(lambda x:self.exists(x),self.__R[0])
            self.__R[1]=filter(lambda x:self.exists(x),self.__R[1])
        self.__scan()
        self.__lock.wait()
        self.__ui.body,self.__ui.menu,self.__ui.screen,self.__ui.exit_key_handler,self.__ui.focus,self.__ui.title=self.__old
        self.__old=None
        i=self.__Body.current()
        if self.__Path is None:return self.__Path
        elif self.__find is 'dir':
            return self.__Path+self.__D[i].replace('[','').replace(']','')+'\\'
        elif self.__Mark:
            return self.__MarkL
        if self.__recent:
            P=self.__Path+self.__D[i].title()
            if len(self.__R[0])==8:del self.__R[0][-1:]
            if P in self.__R[0]:self.__R[0].remove(P)
            self.__R[0]=[P]+self.__R[0];del P
            f=open(ur(self.__recent),'w')
            f.write(repr([self.__R[0],self.__R[1]]))
            f.close()
        return self.__Path+self.__D[i]
    def __Exit(self):
        self.__Path=None
        self.__lock.signal()
    def __Go(self):
        self.__drive=[]
        self.__D=map(lambda x:x.split('\\')[-1],self.__R[0])
        if self.__ext:
            self.__D=filter(lambda x:x.split('.')[-1].lower() in self.__ext,self.__D)
            if not self.__D:
                self.__Lendir=-2
                self.__Body.set_list([ru('No mate file')],0)
                return
        self.__Lendir=-1
        self.__Body.set_list(self.__D,0)
        self.__ui.menu=[(ru('Ok'),self.__Ok),(ru('Details'),self.__Info)]
    def __MarkFile(self):
        i=self.__Body.current()
        if self.__Lendir<0 or not self.__Path:return
        elif i<self.__Lendir:
            self.__Lendir=-3;self.__Index=i
            self.__Body.set_list([ru('Only mark file')],0)
            return
        T=self.__Path+self.__D[i].replace(ru('√'),'')
        if not T in self.__MarkL:
            self.__MarkL.append(T)
        else:
            self.__MarkL.remove(T)
        self.__Move(4);del T
    def GetSize(self,x):
        if x < 0:
            x=x+4294967296
        if x is 0:
            return u"0 B"
        elif x < 1000:
            return u"%s B"%x
        elif x < 1024000:
            return u"%s KB"%round(x / float(1024), 2)
        elif x < 1048576000:
            return u"%s MB"%round(x / float(1024**2), 2)
        else:
            return u"%s GB"%round(x / float(1024**3), 2)

    def __scan(self,N=0):
        if self.__Path and not self.exists(self.__Path):
            if self.__Path==u'AB\\':self.__Go();return
            self.__Lendir=-2
            self.__Body.set_list([ru('Unreal file')],0)
            return
        _Current=0;self.__drive=[]
#        self.__Lendir=0
        if not self.__Path:
            if self.__recent:
                if self.__R[0] and not self.__find is 'dir':
                    self.__drive+=[ru('History file')];B=[u'AB']
                else:B=[]
                self.__drive+=self.__Dr+self.__R[1]
                self.__D=B+self.__Dr+self.__R[1];del B
                self.__Lendir=self.__LenLists=len(self.__D)
            else:
                self.__drive=self.__Dr
                self.__D=self.__Dr
                self.__Lendir=self.__LenLists=len(self.__D)
            if self.__Endpath:
                try:_Current=map(lambda x:x.lower(),self.__D).index(self.__Endpath.lower())
                except:_Current=0
        else:
            if not N:self.__Body.set_list([ru('Please wait...')])
            D=self.__listdir(self.__Path)
            if self.__ext:
                D=[D[0],filter(lambda x:x.split('.')[-1].lower() in self.__ext,D[1])]
                if not D[0] and not D[1]:
                    self.__Lendir=-2
                    self.__Body.set_list([ru('No mate file')],0)
                    return
            elif self.__find is 'dir':
                D=[D[0],[]]
            if not D[0] and not D[1]:
                self.__Lendir=-2
                self.__Body.set_list([ru('Empty folder')],0)
                return
            if self.__Mark:
                f=[]
                for x in D[1]:
                    if self.__Path+x in self.__MarkL:f.append(ru('√')+x)
                    else:f.append(x)
                D=[D[0],f];del f
            self.__D=D[0]+D[1]
            self.__Lendir=len(D[0]);del D
            if self.__Endpath:
                try:_Current=map(lambda x:x.lower(),self.__D).index(self.__Endpath.lower())+1
                except:_Current=0
            self.__D=[ru('<<<')]+map(lambda x:'['+x+']',self.__D[:self.__Lendir])+self.__D[self.__Lendir:]
            self.__Lendir+=1
            self.__LenLists=len(self.__D)
            if N:return
        if self.__drive:
            self.__Body.set_list(self.__drive,_Current)
            self.__ui.menu=[]
        else:
            self.__Body.set_list(self.__D,_Current)
            self.__ui.menu=[(ru('Ok'),self.__Ok),(ru('Details'),self.__Info),(ru('Back'),lambda:self.__Move(5))]
    def __Info(self):
        i=self.__Body.current()
#        T=u'';S=u'';V=u''
        if self.__D[i]==ru('<<<'):return
        elif self.__Lendir in [-2,-3]:return
        elif self.__Lendir is -1:
            T=self.__R[0][i]
            S=ru('Size: ')+u'%s'%(self.GetSize(self.__ex(ur(T))[6]));T+='\n'+S;del S
        elif i<self.__Lendir and self.__Path:
            T=self.__Path+self.__D[i].replace('[','').replace(']','')+'\\'
            if self.__Mark:
                V=ru('Mark: %d'%self.__MarkL.__len__());T+='\n'+V;del V
        elif i>=self.__Lendir and self.__Path:
            T=self.__Path+self.__D[i].replace(ru('√'),'')
            S=ru('Size: ')+u'%s'%(self.GetSize(self.__ex(ur(T))[6]));T+='\n'+S;del S
            if self.__Mark:
                V=ru('Mark: %d'%self.__MarkL.__len__());T+='\n'+V;del V
        self.__msg(ru('Path: ')+T,ru('Info'),3);del T
    def __Ok(self):
        i=self.__Body.current()
        if self.__Lendir is -1:
            p=self.__R[0][i].split('\\')
            self.__Path='\\'.join(p[:-1])+'\\';del p
        elif self.__find is 'file':# and not self.__Mark:
            if self.__Mark and not self.__MarkL:
                if self.__D[i]!=ru('<<<'):
                    self.__MarkL.append(self.__Path+self.__D[i])
                else:#elif not self.__MarkL:
                    self.__Path=None
            elif self.__Mark and self.__MarkL:pass
            elif self.__D[i]==ru('<<<'):
                self.__Path=None
            elif i<self.__Lendir:
                self.__Path=None
        self.__lock.signal()
    def __Move(self,Mode):
        i=self.__Body.current()        
        if Mode is 3:
            if self.__Lendir in [-2,-3] or self.__D[i]==ru('<<<'):
                self.__Move(5);return
            if self.__Lendir is -1:
                self.__Move(6);return
            elif i<self.__Lendir:
                self.__Endpath=None
                self.__Path+=self.__D[i].replace('[','').replace(']','')+'\\'
                self.__scan()
            elif self.__Mark and  self.__find is 'file' and not self.__drive:
                self.__MarkFile()
            else:
                self.__Move(4)
#                self.__lock.signal()
        elif Mode is 4:
            self.__scan(1)
            if i<self.__LenLists-1:
                self.__Body.set_list(self.__D,i+1)
            else:
                self.__Body.set_list(self.__D,0)
        elif Mode is 5 and self.__Path:
            if self.__Lendir is -1:
                self.__Move(7);return
            elif self.__Lendir is -3:#in [-2,-3]:
                __Path=self.__Path+self.__D[self.__Index].replace('[','').replace(']','')+'\\'
                self.__Endpath=__Path.split('\\')[-2]
                self.__scan();return
            self.__Endpath=self.__Path.split('\\')[-2]
            self.__Path='\\'.join(self.__Path.split('\\')[:-2])+'\\'
            if self.__Path==u'\\':
                self.__Path=u''
            self.__scan()
        elif Mode is 6:
            p=self.__R[0][i].split('\\')
            self.__Path='\\'.join(p[:-1])+'\\'
            self.__Endpath=p[-1];del p
            self.__scan()
        elif Mode is 7:
            self.__Path=u''
            self.__Endpath=u'AB'
            self.__scan()
if __name__=='__main__':
    F=manager()
    print F.AskUser(recent='d:\\1.db',mark=0)#find='dir',