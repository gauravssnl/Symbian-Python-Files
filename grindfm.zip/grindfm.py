import appuifw as a
import urlaudiostream,e32,mediakeys,globalui,os
from urllib import urlopen
from graphics import Image
from sysinfo import display_pixels
from key_codes import *


e32.ao_yield()


def ru(x):return x.decode('u8')


infopopup=a.InfoPopup()
def ipop(x):infopopup.show(ru(x))


screen_w, screen_h = display_pixels()
if screen_w==360 and screen_h==640:
  x=y=128
  imgmask=Image.new(size= (x,y),mode = '1')
  imgmask.load('e:\mask128.png')
else:
  x=y=64
  imgmask=Image.new(size= (x,y),mode = '1')
  imgmask.load('e:\mask64.png')
w=-((screen_w-x)*0.5)
h=12-screen_h


fon=Image.new((screen_w,screen_h),mode='RGB')


img=Image.open("e:\Img.jpg").resize((screen_w, screen_h))
imgup=Image.open("e:\up.png").resize((x,y))
imgdown=Image.open("e:\down.png").resize((x,y))


class StreamFM:
  def __init__(s):
    if os.path.exists('C://settings.cfg'):
      file=open('C://settings.cfg','r').read()
      if file<>'':
        exec file
      else:s.vol=20
    else:s.vol=20
    
    s.start_finish=Image.open("e:\play.png").resize((x,y))
    s.key=mediakeys.New(s.keyc)
    s.stream=urlaudiostream.New(s.status)

    a.app.screen='full'
    a.app.body=s.t=a.Canvas(redraw_callback=s.rdrw)
    a.app.menu=[(ru('Выход'),s.exit)]
    a.app.exit_key_handler=s.lasttracks
    try:
      s.t.bind(63557,s.start_or_stop)
      s.t.bind(63497,s.volup)
      s.t.bind(63498,s.voldown)
    except:pass
    try:
      s.t.bind(EButton1Down,start_or_stop,((w,h+128),(w,h+64)))
      s.t.bind(EButton1Down,s.volup,((w,h+192),(w,h+128)))
      s.t.bind(EButton1Down,s.voldown,((w,h+64),(w,h)))
    except:pass
    s.status(0)
    s.rdrw(0)

  def exit(s):
    open('C://settings.cfg','wb').write('s.vol='+str(s.vol))
    os.abort()

  def status(s,val):
    s.state=val

  def rdrw(s,x):
    fon.clear()
    fon.blit(img)
    fon.blit(imgup,(w,h+192),mask=imgmask)
    fon.blit(imgdown,(w,h+64),mask=imgmask)
    fon.blit(s.start_finish,(w,h+128),mask=imgmask)
    s.t.blit(fon)
    if s.state()==1 or s.state()==2 or s.state()==3:
      s.t.text((0,50), s.trackname.decode('u8'), 0x00ff00, font=(u'Nokia Hindi S60', 15, a.STYLE_BOLD))
    else:
      s.t.text((0,0), u'', 0x00ff00, font=(u'Nokia Hindi S60', 10, a.STYLE_BOLD))
    s.t.text((0,25), {0:'Статус: Стоп',1:'Подключено',2:'Статус: Подключение...',3:'Статус: Проигрывается...'}[s.state()].decode('u8'), 0x00ff00, font=(u'Nokia Hindi S60', 15, a.STYLE_BOLD))

  def volup(s):
    if s.vol+5>100:
      ipop('Громкость: '+str(s.vol))
      return
    ipop('Громкость: '+str(s.vol+5))
    s.vol+=5
    s.stream.volume(s.vol)
  def voldown(s):
    if s.vol-5<0:
      ipop('Громкость: '+str(s.vol))
      return
    ipop('Громкость: '+str(s.vol-5))
    s.vol-=5
    s.stream.volume(s.vol)

  def keyc(s,key):
    if key==1:s.volup()
    elif key==3:s.voldown()

  def start_or_stop(s):
    if s.state()==0:
      s.stream.play(u"http://radio.goha.ru:8000/grind.fm")
      s.start_finish=Image.open("e:\stop.png").resize((x,y))
      s.t.blit(s.start_finish,(w,h+128),mask=imgmask)
      s.gettracknames()
    else:
      s.stream.stop()
      s.start_finish=Image.open("e:\play.png").resize((x,y))
      s.t.blit(s.start_finish,(w,h+128),mask=imgmask)

  def gettracknames(s):
    while 1:
      data=urlopen("http://www.grind.fm/sites/grind.fm/counter/meta2.php").read()
      data=data.replace("; do_refresh_list();","").replace("var metalist=","")
      list=eval(data)
      tracklist=[]
      x=13
      while x>0:
        tracklist+=[(list[len(list)-x])[1]+'-'+(list[len(list)-x])[2]]
        x-=1
      s.trackname=tracklist[len(tracklist)-1]
      s.rdrw(0)

  def lasttracks(s):
    lasttrackslist=''
    site=urlopen("http://www.grind.fm/sites/grind.fm/counter/meta2.php").read()
    site=site.replace("; do_refresh_list();","").replace("var metalist=","")
    list1=eval(site)
    tracklist=[]
    x=13
    while x>0:
      tracklist+=[(list1[len(list1)-x])[1]+'-'+(list1[len(list1)-x])[2]]
      x-=1
    for k in tracklist:
      if k<>tracklist[len(tracklist)-1]:
        lasttrackslist=k+'\n\n'+lasttrackslist
    globalui.global_msg_query(ru(lasttrackslist.rstrip()), ru('Ранее проиграные'))

StreamFM()
lck=e32.Ao_lock().wait()