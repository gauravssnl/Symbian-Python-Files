import appuifw,math,time,e32,agraphics
from graphics import *
from random import randint as pt
img=0
def redraw(rect): 
  if img: canvas.blit(img)

canvas=appuifw.Canvas(redraw_callback=redraw)
appuifw.app.screen="full"
appuifw.app.body=canvas

img=Image.new(canvas.size)

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit

img=Image.new((240,320))
pic=Image.new((240,320))
img.clear(0xdddddd)
#agraphics.aline(img,(-5,30,280,80),0x229999)
#agraphics.arc(img,(5,5,235,305),2,3,0xaa2222)
#agraphics.ellipse(img,(20,20,280,380),0x8822dd)
#cur=(0,150, 80,20, 160,150, 220,20)
cur=(120,5,120,103,120,206, 120,320)
#img.line(cur,0xcccccc)
def lits():
  global cur
  dd=(pt(-20,20),0,pt(-20,20),pt(-20,20),pt(-20,20),pt(-20,20),pt(-20,20),0)
  fe=[]
  for i in range(8):
    fe.append((dd[i]+cur[i]))
  return tuple(fe)
for i in range(50):
  img.clear(0)
  for j in range(10):
    curt=lits()
    agraphics.curve(img,curt,0xf0f0ff)
  redraw(())
  e32.ao_sleep(.0)

#agraphics.pieslice(img,(80,180,200,310),0.3, 5.8,  0xaa22dd)

#agraphics.rrectangle(img,(20,120,180,220),40,40, 0x881111)
'''for i in range(300):
  img.clear(0)
  agraphics.aline(img,(5,5,220,i),0x8822f999)
  agraphics.aline(img,(225,5,20,320),0x229999)
  agraphics.pieslice(img,(80,180,200,310),0.3+i/100, i,  0xaa22dd)
  e32.ao_sleep(.01)'''
redraw(())
print dir(agraphics

)
app_lock.wait() 