#include <fbs.h> //CFbsBitmap
#include <coemain.h>
#include <f32file.h>
#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Create(PyObject* /*self*/,PyObject* args)
{
 PyObject* obj_filename;
 PyObject* obj_list;
 if (!PyArg_ParseTuple(args, "UO", &obj_filename, &obj_list))
    return NULL;
  
 TPtrC filename((TUint16*) PyUnicode_AsUnicode(obj_filename),
                           PyUnicode_GetSize(obj_filename));

 _LIT(KTempFile,"d:\\");
 TBuf<8> buf;
 TInt count = PyList_Size(obj_list);
 PyObject *item=NULL;
 
 typedef TBuf<1024> TNames;
 TNames** filenames = new ( ELeave ) TNames*[count];
 CleanupStack::PushL( filenames );
 
 TInt32* uniqueIds = new ( ELeave ) TInt32[count];
 CleanupStack::PushL( uniqueIds );
 
 for (TInt i=0; i<count; i++)
 {
  item = PyList_GetItem(obj_list, i);
  CFbsBitmap *bitmap = (CFbsBitmap*)PyCObject_AsVoidPtr(
                    PyObject_CallObject(PyObject_GetAttrString(
                    item,"_bitmapapi"),NULL));
  buf.Copy(KTempFile);
  buf.AppendNum(i);
  bitmap->Save(buf);
  
  uniqueIds[i] = 0;
  filenames[i] = new (ELeave) TNames(buf);
 }

 CFbsBitmap::StoreL(filename, count, (const TDesC**)filenames, uniqueIds);

 for (TInt i=0; i<count; i++)
 {
     CCoeEnv::Static()->FsSession().Delete(*((const TDesC*)filenames[i]));
     delete filenames[i];
 }

 CleanupStack::PopAndDestroy( filenames );
 CleanupStack::PopAndDestroy( uniqueIds );

 Py_INCREF(Py_None);
 return Py_None;
}
 
//--------------------------------------------------------------------------

static const PyMethodDef multimbm_met[] = {
    {"create", (PyCFunction)Create, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("multimbm", multimbm_met);
}

//--------------------------------------------------------------------------
