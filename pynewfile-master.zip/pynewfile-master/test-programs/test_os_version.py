import sysinfo
print repr(sysinfo.os_version())
