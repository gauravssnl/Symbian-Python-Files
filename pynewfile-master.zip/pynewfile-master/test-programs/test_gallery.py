import pynewfile

# This does not work as desired even though Gallery IS launched.

gallery_uid = 0x101f8599
print repr(pynewfile.take_photo(gallery_uid))
