This is `pynewfile`, a Python for S60 extension for capturing images
via the Camera application, and possibly other things.

http://new.contextlogger.org/pynewfile/
