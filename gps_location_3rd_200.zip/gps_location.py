#
# gps_location.py
#
# Copyright (c) 2007 Christophe Berger <christophe.berger@lip6.fr>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import e32

import _gps_location

def position():
    """
      Returns the position (Latitude, Longitude, Altitude, VerticalAccuracy, HorizontalAccuracy)
    """
    if e32.s60_version_info>=(3,0):
        return _gps_location.position()
    else:
        return None

def position_timestamp():
    """
      Returns the timestamp of the GPS data, from year to microseconds.
    """
    if e32.s60_version_info>=(3,0):
        return _gps_location.position_timestamp()
    else:
        return None

def phone_time():
    """
      Returns the time of the phone from year to microseconds (may not be accurate).
    """
    if e32.s60_version_info>=(3,0):
        return _gps_location.phone_time()
    else:
        return None

def module_name():
    """
      Module used to get GPS data. i.e. Bluetooth, Internal...
      'Last known position' if data returned was in cache.
    """
    if e32.s60_version_info>=(3,0):
        return _gps_location.module_name()
    else:
        return None


def set_update_options(UpdateIntervalMicroSeconds, UpdateTimeOutMicroSeconds, MaxAgeMicroSeconds, AcceptPartialUpdates):
    """
      Allows to set the update options.
        Update Interval in MicroSeconds,
				Update Time Out in MicroSeconds,
				Max Age of GPS data in MicroSeconds,
				Whenever or not to Accept Partial Updates
				
			Returns the error code.
    """
    if e32.s60_version_info>=(3,0):
        return _gps_location.set_update_options(UpdateIntervalMicroSeconds, UpdateTimeOutMicroSeconds, MaxAgeMicroSeconds, AcceptPartialUpdates)
    else:
        return None
