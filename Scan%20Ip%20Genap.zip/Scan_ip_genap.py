def cek(x1,y1,x2,y2,x3,y3,x4,y4,x5,y5,x6,y6,x7,y7,x8,y8,x9,y9,x10,y10,x11,y11,x12,y12,x13,y13,x14,y14,x15,y15,x16,y16,x17,y17,x18,y18,x19,y19,x20,y20,x21,y21,x22,y22,x23,y23,x24,y24,x25,y25,x26,y26,x27,y27,x28,y28,x29,y29,x30,y30,x31,y31,x32,y32,x33,y33,x34,y34,x35,y35,x36,y36,x37,y37,x38,y38,x39,y39,x40,y40,x41,y41,x42,y42,x43,y43,x44,y44,x45,y45,x46,y46):
  if x1==y1 or x2==y2 or x3==y3 or x4==y4 or x5==y5 or x6==y6 or x7==y7 or x8==y8 or x9==y9 or x10==y10 or x11==y11 or x12==y12 or x13==y13 or x14==y14 or x15==y15 or x16==y16 or x17==y17 or x18==y18 or x19==y19 or x20==y20 or x21==y21 or x22==y22 or x23==y23 or x24==y24 or x25==y25 or x26==y26 or x27==y27 or x28==y28 or x29==y29 or x30==y30 or x31==y31 or x32==y32 or x33==y33 or x34==y34 or x35==y35 or x36==y36 or x37==y37 or x38==y38 or x39==y39 or x40==y40 or x41==y41 or x42==y42 or x43==y43 or x44==y44 or x45==y45 or x46==y46: return True
  else: return False

def pjg(x):
  return len(x)

ip1='182.0.'
ip2='182.2.'
ip3='182.4.'
ip4='182.6.'
ip5='182.8'
ip6='182.10.'
ip7='182.12.'
ip8='182.14.'
ip9='182.16.'
ip10='10.18.'
ip11='39.184.'
ip12='39.186.'
ip13='39.188.'
ip14='39.190.'
ip15='39.192.'
ip16='39.194.'
ip17='39.196.'
ip18='39.198.'
ip19='39.200.'
ip20='39.202.'
ip21='39.204.'
ip22='39.206.'
ip23='39.208.'
ip24='39.210.'
ip25='39.212.'
ip26='39.214.'
ip27='39.216.'
ip28='39.218.'
ip29='39.220.'
ip30='39.222.'
ip31='39.224.'
ip32='39.226.'
ip33='39.228.'
ip34='39.230.'
ip35='39.232.'
ip36='39.234.'
ip37='39.236.'
ip38='39.238.'
ip39='39.240.'
ip40='39.242.'
ip41='39.244.'
ip42='39.246.'
ip43='39.248.'
ip44='39.250.'
ip45='39.252.'
ip46='39.254.'

from socket import*;from appuifw import*;from e32 import*

def pilih_apn():
  list=[]
  apn=access_points()
  for i in range(len(apn)):
    l=apn[i]['name']
    list.append(l)
  n=popup_menu(list,unicode('PILIH JALUR KONEKSI'))
  if n != None:
    id = access_points()[n]['iapid']
    return id
  else:
    id = access_points()[0]['iapid']
    return id

iapid = pilih_apn()
con = access_point(iapid)

def nama_apn():
  n = unicode(' ')
  global iapid
  apn = access_points()
  for i in range(len(apn)):
    if apn[i]['iapid'] == iapid:
      n = apn[i]['name']
  return n

run = 0
nama = nama_apn()
teks = unicode('JALUR KONEKSI: '+str(nama)+'\nIP TARGET: \n[1.] '+str(ip1)+'\n[2.] '+str(ip2)+'\n[3.] '+str(ip3)+'\n[4.] '+str(ip4)+'\n[5.] '+str(ip5)+'\n[6.] '+str(ip6)+'\n[7.] '+str(ip7)+'\n[8.] '+str(ip8)+'\n[9.] '+str(ip9)+'\n[10.] '+str(ip10)+'\n[11.] '+str(ip11)+'\n[12.] '+str(ip12)+'\n[13.] '+str(ip13)+'\n[14.] '+str(ip14)+'\n[15.] '+str(ip15)+'\n[16.] '+str(ip16)+'\n[17.] '+str(ip17)+'\n[18.] '+str(ip18)+'\n[19.] '+str(ip19)+'\n[20.] '+str(ip20)+'\n[21.] '+str(ip21)+'\n[22.] '+str(ip22)+'\n[23.] '+str(ip23)+'\n[24.] '+str(ip24)+'\n[25.] '+str(ip25)+'\n[26.] '+str(ip26)+'\n[27.] '+str(ip27)+'\n[28.] '+str(ip28)+'\n[29.] '+str(ip29)+'\n[30.] '+str(ip30)+'\n[31.] '+str(ip31)+'\n[32.] '+str(ip32)+'\n[33.] '+str(ip33)+'\n[34.] '+str(ip34)+'\n[35.] '+str(ip35)+'\n[36.] '+str(ip36)+'\n[37.] '+str(ip37)+'\n[38.] '+str(ip38)+'\n[39.] '+str(ip39)+'\n[40.] '+str(ip40)+'\n[41.] '+str(ip41)+'\n[42.] '+str(ip42)+'\n[43.] '+str(ip43)+'\n[44.] '+str(ip44)+'\n[45.] '+str(ip45)+'\n[46.] '+str(ip46))

while run == 0:
  print teks
  con.start()
  ip = con.ip()
  hasil = cek(ip[:pjg(ip1)],ip1,ip[:pjg(ip2)],ip2,ip[:pjg(ip3)],ip3,ip[:pjg(ip4)],ip4,ip[:pjg(ip5)],ip5,ip[:pjg(ip6)],ip6,ip[:pjg(ip7)],ip7,ip[:pjg(ip8)],ip8,ip[:pjg(ip9)],ip9,ip[:pjg(ip10)],ip10,ip[:pjg(ip11)],ip11,ip[:pjg(ip12)],ip12,ip[:pjg(ip13)],ip13,ip[:pjg(ip14)],ip14,ip[:pjg(ip15)],ip15,ip[:pjg(ip16)],ip16,ip[:pjg(ip17)],ip17,ip[:pjg(ip18)],ip18,ip[:pjg(ip19)],ip19,ip[:pjg(ip20)],ip20,ip[:pjg(ip21)],ip21,ip[:pjg(ip22)],ip22,ip[:pjg(ip23)],ip23,ip[:pjg(ip24)],ip24,ip[:pjg(ip25)],ip25,ip[:pjg(ip26)],ip26,ip[:pjg(ip27)],ip27,ip[:pjg(ip28)],ip28,ip[:pjg(ip29)],ip29,ip[:pjg(ip30)],ip30,ip[:pjg(ip31)],ip31,ip[:pjg(ip32)],ip32,ip[:pjg(ip33)],ip33,ip[:pjg(ip34)],ip34,ip[:pjg(ip35)],ip35,ip[:pjg(ip36)],ip36,ip[:pjg(ip37)],ip37,ip[:pjg(ip38)],ip38,ip[:pjg(ip39)],ip39,ip[:pjg(ip40)],ip40,ip[:pjg(ip41)],ip41,ip[:pjg(ip42)],ip42,ip[:pjg(ip43)],ip43,ip[:pjg(ip44)],ip44,ip[:pjg(ip45)],ip45,ip[:pjg(ip46)],ip46)
  if hasil == True:
    print ip
    note(unicode('ip : '+str(ip)+'\noke, sudah ketemu.. Gan'),'conf')
    run = 1
    break
  else:
    run = 0
    teks = unicode('\nip: '+str(ip))
    con.stop()