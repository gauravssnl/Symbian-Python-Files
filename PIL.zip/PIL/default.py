# coding: utf-8

'''
Calls 0.5.5
автор: Ильнур 
сайт: www.ilnurgi.ru
системные требования: symbian, python 2.0
программа совершает вызов по номеру, взятого из буфера обмена
'''

import sys, telephone, clipboard, rkeypress, msys, laa2, globalui
lock=telephone.e32.Ao_lock()

def tell_call(number):
    kod={'0':48,'1':49,'2':50,'3':51,'4':52,'5':53,'6':54,'7':55,'8':56,'9':57,'*':42,'#':127}
    telephone.e32.ao_sleep(0.1)
    rkeypress.press(197)
    telephone.e32.ao_sleep(0.3)
    for i in number:
        if i=='+':
            telephone.e32.ao_sleep(1)
            rkeypress.press(42)
            telephone.e32.ao_sleep(0.1)
            rkeypress.press(42)
            telephone.e32.ao_sleep(0.1)
        else:
            rkeypress.press(kod[i])
            telephone.e32.ao_sleep(0.1)
    rkeypress.press(196)
    telephone.e32.ao_sleep(10)
    lock.signal()
    
A=clipboard.Get().lower()
dic={   u'а':'%E0',
        u'б':'%E1',
        u'в':'%E2',
        u'г':'%E3',
        u'д':'%E4',
        u'е':'%E5',
        u'ё':'%B8',
        u'ж':'%E6',
        u'з':'%E7',
        u'и':'%E8',
        u'й':'%E9',
        u'к':'%EA',
        u'л':'%EB',
        u'м':'%EC',
        u'н':'%ED',
        u'о':'%EE',
        u'п':'%EF',
        u'р':'%F0',
        u'с':'%F1',
        u'т':'%F2',
        u'у':'%F3',
        u'ф':'%F4',
        u'х':'%F5',
        u'ц':'%F6',
        u'ч':'%F7',
        u'ш':'%F8',
        u'щ':'%F9',
        u'ъ':'%FA',
        u'ы':'%FB',
        u'ь':'%FC',
        u'э':'%FD',
        u'ю':'%FE',
        u'я':'%FF'}
if A:
    msys.send_bg()
    # проверка на номер
    if (A[0]=='+' and A[1:].isdigit()==True) or A.isdigit()==True:
        try:telephone.hang_up()
        except:pass
        telephone.dial(A)
        telephone.e32.ao_sleep(10)
        lock.signal()

    # проверка на ussd
    elif A[0]=='*':
        tell_call(A)
        
    # иначе браузер
    else:
        url = u'http://www.google.ru/m?q='
        print A
        for i in A:
            print '---', i
            if dic.has_key(i):
                url +=dic[i]
            else:
                url +=i
        print url
        laa2.execute_param(0x10008d39, u'http://www.google.ru/m?q=hello')
        telephone.e32.ao_sleep(10)
        lock.signal()
else:
    globalui.global_note(u'Буфер обмена пуст','info')
    lock.signal()
    
lock.wait()            