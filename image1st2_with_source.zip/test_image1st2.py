import image1st2,e32
from graphics import *

img=Image.new((50,50))
img.rectangle((0,0,50,50),0x66dd22,0x66dd22)
img.line((0,0,50,50),0xffffff)

image1st2.resize(img,(70,40))

#gif (not compatible with Ngage)
# jpg png bmp mbm wbmp wmf wmfapm wmfclp ota 
#may not support all formats
image1st2.save(img,u'e:\\test.jpg')

image1st2.rotate(img,90) # 90 180 270 
image1st2.save(img,u'e:\\test.Png')

image1st2.resize(img,(30,30)) 
image1st2.save(img,u'e:\\TEST.BMP')
