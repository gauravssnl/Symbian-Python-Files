#
# camera.py
#
# Copyright (c) 2005 - 2007 Nokia Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import e32

import _camera2
import graphics

_my_camera=_camera2.Camera(0)
number_of_devices = _my_camera.cameras_available()
device=[]
for dev_index in range(number_of_devices):
    device.append(_camera2.Camera(dev_index)) #used only for image size checking
_my_call_back=None
_backlight_on=0

EOpenComplete=_camera2.EOpenComplete
EPrepareComplete=_camera2.EPrepareComplete
ERecordComplete=_camera2.ERecordComplete

formatmap={'Mono'     : _camera2.EFormatMono,
           'RGB444'   : _camera2.EFormat16RGB444,
           'RGB565'   : _camera2.EFormat16RGB565,
           'RGB888'   : _camera2.EFormat32RGB888,
           'Jpeg_Jfif': _camera2.EFormatJpeg,
           'Jpeg_Exif': _camera2.EFormatExif,
           'RGB12'    : _camera2.EColor4K,
           'RGB16'    : _camera2.EColor64K,
           'RGB24'    : _camera2.EColor16M,
           'User'     : _camera2.EFormatUser,
           'YUV420i'  : _camera2.EFormatYUV420i,
           'YUV420p'  : _camera2.EFormatYUV420p,
           'YUV422'   : _camera2.EFormatYUV422,
           'YUV422r'  : _camera2.EFormatYUV422r,
           'YUV444'   : _camera2.EFormatYUV444,
           'YUV420sp' : _camera2.EFormatYUV420sp,
           'RGB24u'   : _camera2.EColor16MU,
           'MJpeg'    : _camera2.EFormatMJPEG,
           'H264'     : _camera2.EFormatH264}  # New!
          #'YUV422r2' : _camera2.EFormatYUV422r2}

modemap={'RGB':_camera2.EColor16M,
         'RGB16':_camera2.EColor64K,
         'RGB12':_camera2.EColor4K,
         'JPEG_Exif':_camera2.EFormatExif,
         'JPEG_JFIF':_camera2.EFormatJpeg}

flashmap={'none':_camera2.EFlashNone,
          'auto':_camera2.EFlashAuto,
          'forced':_camera2.EFlashForced,
          'fill_in':_camera2.EFlashFillIn,
          'red_eye_reduce':_camera2.EFlashRedEyeReduce}

whitebalancemap={'auto':_camera2.EWBAuto,
                 'daylight':_camera2.EWBDaylight,
                 'cloudy':_camera2.EWBCloudy,
                 'tungsten':_camera2.EWBTungsten,
                 'fluorescent':_camera2.EWBFluorescent,
                 'flash':_camera2.EWBFlash}

exposuremap={'auto':_camera2.EExposureAuto,
             'night':_camera2.EExposureNight,
             'backlight':_camera2.EExposureBacklight,
             'center':_camera2.EExposureCenter}

def _finder_call_back(image_frame):
    global _backlight_on
    global _my_call_back
    if(_backlight_on):
        e32.reset_inactivity()
    _my_call_back(graphics.Image.from_cfbsbitmap(image_frame))
def _main_pane_size():
    try:
        if e32.s60_version_info>=(2,8):
            import appuifw
            return appuifw.app.layout(appuifw.EMainPane)[0]
    except:
        pass
    return (176, 144) # hard coded default

def take_photo(mode='RGB16',size=(640, 480),zoom=0,flash='none',
               exposure='auto',white_balance='auto',position=0):
    s=-1
    if (position>=number_of_devices):
        raise ValueError, "Camera position not supported"  
    for i in range(device[position].max_image_size()):
        if device[position].image_size(modemap[mode], i)==size:
            s=i
            break
    if s==-1:
        raise ValueError, "Size not supported for camera"   
                            
    if _my_camera.taking_photo():
        raise RuntimeError, "Photo request ongoing"

    if mode=='JPEG_Exif' or mode=='JPEG_JFIF':
        return _my_camera.take_photo(modemap[mode],s,
                                     zoom,flashmap[flash],
                                     exposuremap[exposure],
                                     whitebalancemap[white_balance],
                                     position)
    else:        
        return graphics.Image.from_cfbsbitmap(_my_camera.take_photo(modemap[mode],s,
                                                                    zoom,flashmap[flash],
                                                                    exposuremap[exposure],
                                                                    whitebalancemap[white_balance],
                                                                    position))
def start_finder(call_back, backlight_on=1, size=_main_pane_size()):
    global _my_camera
    if _my_camera.finder_on():
        raise RuntimeError, "View finder is started already"
    global _my_call_back
    global _backlight_on
    if not callable(call_back):
        raise TypeError("'%s' is not callable"%call_back)
    _my_call_back=call_back
    _backlight_on=backlight_on
    _my_camera.start_finder(_finder_call_back, size)
def stop_finder():
    global _my_camera
    global _my_call_back
    _my_camera.stop_finder()
    _my_call_back=None
def video_formats(): # New!
    formats=[]
    supported = _my_camera.video_formats()
    for key in formatmap:
        if formatmap[key] & supported:
            formats.append(key)
    return formats
def frame_sizes(mode='YUV420p'): # New!
    sizes=[]
    for i in range(_my_camera.max_frame_size()):
        s=_my_camera.frame_size(formatmap[mode], i)
        if s!=(0,0):
            sizes.append(s)
    return sizes
def frame_rates(mode='YUV420p', exposure='auto'): # New!
    rates=[]
    sizes=[]
    for i in range(_my_camera.max_frame_size()):
        s=_my_camera.frame_size(formatmap[mode], i)
        if s!=(0,0):
            for j in range(_my_camera.max_frame_rate()):
                r=_my_camera.frame_rate(formatmap[mode], j, i, exposuremap[exposure])
                if r > 0.0:
                    rates.append({'size':s, 'size_index':i, 'rate':r})
    return rates
def image_modes():
    ret=[]
    modes=_my_camera.image_modes()
    for key in modemap:
        if (modes&modemap[key]):
            ret.append(key)
    return ret
def image_sizes(mode='RGB16'):
    sizes=[]
    for i in range(_my_camera.max_image_size()):
        s=_my_camera.image_size(modemap[mode], i)
        if s!=(0,0):
            sizes.append(s)
    return sizes
def max_zoom():
    return _my_camera.max_zoom()
def flash_modes():
    ret = []
    modes = _my_camera.flash_modes()
    for key in flashmap:
        if (modes&flashmap[key]):
            ret.append(key)
        if (flashmap[key]==0):
            ret.append(key)
    return ret
def exposure_modes():
    ret = []
    modes = _my_camera.exposure_modes()
    for key in exposuremap:
        if (modes&exposuremap[key]):
            ret.append(key)
        if (exposuremap[key]==0):
            ret.append(key)
    return ret
def white_balance_modes():
    ret = []
    modes = _my_camera.white_balance_modes()
    for key in whitebalancemap:
        if (modes&whitebalancemap[key]):
            ret.append(key)
        if (whitebalancemap[key]==0):
            ret.append(key)
    return ret
def cameras_available():
    return _my_camera.cameras_available()
def release():
    global _my_camera
    global number_of_devices
    global device
    _my_camera.release()
    for dev_index in range(number_of_devices):
        device[dev_index].release()
def _handle():
    return _my_camera.handle()

_my_video=_camera2.Video()

def start_record(filename, cb, size=(176,144), format='YUV420p'):
    s=-1
    for i in range(_my_camera.max_frame_size()):
        if _my_camera.frame_size(formatmap[format], i) == size:
            s=i
            break
    if s==-1:
        raise ValueError, "Size not supported for capture"

    if not _my_camera.finder_on():
        raise RuntimeError, "View finder is not started"    
    if not callable(cb):
        raise TypeError("'%s' is not callable"%cb)
    _my_video.start_record(_handle(), unicode(filename), cb, size, formatmap[format])
    
def stop_record():
    _my_video.stop_record()
