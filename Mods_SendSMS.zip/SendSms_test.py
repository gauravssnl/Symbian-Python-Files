import SendSMS
SendSMS.send(u'10086','Привет'.decode('utf8'))
