import flashsms
flashsms.send('15860812356','Привет'.decode('utf8'))