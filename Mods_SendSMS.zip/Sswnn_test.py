import e32
f = open('E:\\smstext.txt','w')
f.write('Привет'.decode('utf8').encode('utf8'))
f.close()
e32.start_exe('sendsmswithnonote.exe','10086')