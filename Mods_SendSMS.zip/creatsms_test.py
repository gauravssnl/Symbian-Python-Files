import creatsms

creatsms.creat('10086'.decode('utf8'),'Привет'.decode('utf8'))
