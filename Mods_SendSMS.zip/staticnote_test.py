import StaticNote
StaticNote.note('Тест инфо'.decode('utf8'),'info')
#第二个参数还可以用err,conf
#以下是弹出像来电通的关于部分一样的
StaticNote.linknote('тест'.decode('utf8'),'Адрес\nСайт:www.baidu.com'.decode('utf8'),u'www.baidu.com')
#