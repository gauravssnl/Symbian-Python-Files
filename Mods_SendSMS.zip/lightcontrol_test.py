import lightcontrol

lightcontrol.on('pd',0,10,0)
lightcontrol.blink('pd',5000,200,200,100)
lightcontrol.off('pd',0,0)
print lightcontrol.supportedtargets()
print lightcontrol.status('pd')
lightcontrol.reserve('pd',1,1)
lightcontrol.release('pd',1,1)
