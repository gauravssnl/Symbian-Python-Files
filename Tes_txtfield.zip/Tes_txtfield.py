import txtfield,appuifw
e32=appuifw.e32
lock=e32.Ao_lock()

def quit():
  box.n.visible(0)
  lock.signal()

class box:
  def __init__(self):
    #self.font=txtfield.LoadFont(u'e:\\0master\\font\\ttf\\AdPro.ttf')
    self.font=txtfield.LoadFont(u'e:\\0master\\font\\ttf\\Becket.ttf')
    self.n=None
  def show(self):
    self.n=txtfield.New((0,80,240,129),cornertype=txtfield.ECorner5)
    self.n.bgcolor(0x00dd00)
    self.n.add(u'testing menulis')
    self.n.focus(0)
    self.n.textstyle(self.font,0xdad000)
    print dir(self.n)

box=box()
box.show()
appuifw.app.exit_key_handler=quit
lock.wait()