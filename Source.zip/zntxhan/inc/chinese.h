#include <utf.h>
#ifndef _ICONV_H_
#define _ICONV_H_

void iconv(TDes& aText,TInt aNum)
{
	if (aNum)
	{
		_LIT8(u8text, "加壳中...");
		TInt a=CnvUtfConverter::ConvertToUnicodeFromUtf8(aText, u8text);
	}
	else
	{
	_LIT8(u8txt, "脱壳中...");
	TInt a=CnvUtfConverter::ConvertToUnicodeFromUtf8(aText, u8txt);
	}
}
#endif

