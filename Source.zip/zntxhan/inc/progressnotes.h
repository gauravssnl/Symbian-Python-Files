#include <eikprogi.h>
#include <aknprogressdialog.h>
 
class  CProgressNotes //: public CBase , public MProgressDialogCallback
{	
public: 
   CProgressNotes() : iProgressDialog(NULL), iProgressInfo(NULL) {};
   void ConstructL(TInt aFinalValue);
   void UpdateProcessL(TInt aProgress,const TDesC& aProgressText);
   void Finishl();
   
private:	
   CAknProgressDialog*  iProgressDialog;
   CEikProgressInfo*    iProgressInfo;
   
   TInt iRscOffset;
};

