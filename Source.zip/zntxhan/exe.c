#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* CSearchVal(char* iData, int L, char* dir)

{ 
// char *outstr;
 char *astr="\x00\x04\x10\x20\x50\x80\x09\x0a\x0d";
 unsigned int iIndex=0, loindex=0;
 FILE *fp;

 if ((fp=fopen(dir, "wb"))==NULL)
    {
    return "can't open file";
    }
 while (iIndex < (L-1))
 {
  if (((iData[1] == astr[0]) && (iData[0] >= astr[3]) && (iData[0] < astr[5])) || ((iData[1] == astr[1]) && (iData[0] >= astr[2]) && (iData[0] <= astr[4])))
    {
    loindex+=2;
    iData+=2;
    iIndex+=2;
    }
  else if ((loindex>=4) && (iData[1] == astr[0]) && ((iData[0] == astr[0]) || (iData[0] == astr[7]) || (iData[0] == astr[6]) || (iData[0] == astr[8])))
    {
    iData-=loindex;
    iIndex-=loindex;
    fwrite(&iIndex, sizeof(iIndex), 1, fp);
    fwrite(iData, loindex, 1, fp);
    fputs("<CR>", fp);
    iIndex+=(loindex+2);
    iData+=(loindex+2);
    loindex=0;
    }
  else
    {
    loindex=0;
    ++iData;
    ++iIndex;
    }
 }
 fclose(fp);
 return "Allright";
}
