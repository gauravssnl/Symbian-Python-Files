// e32tools\petran\Szip\compress.cpp
//
// Copyright (c) 1998-2004 Symbian Software Ltd. All rights reserved.
//
#include "deflate.h"

#include <stdlib.h>
#include <assert.h>
#include "h_utl.h"

class TFileOutput : public TBitOutput
	{
	enum {KBufSize=0x1000};
public:
	TFileOutput(FILE* os);
	~TFileOutput();
	void FlushL();
	TUint32 iDataCount; 
private:
	void OverflowL();
private:
	FILE* iOutStream;
	TUint8 iBuf[KBufSize];
	};

TFileOutput::TFileOutput(FILE* os)
	:iOutStream(os)
	{
	Set(iBuf,KBufSize);
	}

TFileOutput::~TFileOutput()
	{
	iOutStream=NULL;
	}

void TFileOutput::OverflowL()
//
// empty the buffer and reset the pointers
//
	{
	FlushL();
	Set(iBuf,KBufSize);
	}

void TFileOutput::FlushL()
//
// write out the contents of the buffer
//
	{
	TInt len=Ptr()-iBuf;
	if (len)
		{
		fwrite(reinterpret_cast<char *>(iBuf), sizeof(char), len, iOutStream); // write extended header
		iDataCount += len;
		}
	}

void DeflateCompress(char *bytes,TInt size,FILE* os)
	{
	TFileOutput* output=new TFileOutput(os);
	output->iDataCount = 0;
	DeflateL((TUint8*)bytes,size, *output);
	output->FlushL();
	delete output;
	}

