
#include <eikenv.h>
#include <zntxhanpyd.rsg>
#include "progressnotes.h"

void CProgressNotes::ConstructL(TInt aFinalValue)
{
    iRscOffset = CEikonEnv::Static()->AddResourceFileL(_L("\\resource\\apps\\zntxhanpyd.rsc"));
    iProgressDialog = new (ELeave) CAknProgressDialog(
     (REINTERPRET_CAST(CEikDialog**, &iProgressDialog)),
     ETrue);
     
    iProgressDialog->PrepareLC( R_PROGRESS_NOTE);
    iProgressInfo = iProgressDialog->GetProgressInfoL();
    // Make sure there is no text
    //iProgressDialog->SetTextL(aQueueName );
    
    //iProgressDialog->SetCallback( this );
    iProgressDialog->RunLD();
    iProgressInfo->SetFinalValue(aFinalValue);
}

void CProgressNotes::Finishl()
{
        iProgressDialog->SetCallback( NULL );
        iProgressDialog->ProcessFinishedL();
        iProgressInfo = NULL; 
	delete iProgressDialog;
        CEikonEnv::Static()->DeleteResourceFile( iRscOffset );
	delete this;
}

 
void CProgressNotes::UpdateProcessL(TInt aProgress, const TDesC& aProgressText)
{
      iProgressDialog->SetTextL(aProgressText);
      iProgressInfo->SetAndDraw(aProgress);	
}


