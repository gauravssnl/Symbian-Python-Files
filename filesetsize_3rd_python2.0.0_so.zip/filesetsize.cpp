#include <apgtask.h>
#include <eikenv.h>
#include <apgwgnam.h>
#include <apgcli.h>//apgrfx.lib
//#include "e32stdm.h"
#include <python.h>
#include <symbian_python_ext_util.h>
#include <unicodeobject.h>
#include <baclipb.h>//bafl.lib 
#include <coemain.h>//cone.lib 

static PyObject* SetFileSize(PyObject* /*self*/, PyObject *args) 

{ 
 char* fname;
 TInt size;
 RFs aFileServerSession;

 aFileServerSession.Connect();

 RFile afile;
 TBool isopen=false;

if (!PyArg_ParseTuple(args, "si", &fname,&size))
        {
        return 0;
        }
 TFileName *filename=new(ELeave)TFileName;
 CleanupStack::PushL(filename);
 TPtrC8 afnm;
 afnm.Set((const TUint8*)fname,strlen(fname));
 filename->Copy(afnm);
 aFileServerSession.IsFileOpen(*filename,isopen);
 if (isopen){
 CleanupStack::PopAndDestroy(filename);
 return Py_BuildValue("i",1);
 }
 TInt err=afile.Open(aFileServerSession, *filename, EFileWrite);
 CleanupStack::PopAndDestroy(filename);
 if (err!=KErrNotFound){
    err=afile.SetSize((TInt) size);
 }
 else err=1;
 afile.Close();
 aFileServerSession.Close();
 return Py_BuildValue("i",err);

}


  static const PyMethodDef SetFileSize_methods[] =
{
{"setsize", (PyCFunction)SetFileSize, METH_VARARGS, "setsize The file must be closed!"},
{NULL,NULL} 
};

DL_EXPORT( void ) init_zntxhanpyd( )
    {
   Py_InitModule("filesetsize", ( PyMethodDef *) SetFileSize_methods );
    }

#ifndef EKA2
GLDEF_C TInt E32Dll( TDllReason )
{
return KErrNone;
}
#endif
