/*
 * const.h
 *
 *  Created on: 08.04.2011
 *      Author: mvideo
 */

#ifndef CONST_H_
#define CONST_H_
_LIT(KSettingPath,"C:\\System\\Apps\\TTime2\\config.ini");
const TInt KPosX=0;
const TInt KPosY=0;
const TInt KWidth=240;
const TInt KHeight=11;
const TInt KRed=255;
const TInt KGreen=255;
const TInt KBlue=255;
const TInt KTransparency=0;
#endif /* CONST_H_ */
