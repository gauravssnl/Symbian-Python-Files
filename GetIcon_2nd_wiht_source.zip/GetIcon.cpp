#include <fbs.h> //CFbsBitmap
#include <APGCLI.H>
#include <APGICNFL.H>
#include <bitdev.h>
#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Get(PyObject* /*self*/,PyObject* args)
{
 TUint uid;
 PyObject* obj_img;
 PyObject* obj_img_mask;
 
 if (!PyArg_ParseTuple(args, "iOO", &uid, &obj_img, &obj_img_mask))
    return NULL;
  
 const TUid UID = {uid};
 CFbsBitmap* img = (CFbsBitmap*)PyCObject_AsVoidPtr(
                    PyObject_CallObject(PyObject_GetAttrString(
                    obj_img,"_bitmapapi"),NULL)); 
 CFbsBitmap* img_mask = (CFbsBitmap*)PyCObject_AsVoidPtr(
                         PyObject_CallObject(PyObject_GetAttrString(
                         obj_img_mask,"_bitmapapi"),NULL));
 
 
 RApaLsSession apaLsSession;
 apaLsSession.Connect();
 
 CArrayFixFlat<TSize>* array=new(ELeave)CArrayFixFlat<TSize>(3);
 CleanupStack::PushL(array);
 User::LeaveIfError(apaLsSession.GetAppIconSizes(UID,*array));
 
 TSize size = (*array)[0];
 CApaMaskedBitmap *appBitmap = CApaMaskedBitmap::NewLC();
 apaLsSession.GetAppIcon(UID, size, *appBitmap);
 
 TDisplayMode mode = img_mask->DisplayMode();

 User::LeaveIfError(img->Duplicate(appBitmap->Handle()));
 User::LeaveIfError(img_mask->Duplicate(appBitmap->Mask()->Handle()));
 img_mask->SetDisplayMode(mode);
 
 CleanupStack::PopAndDestroy(2);
 apaLsSession.Close();


 Py_INCREF(Py_None);
 return Py_None;

}
 
//--------------------------------------------------------------------------

static const PyMethodDef geticon_met[] = {
    {"get", (PyCFunction)Get, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("geticon", geticon_met);
}

//--------------------------------------------------------------------------
GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
  
}