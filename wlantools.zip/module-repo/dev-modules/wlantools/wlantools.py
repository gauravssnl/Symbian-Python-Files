#
# wlantools.py
#
# Copyright (c) 2007 Christophe Berger <christophe.berger@lip6.fr>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import e32

if e32.s60_version_info>=(3,0):
    import imp
    wlantools = imp.load_dynamic('kf_wlantools', 'kf_wlantools.pyd')
    from wlantools import *
else:
    import wlantools

def scan(get_information_elements=True):
    """
      Returns a list of dictionaries.
      Each dictionary contains the data of an access point.
      If optional argument "get_information_elements" is set to 'True', data about
       Information Elements of IEEE 802.11 frames will be included in output.
       Raw data is copied and tranlated in hex. 
       i.e. "09" = '0000 1001' in 802.11 frame
    """
    if e32.s60_version_info>=(3,0):
        return wlantools.scan(get_information_elements)
    else:
        return None
