#
# keylocker.py
#
import e32

if e32.s60_version_info>=(3,0):
    import imp
    _keylocker = imp.load_dynamic('_keylocker', 'kf_keylocker.pyd')
    
else:
    import _keylocker

del e32, imp
from _keylocker import *
del _keylocker