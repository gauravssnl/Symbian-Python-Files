#
# appswitch.py
#
import e32

if e32.s60_version_info>=(3,0):
    import imp
    _appswitch = imp.load_dynamic('_appswitch', 'kf_appswitch.pyd')
    
else:
    import _appswitch

del e32, imp
from _appswitch import *
del _appswitch