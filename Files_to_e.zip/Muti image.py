import fgimage, e32, appuifw as aw
from graphics import*
from sysinfo import*
l=e32.Ao_lock()
x,y=display_pixels()

img=Image.new((x,y))

def redraw(rect):
  c.blit(img)
  
c=aw.Canvas(redraw_callback=redraw)
aw.app.screen="full"
aw.app.body=c

bat=battery()
bg=Image.open('e:\\im.png')
img.blit(bg)
redraw(())
bat1=Image.open('e:\\b0.png')
bat2=Image.open('e:\\b1.png')
bat3=Image.open('e:\\b2.png')
bat4=Image.open('e:\\b3.png')
bat5=Image.open('e:\\b4.png')

if bat>=87.4:
  img.blit(bat5,target=(300,0))
  redraw(())
elif bat>=75:
  img.blit(bat4,target=(300,0))
  redraw(())
elif bat>=55:
  img.blit(bat3,target=(300,0))
  redraw(())
elif bat>=35:
  img.blit(bat2,target=(300,0))
  redraw(())
elif bat>=15:
  img.blit(bat1,target=(300,0))
  redraw(())
fg=fgimage.FGImage()

text=u'@ watt thanks for assisting me'
t=0
while 1:
  t-=1
  if t<-200:t=320
  bg.clear(0)
  img.text((t,220),text,0xffffff)
  fg.set(0,0, img._bitmapapi())
  e32.ao_sleep(0.04)
fg.unset()
def exit():
  l.signal()
aw.app.exit_key_handler=exit
l.wait()