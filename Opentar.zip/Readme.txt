# OpenTAR for xplore
# joe 05/11/2013


* Buka xplore

* Pilih Menu - Tools - File Association

* Pilih New
masukan 'gz' (tanpa tanda petik)
pilih Aplikasi pembukanya yaitu OpenTAR
selain gz, masukan juga tar dan bz2 agar ekstensi tersebut juga bisa dibuka.

* Selanjutnya, untuk melihat isi file tar ataupun mengekstraknya, cukup klik pada nama file nya di xplore, dengan otomatis, muncul pilihan untuk Melihat / Mengekstrak.
