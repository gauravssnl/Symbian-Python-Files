import appuifw as A
import sys, os
import keypress, globalui

class Util(object):
 def wait(self, txt = u'Please wait...'):
  globalui.global_note(txt, 'wait')

 def finish(self):
  keypress.simulate_key(63555,63555)

class OpenTAR(Util):
 def __init__(self):
  super(OpenTAR, self).__init__()

 def open(self, tar):
  opt = A.popup_menu([u'View', u'Extract'], u'')
  if opt is None:
   os.abort()
  else:
   A.e32.ao_sleep(0)
   import tarfile
   if opt == 0:
    self.wait(u'Opening file...')
    tgz = tarfile.open(tar)
    item = []
    if tgz:
     for i in tgz.getmembers():
      item.append(unicode(i.name))
     self.finish()
     A.popup_menu(item)
    else:
     self.finish()
     A.note(u'Can not open file.', 'error')
   else:
    self.wait(u'Extracting file...')
    tgz = tarfile.open(tar)
    items = tgz.getmembers()
    for i in items:
     tgz.extract(i, 'e:/')
    self.finish()
    A.note(u'Tar extracted')

OpenTar = OpenTAR()

if __name__ == '__main__':
 if len(sys.argv) < 1:os.abort()
 OpenTar.open(sys.argv[1])
 os.abort()