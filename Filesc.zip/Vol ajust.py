import appuifw,e32,audio
from sysinfo import display_pixels
from graphics import*
from key import*
key=Keyboard()
appuifw.app.screen='full'

run=1
def exit():
  global run
  run=0

appuifw.app.exit_key_handler=exit
im=Image.new(display_pixels())
path='e:\\'
s=audio.Sound.open(path+'move.wav')

def up():
    v=s.set_volume(s.current_volume()+1)
def down():
    v=s.set_volume(s.current_volume()-1)
def redraw(rect):
    c.blit(im)
c=appuifw.Canvas(event_callback=key.handle_event)
appuifw.app.body=c
gbr=['vol.jpg','v_up.jpg','v_dw.jpg']
im1= Image.open(path+gbr[0])
im2=Image.open(path+gbr[1])
im3=Image.open(path+gbr[2])
def play():
  s.play()
play()

vol=0
while run:
    while vol<1:
      vol+=1
    im.blit(im1)
    if key.is_down(EScancodeUpArrow):
        im.blit(im2,target=(150,155))
        up()
        vol+=1
    if key.is_down(EScancodeDownArrow):
        im.blit(im3,target=(150,202))
        down()
        vol-=1
    im.rectangle((265,180-vol,290,180),0xff9900,fill=0xff9900,width=1)
    im.text((265,130),str(vol+10)+u' %',0xff0000)
    
    redraw(())
    e32.ao_sleep(0.00001)
    