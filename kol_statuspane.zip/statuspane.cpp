#include <e32std.h>
#include <e32base.h>
#include <Python.h>
#include <symbian_python_ext_util.h>
#include <eikspane.h>

#define MAJOR_VERSION 1
#define MINOR_VERSION 1
#define BUILD_VERSION 0


// history : 
//  initial version : Usanov-Kornilov Nikolay (aka Kolay) kolayuk@mail.ru
//
//
//  version 1.1 : cyke64 cyke64@gmail.com
//      *  add current_layout() function
//
//


static PyObject* Set(PyObject* , PyObject *args)
{		TInt type;
		PyArg_ParseTuple(args,"i",&type);
		TInt err;
		TRAP(err,{
		CEikStatusPane::Current()->SwitchLayoutL(type);
		CEikStatusPane::Current()->DrawNow();
				};);
		if (err==KErrNone){return Py_None;}
		else {return Py_BuildValue("i",err);}
}

static PyObject* Status(PyObject* , PyObject *args)
{		TInt ret;
		TInt err;
		
		TRAP(err,{
		ret=CEikStatusPane::Current()->CurrentLayoutResId();
						};);
		if (err==KErrNone) {
          return Py_BuildValue("i",ret);
          }
		else {
          return Py_BuildValue("i",err);
          }
}



static const PyMethodDef methods[] =
	{
		{"set", (PyCFunction)Set, METH_VARARGS},
		{"current_layout", (PyCFunction)Status, METH_NOARGS},
		{0, 0}
	};


DL_EXPORT(void) init_statuspane()
	{
		PyObject *module;
		PyObject *dict;
		module = Py_InitModule3("statuspane",(PyMethodDef*)methods,"statuspane layout for PyS60");
		dict = PyModule_GetDict(module);
        PyDict_SetItemString(dict,"version", Py_BuildValue("(iii)",MAJOR_VERSION,MINOR_VERSION,BUILD_VERSION));

	}

#ifndef EKA2
//
// For Symbian or rather S60 3rd edition sdk
GLDEF_C TInt E32Dll(TDllReason)
{
  return KErrNone;
}
#endif
