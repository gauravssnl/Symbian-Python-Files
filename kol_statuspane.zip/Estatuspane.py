"""
http://www.developer.nokia.com/Community/Wiki/Status_pane_layout
"""

# Context panel for the clock, with the title, navigation, signals, power panels.
# standby screen in general is this.
ESTATUS_PANE_LAYOUT_IDLE = 0x8cc0032

# Context panel for the application icon, with the title, navigation, signals, power panels.
# third-party applications such default.
ESTATUS_PANE_LAYOUT_USUAL = 0x8cc0033

ESTATUS_PANE_LAYOUT_POWER_OFF_RECHARGE = 0x8cc0034

#No status panel, similar StatusPane () -> MakeVisible (EFalse);
ESTATUS_PANE_LAYOUT_EMPTY = 0x8cc0035

ESTATUS_PANE_LAYOUT_SMALL = 0x8cc0167
ESTATUS_PANE_LAYOUT_SMALL_WITH_SIGNAL_PANE = 0x8cc0168
ESTATUS_PANE_LAYOUT_SMALL_WITH_SIGNAL_PANE_MIRRORED = 0x8cc0169
ESTATUS_PANE_LAYOUT_USUAL_MIRRORED = 0x8cc016a
ESTATUS_PANE_LAYOUT_IDLE_MIRRORED = 0x8cc016b
ESTATUS_PANE_LAYOUT_POWER_OFF_RECHARGE_MIRRORED = 0x8cc016c
ESTATUS_PANE_LAYOUT_VT = 0x8cc0170
ESTATUS_PANE_LAYOUT_VT_MIRRORED = 0x8cc0171
ESTATUS_PANE_LAYOUT_USUAL_WITH_BATTERY_PANE = 0x8cc0179

# Show the title, navigation, signals, power panels.
# A lot of Nokia devices regular menu use this panel.
ESTATUS_PANE_LAYOUT_USUAL_FLAT= 0x8cc018d

ESTATUS_PANE_LAYOUT_IDLE_FLAT = 0x8cc018e

# default status pane layout in Nokia 5800 device.
ESTATUS_PANE_LAYOUT_USUAL_EXT = 0x8cc01a4

ESTATUS_PANE_LAYOUT_IDLE_EXT = 0x8cc01b2


