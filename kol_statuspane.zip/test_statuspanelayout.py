from estatuspane import *

import statuspane
import e32

last_layout=statuspane.current_layout()
statuspane.set(ESTATUS_PANE_LAYOUT_EMPTY)
e32.ao_sleep(5)
statuspane.set(ESTATUS_PANE_LAYOUT_USUAL_FLAT)
e32.ao_sleep(5)
statuspane.set(last_layout)

