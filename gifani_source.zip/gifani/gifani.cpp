
#include "Python.h"
#include "symbian_python_ext_util.h"

#include "gifani.h"

//------------------------------------------------------------------------

CGifAnimator::CGifAnimator()
{
}
//------------------------------------------------------------------------

CGifAnimator::~CGifAnimator()
{    
  TInt count = iListAnimation.Count();
  if (count)
  {
    for(TInt i=0; i < count; i++)
     {
     // delete iListAnimation[i]->iGifFileDataprovider;
     // delete iListAnimation[i]->iGifAnimatior;
      iListAnimation.Remove(0);
     }
     //iListAnimation.Remove(0);
     iListAnimation.Reset();
   }

}
  
//------------------------------------------------------------------------

CGifAnimator* CGifAnimator::NewL(TRect aRect, TRgb aRgb)
{
	CGifAnimator* ctrl = new  CGifAnimator();//ELeave);
	CleanupStack::PushL(ctrl);
	ctrl->ConstructL(aRect, aRgb);
	CleanupStack::Pop(ctrl);
	return ctrl;
}

//------------------------------------------------------------------------

void CGifAnimator::ConstructL(TRect aRect, TRgb aRgb)
{
    CreateWindowL(CEikonEnv::Static()->RootWin());
    SetRect(aRect);
    iRgb = aRgb;
    ActivateL();

}

//------------------------------------------------------------------------

void CGifAnimator::Draw(const TRect& aRect) const
 {

  CWindowGc& gc = SystemGc();
  gc.SetBrushStyle( CGraphicsContext::ESolidBrush );
  gc.SetBrushColor(iRgb);
  gc.Clear();
    
  TInt count = iListAnimation.Count();
  for(TInt i=0; i < count; i++)
   {
     iListAnimation[i]->iGifAnimatior->Draw(gc);
   }

 }

//------------------------------------------------------------------------

TUint CGifAnimator::Add(const TDesC& aFile, TPoint aPoint)
 {
  
   TAnimation* ani = new(ELeave)TAnimation;
  
   
   ani->iGifFileDataprovider = new (ELeave) CICLAnimationDataProvider;
   ani->iGifFileDataprovider->SetFileL(CCoeEnv::Static()->FsSession(),aFile); 
 
   TAnimationConfig igifanimationconfig;
   
   igifanimationconfig.iFlags = TAnimationConfig::ELoop;
   igifanimationconfig.iData = 10000;
   
   ani->iGifAnimatior = CBasicAnimation::NewL(ani->iGifFileDataprovider,aPoint, iEikonEnv->WsSession(), Window());

 
   ani->iGifAnimatior->Start(igifanimationconfig);
   
   iListAnimation.Append(ani);

 return (TUint)ani;
 }
   

//-----------------------------------------------------------

 void CGifAnimator::SetPos(TUint aKey, TPoint aPoint)
 {
   TInt index = iListAnimation.Find((TAnimation*)aKey);
    if(index != KErrNotFound)
      iListAnimation[index]->iGifAnimatior->SetPosition(aPoint);
     
 } 
  
//----------------------------------------------------------- 
  
 void CGifAnimator::Stop(TUint aKey)
 {
   TInt index = iListAnimation.Find((TAnimation*)aKey);
    if(index != KErrNotFound)
      iListAnimation[index]->iGifAnimatior->Stop();
 } 
 
//-----------------------------------------------------------

 void CGifAnimator::Pause(TUint aKey)
 {
   TInt index = iListAnimation.Find((TAnimation*)aKey);
    if(index != KErrNotFound)
      iListAnimation[index]->iGifAnimatior->Pause();
 } 
 
//-----------------------------------------------------------

 void CGifAnimator::Pesume(TUint aKey)
 {
   TInt index = iListAnimation.Find((TAnimation*)aKey);
    if(index != KErrNotFound)
      iListAnimation[index]->iGifAnimatior->Resume();
 } 
 
//●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●

#define GifAnimator_type ((PyTypeObject*)SPyGetGlobalString("GifAnimator"))
struct obj_GifAnimator {
  PyObject_VAR_HEAD
  CGifAnimator* iGifAnimator;
};

//=========================

static PyObject* New_GifAnimator(obj_GifAnimator* self, PyObject* args)

{
    TInt x1,y1,x2,y2,r,g,b;    
    x1=y1=x2=y2=r=g=b=0;
    
    if (!PyArg_ParseTuple(args, "(iiii)|(iii)", &x1,&y1,&x2,&y2,&r,&g,&b))
    return NULL;


    obj_GifAnimator *ir = PyObject_New(obj_GifAnimator, GifAnimator_type);
    if (!ir) return NULL;

    ir->iGifAnimator = 0;
    TRAPD(err,
          ir->iGifAnimator  = CGifAnimator::NewL(TRect(x1,y1,x2,y2),TRgb(r,g,b)); 
         );

    if (err)
    {
      PyObject_Del(ir);
      return SPyErr_SetFromSymbianOSErr(err);
    }

  return (PyObject*)ir;
}

//●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●
static PyObject* AddAnimation(obj_GifAnimator* self, PyObject* args)
{
  
 PyObject* file=NULL;
 TInt x=0;
 TInt y=0;
 TUint key=0;
 
 if (!PyArg_ParseTuple(args, "O|(ii)", &file,&x,&y)) return 0;
 
 
 if ( !PyUnicode_Check(file) )
  {
   PyErr_SetString(PyExc_ValueError, "argument is not unicode");
   return NULL;
  }
 
  TRAPD(err, key = self->iGifAnimator->Add(TPtrC((TUint16*) PyUnicode_AsUnicode(file),  PyUnicode_GetSize(file)), TPoint(x,y) ));
   
  if (err)  return SPyErr_SetFromSymbianOSErr(err); 

 
 return Py_BuildValue("i", key);
}

//●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●

static PyObject* PositionPy(obj_GifAnimator* self, PyObject* args)
{
  TUint key;
  TInt x,y;
  if (!PyArg_ParseTuple(args, "i(ii)", &key,&x,&y)) return 0;
  
  TRAPD(err, self->iGifAnimator->SetPos(key, TPoint(x,y)));
  
  if (err)  return SPyErr_SetFromSymbianOSErr(err); 
 
 Py_INCREF(Py_None);
 return Py_None; 
}
//●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●

static PyObject* StopPy(obj_GifAnimator* self, PyObject* args)
{
  TUint key;
  if (!PyArg_ParseTuple(args, "i", &key)) return 0;
 
  TRAPD(err, self->iGifAnimator->Stop(key));
  
  if (err)  return SPyErr_SetFromSymbianOSErr(err); 
 
 Py_INCREF(Py_None);
 return Py_None; 
}
//●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●

static PyObject* PausePy(obj_GifAnimator* self, PyObject* args)
{
  TUint key;
  if (!PyArg_ParseTuple(args, "i", &key)) return 0;
 
  TRAPD(err, self->iGifAnimator->Pause(key));
  
  if (err)  return SPyErr_SetFromSymbianOSErr(err); 
 
 Py_INCREF(Py_None);
 return Py_None; 
}
//●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●

static PyObject* ResumePy(obj_GifAnimator* self, PyObject* args)
{
  TUint key;
  if (!PyArg_ParseTuple(args, "i", &key)) return 0;
 
  TRAPD(err, self->iGifAnimator->Pesume(key));
  
  if (err)  return SPyErr_SetFromSymbianOSErr(err); 
 
 Py_INCREF(Py_None);
 return Py_None; 
}
//●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●


//Setting(TBps aBps, TParity aParity, TDataBits aDataBits, TStopBits aStopBits)
static void dealloc_GifAnimator(obj_GifAnimator* anim)
{   
  delete anim->iGifAnimator;
  anim->iGifAnimator = 0;
  PyObject_Del(anim);    
}
 

static const PyMethodDef FGImage_methods[] =
  {
    {"add", (PyCFunction)AddAnimation, METH_VARARGS},
    {"stop", (PyCFunction)StopPy, METH_VARARGS},
    {"pause", (PyCFunction)PausePy, METH_VARARGS},
    {"resume", (PyCFunction)ResumePy, METH_VARARGS},
    {"setpos", (PyCFunction)PositionPy, METH_VARARGS},
    {NULL, NULL}
  };


static PyObject *getattr_GifAnimator(PyObject *self, char *name)
{
  return Py_FindMethod(const_cast<PyMethodDef*>(&FGImage_methods[0]), self, name);
}


static const PyTypeObject type_template_GifAnimator = {
/*******************************************************/
    PyObject_HEAD_INIT(0)    /* initialize to 0 to ensure Win32 portability */
    0,                 /*ob_size*/
    "gifani.New",            /*tp_name*/
    sizeof(obj_GifAnimator), /*tp_basicsize*/
    0,                 /*tp_itemsize*/
    /* methods */
    (destructor)dealloc_GifAnimator, /*tp_dealloc*/
 0, /*tp_print*/
    (getattrfunc)getattr_GifAnimator, /*tp_getattr*/

}; 



static const PyMethodDef GifAnimator_methods[] =
{
  {"New", (PyCFunction)New_GifAnimator, METH_VARARGS},
  {0, 0}
};


#define DEFTYPE(name,type_template)  do {\
    PyTypeObject* tmp = PyObject_New(PyTypeObject, &PyType_Type);\
    *tmp = (type_template);\
    tmp->ob_type = &PyType_Type;\
    SPyAddGlobalString((name), (PyObject*)tmp);\
  } while (0)
 


extern "C" {

DL_EXPORT(void) initaudiostream(void)
{
    PyObject *m;
    DEFTYPE("GifAnimator",type_template_GifAnimator);
    m = Py_InitModule("gifani", (PyMethodDef*)GifAnimator_methods);
    PyModule_GetDict(m); 
    
}
    
  DL_EXPORT(void) zfinalizeaudiostream(void)
  {
    //RFbsSession::Disconnect();
  }     

} /* extern "C" */


