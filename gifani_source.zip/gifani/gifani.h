#ifndef GIFANIMATIONPY_H
#define GIFANIMATIONPY_H


#include <e32std.h>
#include <e32base.h>

#include <eikenv.h>
#include <coecntrl.h>
#include <coemain.h>

#include <eikstart.h>//Open C

#include <w32std.h>
//#include <f32file.h>

#include <ICLAnimationDataProvider.h> //CICLAnimationDataProvider
#include <BasicAnimation.h> //CBasicAnimation
#include <AnimationConfig.h>


//---------------------------------------------------------------------------
struct TAnimation
{
  public :
    CBasicAnimation* iGifAnimatior;
    CICLAnimationDataProvider* iGifFileDataprovider;
};

//---------------------------------------------------------------------------
class CGifAnimator :public CCoeControl//, public MEikEdwinObserver
{
  
public:
	static CGifAnimator* NewL(TRect aRect, TRgb aRgb);

 void ConstructL(TRect aRect, TRgb aRgb);
  
	~CGifAnimator();
	CGifAnimator();
	
  
  void Draw(const TRect& aRect) const;
 
  TUint Add(const TDesC& aFile, TPoint aPoint);
  
  void SetPos(TUint aKey, TPoint aPoint);
  void Stop(TUint aKey);
  void Pause(TUint aKey);
  void Pesume(TUint aKey);
 
  //TInt CountComponentControls() const;
  //CCoeControl* ComponentControl(TInt aIndex) const;
  //TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);


public:
  //CICLAnimationDataProvider* iGifFileDataprovider;
  //CBasicAnimation* iGifAnimatior;
  
  RPointerArray<TAnimation> iListAnimation;
  
  TRgb iRgb;
  
  //CAknsBasicBackgroundControlContext *iBackground;
};





#endif