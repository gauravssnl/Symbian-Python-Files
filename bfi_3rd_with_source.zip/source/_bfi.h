#ifndef IMAGECONV_H
#define IMAGECONV_H

#include <coecntrl.h>
#include <ImageConversion.h>
#include <f32file.h>

 
//-------------------------------------------------------------------------

class CImageConv : public CActive
{
    	
public:
	 static CImageConv* NewL();
	 CImageConv();
  void ConstructL();
	 ~CImageConv();

  TInt Convert(CFbsBitmap& aBitmap,const TDesC8& aSourceData );

protected:
  void DoCancel();
  void RunL();
	
private:
	 CImageDecoder* iDecoder;
  CActiveSchedulerWait iWait;

	
 };
//---------------------------------------------------------------------------


#endif
  