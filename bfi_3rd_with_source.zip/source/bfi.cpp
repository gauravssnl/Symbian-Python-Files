#include <fbs.h> //CFbsBitmap
#include <coemain.h>

#include "_bfi.h"
#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Get(PyObject* /*self*/,PyObject* args)
{
 PyObject* obj_img;
 char *s;
 TInt len;
 
 if (!PyArg_ParseTuple(args, "Os#", &obj_img, &s, &len))
    return NULL;
  
 CFbsBitmap* bitmap = (CFbsBitmap*)PyCObject_AsVoidPtr(
                       PyObject_CallObject(PyObject_GetAttrString(
                       obj_img,"_bitmapapi"),NULL));


 //EOptionAlwaysThread DOESN'T work for CImageDecoder::DataNewL
 /*
 CImageDecoder* decoder =  CImageDecoder::DataNewL(CCoeEnv::Static()->FsSession(),  *source, CImageDecoder::EOptionAlwaysThread );
*/

 CImageConv* imageConv = CImageConv::NewL();
 imageConv->Convert(*bitmap,(TPtrC8((TUint8*)s, len)));
 delete imageConv;

 Py_INCREF(Py_None);
 return Py_None;
}
 
//--------------------------------------------------------------------------

static const PyMethodDef bfi_met[] = {
    {"get", (PyCFunction)Get, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("bfi", bfi_met);
}

//--------------------------------------------------------------------------
