#include "_bfi.h"
#include "Python.h"
#include "symbian_python_ext_util.h"
//-------------------------------------------------------------------------
CImageConv* CImageConv::NewL()
{
   CImageConv* self =  new(ELeave) CImageConv();
   CleanupStack::PushL( self );
   self->ConstructL();
   CleanupStack::Pop(self);
   return self;
}
//-------------------------------------------------------------------------
CImageConv::CImageConv()
: CActive( EPriorityStandard )
{
}
//-------------------------------------------------------------------------
void CImageConv::ConstructL()
{
  CActiveScheduler::Add(this);
}
//-------------------------------------------------------------------------
CImageConv::~CImageConv()
{
  Cancel();
  if ( iDecoder )
    delete iDecoder;
}


//-------------------------------------------------------------------------


TInt CImageConv::Convert(CFbsBitmap& aBitmap,const TDesC8& aSourceData )
{
  
 if ( iDecoder )
 {
  delete iDecoder;
  iDecoder = NULL;
 }

  iDecoder = CImageDecoder::DataNewL(CCoeEnv::Static()->FsSession(),  aSourceData );
  
  aBitmap.Resize(iDecoder->FrameInfo().iOverallSizeInPixels);
  iDecoder->Convert(&iStatus, aBitmap );
  SetActive();
  Py_BEGIN_ALLOW_THREADS
  iWait.Start();
  Py_END_ALLOW_THREADS
  
  return 1;
}

//-------------------------------------------------------------------------
void CImageConv::DoCancel()
{
   iDecoder->Cancel();
}
//-------------------------------------------------------------------------

void CImageConv::RunL()
{
   switch( iStatus.Int() )
   {
       case KErrNone:
          iWait.AsyncStop();
          break;
          
       case KErrUnderflow:
          iDecoder->ContinueConvert( &iStatus );
          SetActive();
          break;

       default:
          iWait.AsyncStop();
          break;
    }
}
//-------------------------------------------------------------------------
