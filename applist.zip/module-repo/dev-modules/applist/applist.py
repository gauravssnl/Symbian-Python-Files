#
# applist.py
#


import e32

if e32.s60_version_info>=(3,0):
    import imp
    _applist = imp.load_dynamic('_applist', 'kf_applist.pyd')
    
else:
    import _applist

del e32, imp
from _applist import *
del _applist