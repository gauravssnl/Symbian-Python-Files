AlarmSwitcher
=============

A button to switch alarms on or off
