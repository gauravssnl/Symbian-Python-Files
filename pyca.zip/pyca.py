'''
Watt, please make the simple script below to .pyd module for S60 2nd. Please fix script below :D
Module name = pyca.pyd
Module function = Encrypt the PyS60 script, because .pyc is not safe.
thnx b4 :)
'''
import os
def encrypt(txt):
 return 'PYCA\x00'+txt.encode('zlib')+'\x00'
class Load:
 def __init__(self,file):
  self.file=file
 def Lock(self):
  enc=encrypt(open(self.file).read())
  f=open(self.file+'.pya','w')
  f.write(enc)
  f.close()
 def Exec(self):
  script=open(self.file).read()[5:][:-1].decode('zlib')
  tmp='c:\\pytmp'
  f=open(tmp,'w')
  f.write(script)
  f.close()
  execfile(tmp)
  os.remove(tmp)

# API
# Encript the script
s=Load('e:\\secret.py')
s.Lock()
# Exec the encrypted script
s=Load('e:\\secret.pyca')
s.Exec()