
#include <e32base.h>
#include <w32std.h>  
#include <apgwgnam.h> 
#include <avkon.hrh>

#include "Python.h"
#include "symbian_python_ext_util.h"
  

class RWindowGroup;
class CApaWindowGroupName;
//---------------------------------------------------------------------------


const TUint KScanCode = 0xE3;
const TUint KKeyCode = 0xF883;

class CGlobCapture : public CActive 
{
   
 public:
    CGlobCapture();
    ~CGlobCapture();
    void ConstructL();
    void CallPy(TInt aVal);
    void Stop();
    void Start();

 private:
    void RunL();
  
	protected:
		virtual void DoCancel();
  
	private:
		RWsSession iWsSession;
		RWindowGroup* iWindowGroup;
		CApaWindowGroupName* iWindowGroupName;
  
		TInt32 iCaptureHandle;
		TInt32 iCaptureHandleUd;
  TInt32 iCaptureHandleLong;
  
 public:
  PyObject *iCb;
                         
    
};
 
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------  
//----------------------------------------------------------------------------

void CGlobCapture::ConstructL()
{ 
	User::LeaveIfError( iWsSession.Connect() );

	iWindowGroup = new (ELeave) RWindowGroup ( iWsSession );
	iWindowGroup->Construct( (TUint32)iWindowGroup, EFalse );

	iWindowGroup->SetOrdinalPosition(-1);
	iWindowGroup->EnableReceiptOfFocus( EFalse );
	iWindowGroupName = CApaWindowGroupName::NewL( iWsSession );
	iWindowGroupName->SetHidden(ETrue);
	iWindowGroupName->SetWindowGroupName( *iWindowGroup );
	CActiveScheduler::Add( this );

}
 
 
//----------------------------------------------------------------------------
CGlobCapture::CGlobCapture():CActive( EPriorityNormal ),iCb(NULL)
{
 
}

//---------------------------------------------------------------------------
CGlobCapture::~CGlobCapture()
{ 

  iWsSession.EventReadyCancel();
  Cancel();
  //CActiveScheduler::Stop();
	 delete iWindowGroupName;
	 delete iWindowGroup;
	 iWsSession.Close();
  Py_XDECREF(iCb); 
}

//---------------------------------------------------------------------------

void CGlobCapture::DoCancel()
{
	 iWindowGroup->CancelCaptureKey(iCaptureHandle);
  iWindowGroup->CancelCaptureKeyUpAndDowns(iCaptureHandleUd);
  iWindowGroup->CancelCaptureLongKey(iCaptureHandleLong);
}


//---------------------------------------------------------------------------

void CGlobCapture::CallPy(TInt aVal)
{  
  PyObject *arglist;
  arglist = Py_BuildValue("(i)", aVal);
  PyEval_RestoreThread(PYTHON_TLS->thread_state);
  PyEval_CallObject(iCb, arglist);
  PyEval_SaveThread(); 
  Py_DECREF(arglist);
}


//---------------------------------------------------------------------------
void CGlobCapture::RunL()
	{
	if( iStatus == KErrNone ) 
		{
		  TWsEvent we;
		  iWsSession.GetEvent( we );
  
    if( we.Key()->iCode == KKeyCode  )
    {
     if( we.Key()->iRepeats>0 )
       CallPy(4);
     else
       CallPy(2);  
    }
    else if( we.Key()->iScanCode == KScanCode )
    { 
      if( we.Type() ==  EEventKeyDown )  
        CallPy(1);
      else if  ( we.Type() ==  EEventKeyUp )
        CallPy(3); 
    } 
		  else 
			 { 
			   TInt foregroundAppId = iWsSession.GetFocusWindowGroup();
			   iWsSession.SendEventToWindowGroup( foregroundAppId, we );
			 }  

			 iWsSession.EventReady( &iStatus );
			 SetActive();
		} 

	}

//---------------------------------------------------------------------------
 
void CGlobCapture::Start()
{
	 	User::LeaveIfError( iCaptureHandle = iWindowGroup->CaptureKey(KKeyCode, 0, 0 ) );
   User::LeaveIfError( iCaptureHandleUd = iWindowGroup->CaptureKeyUpAndDowns(KScanCode, 0, 0 ) );
   User::LeaveIfError( iCaptureHandleLong = iWindowGroup->CaptureLongKey(KKeyCode,KKeyCode,0,0,0,0 ) );
   iWsSession.EventReady( &this->iStatus );
	  SetActive();
}


//---------------------------------------------------------------------------

void CGlobCapture::Stop()
{
   iWsSession.EventReadyCancel();
	  Cancel();
}


//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

#define GCapture_type ((PyTypeObject*)SPyGetGlobalString("GlobCapture"))
struct obj_GCapture {
  PyObject_VAR_HEAD  // PyObject_HEAD;
  CGlobCapture* iGCapture;
};


//---------------------------------------------------------------------------

static PyObject* New_GlobCapture(obj_GCapture* self, PyObject* args)

{

    PyObject *c = NULL;

    if (!PyArg_ParseTuple(args, "O:set_callback", &c))
    return NULL;


    obj_GCapture *ir = PyObject_New(obj_GCapture, GCapture_type);
    if (!ir) return NULL;

    ir->iGCapture = 0;
    TRAPD(err,
          ir->iGCapture  = new CGlobCapture(); 
          ir->iGCapture->ConstructL();
          ir->iGCapture->iCb = c;
          Py_XINCREF(ir->iGCapture->iCb);

         );

    if (err)
    {
      PyObject_Del(ir);
      return SPyErr_SetFromSymbianOSErr(err);
    }
 

  return (PyObject*)ir;
}

//---------------------------------------------------------------------------

static PyObject* Start(obj_GCapture* self, PyObject*)
{
  self->iGCapture->Start();
  Py_INCREF(Py_None);
  return Py_None;
}

//---------------------------------------------------------------------------

static PyObject* Stop(obj_GCapture* self, PyObject*)
{
  self->iGCapture->Stop(); 
  Py_INCREF(Py_None);
  return Py_None;
}

//---------------------------------------------------------------------------

static void dealloc_GlobCapture(obj_GCapture* aCapture)
{ 
  delete aCapture->iGCapture;
  aCapture->iGCapture = NULL;
  PyObject_Del(aCapture);    
}
 
static const PyMethodDef GlobCapture_methods[] =
  {
    {"start", (PyCFunction)Start, METH_NOARGS},
    {"stop", (PyCFunction)Stop, METH_NOARGS},
    {NULL, NULL} /* sentinel */
  };

static PyObject *getattr_GlobCapture(PyObject *self, char *name)
{
  return Py_FindMethod(const_cast<PyMethodDef*>(&GlobCapture_methods[0]), self, name);
}


static const PyTypeObject type_template_GlobCapture = {
    PyObject_HEAD_INIT(0)   
    0,                 /*ob_size*/
    "_globcapture.New",            /*tp_name*/
    sizeof(obj_GCapture), /*tp_basicsize*/
    0,                 /*tp_itemsize*/
    /* methods */
    (destructor)dealloc_GlobCapture, /*tp_dealloc*/
    0, /*tp_print*/
    (getattrfunc)getattr_GlobCapture,

}; 




static const PyMethodDef globcapture_methods[] =
{
  {"New", (PyCFunction)New_GlobCapture, METH_VARARGS},
  {0, 0} 
};


#define DEFTYPE(name,type_template)  do {\
    PyTypeObject* tmp = PyObject_New(PyTypeObject, &PyType_Type);\
    *tmp = (type_template);\
    tmp->ob_type = &PyType_Type;\
    SPyAddGlobalString((name), (PyObject*)tmp);\
  } while (0)
 


extern "C" {

 DL_EXPORT(void) initaudiostream(void)
 {
    PyObject *m;
    DEFTYPE("GlobCapture",type_template_GlobCapture);
    m = Py_InitModule("_globcapture", (PyMethodDef*)globcapture_methods); 
    PyModule_GetDict(m);    
 }
        

} 


GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
  
}













