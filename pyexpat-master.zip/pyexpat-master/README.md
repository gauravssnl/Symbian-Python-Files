This is a Symbian port of ``pyexpat``. It contains a built-in copy of Expat.

http://new.contextlogger.org/pyexpat/
