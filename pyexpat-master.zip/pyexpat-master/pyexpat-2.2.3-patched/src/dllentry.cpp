// -*- symbian-c++ -*-

#include <e32std.h>

#ifndef EKA2
/** The DLL entry point.
 */
GLDEF_C TInt E32Dll(TDllReason)
	{
	return KErrNone;
	}
#endif
