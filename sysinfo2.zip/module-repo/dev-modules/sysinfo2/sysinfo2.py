#
# sysinfo2.py
#
import e32

if e32.s60_version_info>=(3,0):
    import imp
    kf_sysinfo2 = imp.load_dynamic('kf_sysinfo2', 'kf_sysinfo2.pyd')
    
else:
    import kf_sysinfo2

del e32, imp
from kf_sysinfo2 import *
del kf_sysinfo2
from sysinfo import *

EApBearerTypeCSD=0x00000001
EApBearerTypeGPRS=0x00000002
EApBearerTypeHSCSD=0x00000004
EApBearerTypeCDMA=0x00000010
EApBearerTypeWLAN=0x00000020
EApBearerTypeLAN=0x00000040
EApBearerTypeLANModem=0x00000080

def access_points():
    return list_access_points(0)

def active_access_points():
    aps=list_access_points(1)
    L=[]
    for item in aps:
        if item['active']==1:
            ap={'iapid':item['iapid'],'name':item['name'],'type':item['type']} 
            L.append(ap)
    return L    