import appuifw2
import e32

cn = lambda x:unicode(x,"utf-8","ignore")

class Jed(object,):

    def __init__(self):
        self.oldbody = appuifw2.app.body
        self.oldmenu = appuifw2.app.menu
        self.oldscreen = appuifw2.app.screen
        self.oldhandler = appuifw2.app.exit_key_handler
        self.body = appuifw2.Text(flags=appuifw2.ENoCustomDraw|appuifw2.ETextFlags)
        self.lock = e32.Ao_lock()

    def start(self):
        self.body.bgcolor = 0x000000
        self.body.color = 0xFFFFFF
        self.body.add(cn("世界，你好！Hello World!\n"))
        self.body.color = 0xFF0000
        self.body.add(cn("世界，你好！Hello World!\n"))
        self.body.color = 0x00FF00
        self.body.add(cn("世界，你好！Hello World!\n"))
        self.body.color = 0x0000FF
        self.body.add(cn("世界，你好！Hello World!\n"))
        appuifw2.app.body = self.body
        appuifw2.app.screen = "normal"
        appuifw2.app.exit_key_handler = self.exit
        self.lock.wait()

    def exit(self):
        appuifw2.app.body = self.oldbody
        appuifw2.app.menu = self.oldmenu
        appuifw2.app.screen = self.oldscreen
        appuifw2.app.exit_key_handler = self.oldhandler
        self.lock.signal()
        appuifw2.app.set_exit()

    def __del__(self):
        pass

m = Jed()
m.start()