import pyinbox
inbox = pyinbox.Inbox(0x10009ED5)
print(repr(inbox.list_messages(0x10009ED5)))
