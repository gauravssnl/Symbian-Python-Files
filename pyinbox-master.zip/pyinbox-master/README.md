This is `pyinbox`, a tweaked version of the Python for S60 `inbox` module.
The tweaks make it possible to access received OBEX Bluetooth messages,
possibly among other things.

http://new.contextlogger.org/pyinbox/
