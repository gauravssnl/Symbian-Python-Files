import gifani, e32

ani=gifani.New((0,0,80,80),(120,120,120))

a=ani.add(u"e:\\anim.gif")
a2=ani.add(u"e:\\anim.gif",(40,40))

e32.ao_sleep(3)
ani.pause(a)
e32.ao_sleep(3)
ani.resume(a)
e32.ao_sleep(3)
ani.setpos(a,(0,20))
e32.ao_sleep(3)
ani.SetPosition((50,50))
e32.ao_sleep(3)
ani.Visible(0)
e32.ao_sleep(1)
ani.Visible(1)
e32.ao_sleep(3)
ani.delete(a2)
e32.ao_sleep(3)

del ani
print "end"