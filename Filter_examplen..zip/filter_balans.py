import appuifw,math,time,e32,filter
from graphics import *

img=Image.new((240,320))

info=lambda:appuifw.note("1 +R , 3 -R\n2 +G , 5 -G\n3 +B , 6 -B".decode('utf-8'), "info")

def redraw(rect): 
 canvas.blit(img)

canvas=appuifw.Canvas(redraw_callback=redraw,event_callback=lambda(x):x['scancode']==164 and info())
appuifw.app.screen="full"
appuifw.app.body=canvas

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit

pic=Image.open("e:\\tools.png")
pic_target=Image.new(pic.size)

R=1; G=1; B=1

def start(r=0,g=0,b=0):
  global R,G,B
  R+=r; G+=g; B+=b
  filter.balans(pic,pic_target, (R,G,B))
  img.blit(pic_target,target=(-5,-5))
  redraw(())

#1
canvas.bind(49, lambda:start(r=0.1)) 
#4
canvas.bind(52, lambda:start(r=-0.1)) 
#2
canvas.bind(50, lambda:start(g=0.1)) 
#5
canvas.bind(53, lambda:start(g=-0.1)) 
#3
canvas.bind(51, lambda:start(b=0.1)) 
#6
canvas.bind(54, lambda:start(b=-0.1)) 
 
start()
info()
app_lock.wait()