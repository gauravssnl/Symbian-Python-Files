import appuifw,math,time,e32,filter
from graphics import *

canvas=appuifw.Canvas()
appuifw.app.screen="full"
appuifw.app.body=canvas

img=Image.new(canvas.size)

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit

pic=Image.open("e:\\tools.png")

pic_target=Image.new(pic.size)

t=time.clock()

for i in range(1,8):
  filter.warp(pic,pic_target, i )
  img.clear(0xffffff)
  img.blit(pic_target)
  canvas.blit(img)
  e32.ao_sleep(1)


app_lock.wait()
