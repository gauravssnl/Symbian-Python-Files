import appuifw,math,time,e32,filter
from random import  randint , choice
from graphics import *

img=0
def redraw(rect): 
  if img: canvas.blit(img)

canvas=appuifw.Canvas(redraw_callback=redraw)
appuifw.app.screen="full"
appuifw.app.body=canvas

img=Image.new(canvas.size)

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit


pic_target=Image.new(canvas.size)
colors = [ 0xdd0000, 0x00dd00 , 0x0000dd , 0xeeee00 ,  0xffffff, 0xddaa00 ]
array=[Image.new(canvas.size) for i in range(10)] 

for i in array:
 i.clear(choice(colors))
 for j in range(70):
  rad=randint (5,30)
  x=randint (0,canvas.size[0])
  y=randint (0,canvas.size[1])
  i.ellipse((x-rad, y-rad, x + rad, y + rad), 0, choice(colors) , 1 )

for i in range(len(array)-1):
 for p in range(0,260,10):
   filter.piconpic(array[i],array[i+1],pic_target,p+5,(0,0),0)
   img.clear(0)
   img.blit(pic_target)
   redraw(())
   e32.ao_yield()
 e32.ao_sleep(1)


app_lock.wait()
