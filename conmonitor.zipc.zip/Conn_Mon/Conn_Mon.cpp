#include <rconnmon.h>	

#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Get(PyObject* /*self*/,PyObject* /*args*/)
{
  
  RConnectionMonitor monitor;
  TRequestStatus status;

  TUint connectionCount(0);
  TUint subConnectionCount(0);
  TUint connectionId(0);
 
  monitor.ConnectL(); 
  monitor.GetConnectionCount( connectionCount, status);
  User::WaitForRequest(status);

  if ( connectionCount == 0 )
    return Py_BuildValue("i", connectionCount);
    
  //-----  

  PyObject* list = PyList_New(connectionCount);
  
  for ( TUint idx = 1; idx <= connectionCount; idx++ )
   {

   TBuf<KConnMonMaxStringAttributeLength> iapName;
   TUint iapId = 0;
   TUint downlinkData = 0;
   TUint uplinkData = 0;
   //Int signalStrength = 0;
   TBool connectionActivity = EFalse;
  // TInt bearer = 0;
 
   // Get the connection id
   monitor.GetConnectionInfo(idx, connectionId,subConnectionCount);
 
   // Get connection IAP name
   monitor.GetStringAttribute(connectionId,0,KIAPName,iapName,status);
   User::WaitForRequest( status );
 
   // Get connection IAP ID
   monitor.GetUintAttribute(connectionId,0,KIAPId,iapId,status);
   User::WaitForRequest( status );
   
   // Get connection downlink data (in bytes)
   monitor.GetUintAttribute(connectionId,0,KDownlinkData,downlinkData,status);
   User::WaitForRequest( status );
 
   // Get connection uplink data (in bytes)
   monitor.GetUintAttribute(connectionId,0,KUplinkData,uplinkData,status);
   User::WaitForRequest( status );
   
   // Get the signal strength (in mW)
  // monitor.GetIntAttribute(connectionId,0,KSignalStrength,signalStrength,status);
  // User::WaitForRequest( status );
   
   // Get the current connection activity
   monitor.GetBoolAttribute(connectionId,0,KConnectionActive,connectionActivity,status);
   User::WaitForRequest( status );
 
   // Get the connection bearer
  //monitor.GetIntAttribute(connectionId,0,KBearer,bearer,status );
  // User::WaitForRequest( status );
 
 
    PyList_SetItem( list, idx-1, Py_BuildValue("u#iiii",iapName.Ptr(),iapName.Length(),
                                              iapId,
                                              downlinkData,
                                              uplinkData,
                                              (TInt)connectionActivity
                                               )); 
    
   }
 
  monitor.Close(); // Close RConnectionMonitor object    
  return list;
}
 
//--------------------------------------------------------------------------

static const PyMethodDef connmon_met[] = {
    {"get", (PyCFunction)Get, METH_NOARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
    Py_InitModule("conmonitor", connmon_met);
}

//--------------------------------------------------------------------------

