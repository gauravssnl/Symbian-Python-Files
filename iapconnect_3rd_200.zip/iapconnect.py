import e32

if e32.s60_version_info>=(3,0):
    import imp
    _iapconnect=imp.load_dynamic('_iapconnect',
                                   'c:\\sys\\bin\\kf__iapconnect.pyd')
                                   
else:
    import _iapconnect

from _iapconnect import *
del imp, e32, _iapconnect
