#ifndef __CTEXRECOGNIZER_H_
#define __CTEXRECOGNIZER_H_
 
#include <apmrec.h>  // CApaDataRecognizerType
 
class CTexRecognizer : public CApaDataRecognizerType
    {
    public:  // Constructors and destructor
        CTexRecognizer();
        static CApaDataRecognizerType* CreateRecognizerL();
        virtual ~CTexRecognizer();
 
    public:  // Methods from base classes
        TUint PreferredBufSize();
        TDataType SupportedDataTypeL(TInt aIndex) const;
 
    private:  // Methods from base classes
        void DoRecognizeL(const TDesC& aName, const TDesC8& aBuffer);
    };
 
#endif /*__CTEXRECOGNIZER_H_*/