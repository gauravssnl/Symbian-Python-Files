#include <apmrec.h>   // CApaDataRecognizerType
#include <f32file.h>  // TParse
#include <ImplementationProxy.h>  // TImplementationProxy
 
#include "CTexRecognizer.h"
 
const TUid KRecognizerUid = {0x101FF1EC};
const TInt KRecognizerImplUid = {0x101FF1ED};
const TInt KMaxBufferSize = 128;
_LIT8(KMIMETex, "application/x-tex");
_LIT(KTexExtension, ".tex");
 
CTexRecognizer::CTexRecognizer()
    : CApaDataRecognizerType(KRecognizerUid, CApaDataRecognizerType::ENormal)
    {
    iCountDataTypes = 1;
    }
 
CTexRecognizer::~CTexRecognizer()
    {
    // No implementation required
    }
 
/**
 * From CApaDataRecognizerType.
 */
TUint CTexRecognizer::PreferredBufSize()
    {
    return KMaxBufferSize; 
    }
 
/**
 * From CApaDataRecognizerType.
 * Gets one of the data types that this recognizer can recognize.
 */
TDataType CTexRecognizer::SupportedDataTypeL(TInt /*aIndex*/) const
    {
    return TDataType(KMIMETex);
    }
 
/**
 * From CApaDataRecognizerType.
 * Attempts to recognize data denoted by aName and residing in aBuffer.
 */
void CTexRecognizer::DoRecognizeL(const TDesC& aName, const TDesC8& aBuffer)
    {
    // To keep the code simple, we only check the file name extension: If the
    // extension is ".tex", we are "ECertain" that the file is of type
    // application/x-tex.
    TParse parse;
    parse.Set(aName, NULL, NULL);
    TPtrC ext = parse.Ext();
    if (ext.CompareF(KTexExtension) == 0)
        {
        iConfidence = ECertain;
        iDataType = TDataType(KMIMETex);
        }
    }
 
// *** ECOM framework code ***
 
CApaDataRecognizerType* CTexRecognizer::CreateRecognizerL()
    {
    return new (ELeave) CTexRecognizer();
    }
 
const TImplementationProxy ImplementationTable[] =
    {
    IMPLEMENTATION_PROXY_ENTRY(KRecognizerImplUid,
            CTexRecognizer::CreateRecognizerL)
    };
 
EXPORT_C const TImplementationProxy* ImplementationGroupProxy(
        TInt& aTableCount)
    {
    aTableCount = sizeof(ImplementationTable) / sizeof(TImplementationProxy);
    return ImplementationTable;
    }