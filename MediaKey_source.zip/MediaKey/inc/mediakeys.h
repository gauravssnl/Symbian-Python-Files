#ifndef MEDIAKEYS_PY_H
#define MEDIAKEYS_PY_H

#include <COEVIEW.H>
#include <e32base.h>
#include <aknappui.h> 
#include <remconcoreapitargetobserver.h>    
#include <remconcoreapitarget.h>            
#include <remconinterfaceselector.h>       


#include "Python.h"
#include "symbian_python_ext_util.h"

//-----------------------------------------------------------------------------

class CMediaKeysTestUi : public CAknAppUi, public MRemConCoreApiTargetObserver
 {
   
 public:
   
    CMediaKeysTestUi();
    ~CMediaKeysTestUi();
    void CallPy();
    static TInt CTimerCallBack(TAny* aPtr);
    void ConstructL();
    
 private:        
    void MrccatoCommand(TRemConCoreApiOperationId aOperationId,
                         TRemConCoreApiButtonAction aButtonAct);
 
                         
 private:                         
   // CRemConInterfaceSelector* iInterfaceSelector;
   // CRemConCoreApiTarget*     iCoreTarget;
    
 public:
    CRemConInterfaceSelector* iInterfaceSelector;
    CRemConCoreApiTarget*     iCoreTarget;
    CPeriodic* iTimer;
    PyObject *iCb;
    TInt iNum;
    
 };
 
    
#endif
