# Payload-Teensy ( BadUSB ) Like a Rubber Ducky 

This script  was tested on an Teensy 3.2 and Windows. To run this script , simply download the repository and extract  in your pc or lapt. Paste the the payload script into  your Arduino  . So this is  all of payload for teensy ( sketch ) 
You can buy Teensy >> ( https://www.pjrc.com )


## PaensyLib By Ozuru
You will need the Teensy USB Development Board and Teensyduino. The PJRC website has a very easy to use guide on getting Teensyduino setup.

Once Teensyduino is installed and working, place the PaensyLib folder inside your Arduino\libraries. Arduino is installed in your Program Files (x86 if 64 bit) directory by default. To utilize Paensy, simply include the library in your code:

    #include <paensy.h>

List payload paensy
1. BadUSB_AddAdmin
2. BadUSB_DownloadExecute
3. BadUSB_FacebookPost
4. BadUSB_HideWindow
5. BadUSB_LockYourComputer (fix with me)

If list payload 1,2,3,4 not work you can use Kautilya ( is the best for execute backdoor or powershell )

## Tutorial for use teensy

1. ( https://www.pjrc.com/teensy/teensyduino.html ) 
2. ( www.irongeek.com/i.php?page=security/programmable-hid-usb-keystroke-dongle )

## Another Payload you can find 
1. ( https://www.trustedsec.com/social-engineer-toolkit/ )
2. ( www.irongeek.com/i.php?page=security/programmable-hid-usb-keystroke-dongle )
3. ( http://malware.cat/?p=89 ) 
4. ( https://github.com/Ozuru/Paensy/tree/master/Payloads )

## Contact 

@ Edo -m- you can contact me in screetsec@gmail.com 
thanks 

Ozuru > https://github.com/Ozuru/

#THE PAYLOAD FOR WINDOWS


