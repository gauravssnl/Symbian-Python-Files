#SmartSIS v2.3 by smart4n
import sys
import os
import appuifw
import e32
def ru(x): return x.decode('utf-8')
def ur(x): return x.encode('utf-8')
sys.setdefaultencoding('utf-8')
notif=appuifw.note
if os.path.exists('C:\\System\\Apps\\SmartSIS\\checkdisk.cds') and os.path.exists('C:\\System\\Apps\\SmartSIS\\_sismain.pyc'):
  disk='C'
elif os.path.exists('E:\\System\\Apps\\SmartSIS\\checkdisk.cds') and os.path.exists('E:\\System\\Apps\\SmartSIS\\_sismain.pyc'):
  disk='E'
else:
  notif(ru('Reinstall the program'),'error')
  sys.exit()
sys.path.insert(0,disk+':\\System\\Apps\\SmartSIS')
import timer as tim
import prodb1 as pro
try:
  import appswitch
  from misty import vibrate
  from envy import set_app_system
except:
  notif(ru('Please install <megaPyModulePack by smart4n>'),'error')
  sys.exit()

appuifw.app.body=body=appuifw.Text()
appuifw.app.screen='normal'
appuifw.app.title = u'SmartSIS'
if not os.path.exists(disk+':\System\Apps\smartSIS\ss.dat'):
  ss=pro.set(disk+':/System/Apps/smartSIS/ss.dat',load=0,save=0)
  ss.PATH='C'
  ss.SOUND=1
  ss.SCRKILL=0
  ss.LASTPATH='C:\\'
  ss.PACKMODE='master'
  ss.LANG='en'
  ss.AUTOSIGN=0
  ss.CERT='C:\\smartSIS\\cert\\mycert.cer'
  ss.PRIVKEY='C:\\smartSIS\\cert\\mykey.key'
  ss.PKGPY2SIS='C:\\SmartSIS\\PKGs\\py2sis.pkg'
  ss.PKGPACK='C:\\SmartSIS\\PKGs\\sis.pkg'
  ss.save()
ss=pro.set(disk+':/System/Apps/smartSIS/ss.dat')
import base64
if ss.LANG == 'en':
  try:
    f=file(disk+':\\System\\Apps\\SmartSIS\\langs\\en.lang','rb')
    lang=base64.decodestring(f.read()).split('\n')
    f.close()
    helptext=disk+':\\System\\Apps\\smartSIS\\help\\en_'
    mainfont=u'LatinPlain12'
    progressfont=u'LatinPlain12'
  except:
    notif(ru('Language file is damaged, reinstall the program'),'error')
    sys.exit()
elif ss.LANG == 'ru':
  try:
    f=file(disk+':\\System\\Apps\\SmartSIS\\langs\\ru.lang','rb')
    lang=base64.decodestring(f.read()).split('\n')
    f.close()
    helptext=disk+':\\System\\Apps\\smartSIS\\help\\ru_'
    mainfont=u'LatinPlain12'
    progressfont=u'LatinPlain12'
  except:
    notif(ru('Файл языка поврежден, переустановите программу'),'error')
    sys.exit()
elif ss.LANG == 'cn':
  try:
    f=file(disk+':\\System\\Apps\\SmartSIS\\langs\\cn.lang','rb')
    lang=base64.decodestring(f.read()).split('\n')
    f.close()
    helptext=disk+':\\System\\Apps\\smartSIS\\help\\cn_'
    mainfont='normal'
    progressfont=u'Sans MT 936_s60'
  except:
    notif(ru('Language file is damaged, reinstall the program'),'error')
    sys.exit()
del base64
progversion=''
for i in [118,50,46,51]: progversion+=chr(i)
def printout(mess):
  appuifw.app.body.add(mess)
  appuifw.app.body.add(u"\n")
  
def printoutn(mess):
  appuifw.app.body.add(mess)

set_app_system(1)
  
def alert():
  import audio
  global sound
  notific=ss.SOUND
  if notific==1:
    try:
      sound=audio.Sound.open(unicode(disk+':\\System\\Apps\\smartSIS\\done.mp3'))
      sound.play()
      appuifw.app.exit_key_handler=sstop
    except:
      notif(ru(lang[2-1]),'error')
  elif notific==2:
    try:
      vibrate(300,50)
      e32.ao_sleep(0.2)
      vibrate(500,70)
      e32.ao_sleep(0.2)
      vibrate(800,90)
      e32.ao_sleep(0.2)
    except:
      pass
  elif notific==0:
    pass
  
def sstop():
  global sound
  sound.stop()
  appuifw.app.exit_key_handler = back
  
class error:
	flag=0
	def write(s,text):
		if s.flag:
			appuifw.app.body.add(ru(text))
		else:
			appuifw.app.exit_key_handler=sys.exit
			appuifw.app.menu=[(ru(lang[3-1]),sys.exit)]
			appuifw.app.body=appuifw.Text(ru(lang[4-1]+'\n'))
			appuifw.app.body.color=0xff0000
			s.flag=1
                        quit(1)
sys.stderr=error()
  
def _findItem(item, itemParent, index, objectIdentifier):
  import base
  if isinstance(item, base.AbstractSimpleAsn1Item) :
    if item == objectIdentifier :
      return itemParent[index+1]
  else :
    for i in range(len(item)) :
      found = _findItem(item[i], item, i, objectIdentifier)
      if found : 
        return found

def findItem(decodedCert, objectIdentifier) :
  return _findItem(decodedCert, None, 0, objectIdentifier)

  
class SignSIS:
  def __init__(s):
    import dss1
    import powlite_fm
    s.dss1,s.powlite_fm=dss1,powlite_fm
    
  def sign(s,sisfile):
    s.dss1.startsign(sisfile,ur(ru(ss.CERT)),ur(ru(ss.PRIVKEY)))
  
  def selfsign(s,sisfile):
    s.dss1.startsign(sisfile)
  
  def unsign(s,sisfile):
    s.dss1.unsign(sisfile)
  
  def decipher(s):
    fm=s.powlite_fm.manager()
    inkey=fm.AskUser(ext=['.key'])
    if inkey:
      inkey=ur(inkey)
    else:
      return 0
    passphrase=appuifw.query(ru(lang[177-1]),'text')
    if passphrase:
      try:
        passphrase=str(passphrase)
      except:
        notif(lang[181-1],'error')
    else:
      return 0
    outkey=os.path.basename(inkey).split('.')
    outkey=os.path.dirname(inkey)+os.sep+outkey[0]+'_no_passphrase.'+outkey[1]
    timer=tim.Timer()
    e32.ao_yield()
    body.color=0x333399
    body.focus=False
    body.font='title'
    body.style=appuifw.HIGHLIGHT_SHADOW
    body.set(ru('\tSmartSIS '+str(progversion)))
    body.style=0
    body.color=0
    body.font=mainfont
    printout(ru('\n\n'+lang[74-1]))
    e32.ao_yield()
    try:
      s.dss1.getPrivateKey(inkey,passphrase,outkey)
    except:
      notif(ru(lang[76-1]),'error')
      return 0
    body.color=0
    body.font=mainfont
    body.set(ru(lang[176-1]+'\n'+lang[146-1]+timer.endtimer()))
    alert()
    notif(ru(lang[176-1]),'conf')
    appuifw.app.exit_key_handler = back
    
    
def dosign(act):
  global signer
  signer=SignSIS()
  body.focus=False
  if act == 3:
    signer.decipher()
    return 0
  fm=signer.powlite_fm.manager()
  sisfile=fm.AskUser(ss.LASTPATH,ext=['.sis','.sisx'])
  if sisfile:
    ss.LASTPATH=os.path.dirname(sisfile)
    sisfile=ur(sisfile)
  else:
    return 0
  timer=tim.Timer()
  e32.ao_yield()
  body.color=0x333399
  body.font='title'
  body.style=appuifw.HIGHLIGHT_SHADOW
  body.set(ru('\tSmartSIS '+str(progversion)))
  body.style=0
  body.color=0
  body.font=mainfont
  printout(ru('\n\n'+lang[74-1]))
  e32.ao_yield()
  if   act == 0:
    try:
      signer.sign(sisfile)
    except:
      notif(ru(lang[76-1]),'error')
      return 0
  elif act == 1:
    try:
      signer.selfsign(sisfile)
    except:
      notif(ru(lang[76-1]),'error')
      return 0
  elif act == 2:
    try:
      signer.unsign(sisfile)
    except:
      notif(ru(lang[76-1]),'error')
      return 0
  body.color=0
  body.font=mainfont
  body.set(ru(lang[176-1]+'\n'+lang[146-1]+timer.endtimer()))
  alert()
  notif(ru(lang[176-1]),'conf')
  appuifw.app.exit_key_handler = back
    
    
class Altere32:
  def __init__(s):
    import struct
    import symbianutil
    import powlite_fm
    s.struct,s.symbianutil,s.powlite_fm=struct,symbianutil,powlite_fm
  def choose_file(s):
    fm=s.powlite_fm.manager()
    s.image=fm.AskUser(ss.LASTPATH,ext=['.dll','.exe','.pyd'])
    if s.image:
      ss.LASTPATH=os.path.dirname(s.image)
      s.image=ur(s.image)
    else:
      return 0
    f = file(s.image, "rb")
    s.instring = f.read()
    f.close()
    s.image_info()
  def image_info(s,refresh=0):
    try:
      if refresh:
        f = file(s.image, "rb")
        s.instring = f.read()
        f.close()
      (uid1, uid2, s.uid3,sid, vid, capmask) = s.symbianutil.e32imageinfo(s.instring)
      caps = s.symbianutil.capmasktostring(capmask, True)
      body.color=0xff0000
      body.focus=True
      body.set(ru('\t'+lang[195-1]+'\n\n'))
      body.color=0
      printout(ru("    %s" % s.image))
      printout(ru("    ------------------------------"))
      printout(ru("    UID1            0x%08x" % uid1))
      printout(ru("    UID2            0x%08x" % uid2))
      printout(ru("    Secure ID     0x%08x" % sid))
      printout(ru("    Vendor ID     0x%08x" % vid))
      printout(ru("    ------------------------------"))
      printout(ru("    UID(UID3)     0x%08x" % s.uid3))
      printout(ru("    Capabilities   0x%x (%s)" % (capmask, caps)))
    except:
      notif(ru(lang[193-1]),'error')
      return 0
    appuifw.app.exit_key_handler = back
    menu(7)
  def do_it(s,act,sec):
    if act == 'caps':
      secureid=vendorid=s.uid3=None
      capmask = s.symbianutil.capstringtomask(sec)
    else:
      vendorid=capmask=None
      s.uid3=secureid=sec
    try:
      outstring = s.symbianutil.e32imagecrc(s.instring, s.uid3,secureid, vendorid, capmask)
    except:
      notif(ru(lang[193-1]),'error')
      return 0

    f = file(s.image, "wb")
    f.write(outstring)
    f.close()
    notif(ru(lang[78-1]),'conf')
  def set_caps(s,act):
    if act == 'ch':
      all_caps=[u"PowerMgmt",u"ReadDeviceData",u"WriteDeviceData",u"TrustedUI",
                u"ProtServ",u"SwEvent",u"NetworkServices",u"LocalServices",u"ReadUserData",
                u"WriteUserData",u"Location",u"SurroundingsDD",u"UserEnvironment",
                u"DRM",u"TCB",u"CommDD",u"MultimediaDD",u"DiskAdmin",u"NetworkControl",u"AllFiles"]
      dict_caps={0:"PowerMgmt",1:"ReadDeviceData",2:"WriteDeviceData",3:"TrustedUI",
                 4:"ProtServ",5:"SwEvent",6:"NetworkServices",7:"LocalServices",8:"ReadUserData",
                 9:"WriteUserData",10:"Location",11:"SurroundingsDD",12:"UserEnvironment",
                 13:"DRM",14:"TCB",15:"CommDD",16:"MultimediaDD",17:"DiskAdmin",18:"NetworkControl",19:"AllFiles"}
      inds=appuifw.multi_selection_list(all_caps)
      capsstring=''
      for i in inds:
        capsstring+=dict_caps[i]+'+'
      if capsstring.endswith('+'): capsstring=capsstring[:-1]
    elif act == 'dev':
      capsstring="PowerMgmt+ReadDeviceData+WriteDeviceData+TrustedUI+ProtServ+SwEvent+LocalServices+ReadUserData+WriteUserData+Location+SurroundingsDD+UserEnvironment+NetworkServices"
    elif act == 'self':
      capsstring='ReadUserData+WriteUserData+UserEnvironment+NetworkServices+LocalServices'
    s.do_it('caps',capsstring)
    s.image_info(1)
  def change_uid(s):
    uid=appuifw.query(ru(lang[57-1]),'text',ru('0x%08x'%s.uid3))
    if not uid: return 0
    if len(uid) <> 10 or not uid.startswith('0x'):
      notif(ru(lang[194-1]),'error')
      return 0
    try:
      uid=long(uid,16)
    except:
      notif(ru(lang[194-1]),'error')
      return 0
    s.do_it('uid',uid)
    s.image_info(1)
    
def run_altere32():
  global altere32
  altere32=Altere32()
  altere32.choose_file()
    
    
  
class CertificateOrganization :
  def __init__(s) :
    pass
	
  def parse(s, decodedCert) :
    s.commonName = findItem(decodedCert, (2,5,4,3))
    s.countryCode = findItem(decodedCert, (2,5,4,6))
    s.locality = findItem(decodedCert, (2,5,4,7))
    s.state = findItem(decodedCert, (2,5,4,8))
    s.street = findItem(decodedCert, (2,5,4,9))
    s.organization = findItem(decodedCert, (2,5,4,10))

  def readableStr(s) :
    buf = ""
    if s.commonName :
      buf += s.commonName.prettyPrint() + "\n"
    if s.countryCode :
      buf += s.countryCode.prettyPrint() + "\n"
    if s.locality :
      buf += s.locality.prettyPrint() + "\n"
    if s.state :
      buf += s.state.prettyPrint() + "\n"
    if s.street :
      buf += s.street.prettyPrint() + "\n"
    if s.organization :
      buf += s.organization.prettyPrint()
    return buf
		
class CertificateInfo :
  def __init__(s) :
    pass
		
  def parse(s, decodedCert) :
    s.issuer = CertificateOrganization()
    s.issuer.parse(decodedCert[0][3])
		
    s.signer = CertificateOrganization()
    s.signer.parse(decodedCert[0][5])
		
  def readableStr(s) :
    buf = lang[5-1]+'\n' + "\n  ".join(s.signer.readableStr().split('\n')) + "\n"
    buf += lang[6-1]+'\n' + "\n  ".join(s.issuer.readableStr().split('\n')) + "\n"
    return buf

class UnpackSIS:
  def __init__(s):
    import sisinfo
    import sisfields
    import sunps8
    import powlite_fm
    import progressbar
    s.sisinfo,s.sisfields,s.sunps8,s.progressbar,s.powlite_fm=sisinfo,sisfields,sunps8,progressbar,powlite_fm
    s.sisfields.uids=0
    s.sis=s.expath=''
    s.sisfields.all=s.sisfields.dates=s.sisfields.times=s.sisfields.versn=''
    s.files = []
    s.fileDatas = []
    s.signatureCertificateChains = []
    s.sisInfo = s.sisinfo.SISInfo()
    
  def handleField(s, field, depth):
    if field.type == s.sisfields.FileDescriptionField :
      s.files.append(field)
    elif field.type == s.sisfields.FileDataField :
      s.fileDatas.append(field)
    elif field.type == s.sisfields.SignatureCertificateChainField  :
      s.signatureCertificateChains.append(field)
      
  def unpack_s9(s):
    scrkill()
    s.expath=ss.PATH+':\\smartSIS\\unpacked\\'
    checkalldir()
    tmpp=os.path.split(s.csis)[1]
    if tmpp.endswith('sis'):
      tmpp=tmpp[:-4]
    else:
      tmpp=tmpp[:-5]
    s.expath=s.expath+'symbian9\\'+ru(tmpp)
    s.expath=ur(s.expath)
    checkdir(s.expath)
    try:
      timer=tim.Timer()
      e32.ao_yield()
      i=0
      prss=s.progressbar.ProgressBarTW(progressfont)
      forcn=0
      if ss.LANG=='cn': forcn=1
      prss.begin_progress(len(s.files),1)
      for f in s.files:
        e32.reset_inactivity()
        parts = f.findField(s.sisfields.StringField)[0].readableStr().split("\\")
        if forcn:
          prss.do_progress(i,ru(str(os.path.split(f.findField(s.sisfields.StringField)[0].readableStr())[1])))
        else:
          prss.do_progress(i,os.path.split(f.findField(s.sisfields.StringField)[0].readableStr())[1])
        i=i+1
        if len(parts[len(parts) - 1]) > 0 :
          pathh = ru(os.path.abspath(s.expath))
          pathh += os.sep + parts[0][:1] + os.sep + os.sep.join(parts[1:-1])
          pathh=ur(pathh)
          if not os.path.exists(pathh) :
            os.makedirs(pathh)
          newFile = file(pathh + ur(os.sep) + ur(parts[len(parts) - 1]), 'wb')
          newFile.write(s.fileDatas[f.fileIndex].findField(s.sisfields.CompressedField)[0].data)
          newFile.close()
      prss.end_progress()
      s.create_pkg()
      e32.ao_yield()
      menu(0)
      body.color=0
      alert()
      body.set(ru(lang[147-1]+str(s.expath)+'\n'+lang[146-1]+timer.endtimer()))
    except:
      notif(ru(lang[102-1]),'error')

  def execute_info(s):
    e32.ao_yield()
    i=0
    prss=s.progressbar.ProgressBarTW(progressfont)
    prss.begin_progress(len(s.files))
    e32.ao_yield()
    for f in s.files:
      prss.do_progress(i)
      i=i+1
      e32.reset_inactivity()
      stroke=f.findField(s.sisfields.StringField)[0].readableStr()
      if stroke:
        buf = "   " + stroke
        caps = f.findField(s.sisfields.CapabilitiesField)[0]
        if caps :
          buf += " [" + " ".join(f.findField(s.sisfields.CapabilitiesField)[0].readableCaps) + "]"
        printout(buf)
    prss.end_progress()
      
      
  def execute_cert(s) :
    import derdecoder
    e32.ao_yield()
    if len(s.signatureCertificateChains) <> 0:
        body.color=0xff0000
        printout(ru(lang[7-1]))
        body.color=0
        for sss in s.signatureCertificateChains :
                e32.reset_inactivity()
                appuifw.app.body.set_pos(len(appuifw.app.body.get()))
                buf = sss.findField(s.sisfields.CertificateChainField)[0].subFields[0].data
                i = 1
                while len(buf) > 0 :
                  body.color=0x0000ff
                  printout(ru(lang[8-1] + str(i) + ":"))
                  body.color=0
                  i += 1
                  decoded = derdecoder.decode(buf)
                  cer = CertificateInfo()
                  cer.parse(decoded[0])
                  readableStr = cer.readableStr()     
                  printout(ru("     " + "\n     ".join(readableStr.split('\n'))))
                  buf=decoded[1]
    else:
        notif(ru(lang[9-1]),'info')
    del derdecoder
      
  def unpack_s8(s):
    if not os.path.isdir('e:\\sisunpack'): os.mkdir('e:\\sisunpack')
    import sunps8_ex
    del sunps8_ex
    import sunps8_ex
    path=ss.PATH+':\\smartSIS\\unpacked\\'
    checkalldir()
    scrkill()
    try:
      timer=tim.Timer()
      br = sunps8_ex.BinaryReader()
      br.Open(s.csis)
      sh = sunps8_ex.SisHeader()
      sh.ReadHeader(br)
      body.color=0xff0000
      sfr = sunps8_ex.SisFileRecord()
      tmpp=os.path.split(s.csis)[1][:-4]
      tmpbase = (path+'symbian8\\'+tmpp+'\\')
      prss=s.progressbar.ProgressBarTW(progressfont)
      prss.begin_progress(sh.NumberOfFiles)
      for i in range(sh.NumberOfFiles):
        sfr.ScanRecord(br, sh, tmpbase)
        prss.do_progress(i)
      br.Close()
      menu(0)
      prss.end_progress()
      appuifw.app.body.set_pos(0)
      appuifw.app.exit_key_handler = back
      body.color=0
      body.focus=False
      body.set(ru(lang[147-1]+str(tmpbase)+'\n'+lang[146-1]+timer.endtimer()))
      alert()
      notif(ru(lang[101-1]),'conf')
    except:
      notif(ru(lang[102-1]),'error')
    if os.path.isdir('e:\\sisunpack'): os.rmdir('e:\\sisunpack')
      
  def create_pkg(s):
    directory=s.expath
    name=unicode(s.sisfields.all.split('\n')[1])
    version=str(s.sisfields.versn.split(')')[0][1:])
    UID=str(hex(s.sisinfo.uids))
    vendor=unicode(s.sisfields.all.split('\n')[0])
    sistype=u'SA'
    textfile=u'None'
    language=u'EN'
    pkgpath=str(ss.PATH)+':\\SmartSIS\\PKGs\\'+os.path.split(os.path.realpath(directory))[-1]+'.pkg'
    f=file(pkgpath,'w')
    data=directory+'\r\n'+name+'\r\n'+version+'\r\n'+UID+'\r\n'+vendor+'\r\n'+sistype+'\r\n'+textfile+'\r\n'+language
    f.write(ur(data))
    f.close()
    
  def infosis(s):
    s.dates=s.sisfields.dates.split(')')[0].split('.')
    s.dates=s.dates[0]+'.'+str(int(s.dates[1])+1)+'.'+s.dates[2]
    try:
      printout(ru(lang[90-1]+str(s.sisfields.all.split('\n')[1])))
    except:
      printoutn(ru(lang[90-1]))
      printout(unicode(s.sisfields.all.split('\n')[1]))
    try:
      printout(ru(lang[91-1]+str(s.sisfields.versn.split(')')[0][1:])))
    except:
      printoutn(ru(lang[91-1]))
      printout(str(s.sisfields.versn.split(')')[0][1:]))
    printout(ru(lang[92-1]+str(hex(s.sisinfo.uids))))
    printout(ru(lang[93-1]+s.dates))
    printout(ru(lang[94-1]+str(s.sisfields.times.split(')')[0])))
    try:
      printout(ru(lang[95-1]+str(s.sisfields.all.split('\n')[0])))
    except:
      printoutn(ru(lang[95-1]))
      printout(unicode(s.sisfields.all.split('\n')[0]))
    try:
      printout(ru(lang[96-1]+str(s.sisfields.all.split('\n')[0])))
    except:
      printoutn(ru(lang[96-1]))
      printout(unicode(s.sisfields.all.split('\n')[0]))
    printout(ru('=*=*=*=*=*=*=*=*=*=*=*=*=*'))
      
  def chsis(s):
    body.focus=True
    fm=s.powlite_fm.manager()
    s.csis=fm.AskUser(ss.LASTPATH,ext=['.sis','.sisx'])
    if s.csis <> None:
      ss.LASTPATH=os.path.dirname(s.csis)
      s.csis=ur(s.csis)
    else:
      return 0
    try:
      s.sisInfo.parse(s.csis)
      s.sisInfo.traverse(unpacker)
      body.color=0xff0000
      body.set(ru('\t\t'+lang[99-1]+'\n'))
      body.color=0
      printout(ru('=*=*=*=*=*=*=*=*=*=*=*=*=*'))
      body.color=0xff0000
      printout(ru(lang[100-1]))
      body.color=0
      s.infosis()
      body.color=0xff0000
      printout(ru(lang[137-1]))
      body.color=0
      s.execute_info()
      printout(ru('=*=*=*=*=*=*=*=*=*=*=*=*=*'))
      appuifw.app.exit_key_handler = back
      appuifw.app.body.set_pos(0)
      menu(1)
    except:
      br = s.sunps8.BinaryReader()
      br.Open(s.csis)
      sh = s.sunps8.SisHeader()
      sh.ReadHeader(br)
      sfr = s.sunps8.SisFileRecord()
      tmpbase = (s.csis)
      body.color=0x333399
      prss=s.progressbar.ProgressBarTW(progressfont)
      prss.begin_progress(sh.NumberOfFiles)
      body.font='title'
      body.style=appuifw.HIGHLIGHT_SHADOW
      body.set(ru('\tSmartSIS '+str(progversion)))
      body.style=0
      body.color=0
      body.font=mainfont
      printout(ru('\n\n'+lang[97-1]))
      menu(2)
      for i in range(sh.NumberOfFiles):
        sfr.ScanRecordInfo(br, sh, tmpbase)
        prss.do_progress(i)
      body.color=0xff0000
      prss.end_progress()
      body.set(ru(lang[98-1]+'\n'+lang[137-1]+'\n'))
      body.color=0
      printout(ru(s.sunps8.total))
      appuifw.app.body.set_pos(0)
      appuifw.app.exit_key_handler = back
      br.Close()
      del br
      del sh
      del sfr
      
  
def dounpack():
  global unpacker
  unpacker=UnpackSIS()
  unpacker.chsis()
  
def dounpack_unpack_s9():
  global unpacker
  unpacker.unpack_s9()
  
def dounpack_unpack_s8():
  global unpacker
  unpacker.unpack_s8()
  
def dounpack_cert():
  global unpacker
  unpacker.execute_cert()

  
class MifSvg:
  def __init__(s):
    import struct
    import powlite_fm
    import miffile
    s.struct,s.powlite_fm,s.miffile=struct,powlite_fm,miffile
    s.path=ss.PATH
    s.dir = s.path+':\\smartSIS\\MIFs\\unpacked\\'
    checkdir(s.dir)
    s.dumpcounter=1
    s.mif=s.dirMIF=s.dirSVG=s.svg=s.outfile=s.mifdata=s.tempdir=''
    s.miffilenames=s.svgfilenames=[]
    
  def _dumpdata(s,ddata):
    ext = "svg"
    filename = os.path.join(s.tempdir, "dump%04d.%s" % (s.dumpcounter, ext))
    f = file(filename, "wb")
    f.write(ddata.split('C##4')[0])
    f.close()
    del ddata
    printout(ru("  dump%04d.%s" % (s.dumpcounter, ext)+lang[160-1]))
    s.dumpcounter += 1

  def pack(s,act):
    s.svgfilenames=[]
    body.focus=True
    if act==0:
      fm=s.powlite_fm.manager()
      s.svg=fm.AskUser(ss.LASTPATH,ext=['.svg'])
      if s.svg <> None:
        ss.LASTPATH=os.path.dirname(s.svg)
        s.svg=ur(s.svg)
      else:
        return 0
      s.svgfilenames.append(s.svg)
    else:
      fm=s.powlite_fm.manager()
      s.dirSVG=fm.AskUser(find='dir')
      if s.dirSVG <> None:
        s.dirSVG=ur(s.dirSVG)
      else:
        return 0
      def getfiles(arg, dirname, names):
            for name in names:
              if name.endswith('.svg'): 
                path = os.path.join(dirname, name)
                if not os.path.isdir(path):
                    arg.append(path)
      os.path.walk(s.dirSVG, getfiles, s.svgfilenames)
    timer=tim.Timer()
    body.color=0
    body.set('')
    mw = s.miffile.MIFWriter()
    s.svgfilenames.sort()
    for filename in s.svgfilenames:
      f=file(filename,'rb')
      string=f.read()
      f.close()
      mw.addfile(string)
      printout(ru("  %s " % (os.path.split(filename)[1])+lang[161-1]))
    string = mw.tostring()
    if act==0:
      s.outfile=os.path.split(s.svgfilenames[0])[1][:-4]
    else:
      s.outfile=s.dirSVG.split('\\')[-2]
    s.outfile=s.path+':\\smartSIS\\MIFs\\'+s.outfile+'.mif'
    f=file(s.outfile,'wb')
    f.write(string)
    f.close()
    del string
    printout(ru(lang[145-1]+str(s.outfile)+'\n'))
    body.color=0xff0000
    appuifw.app.exit_key_handler = back
    printout(ru(lang[159-1]+'\n'+lang[146-1]+timer.endtimer()))
    body.color=0
    alert()
    notif(ru(lang[78-1]),'conf')
    
    
  def unpack(s,act):
    
    s.miffilenames=[]
    body.focus=True
    if act==0:
      fm=s.powlite_fm.manager()
      s.mif=fm.AskUser(ss.LASTPATH,ext=['.mif'])
      if s.mif <> None:
        ss.LASTPATH=os.path.dirname(s.svg)
        s.mif=ur(s.mif)
      else:
        return 0
      s.miffilenames.append(s.mif)
    else:
      fm=s.powlite_fm.manager()
      s.dirMIF=fm.AskUser(find='dir')
      if s.dirMIF <> None:
        s.dirMIF=ur(s.dirMIF)
      else:
        return 0
      def getfiles(arg, dirname, names):
            for name in names:
              if name.endswith('.mif'): 
                path = os.path.join(dirname, name)
                if not os.path.isdir(path):
                    arg.append(path)
      os.path.walk(s.dirMIF, getfiles, s.miffilenames)
    
    body.set('')
    timer=tim.Timer()
      
    for miffilename in s.miffilenames:
            s.dumpcounter=1
            body.color=0x0000ff
            printout(ru(lang[162-1]+miffilename))
            body.color=0
            s.tempdir=s.dir+os.path.split(miffilename)[1][:-4]+'\\'
            checkdir(s.tempdir)
            try:
              miffile = file(miffilename, "rb")
              s.mifdata = miffile.read()
              miffile.close()
            except:
              notif(ru(lang[164-1]),'error')

            if s.mifdata[:4] != "B##4":
                notif(ru("%s: " % (miffilename)+lang[165-1]),'error')
                return 0
            entries = s.struct.unpack("<L", s.mifdata[12:16])[0] / 2
            
            printout(ru(lang[166-1]+str(entries)))
            
            if len(s.mifdata) < (16 + 16 * entries):
                raise ValueError("%s: file too short" % miffilename)
            index = []
            for n in xrange(entries):
                hdroff = 16 + n * 16
                a = s.struct.unpack("<L", s.mifdata[hdroff +  0:hdroff + 4])[0]
                b = s.struct.unpack("<L", s.mifdata[hdroff +  4:hdroff + 8])[0]
                c = s.struct.unpack("<L", s.mifdata[hdroff +  8:hdroff + 12])[0]
                d = s.struct.unpack("<L", s.mifdata[hdroff + 12:hdroff + 16])[0]
                if b == 0 and d == 0:
                    continue
                if a != c or b != d:
                    raise ValueError("%s: invalid index entry %d" %
                                     (miffilename, n))
                if a + b > len(s.mifdata):
                    raise ValueError("%s: index %d out of range" %
                                     (miffilename, n))
                index.append((a, b))
            n = len(index)
            for i in index:
                offset = i[0]
                length = i[1]
                if s.mifdata[offset:offset + 4] != "C##4":
                    notif(ru(str(miffilename)+": неверный заголовок "+str(n)),'error')
                    raise 0
                s._dumpdata(s.mifdata[offset + 32:offset + length + 32])
            printout(ru(' '+lang[147-1]+str(s.tempdir)+'\n'))
    body.color=0xff0000
    body.focus=False
    appuifw.app.exit_key_handler = back
    printout(ru('\n'+lang[159-1]+'\n'+lang[146-1]+timer.endtimer()))
    body.color=0
    alert()
    notif(ru(lang[78-1]),'conf')
    
            
     

def mifandsvg():
  global mifsvger
  mifsvger=MifSvg()
  body.color=0xff0000
  body.set(ru(lang[167-1]))
  body.color=0
  appuifw.app.exit_key_handler = back
  menu(6)
     
def domif2svg(act):
  global mifsvger
  try:
    mifsvger.unpack(act)
  except:
    notif(ru(lang[102-1]),'error')
  
  
def dosvg2mif(act):
  global mifsvger
  try:
    mifsvger.pack(act)
  except:
    notif(ru(lang[148-1]),'error')

  
class Py2SIS:
  def __init__(s):
    import sisfile
    import sisfield
    import symbianutil
    import rscfile
    import miffile
    import zlib
    import defaultpy2sis
    import progressbar
    import powlite_fm
    s.zlib,s.sisfile,s.sisfield,s.symbianutil,s.rscfile,s.miffile,s.defaultpy2sis,s.progressbar,s.powlite_fm=zlib,sisfile,sisfield,symbianutil,rscfile,miffile,defaultpy2sis,progressbar,powlite_fm
    s.MAXICONFILESIZE=65536
    s.MAXOTHERFILESIZE=1024*1024*2
    s.MAXTEXTFILELENGTH=1024
    s.directory=s.basename=s.outfile=s.version=s.caption=s.vendor=s.basename=''
    s.srcdir=s.caps=s.autostartflag=s.icon=s.textfile=s.pyfile=s.iscaps=s.hidden=s.autorun=''
    s.language=s.coding=s.srcdisk=''
    s.pkgfile=ur(ss.PKGPY2SIS)
    s.uid3=s.numlang=s.autostart=0
    s.notECI=0
    s.srcdirI=s.srcdirC=s.srcdirE=s.codingpkg=''
    s.autorunflag=s.hiddenflag=''
    s.srcfiles=s.lang=[]
    s.src_embsis=[]
    s.execstubdata = s.defaultpy2sis.execstubdatas
    s.defaulticondata = s.defaultpy2sis.defaulticondatas
    s.pythons60rscdata = s.defaultpy2sis.pythons60rscdatas
    
  def _tovers(s,version):
    if "." in version:
        parts = [int(n) for n in version.split(".")]
    else:
        parts = [int(n) for n in version.split(",")]
    parts.extend([0, 0])
    return parts[0:3]
  def _readtextfiles(s, pattern, languages):
    s.coding=''
    if "%" not in pattern:
        filenames = [pattern]
    else:
        filenames = []
        for langid in languages:
            langnum  = s.symbianutil.langidtonum[langid]
            langname = s.symbianutil.langnumtoname[langnum]
            filename = pattern
            filename = filename.replace("%n", "%02d" % langnum)
            filename = filename.replace("%c", langid.lower())
            filename = filename.replace("%C", langid.upper())
            filename = filename.replace("%l", langname.lower())
            filename = filename.replace("%L", langname)
            filename = filename.replace("%%", "%")

            filenames.append(filename)
    texts = []

    for filename in filenames:
        f = file(filename, 'r')
        text = f.read(1024 + 1)
        f.close()
        if len(text) > 1024:
            notif(ru(lang[10-1]+str(filename)+lang[11-1]),'error')
            raise 0
        if text.startswith('\xff\xfe'):
          texts.append(text.decode('UTF-16LE').encode('UTF-16LE'))
          s.coding='(Unicode)'
        else:
          try:
            texts.append(text.decode('UTF-8').encode('UTF-16'))
            s.coding='(UTF-8)'
          except:
            try:
              texts.append(text.decode('cp1251').encode('UTF-16'))
              s.coding='(Win 1251)'
            except:
              notif(ru(str(filename)+lang[12-1]),'error')
              raise 0
    return texts
  def choose_pkg(s):
    pkgfile=s.pkgfile
    fm=s.powlite_fm.manager()
    s.pkgfile=fm.AskUser(ss.PATH+':\\smartSIS\\PKGs',ext=['.pkg'])
    if s.pkgfile:
      s.pkgfile=ur(s.pkgfile)
    else:
      s.pkgfile=pkgfile
    s.packinfo()
  def _readpkg(s):
    body.focus=True
    path=ss.PATH
    checkdir(path+':\\smartSIS')
    checkdir(path+':\\smartSIS\\packed')
    if not os.path.exists(s.pkgfile):
      notif(ru(('%s '%s.pkgfile)+lang[138-1]),'error')
      fm=s.powlite_fm.manager()
      pkgfile=fm.AskUser(ss.PATH+':\\smartSIS\\PKGs',ext=['.pkg'])
      if pkgfile: s.pkgfile=ur(pkgfile)
      else: return 0
    f=file(s.pkgfile,'rb')
    strings=f.read()
    f.close()
    if strings.startswith('\xff\xfe'):
      strings=strings.decode('UTF-16LE')
      strings=strings[1:]
      s.codingpkg='(Unicode)'
    else:
      try:
        strings=strings.decode('UTF-8')
        s.codingpkg='(UTF-8)'
      except:
        try:
          strings=strings.decode('cp1251')
          s.codingpkg='(Win 1251)'
        except:
          notif(ru(str(s.pkgfile)+lang[12-1]),'error')
          raise 0
    strings=strings.split('\r\n')
    s.pypath=ur(strings[0])
    if len(s.pypath.split('+'))==1:
      s.pyfile=s.pypath
      s.directory=''
      if not os.path.isfile(s.pyfile):
        notif(ru(str(s.pyfile)+lang[138-1]),'error')
        raise 0
    else:
      s.pyfile=s.pypath.split('+')[0]
      s.directory=s.pypath.split('+')[1]
      if not os.path.isfile(s.pyfile):
        notif(ru(str(s.pyfile)+lang[138-1]),'error')
        raise 0
      if not os.path.isdir(s.directory):
        notif(ru(str(s.directory)+lang[138-1]),'error')
        raise 0
    s.basename=strings[1]
    s.version = str(strings[2])
    try:
      vers = s._tovers(s.version)
    except:
      notif(ru(lang[13-1]),'error')
      raise 0
    s.outfile = path+':\\smartSIS\\packed\\'+s.basename+'_v'+str(vers[0])+'_'+str(vers[1])+'_'+str(vers[2])+'.sis'
    try:
      s.uid3 = long(strings[3],16)
    except:
      notif(ru(lang[14-1]),'error')
      raise 0
    s.srcdisk=str(strings[4]).lower()
    if not s.srcdisk in ('!','e','c'):
      s.srcdisk='!'
    s.vendor=strings[5]
    s.icon=strings[6]
    s.iscaps=str(strings[7]).lower()
    s.autostart=strings[8]
    if s.autostart=='autostart':
      s.autostart=1
      s.autostartflag=lang[15-1]
    elif s.autostart=='noautostart':
      s.autostart=0
      s.autostartflag=lang[16-1]
    else:
      notif(ru(lang[17-1]),'error')
      raise 0
    if s.iscaps=='caps':
      s.caps="PowerMgmt+ReadDeviceData+WriteDeviceData+TrustedUI+ProtServ+SwEvent+LocalServices+ReadUserData+WriteUserData+Location+SurroundingsDD+UserEnvironment+NetworkServices"
    elif s.iscaps=='nocaps':
      s.caps='ReadUserData+WriteUserData+UserEnvironment+NetworkServices+LocalServices'
    else:
      notif(ru(lang[18-1]),'error')
      raise 0
          
    s.textfile=strings[9]
    if s.textfile.lower() == 'none':
      s.textfile='None'
    s.language=strings[10].lower().upper()
    try:
      langgg=s.symbianutil.langidtonum[s.language]
      del langgg
    except:
      notif(ru(lang[40-1]),'error')
      raise 0
      
    s.autorun=strings[11].lower()
    if s.autorun == 'autorun':
      s.autorun=1
      s.autorunflag=lang[15-1]
    elif s.autorun == 'noautorun':
      s.autorun=0
      s.autorunflag=lang[16-1]
    else:
      notif(ru(lang[22-1]),'error')
      raise 0
      
    s.hidden=strings[12].lower()
    if s.hidden == 'hidden':
      s.hidden=1
      s.hiddenflag=lang[15-1]
    elif s.hidden == 'nohidden':
      s.hidden=0
      s.hiddenflag=lang[16-1]
    else:
      notif(ru(lang[22-1]),'error')
      raise 0
      
    s.srcfiles=[]
    s.src_embsis=[]
    s.srcdir=''
    s.notECI=0
    s.srcdirI=s.srcdirC=s.srcdirE=''
    
    
    s.capmask = s.symbianutil.capstringtomask(s.caps)
    s.caps = s.symbianutil.capmasktostring(s.capmask, True)
    
    src = s.directory
    if not os.path.isdir(src):
      notif(ru(lang[41-1]+str(src)+lang[42-1]),'error')
      raise 0
        
    if s.directory:
      if os.path.isdir(src+'\\E'):
          srcE = os.path.split(src+'\\E' + os.sep)[0]
          s.srcdirE = srcE
          prefixlen = len(s.srcdirE) + len(os.sep)
          def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if path.endswith('.sis') or path.endswith('.sisx'):
                  s.src_embsis.append(path)
                elif not os.path.isdir(path):
                  arg.append('E:\\'+path[prefixlen:])
          os.path.walk(s.srcdirE, getfiles, s.srcfiles)
      if os.path.isdir(src+'\\C'):
          srcC = os.path.split(src+'\\C' + os.sep)[0]
          s.srcdirC = srcC
          prefixlen = len(s.srcdirC) + len(os.sep)
          def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if path.endswith('.sis') or path.endswith('.sisx'):
                  s.src_embsis.append(path)
                elif not os.path.isdir(path):
                  arg.append('C:\\'+path[prefixlen:])
          os.path.walk(s.srcdirC, getfiles, s.srcfiles)
          
      if os.path.isdir(src+'\\!'):
          srcI = os.path.split(src +'\\!'+ os.sep)[0]
          s.srcdirI = srcI
          prefixlen = len(s.srcdirI) + len(os.sep)
          def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if path.endswith('.sis') or path.endswith('.sisx'):
                  s.src_embsis.append(path)
                elif not os.path.isdir(path):
                  arg.append('!:\\'+path[prefixlen:])
          os.path.walk(s.srcdirI, getfiles, s.srcfiles)

      if not os.path.isdir(src+'\\!') and not os.path.isdir(src+'\\E') and not os.path.isdir(src+'\\C'):
          s.notECI=1
          src = os.path.split(src + os.sep)[0]
          s.srcdir = src
          prefixlen = len(s.srcdir) + len(os.sep)
          def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if path.endswith('.sis') or path.endswith('.sisx'):
                  s.src_embsis.append(path)
                elif not os.path.isdir(path):
                  arg.append('!:\\'+path[prefixlen:])
          os.path.walk(s.srcdir, getfiles, s.srcfiles)

        
        
    s.appname = s.basename

    s.lang = (s.language).split(",")
    s.numlang = len(s.lang)

    if s.icon <> 'default':
        f = file(s.icon, "rb")
        s.icondata = f.read(s.MAXICONFILESIZE + 1)
        f.close()

        if len(s.icondata) > s.MAXICONFILESIZE:
            notif(ru(lang[20-1]),'error')
            raise 0
    else:
        s.icondata = s.zlib.decompress(s.defaulticondata.decode("base-64"))


    s.texts = []
    cop=''
    for nnnn in [80,97,99,107,101,100,32,105,110,32,60,83,109,97,114,116,83,73,83,32,98,121,32,115,109,97,114,116,52,110,62]:
      cop+=unichr(nnnn)
    if s.textfile  <>  'None':
      s.texts = s._readtextfiles(s.textfile, s.lang)
      s.texts.append(str(cop).decode("UTF-8").encode("UTF-16LE"))
      s.textfile=s.textfile+' '+s.coding
    else:
      s.texts.append(str(cop).decode("UTF-8").encode("UTF-16LE"))
    if s.texts==[0]:
       raise 0
    s.shortcaption = s.basename
    s.caption = s.basename
    if len(s.shortcaption) == 0:
        s.shortcaption = [s.basename]*s.numlang
    else:
        s.shortcaption = s.shortcaption.split(",")
    if len(s.caption) == 0:

        s.caption = s.shortcaption
    else:
        s.caption = s.caption.split(",")
        

    if len(s.shortcaption) <> s.numlang or len(s.caption) <> s.numlang:
        notif(ru(lang[21-1]),'error')
        raise 0
    return 1

  def packinfo(s):
    try:
      if not s._readpkg(): return 0
      ss.PKGPY2SIS=s.pkgfile
    except:
      notif(ru(lang[43-1]+('%s'%s.pkgfile)),'error')
      return 0
    body.color=0xff0000
    body.set(ru(lang[23-1]+str(s.pkgfile)+s.codingpkg+'\n'))
    body.color=0
    printoutn(ru(lang[24-1]))
    body.color=0x33c533
    printout(ru(str(s.pyfile)))
    body.color=0
    printoutn(ru(lang[183-1]))
    body.color=0x33c533
    printout(ru(str(s.srcdisk)))
    body.color=0
    if len(s.srcfiles) <> 0:
      printout(ru(lang[25-1]))
      body.color=0x0000ff
      for i in s.srcfiles:
        printout(ru('    '+str(i)))
    else:
      printoutn(ru(lang[25-1]))
      body.color=0x33c533
      printout(ru(lang[26-1]))
    body.color=0
    if s.src_embsis:
      printout(ru(lang[184-1]))
      body.color=0x0000ff
      for i in s.src_embsis:
        printout(ru('    '+str(os.path.split(i)[1])))
    body.color=0
    printoutn(ru(lang[27-1]))
    body.color=0x33c533
    printout(ru(str(s.basename)))
    body.color=0
    printoutn(ru(lang[31-1]))
    body.color=0x33c533
    printout(ru(str(s.version)))
    body.color=0
    printoutn(ru(lang[28-1]))
    body.color=0x33c533
    printout(ru('0x%08x' % s.uid3))
    body.color=0
    printoutn(ru(lang[32-1]))
    body.color=0x33c533
    printout(ru(str(s.vendor)))
    body.color=0
    printoutn(ru(lang[29-1]))
    body.color=0x33c533
    printout(ru(str(s.icon)))
    body.color=0
    printoutn(ru(lang[30-1]))
    body.color=0x33c533
    printout(ru(s.autostartflag))
    body.color=0
    
    printoutn(ru(lang[185-1]))
    body.color=0x33c533
    printout(ru(s.autorunflag))
    body.color=0
    
    printoutn(ru(lang[186-1]))
    body.color=0x33c533
    printout(ru(s.hiddenflag))
    body.color=0
    
    printoutn(ru(lang[33-1]))
    body.color=0x33c533
    printout(ru(str(s.textfile)))
    body.color=0
    printoutn(ru(lang[155-1]))
    body.color=0x33c533
    printout(ru(str(s.language)))
    body.color=0
    appuifw.app.exit_key_handler = back
    menu(5)
    
  def packit(s):
    scrkill()
    e32.ao_yield()
    timer=tim.Timer()
    s.prss=s.progressbar.ProgressBarTW(progressfont)
    s.autosign=ss.AUTOSIGN
    progress=13
    if s.autosign:
      progress+=1
    if s.src_embsis:
      progress+=len(s.src_embsis)
    s.prss.begin_progress(progress,1)
    i=0
    s.prss.do_progress(i,ru(lang[149-1]))
    s.version = s._tovers(s.version)
    sw = s.sisfile.SimpleSISWriter(s.lang, s.caption, s.uid3, s.version, s.vendor, [s.vendor] * s.numlang)
    if s.textfile <> 'None':
      sw.addfile(s.texts[0], operation = s.sisfield.EOpText)
      sw.addfile(s.texts[1], operation = s.sisfield.EOpText)
    else:
      sw.addfile(s.texts[0], operation = s.sisfield.EOpText)
    
    
    i+=1
    rsctarget = unicode(s.srcdisk+":\\resource\\apps\\%s_0x%08x.rsc" % (s.appname, s.uid3))
    s.prss.do_progress(i,os.path.split(rsctarget)[1])
    string = s.zlib.decompress(s.pythons60rscdata.decode("base-64"))
    sw.addfile(string, rsctarget)
    del string


    i+=1
    regtarget = unicode(s.srcdisk+":\\private\\10003a3f\\import\\apps\\%s_0x%08x_reg.rsc" % (s.appname, s.uid3))
    s.prss.do_progress(i,os.path.split(regtarget)[1])
    exename = u"%s_0x%08x" % (s.appname, s.uid3)
    locpath = u"\\resource\\apps\\%s_0x%08x_loc" % (s.appname, s.uid3)
    rw = s.rscfile.RSCWriter(uid2 = 0x101f8021, uid3 = s.uid3)

    e32.ao_yield()
    i+=1
    s.prss.do_progress(i,os.path.split(locpath)[1])
    res = s.rscfile.Resource(["LONG", "LLINK", "LTEXT", "LONG", "LTEXT", "LONG",
                            "BYTE", "BYTE", "BYTE", "BYTE", "LTEXT", "BYTE",
                            "WORD", "WORD", "WORD", "LLINK"],
                           0, 0, exename, 0, locpath, 1,
                           s.hidden, 0, 0, 0, "", 0,
                           0, 0, 0, 0)
    rw.addresource(res)
    string = rw.tostring()
    del rw
    sw.addfile(string, regtarget)
    del string
    exetarget = unicode(s.srcdisk+":\\sys\\bin\\%s_0x%08x.exe" % (s.appname, s.uid3))
    if s.autostart:
        autotarget = unicode(s.srcdisk+":\\private\\101f875a\\import\\[%08x].rsc" % s.uid3)
        rw = s.rscfile.RSCWriter(uid2 = 0, offset = "    ")
        res = s.rscfile.Resource(["BYTE", "LTEXT", "WORD",
                                "LONG", "BYTE", "BYTE"],
                               0, exetarget, 0, 0, 0, 0)
        rw.addresource(res)
        string = rw.tostring()
        del rw
        sw.addfile(string, autotarget)
        del string

    e32.ao_yield()
    i+=1
    iconpath = "\\resource\\apps\\%s_0x%08x_aif.mif" % (s.appname, s.uid3)
    for n in xrange(s.numlang):
        loctarget = unicode(s.srcdisk+":\\resource\\apps\\%s_0x%08x_loc.r%02d" % (s.appname, s.uid3, s.symbianutil.langidtonum[s.lang[n]]))
        s.prss.do_progress(i,os.path.split(loctarget)[1])
        rw = s.rscfile.RSCWriter(uid2 = 0, offset = "    ")
        res = s.rscfile.Resource(["LONG", "LLINK", "LTEXT",
                                "LONG", "LLINK", "LTEXT",
                                "WORD", "LTEXT", "WORD", "LTEXT"],
                               0, 0, s.shortcaption[n],
                               0, 0, s.caption[n],
                               1, iconpath, 0, "")
        rw.addresource(res)
        string = rw.tostring()
        del rw
        sw.addfile(string, loctarget)
        del string


    e32.ao_yield()
    i+=1
    icontarget = unicode(s.srcdisk+":\\resource\\apps\\%s_0x%08x_aif.mif" % (s.appname, s.uid3))
    s.prss.do_progress(i,os.path.split(icontarget)[1])
    if s.icon.endswith('.mif'):
      sw.addfile(s.icondata, icontarget)
    else:
      mw = s.miffile.MIFWriter()
      mw.addfile(s.icondata)
      string = mw.tostring()
      sw.addfile(string, icontarget)
      del mw
      del string
    del s.icondata
    
    f = file(s.pyfile, "rb")
    string = f.read()
    f.close()

    i+=1
    e32.ao_yield()
    target = "default.py"
    s.prss.do_progress(i,ru(target))
    sw.addfile(string, s.srcdisk+":\\private\\%08x\\%s" % (s.uid3, target))
    del string
    i+=1
    s.prss.do_progress(i,ru(lang[150-1]))
    if s.directory <> '':
        for srcfile in s.srcfiles:
            if srcfile.startswith('C:\\'):
              f = file(os.path.join(s.srcdirC, srcfile[3:]), "rb")
            elif srcfile.startswith('E:\\'):
              f = file(os.path.join(s.srcdirE, srcfile[3:]), "rb")
            elif srcfile.startswith('!:\\'):
              if s.notECI==0:
                f = file(os.path.join(s.srcdirI, srcfile[3:]), "rb")
              else:
                f = file(os.path.join(s.srcdir, srcfile[3:]), "rb")
                
            string = f.read()
            f.close()
            
            if len(string) > s.MAXOTHERFILESIZE:
                notif(ru(lang[34-1]+str(srcfile)+lang[35-1]),'error')
                return 0
            
            target = srcfile.replace(os.sep, "\\")
            try:
              sw.addfile(string, "%s" % target)
            except:
              notif(ru(lang[71-1]),'error')
              s.prss.end_progress()
              del string
              raise 0
            del string

    i+=1
    s.prss.do_progress(i,ru(lang[151-1]))
    e32.ao_yield()
    sw.addtargetdevice(0x101f7961L, (0, 0, 0), None,
                       ["Series60ProductID"] * s.numlang)

    i+=1
    s.prss.do_progress(i,ru(lang[152-1]))
    e32.ao_yield()
    sw.adddependency(0x2000b1a0L, (1, 4, 0), None,
                     ["Python for S60"] * s.numlang)

    sw.addcertificate('','','')

    i+=1
    exetarget = unicode(s.srcdisk+":\\sys\\bin\\%s_0x%08x.exe" % (s.appname, s.uid3))
    s.prss.do_progress(i,os.path.split(exetarget)[1])
    string = s.execstubdata.decode("base-64")
    string = s.symbianutil.e32imagecrc(string, s.uid3, s.uid3, None, s.capmask)
    if s.autorun:
      sw.addfile(string, exetarget, None, capabilities = s.capmask,operation = s.sisfield.EOpRun,
                     options = s.sisfield.EInstFileRunOptionInstall)
    else:
      sw.addfile(string, exetarget, None, capabilities = s.capmask)
    del string
    
    i+=1
    s.prss.do_progress(i,ru(lang[153-1]))
    sw.tofile(ur(ru(str(s.outfile))))
    del sw
    i+=1
    
    if s.src_embsis:
      insis = []
      s.src_embsis.insert(0,ur(ru(str(s.outfile))))
      for n in xrange(len(s.src_embsis)):
          s.prss.do_progress(i,ru(str(os.path.split(s.src_embsis[n])[1])))
          i+=1
          f = file(s.src_embsis[n], "rb")
          instring = f.read()
          f.close()
          if n == 0:
            uids = instring[:16]
          sf, rlen = s.sisfield.SISField(instring[16:], False)
          del instring
          if len(sf.Data.DataUnits) > 1:
              notif(ru(("%s "%s.src_embsis[n])+lang[187-1]),'info')
              continue
          insis.append(sf)
      ctrlfield = insis[0].Controller.Data
      didxfield = ctrlfield.DataIndex
      ctrlfield.DataIndex = None
      if len(ctrlfield.getsignatures()) > 0:
          ctrlfield.setsignatures([])

      for n in xrange(1,len(insis)):
          insis[0].Data.DataUnits.append(insis[n].Data.DataUnits[0])
          insis[n].Controller.Data.DataIndex.DataIndex = n
          ctrlfield.InstallBlock.EmbeddedSISFiles.append(insis[n].Controller.Data)
      string = ctrlfield.tostring()
      string = s.sisfield.stripheaderandpadding(string)
      ctrlfield.DataIndex = didxfield
      outstring = insis[0].tostring()

      f = file(ur(ru(str(s.outfile))), "wb")
      f.write(uids)
      f.write(outstring)
      f.close()
    
    if s.autosign:
      s.prss.do_progress(i,ru(lang[106-1]+'...'))
      e32.ao_yield()
      i+=1
      try:
        global signer
        signer=SignSIS()
        if s.iscaps == 'caps':
          signer.sign(s.outfile)
        elif s.iscaps == 'nocaps':
          signer.selfsign(s.outfile)
      except:
        notif(ru(lang[77-1]),'info')
    s.prss.do_progress(i,ru(lang[154-1]))
    s.prss.end_progress()
    body.color=0
    body.focus=False
    body.set(ru(lang[36-1]+str(s.outfile)+'\n'+lang[146]+timer.endtimer()))
    menu(0)
  
def dopy2sisref():
  global py2sispacker
  py2sispacker=Py2SIS()
  py2sispacker.packinfo()
  
def dopy2sis():
  py2sispacker.packit()
  alert()  
  notif(ru(lang[73-1]),'conf')
  
  
class PackSIS:
  def __init__(s):
    import struct
    import zlib
    import sisfile
    import sisfield
    import symbianutil
    import progressbar
    import powlite_fm
    s.struct,s.zlib,s.sisfile,s.sisfield,s.symbianutil,s.progressbar,s.powlite_fm=struct,zlib,sisfile,sisfield,symbianutil,progressbar,powlite_fm
    s.directory=s.basename=s.outfile=s.version=s.caption=s.vendor=s.basename=s.srcdirI=s.srcdirE=s.srcdirC=s.caps=s.insttype=s.language=''
    s.codingpkg,s.coding='',''
    s.pkgfile=ur(ss.PKGPACK)
    s.puid=s.numlang=0
    s.srcfiles=s.lang=[]
    s.src_embsis=[]
    s.notECI=0
  def _tovers(s,version):
    if "." in version:
        parts = [int(n) for n in version.split(".")]
    else:
        parts = [int(n) for n in version.split(",")]
    parts.extend([0, 0])

    return parts[0:3]
  def _gete32imagecaps(s,string):
    if not s.symbianutil.ise32image(string):
        return None
    return s.struct.unpack("<Q", string[136:144])[0]
    
  def _readtextfiles(s, pattern, languages):
    s.coding=''
    if "%" not in pattern:
        filenames = [pattern]
    else:
        filenames = []
        for langid in languages:
            langnum  = symbianutil.langidtonum[langid]
            langname = symbianutil.langnumtoname[langnum]
            filename = pattern
            filename = filename.replace("%n", "%02d" % langnum)
            filename = filename.replace("%c", langid.lower())
            filename = filename.replace("%C", langid.upper())
            filename = filename.replace("%l", langname.lower())
            filename = filename.replace("%L", langname)
            filename = filename.replace("%%", "%")

            filenames.append(filename)
    texts = []

    for filename in filenames:
        f = file(filename, 'r')
        text = f.read(1024 + 1)
        f.close()
        if len(text) > 1024:
            notif(ru(lang[10-1]+str(filename)+lang[11-1]),'error')
            raise 0
        if text.startswith('\xff\xfe'):
          texts.append(text.decode('UTF-16LE').encode('UTF-16LE'))
          s.coding='(Unicode)'
        else:
          try:
            texts.append(text.decode('UTF-8').encode('UTF-16'))
            s.coding='(UTF-8)'
          except:
            try:
              texts.append(text.decode('cp1251').encode('UTF-16'))
              s.coding='(Win 1251)'
            except:
              notif(ru(str(filename)+lang[12-1]),'error')
              raise 0
    
    return texts
  def choose_pkg(s):
    pkgfile=s.pkgfile
    fm=s.powlite_fm.manager()
    s.pkgfile=fm.AskUser(ss.PATH+':\\smartSIS\\PKGs',ext=['.pkg'])
    if s.pkgfile:
      s.pkgfile=ur(s.pkgfile)
    else:
      s.pkgfile=pkgfile
    s.packinfo()
  def _readpkg(s):
    body.focus=True
    path=ss.PATH
    checkdir(path+':\\smartSIS\\packed')
    if ss.PACKMODE <> 'master':
      if not os.path.exists(s.pkgfile):
        notif(ru(('%s '%s.pkgfile)+lang[138-1]),'error')
        fm=s.powlite_fm.manager()
        pkgfile=fm.AskUser(ss.PATH+':\\smartSIS\\PKGs',ext=['.pkg'])
        if pkgfile: s.pkgfile=ur(pkgfile)
        else: return 0
      f=file(s.pkgfile,'r')
      strings=f.read()
      f.close()
      s.rawcoding=''
      if strings.startswith('\xff\xfe'):
        strings=strings.decode('UTF-16LE')
        strings=strings[1:]
        s.codingpkg='(Unicode)'
        s.rawcoding='UTF-16LE'
      else:
        try:
          strings=strings.decode('UTF-8')
          s.codingpkg='(UTF-8)'
          s.rawcoding='UTF-8'
        except:
          try:
            strings=strings.decode('cp1251')
            s.codingpkg='(Win 1251)'
            s.rawcoding='cp1251'
          except:
            notif(ru(str(s.pkgfile)+lang[12-1]),'error')
            raise 0
      s.directory=ur(strings.split('\r\n')[0])
      s.textfile= ur(strings.split('\r\n')[6])
      if s.textfile.lower() == 'none': s.textfile='None'
      strings=strings.split('\r\n')
      #s.directory=strings[0]
      s.basename=strings[1]
      s.version = str(strings[2])
      vers = s._tovers(s.version)
      s.outfile = path+':\\smartSIS\\packed\\'+s.basename+'_v'+str(vers[0])+'_'+str(vers[1])+'_'+str(vers[2])+'.sis'
      try:
        s.puid = long(str(strings[3]),16)
      except:
        raise 0
      s.vendor=strings[4]
      s.insttype=str(strings[5]).lower()
      if s.insttype in ['sa','sp','pu']:
        if s.insttype=='sa':
          s.sisfield.insttype=0
        elif s.insttype=='sp':
          s.sisfield.insttype=1
        elif s.insttype=='pu':
          s.sisfield.insttype=2
      else:
        notif(ru(lang[39-1]),'error')
        raise 0
      
      s.language=str(strings[7].lower().upper())
      try:
        langgg=s.symbianutil.langidtonum[s.language]
        del langgg
      except:
        notif(ru(lang[40-1]),'error')
        raise 0
    else:
      vers = s._tovers(s.version)
      s.outfile = path+':\\smartSIS\\packed\\'+s.basename+'_v'+str(vers[0])+'_'+str(vers[1])+'_'+str(vers[2])+'.sis'
      
    s.srcfiles=[]
    s.src_embsis=[]
    s.notECI=0
    s.srcdirI=s.srcdirC=s.srcdirE=''

    src = s.directory
    if not os.path.isdir(src):
      notif(ru(lang[41-1]+str(src)+lang[42-1]),'error')
      raise 0

    if os.path.isdir(src+'\\E'):
        srcE = os.path.split(src+'\\E' + os.sep)[0]
        s.srcdirE = srcE
        prefixlen = len(s.srcdirE) + len(os.sep)
        def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if path.endswith('.sis') or path.endswith('.sisx'):
                  s.src_embsis.append(path)
                elif not os.path.isdir(path):
                  arg.append('E:\\'+path[prefixlen:])
        os.path.walk(s.srcdirE, getfiles, s.srcfiles)
    if os.path.isdir(src+'\\C'):
        srcC = os.path.split(src+'\\C' + os.sep)[0]
        s.srcdirC = srcC
        prefixlen = len(s.srcdirC) + len(os.sep)
        def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if path.endswith('.sis') or path.endswith('.sisx'):
                  s.src_embsis.append(path)
                elif not os.path.isdir(path):
                  arg.append('C:\\'+path[prefixlen:])
        os.path.walk(s.srcdirC, getfiles, s.srcfiles)
    if os.path.isdir(src+'\\!'):
        srcI = os.path.split(src +'\\!'+ os.sep)[0]
        s.srcdirI = srcI
        prefixlen = len(s.srcdirI) + len(os.sep)
        def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if path.endswith('.sis') or path.endswith('.sisx'):
                  s.src_embsis.append(path)
                elif not os.path.isdir(path):
                  arg.append('!:\\'+path[prefixlen:])
        os.path.walk(s.srcdirI, getfiles, s.srcfiles)

    if not os.path.isdir(src+'\\!') and not os.path.isdir(src+'\\E') and not os.path.isdir(src+'\\C'):
        s.notECI=1
        src = os.path.split(src + os.sep)[0]
        s.srcdir = src
        prefixlen = len(s.srcdir) + len(os.sep)
        def getfiles(arg, dirname, names):
            for name in names:
                path = os.path.join(dirname, name)
                if not os.path.isdir(path):
                    arg.append('!:\\'+path[prefixlen:])
        os.path.walk(s.srcdir, getfiles, s.srcfiles)


    s.lang=[s.language]
    s.numlang = len(s.lang)
    s.caption = [s.basename] * s.numlang

    s.texts = []
    cop=''
    for nnnn in [80,97,99,107,101,100,32,105,110,32,60,83,109,97,114,116,83,73,83,32,98,121,32,115,109,97,114,116,52,110,62]:
      cop+=unichr(nnnn)
    if s.textfile  <>  'None':
      s.texts = s._readtextfiles(s.textfile, s.lang)
      s.texts.append(str(cop).decode("UTF-8").encode("UTF-16LE"))
      s.textfile=s.textfile
    else:
      s.texts.append(str(cop).decode("UTF-8").encode("UTF-16LE"))
    if s.texts==[0]:
       raise 0

    s.caps  = ""
    capmask = s.symbianutil.capstringtomask(s.caps)
    s.caps  = s.symbianutil.capmasktostring(capmask, True)
    return 1
    
  def packinfo(s):
    #try:#################################################################
    if not s._readpkg(): return 0
    ss.PKGPACK=s.pkgfile
    #except:
    #  notif(ru(lang[43-1]+('%s'%s.pkgfile)),'error')
    #  return 0
    body.color=0xff0000
    pmode=ss.PACKMODE
    if pmode=='sispkg':
      body.set(ru(lang[44-1]+str(s.pkgfile)+s.codingpkg+'\n'))
    else:
      body.set(ru(lang[45-1]+'\n'))
    body.color=0
    printout(ru(lang[46-1]))
    body.color=0x0000ff
    for i in s.srcfiles:
      printout(ru('    '+str(i)))
    body.color=0
    if s.src_embsis:
      printout(ru(lang[184-1]))
      body.color=0x0000ff
      for i in s.src_embsis:
        printout(ru('    '+str(os.path.split(i)[1])))
    body.color=0
    printoutn(ru(lang[47-1]))
    body.color=0x33c533
    printout(ru(str(s.basename)))
    body.color=0
    printoutn(ru(lang[50-1]))
    body.color=0x33c533
    printout(ru(str(s.version)))
    body.color=0
    printoutn(ru(lang[49-1]))
    body.color=0x33c533
    printout(ru('0x%08x'% s.puid))
    body.color=0
    printoutn(ru(lang[51-1]))
    body.color=0x33c533
    printout(ru(str(s.vendor)))
    body.color=0
    printoutn(ru(lang[48-1]))
    body.color=0x33c533
    printout(ru(str(s.insttype).upper()))
    body.color=0
    printoutn(ru(lang[52-1]))
    body.color=0x33c533
    printout(ru(s.textfile+' '+s.coding))
    body.color=0
    printoutn(ru(lang[155-1]))
    body.color=0x33c533
    printout(ru(s.language))
    body.color=0
    appuifw.app.exit_key_handler = back
    if pmode == 'sispkg':
      menu(3)
    else:
      appuifw.app.menu=[(ru(lang[53-1]),dopack),(ru(lang[54-1]),s.step8)]
    
  def action(s,act):
    if act==1:
      fm=s.powlite_fm.manager()
      s.dir=fm.AskUser(find='dir')
      if s.dir <> None:
        s.directory=ur(s.dir)
      else:
        pass
      s.rawpkg[0]=s.directory
      s.step1()
    elif act==2:
      s.bn=appuifw.query(ru(lang[55-1]),'text',ru(s.basename))
      if s.bn <> None:
        s.basename=str(s.bn)
      else:
        pass
      s.rawpkg[1]=s.basename
      s.step2()
    elif act==3:
      s.ver=appuifw.query(ru(lang[56-1]),'text',ru(s.version))
      if s.ver <> None:
        s.version=str(s.ver)
      else:
        pass
      s.rawpkg[2]=s.version
      s.step3()
    elif act==4:
      s.pd=appuifw.query(ru(lang[57-1]),'text',ru('0x%08x'% s.puid))
      if s.pd <> None:
        try: s.puid=long(s.pd,16)
        except: notif(ru(lang[194-1]),'error')
      else:
        pass
      s.rawpkg[3]=s.puid
      s.step4()
    elif act==5:
      s.vd=appuifw.query(ru(lang[58-1]),'text',ru(s.vendor))
      if s.vd <> None:
        s.vendor=str(s.vd)
      else:
        pass
      s.rawpkg[4]=s.vendor
      s.step5()
    elif act==6:
      fm=s.powlite_fm.manager()
      s.tf=fm.AskUser(ext=['.txt'])
      if s.tf <> None:
        s.textfile=ur(s.tf)
      else:
        pass
      s.rawpkg[6]=s.textfile
      s.step6()
    elif act==7:
      ind=appuifw.selection_list([u'SA(Standart App)',u'SP(Augmentation)',u'PU(Partial Upgrade)'])
      if ind <> None:
        if ind==0:
          s.insttype='sa'
          s.sisfield.insttype=0
        if ind==1:
          s.insttype='sp'
          s.sisfield.insttype=1
        if ind==2:
          s.insttype='pu'
          s.sisfield.insttype=2
      else:
        pass
      s.rawpkg[5]=s.insttype
      s.step7()
    elif act==8:
      s.lg=appuifw.query(ru(lang[58-1]),'text',ru(s.language))
      if s.lg <> None:
        try:
          langgg=s.symbianutil.langidtonum[s.lg.upper()]
          del langgg
          s.language=str(s.lg).upper()
        except:
          notif(ru(lang[40-1]),'error')
      s.rawpkg[7]=s.language
      s.step8()
      
      
  def step1(s):
    body.set(ru(lang[59-1]+'\n'+lang[123-1]+'\n\n'+lang[124-1]+str(s.directory)))
    s.rawpkg[0]=s.directory
    appuifw.app.menu=[(ru(lang[60-1]),lambda: s.action(1)),(ru(lang[62-1]),s.step2),(ru(lang[63-1]),s.startmaster)]
  
  def step2(s):
    body.set(ru(lang[64-1]+'\n'+lang[125-1]+'\n\n'+lang[126-1]+str(s.basename)))
    s.rawpkg[1]=s.basename
    appuifw.app.menu=[(ru(lang[61-1]),lambda: s.action(2)),(ru(lang[62-1]),s.step3),(ru(lang[63-1]),s.step1)]
    
  def step3(s):
    body.set(ru(lang[65-1]+'\n'+lang[127-1]+'\n\n'+lang[128-1]+str(s.version)))
    s.rawpkg[2]=s.version
    appuifw.app.menu=[(ru(lang[60-1]),lambda: s.action(3)),(ru(lang[62-1]),s.step4),(ru(lang[63-1]),s.step2)]
  
  def step4(s):
    body.set(ru(lang[66-1]+'\n'+lang[129-1]+'\n\n'+lang[130-1]+'0x%08x'% s.puid))
    s.rawpkg[3]='0x%08x'% s.puid
    appuifw.app.menu=[(ru(lang[61-1]),lambda: s.action(4)),(ru(lang[62-1]),s.step5),(ru(lang[63-1]),s.step3)]
  
  def step5(s):
    body.set(ru(lang[67-1]+'\n'+lang[131-1]+'\n\n'+lang[132-1]+str(s.vendor)))
    s.rawpkg[4]=s.vendor
    appuifw.app.menu=[(ru(lang[61-1]),lambda: s.action(5)),(ru(lang[62-1]),s.step6),(ru(lang[63-1]),s.step4)]
  
  def step6(s):
    body.set(ru(lang[68-1]+'\n'+lang[133-1]+'\n\n'+lang[134-1]+str(s.textfile)))
    s.rawpkg[6]=s.textfile
    appuifw.app.menu=[(ru(lang[60-1]),lambda: s.action(6)),(ru(lang[62-1]),s.step7),(ru(lang[63-1]),s.step5)]
  
  def step7(s):
    body.set(ru(lang[69-1]+'\n'+lang[135-1]+'\n\n'+lang[136-1]+str(s.insttype).upper()))
    s.rawpkg[5]=str(s.insttype)
    appuifw.app.menu=[(ru(lang[61-1]),lambda: s.action(7)),(ru(lang[62-1]),s.step8),(ru(lang[63-1]),s.step6)]
    
  def step8(s):
    body.set(ru(lang[156-1]+'\n'+lang[157-1]+'\n\n'+lang[158-1]+str(s.language).upper()))
    s.rawpkg[7]=s.language.upper()
    appuifw.app.menu=[(ru(lang[61-1]),lambda: s.action(8)),(ru(lang[62-1]),s.step9),(ru(lang[63-1]),s.step7)]
    
  
  def step9(s):
    s.packinfo()
    pkg=''
    for i in s.rawpkg:
      pkg+=i+'\r\n'
    if pkg.endswith('\r\n'): pkg=pkg[:-2]
    f=file(ss.PATH+':\\SmartSIS\\PKGs\\sis.pkg','w')
    f.write(ur(pkg))
    f.close()
    
  
  def startmaster(s):
    path=ss.PATH
    if not os.path.exists(path+':\\SmartSIS\\PKGs\\sis.pkg'):
      f=file(path+':\\SmartSIS\\PKGs\\sis.pkg','w')
      f.write(u'C:\\SmartSIS\\Simpledir\r\nMyprogram\r\n1.0.0\r\n0xf0000001\r\nsmart4n\r\nsa\r\nC:\\SmartSIS\\text.txt\r\nEN')
      f.close()
    f=file(path+':\\SmartSIS\\PKGs\\sis.pkg','r')
    strings=f.read()
    f.close()
    if strings.startswith('\xff\xfe'):
      strings=strings.decode('UTF-16LE')
      strings=strings[1:]
      s.codingpkg='(Unicode)'
    else:
      try:
        strings=strings.decode('UTF-8')
        s.codingpkg='(UTF-8)'
      except:
        try:
          strings=strings.decode('cp1251')
          s.codingpkg='(Win 1251)'
        except:
          notif(ru(str(filename)+lang[12-1]),'error')
          raise 0
    strings=strings.split('\r\n')
    s.directory=s.dir=str(strings[0])
    s.basename=s.bn=str(strings[1])
    s.version=s.ver=str(strings[2])
    try:
      s.puid=s.pd=long(str(strings[3]),16)
    except:
      s.puid=s.pd=long('0xFCBA17E3',16)
    s.vendor=s.vd=str(strings[4])
    s.insttype=str(strings[5])
    s.textfile=s.tf=str(strings[6])
    s.language=s.lg=str(strings[7]).upper()
    s.rawpkg=['','','','','','','','']
    body.color=0
    appuifw.app.exit_key_handler = back
    body.set(ru(lang[70-1]))
    appuifw.app.menu=[(ru(lang[62-1]),s.step1),(ru(lang[63-1]),back)]
    
  def packit(s):
    scrkill()
    timer=tim.Timer()
    e32.ao_yield()
    s.prss=s.progressbar.ProgressBarTW(progressfont)
    s.autosign=ss.AUTOSIGN
    progress=len(s.srcfiles)+3
    prs=0
    if s.autosign:
      progress+=1
    if s.src_embsis:
      progress+=len(s.src_embsis)+1
    s.prss.begin_progress(progress,1)
    s.prss.do_progress(prs,ru(lang[149-1]))
    prs+=1
    s.version = s._tovers(s.version)
    sw = s.sisfile.SimpleSISWriter(s.lang, s.caption, s.puid, s.version, s.vendor, [s.vendor] * s.numlang)
    if s.textfile <> 'None':
      sw.addfile(s.texts[0], operation = s.sisfield.EOpText)
      sw.addfile(s.texts[1], operation = s.sisfield.EOpText)
    else:
      sw.addfile(s.texts[0], operation = s.sisfield.EOpText)

    sysbinprefix = os.path.join("sys", "bin", "")
    e32.ao_yield()
    for srcfile in s.srcfiles:
        s.prss.do_progress(prs,ru(str(os.path.split(srcfile)[1])))
        prs+=1
        e32.reset_inactivity()
        e32.ao_yield()
        if srcfile.startswith('C:\\'):
          f = file(os.path.join(s.srcdirC, srcfile[3:]), "rb")
        elif srcfile.startswith('E:\\'):
          f = file(os.path.join(s.srcdirE, srcfile[3:]), "rb")
        elif srcfile.startswith('!:\\'):
          if s.notECI==0:
            f = file(os.path.join(s.srcdirI, srcfile[3:]), "rb")
          else:
            f = file(os.path.join(s.srcdir, srcfile[3:]), "rb")
        string = f.read()
        f.close()
        s.caps = s._gete32imagecaps(string)
        target = srcfile.replace(os.sep, "\\")
        try:
          sw.addfile(string, "%s" % target, capabilities = s.caps)
        except:
          notif(ru(lang[71-1]),'error')
          s.prss.end_progress()
          del string
          raise 0
        del string        

    s.prss.do_progress(prs,ru(lang[151-1]))
    e32.ao_yield()
    prs+=1
    sw.addtargetdevice(0x101f7961L, (0, 0, 0), None, ["Series60ProductID"] * s.numlang)
    pr=cet=pas=''
    sw.addcertificate(pr, cet, pas)
    s.prss.do_progress(prs,ru(lang[153-1]))
    e32.ao_yield()
    prs+=1
    sw.tofile(ur(ru(str(s.outfile))))
    del sw

    if s.src_embsis:
      insis = []
      s.src_embsis.insert(0,ur(ru(str(s.outfile))))
      for n in xrange(len(s.src_embsis)):
          s.prss.do_progress(prs,ru(str(os.path.split(s.src_embsis[n])[1])))
          prs+=1
          f = file(s.src_embsis[n], "rb")
          instring = f.read()
          f.close()
          if n == 0:
            uids = instring[:16]
          sf, rlen = s.sisfield.SISField(instring[16:], False)
          del instring
          if len(sf.Data.DataUnits) > 1:
              notif(ru(("%s "%s.src_embsis[n])+lang[187-1]),'info')
              continue
          insis.append(sf)
      ctrlfield = insis[0].Controller.Data
      didxfield = ctrlfield.DataIndex
      ctrlfield.DataIndex = None
      if len(ctrlfield.getsignatures()) > 0:
          ctrlfield.setsignatures([])

      for n in xrange(1,len(insis)):
          insis[0].Data.DataUnits.append(insis[n].Data.DataUnits[0])
          insis[n].Controller.Data.DataIndex.DataIndex = n
          ctrlfield.InstallBlock.EmbeddedSISFiles.append(insis[n].Controller.Data)
      string = ctrlfield.tostring()
      string = s.sisfield.stripheaderandpadding(string)
      ctrlfield.DataIndex = didxfield
      outstring = insis[0].tostring()

      f = file(s.outfile, "wb")
      f.write(uids)
      f.write(outstring)
      f.close()

    if s.autosign:
      s.prss.do_progress(prs,ru(lang[106-1]+'...'))
      prs+=1
      e32.ao_yield()
      try:
        global signer
        signer=SignSIS()
        signer.sign(s.outfile)
      except:
        notif(ru(lang[77-1]),'info')
    s.prss.do_progress(prs,ru(lang[154-1]))
    s.prss.end_progress()
    body.color=0
    body.focus=False
    body.set(ru(lang[72-1]+str(s.outfile)+'\n'+lang[146-1]+timer.endtimer()))
    appuifw.app.exit_key_handler = back
    menu(0)
  
class temp:
  a=0
    
def dopacker():
  global packer
  packer=PackSIS()
  if ss.PACKMODE == 'master':
    packer.startmaster()
  elif ss.PACKMODE=='sispkg':
    packer.packinfo()
  
def dopack():
  try:
    packer.packit()
    alert()
    notif(ru(lang[73-1]),'conf')
  except:
    notif(ru(lang[143-1]),'error')
  
def scrkill():
  if ss.SCRKILL == 1:
    apps=appswitch.application_list(1)
    if u'screensaver' in apps:
      try:
        appswitch.kill_app(u'screensaver')
      except:
        notif(ru(lang[79-1]),'error')
    else:
      pass
  else:
    pass

def checksets():
  try:
    settings()
  except:
    os.remove(disk+':\\System\\Apps\\smartSIS\\ss.dat')
    notif(ru(lang[80-1]),'error')
    sys.exit()
    
def settings():
  lastlang=ss.LANG
  if lastlang == 'en':
    lastlang=0
  else:
    lastlang=1
  if ss.LANG=='en':
    iflang=0
  elif ss.LANG=='ru':
    iflang=1
  elif ss.LANG=='cn':
    iflang=2
  if ss.PACKMODE=='master':
    ifpackmode=0
  else:
    ifpackmode=1
  if ss.PATH == 'E':
    path=1
  else:
    path=0
  form=appuifw.Form([
        (ru(lang[81-1]),'combo',([u'C:\\SmartSIS',u'E:\\SmartSIS'],path)),
        (ru(lang[82-1]),'combo',([ru(lang[179-1]),ru(lang[172-1]),ru(lang[173-1])],int(ss.SOUND))),
        (ru(lang[83-1]),'combo',([ru(lang[16-1]),ru(lang[15-1])],int(ss.SCRKILL))),
        (ru(lang[84-1]),'combo',([ru(lang[85-1]),ru(lang[86-1])],ifpackmode)),
        (ru(lang[139-1]),'combo',([ru(lang[140-1]),ru(lang[141-1]),ru(lang[196-1])],iflang)),
        (ru(lang[178-1]),'combo',([ru(lang[16-1]),ru(lang[15-1])],int(ss.AUTOSIGN))),
        (ru(lang[87-1]),'text',ru(ss.CERT)),
        (ru(lang[88-1]),'text',ru(ss.PRIVKEY))],
        appuifw.FFormEditModeOnly|appuifw.FFormDoubleSpaced)
  form.execute()
  uy_pt=form[0][2][1]
  ss.SOUND=int(form[1][2][1])
  uy_scr=form[2][2][1]
  uy_pmode=form[3][2][1]
  uy_lang=form[4][2][1]
  
  if uy_lang == 0:
    ss.LANG='en'
  elif uy_lang == 1:
    ss.LANG='ru'
  elif uy_lang == 2:
    ss.LANG='cn'
    
  if lastlang <> uy_lang:
    notif(ru(lang[142-1]),'info')
  if uy_pt == 0 :
    ss.PATH='C'
  elif uy_pt == 1:
    ss.PATH='E'
    
  if uy_scr == 0:
    ss.SCRKILL=0
  elif uy_scr == 1:
    ss.SCRKILL=1
    
  if uy_pmode == 0:
    ss.PACKMODE='master'
  elif uy_pmode == 1:
    ss.PACKMODE='sispkg'
    
  ss.AUTOSIGN=int(form[5][2][1])
  ss.CERT=ur(form[6][2])
  ss.PRIVKEY=ur(form[7][2])
    
    
  
def checkdir(ph):
  if not os.path.exists(ph):
    os.makedirs(ph)
      
def checkalldir():
  workspace=ss.PATH
  checkdir(workspace+':\\smartSIS\\packed\\')
  checkdir(workspace+':\\smartSIS\\MIFs\\')
  checkdir(workspace+':\\smartSIS\\unpacked\\symbian8\\')
  checkdir(workspace+':\\smartSIS\\unpacked\\symbian9\\')
  checkdir(workspace+':\\smartSIS\\PKGs\\')
  
def quit(act=0):
  if u'screensaver' not in appswitch.application_list(1):
    e32.start_exe('screensaver.exe','',0)
    e32.start_exe('phone.exe','',0)
  try:
    del packer
  except:
    pass
  try:
    del py2sispacker
  except:
    pass
  try:
    del unpacker
  except:
    pass
  try:
    del mifsvger
  except:
    pass
  try:
    del signer
  except:
    pass
  if act == 0:
    sys.exit()

def about():
  notif(ru('SmartSIS '+str(progversion)+' by smart4n\nsmart4n.ucoz.kz'),'info')


  
def back():
  global packer,py2sispacker,unpacker,svg2mifer
  body.color=0x333399
  body.focus=False
  body.font='title'
  body.style=appuifw.HIGHLIGHT_SHADOW
  body.set(ru('\tSmartSIS '+str(progversion)))
  body.style=0
  body.font=mainfont
  try:
    del packer
  except:
    pass
  try:
    del py2sispacker
  except:
    pass
  try:
    del unpacker
  except:
    pass
  try:
    del mifsvger
  except:
    pass
  try:
    del signer
  except:
    pass
  appuifw.app.exit_key_handler = quit
  menu()
  
def help(ccc=0):
  appuifw.app.exit_key_handler = lambda: menu(4)
  body.focus=True
  body.color=0x53c177
  body.font='normal'
  body.set(ru('\t-=SmartSIS '+progversion+'=-\n\n'))
  body.font=mainfont
  body.color=0
  if ccc==0:
    try:
      f=file(helptext+'SS_help_general.txt','rb')
      text=f.read()
      f.close()
    except:
      notif(ru(lang[103-1]),'error')
      return 0
    body.color=0
    body.add(ru(text))
    appuifw.app.body.set_pos(0)
    menu(4)
  elif ccc==1:
    try:
      f=file(helptext+'SS_help_pack.txt','rb')
      text=f.read()
      f.close()
    except:
      notif(ru(lang[103-1]),'error')
      return 0
    body.color=0
    body.add(ru(text))
    appuifw.app.body.set_pos(0)
  elif ccc==2:
    try:
      f=file(helptext+'SS_help_unpack.txt','rb')
      text=f.read()
      f.close()
    except:
      notif(ru(lang[103-1]),'error')
      return 0
    body.color=0
    body.add(ru(text))
    appuifw.app.body.set_pos(0)
  elif ccc==3:
    try:
      f=file(helptext+'SS_help_mif.txt','rb')
      text=f.read()
      f.close()
    except:
      notif(ru(lang[103-1]),'error')
      return 0
    body.color=0
    body.add(ru(text))
    appuifw.app.body.set_pos(0)
  elif ccc==4:
    try:
      f=file(helptext+'SS_help_py2sis.txt','rb')
      text=f.read()
      f.close()
    except:
      notif(ru(lang[103-1]),'error')
      return 0
    body.color=0
    body.add(ru(text))
    appuifw.app.body.set_pos(0)
  elif ccc==5:
    try:
      f=file(helptext+'SS_help_sign.txt','rb')
      text=f.read()
      f.close()
    except:
      notif(ru(lang[103-1]),'error')
      return 0
    body.color=0
    body.add(ru(text))
    appuifw.app.body.set_pos(0)
  elif ccc==6:
    try:
      f=file(helptext+'SS_help_altere32.txt','rb')
      text=f.read()
      f.close()
    except:
      notif(ru(lang[103-1]),'error')
      return 0
    body.color=0
    body.add(ru(text))
    appuifw.app.body.set_pos(0)
  
  
def menu(ttype=0):
  if   ttype==0:
    appuifw.app.menu=[(ru(lang[104-1]),dopacker),(ru(lang[105-1]),dounpack),(ru(lang[106-1]),((ru(lang[107-1]),lambda: dosign(0)),(ru(lang[108-1]),lambda: dosign(1)),(ru(lang[109-1]),lambda: dosign(2)),(ru(lang[175-1]),lambda: dosign(3)))),(ru(lang[174-1]),((ru(lang[110-1]),dopy2sisref),(ru(lang[144-1]),mifandsvg),(ru('altere32'),run_altere32))),(ru(lang[111-1]),checksets),(ru(lang[112-1]),((ru(lang[113-1]),about),(ru(lang[114-1]),help))),(ru(lang[115-1]),quit)]
  elif ttype==1:
    appuifw.app.menu=[(ru(lang[116-1]),dounpack),(ru(lang[117-1]),dounpack_unpack_s9),(ru(lang[118-1]),dounpack_cert),(ru(lang[119-1]),back)]
  elif ttype==2:
    appuifw.app.menu=[(ru(lang[116-1]),dounpack),(ru(lang[117-1]),dounpack_unpack_s8),(ru(lang[119-1]),back)]
  elif ttype==3:
    appuifw.app.menu=[(ru(lang[120-1]),dopack),(ru(lang[121-1]),packer.packinfo),(ru(lang[182-1]),packer.choose_pkg),(ru(lang[119-1]),back)]
  elif ttype==4:
    appuifw.app.menu=[(ru(lang[122-1]),help),(ru(lang[104-1]),lambda: help(1)),(ru(lang[105-1]),lambda: help(2)),(ru(lang[106-1]),lambda: help(5)),(ru(lang[144-1]),lambda: help(3)),(ru(lang[110-1]),lambda: help(4)),(ru(lang[195-1]),lambda: help(6)),(ru(lang[119-1]),back)]
  elif ttype==5:
    appuifw.app.menu=[(ru(lang[120-1]),dopy2sis),(ru(lang[121-1]),py2sispacker.packinfo),(ru(lang[182-1]),py2sispacker.choose_pkg),(ru(lang[119-1]),back)]
  elif ttype==6:
    appuifw.app.menu=[(ru(lang[168-1]),((ru(lang[169-1]),lambda: dosvg2mif(0)),(ru(lang[170-1]),lambda: dosvg2mif(1)))),(ru(lang[171-1]),((ru(lang[169-1]),lambda: domif2svg(0)),(ru(lang[170-1]),lambda: domif2svg(1)))),(ru(lang[119-1]),back)]
  elif ttype==7:
    appuifw.app.menu=[(ru(lang[188-1]),((ru(lang[189-1]),lambda: altere32.set_caps('dev')),(ru(lang[190-1]),lambda: altere32.set_caps('self')),(ru(lang[191-1]),lambda: altere32.set_caps('ch')))),(ru(lang[192-1]),altere32.change_uid),(ru(lang[116-1]),run_altere32),(ru(lang[119-1]),back)]
  
body.color=0x333399
body.font='title'
body.style=appuifw.HIGHLIGHT_SHADOW
body.focus=False
printout(ru('\tSmartSIS '+str(progversion)))
body.style=0
body.font=mainfont
checkalldir()
packer=py2sispacker=mifsvger=unpacker=signer=altere32=temp()
menu()
app_lock = e32.Ao_lock()
appuifw.app.exit_key_handler = quit
app_lock.wait()