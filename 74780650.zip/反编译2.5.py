#coding:utf8
from SisManFMM import manager
from uncompyle2 import main
fileman=manager()
filepath = fileman.AskUser(ext=['.pyc'],mark=1)
if filepath!=None:
    print u'反编译中...'
    main(files=filepath)