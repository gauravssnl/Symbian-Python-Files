import e32,appuifw
from graphics import *

img=0
def redraw(rect):
  if img: canvas.blit(img)

canvas=appuifw.Canvas(redraw_callback=redraw)  
appuifw.app.screen="full"
appuifw.app.body=canvas
img=Image.new((canvas.size))

pic=Image.open(u"e:\\menu.png")
pic_mask=Image.new(pic.size,"L")
pic_mask.blit(pic)

Y=0
def menu(mov):
  global Y
  Y+=mov
  if Y>16: 
    Y=0
  elif Y<0:
     Y=16
  img.clear(0xaade66)
  img.rectangle((0,10+Y*18,canvas.size[0],10+Y*18+18),0xddaa88,0xddaa88)
  for i in range(17):
    img.blit(pic,mask=pic_mask,source=(i*16,0,i*16+16,16), target=(10,10+i*18))
    img.text((30,22+i*18), u"menu item number %i"%i)
  redraw(())

canvas.bind(63497,lambda:menu(-1))
canvas.bind(63498,lambda:menu(1))
canvas.bind(63557,lambda:appuifw.note(u"item number %i"%Y,"info"))

menu(0)

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit

app_lock.wait()
