/*
 * connmgr.cpp
 *
 *  Created on: 2012-9-13
 *      Author: No.2
 */

#include <es_sock.h>
#include <es_enum.h>
#include "Python.h"
#include "symbian_python_ext_util.h"


static PyObject* end_all(PyObject* /*self*/, PyObject * /*args*/)
{
	  RConnection connection;
	  RSocketServ socketServ;
	  TConnectionInfoBuf connInfo;
	  TUint count;
	  TInt stop_status=-2;
	  socketServ.Connect();
	  connection.Open(socketServ);
	  if ( connection.EnumerateConnections(count) == KErrNone )
	    {
	      for (TUint i=1; i<=count; i++)
	        {
	          if ( connection.GetConnectionInfo( i, connInfo ) == KErrNone )
	            {
	              if ( connInfo().iIapId )
	                {
	                  if ( connection.Attach(connInfo, RConnection::EAttachTypeMonitor) == KErrNone )
	                    {
	                	  stop_status=connection.Stop(RConnection::EStopAuthoritative);
	                     }
	                  }
	            }
	        }
	    }
	   
	  connection.Close();
	  socketServ.Close();
      return Py_BuildValue("i", stop_status);
  	
}

static const PyMethodDef connmgr_methods[] =
{
	{"end_all", (PyCFunction)end_all, METH_NOARGS},
	{0, 0} /* sentinel */
};

DL_EXPORT(void) init_connmgr()
{
	//PyObject* module = 
	Py_InitModule("_connmgr", (PyMethodDef*)connmgr_methods);
}

#ifndef EKA2
GLDEF_C TInt E32Dll(TDllReason)
{
	return KErrNone;
}
#endif

