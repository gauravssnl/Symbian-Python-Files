import audiostream
as = audiostream.New()
as.play(u"http://radio.goha.ru:8000/grind.fm")