#include "deflate.h"
//#include "fstream.h"
//#include "ostream.h"
//#include "e32stdm.h" // for 2.2 only
#include "huffman.h"
#include "python.h"
#include "symbian_python_ext_util.h"
#include "h_utl.h"
#include "chinese.h"

#define HEADER_SIZE 156
#define KUidCompressionDeflate  0x101f7afc
#define KImageCrcInit 0xc90fdaa2

//using namespace std;

static PyObject* e32decompress(PyObject* /*self*/, PyObject* args)
{
   char* ifilename;
   char* ofilename;

   if (!PyArg_ParseTuple(args, "ss", &ifilename,&ofilename))
   {
     return NULL;
     }

        FILE* in = fopen(ifilename, "rb");
        if (!in) {
            return Py_BuildValue("i", 1);
        }
        fseek(in, 0, SEEK_END);
        TUint32 len = ftell(in);
        fseek(in, 0, SEEK_SET);

        TUint32 headersize;
TUint8* header = new TUint8[HEADER_SIZE];
fread(header, 1, HEADER_SIZE, in);
        headersize = TUint32(header[0x64]);
        len -= headersize;
        TUint8* data = (TUint8*)PyMem_Malloc(len);  /***must use this,can't is stdc malloc***/
        if (data==NULL) User::Leave(KErrNoMemory);
        fread(data, 1, len, in);
fclose(in);

        TUint32 compression = header[0x1C + 0] | (header[0x1C + 1] << 8) | (header[0x1C + 2] << 16) | (header[0x1C + 3] << 24);
        if (compression != KUidCompressionDeflate) {
            return Py_BuildValue("i", 2);
        }
        header[0x1C + 0] = 0;
        header[0x1C + 1] = 0;
        header[0x1C + 2] = 0;
        header[0x1C + 3] = 0;

        if (headersize==0x9c){
        header[0x14] = KImageCrcInit & 0xff;
        header[0x14 + 1] = (KImageCrcInit >> 8) & 0xff;
        header[0x14 + 2] = (KImageCrcInit >> 16) & 0xff;
        header[0x14 + 3] = (KImageCrcInit >> 24) & 0xff;

        TUint32 crc=0;
        HMem::Crc32(crc,header,HEADER_SIZE);
        header[0x14] = crc & 0xff;
        header[0x14 + 1] = (crc >> 8) & 0xff;
        header[0x14 + 2] = (crc >> 16) & 0xff;
        header[0x14 + 3] = (crc >> 24) & 0xff;
        }

        TBitInput bitInput(data, 8*len);
        CInflater* inflater = CInflater::NewLC(bitInput);

        FILE* out = fopen(ofilename, "wb");

        fwrite(header, HEADER_SIZE, 1, out);
        delete [] header;

        TUint8* outbuf = new(ELeave) TUint8[4096];
while (true) {
        int n = inflater->ReadL(outbuf, 4096);
        if (n <= 0)
            break;
        fwrite(outbuf, n, 1, out);
        }
        fclose(out);

        PyMem_Free(data);
        delete outbuf;
        delete inflater;

        return Py_BuildValue("i", 0);
}

static PyObject* e32compress(PyObject* /*self*/, PyObject* args)
{
   char* ifilename;
   char* ofilename;

   if (!PyArg_ParseTuple(args, "ss", &ifilename,&ofilename))
   {
     return NULL;
     }

        FILE* in = fopen(ifilename, "rb");
        if (!in) {
//                perror(ifilename);
                return Py_BuildValue("i", 1);
        }
        fseek(in, 0, SEEK_END);
        uint32_t len = ftell(in);
        fseek(in, 0, SEEK_SET);

        TUint32 headersize;
        uint8_t* header = new uint8_t[HEADER_SIZE];
        fread(header, HEADER_SIZE, 1, in);
        headersize = TUint32(header[0x64]);
        len -= headersize;
        if (headersize==0x7c) 
                {
                fseek(in, 0x7c, SEEK_SET);
                headersize+=4;
                }
        uint8_t* data = (uint8_t*)PyMem_Malloc(len);/***must use this,can't is stdc malloc***/
        if (data==NULL) User::Leave(KErrNoMemory);
        fread(data, len, 1, in);
        fclose(in);

        uint32_t compression = header[0x1C + 0] | (header[0x1C + 1] << 8) | (header[0x1C + 2] << 16) | (header[0x1C + 3] << 24);
        if (compression != 0) {
                return Py_BuildValue("i", 2);
        }
        header[0x1C + 0] = (KUidCompressionDeflate >> 0)&0xff;
        header[0x1C + 1] = (KUidCompressionDeflate >> 8)&0xff;
        header[0x1C + 2] = (KUidCompressionDeflate >> 16)&0xff;
        header[0x1C + 3] = (KUidCompressionDeflate >> 24)&0xff;

        if (headersize==0x9c)
        {
        header[0x14] = KImageCrcInit&0xff;
        header[0x14 + 1] = (KImageCrcInit >> 8)&0xff;
        header[0x14 + 2] = (KImageCrcInit >> 16)&0xff;
        header[0x14 + 3] = (KImageCrcInit >> 24)&0xff;

        TUint32 crc=0;
        HMem::Crc32(crc,header,HEADER_SIZE);
        header[0x14] = crc&0xff;
        header[0x14 + 1] = (crc >> 8)&0xff;
        header[0x14 + 2] = (crc >> 16)&0xff;
        header[0x14 + 3] = (crc >> 24)&0xff;
        }
        else
        {
        header[0x2f] = 1;
        header[0x7c] = len&0xff;
        header[0x7c + 1] = (len >> 8)&0xff;
        header[0x7c + 2] = (len >> 16)&0xff;
        header[0x7c + 3] = (len >> 24)&0xff;
        }

        FILE* out = fopen(ofilename, "wb");
        fwrite(header, HEADER_SIZE, 1, out);
        delete [] header;

        TUint8* op = new TUint8[0x1000];
        TBitOutput* output=new TBitOutput(op,out);
        DeflateL(data, TInt(len), *output);
        output->FlushL();
fclose(out);

        delete [] op;
        delete output;
        fclose(out);
        PyMem_Free(data);

        return Py_BuildValue("i", 0);
}


static const PyMethodDef E32Methods[] =
{
  {"uncompress", e32decompress, METH_VARARGS},
  {"compress", e32compress, METH_VARARGS},
  {NULL, NULL}
};

DL_EXPORT(void) init_petran()
{
   Py_InitModule("petran",( PyMethodDef *) E32Methods);
}

#ifndef EKA2
GLDEF_C TInt E32Dll( TDllReason )
{
        return KErrNone;
}
#endif


