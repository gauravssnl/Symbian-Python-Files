#ifndef _M_E32STD_H
#define _M_E32STD_H

#include "e32base.h"

typedef TUint16 uintptr_t;
typedef TInt16 intptr_t;
typedef TUint32 uint32_t;
typedef TUint8 uint8_t;

#endif
