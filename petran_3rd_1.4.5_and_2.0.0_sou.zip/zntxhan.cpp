#include <apgtask.h>
#include <eikenv.h>
#include <apgwgnam.h>
#include <apgcli.h>//apgrfx.lib
// not for 2.5 #include "e32stdm.h"
#include <python.h>
#include <symbian_python_ext_util.h>
#include <unicodeobject.h>
#include <baclipb.h>//bafl.lib 
#include <coemain.h>//cone.lib 
#include <txtetext.h>//etext.lib 
#include "deflate.h"
#include "huffman.h"
#include "h_utl.h"
#include "chinese.h"

#define HEADER_SIZE 156
#define KUidCompressionDeflate  0x101f7afc
#define KImageCrcInit 0xc90fdaa2

extern "C" { extern char* CSearchVal(char* iData, int L, char* dir);}

void OpenUrlL(const TDesC& aUrl)
{
 TUint IssysBrower = 0;
 const TInt KBrowserUids[7]={0x2001f848,
	0xa000998f,
	0xa000997f,
	0x200030f4,
	0x200030f3,
	0x1020724d,
	0x10008D39};
 RApaLsSession appArcSession;
 User::LeaveIfError(appArcSession.Connect());// connect to AppArc server
 HBufC* param = HBufC::NewLC( aUrl.Length() + 8 );
// Wap Browser's constants UId
 TApaAppInfo appInfo;
 TUid browserId( TUid::Uid( KBrowserUids[-1] ) );
 for (TInt i=0; i<7; i++){
   browserId = TUid::Uid( KBrowserUids[i] );
   if( appArcSession.GetAppInfo( appInfo, browserId ) == KErrNone )
   {
   if (KBrowserUids[i] < 0x20000000)
    {
     IssysBrower = 1;
    }
   break;
   }
 }
 if (IssysBrower)
   {
    param->Des().Format( _L("4 %S"),&aUrl );
   }
 else{param->Des().Copy( aUrl );}
 TApaTaskList taskList( CEikonEnv::Static()->WsSession() );
 TApaTask task(taskList.FindApp( browserId ));
if( task.Exists() )
 {
// task.KillTask();
 HBufC8* param8 = HBufC8::NewLC( param->Length() * 4 );
 param8->Des().Append( *param );
 if (IssysBrower) task.SendMessage( TUid::Uid( 0 ), *param8 );// Uid is not used
 else {
   task.BringToForeground();
   task.SwitchOpenFile(*param);
   }
 CleanupStack::PopAndDestroy();// param8
 }
else
 {
 TThreadId id;
 appArcSession.StartDocument( *param, browserId, id );
 }
 appArcSession.Close();
 CleanupStack::PopAndDestroy();// param
return;
}

void SetTextToClipBoardL(const TDesC& aText)
{
 CClipboard* cb = CClipboard::NewForWritingLC(CCoeEnv::Static()->FsSession());

 (cb->StreamDictionary()).At(KClipboardUidTypePlainText);

 CPlainText* BPlainText = CPlainText::NewL();
 CleanupStack::PushL(BPlainText);

 BPlainText->InsertL(0,aText);

 BPlainText->CopyToStoreL(cb->Store(), cb->StreamDictionary(), 0, BPlainText->DocumentLength());

 CleanupStack::PopAndDestroy(); // BPlainText
 cb->CommitL();
 CleanupStack::PopAndDestroy(); // cb
}

//

CPlainText* GetTextFromClipBoardL(void)
{
 CPlainText* BPlainText = CPlainText::NewL();
 CleanupStack::PushL(BPlainText);

 CClipboard* cb = CClipboard::NewForReadingL(CCoeEnv::Static()->FsSession());
 CleanupStack::PushL(cb);
 (cb->StreamDictionary()).At(KClipboardUidTypePlainText);

 BPlainText->PasteFromStoreL(cb->Store(), cb->StreamDictionary(), 0);

// the text is now inside the BPlainText 
// cb->CommitL();
 CleanupStack::PopAndDestroy(); // cb?
 CleanupStack::Pop(); // BPlainText
 return BPlainText;
}

//SetClipboard

static PyObject* SetClipboard(PyObject* /*self*/, PyObject *args) 

{ 
 char* InputStr;
 TInt putlen=0;

 if (!PyArg_ParseTuple(args, "u#", &InputStr,&putlen))
        {
        return 0;
        }
 TPtrC16 original((const TUint16*)InputStr, putlen);
 SetTextToClipBoardL(original);
 return Py_None;
}

//GetClipboard

static PyObject* GetClipboard(void) 

{ 
 CPlainText* ptext=GetTextFromClipBoardL();
 TUint16* buffer=new TUint16[ptext->DocumentLength()];
 TPtr16* text=new TPtr16(buffer, ptext->DocumentLength());
 ptext->Extract(*text);
 return Py_BuildValue("u#", (*text).Ptr(), (*text).Length());
}


//SetFileSize

static PyObject* SetFileSize(PyObject* /*self*/, PyObject *args) 

{ 
 char* fname;
 TInt size;
 RFs aFileServerSession;

 aFileServerSession.Connect();

 RFile afile;
 TBool isopen=false;

if (!PyArg_ParseTuple(args, "si", &fname,&size))
        {
        return 0;
        }
 TFileName *filename=new(ELeave)TFileName;
 CleanupStack::PushL(filename);
 TPtrC8 afnm;
 afnm.Set((const TUint8*)fname,strlen(fname));
 filename->Copy(afnm);
 aFileServerSession.IsFileOpen(*filename,isopen);
 if (isopen){
	 CleanupStack::PopAndDestroy(filename);
	 return Py_BuildValue("i",1);
 }
 TInt err=afile.Open(aFileServerSession, *filename, EFileWrite);
 CleanupStack::PopAndDestroy(filename);
 if (err!=KErrNotFound){
    err=afile.SetSize((TInt) size);
 }
 else err=1;
 afile.Close();
 aFileServerSession.Close();
 return Py_BuildValue("i",err);

}

static PyObject* Open_Url(PyObject* /*self*/,PyObject *args) 

{ 
 char* url;// = "http://down2.ucweb.com/download.asp?f=client@mdnn&url=&title=";
 TInt urlen;

if (!PyArg_ParseTuple(args, "u#", &url, &urlen))
        {
        return 0;
        }
 TPtrC16 aurl((const TUint16*) url,urlen);
 OpenUrlL(aurl);
 return Py_None;
}

static PyObject* SearchVal(PyObject* /*self*/, PyObject *args)

{
 char *iData=NULL;
 char *out;
 char *dir=NULL;
 int L=1;

 if (!PyArg_ParseTuple(args, "z#s", &iData, &L, &dir))
        {
        return 0;
        }
 out=CSearchVal(iData, L, dir);

 return Py_BuildValue("s", out);
}

static PyObject* e32compress(PyObject* /*self*/, PyObject* args)
{
//   PyObject* pydata;
   char* ifilename;
   char* ofilename;

   if (!PyArg_ParseTuple(args, "ss", &ifilename,&ofilename))
   {
     return NULL;
     }

        FILE* in = fopen(ifilename, "rb");
        if (!in) {
                return Py_BuildValue("s", "Can't open file");
        }
        fseek(in, 0, SEEK_END);
        uint32_t len = ftell(in);
        fseek(in, 0, SEEK_SET);

	TUint32 headersize;
        uint8_t* header = new(ELeave) uint8_t[HEADER_SIZE];
        fread(header, HEADER_SIZE, 1, in);
	headersize = TUint32(header[0x64]);
	len -= headersize;
	if (headersize==0x7c) 
		{
		fseek(in, 0x7c, SEEK_SET);
		headersize+=4;
		}
        uint8_t* data = (uint8_t*)PyMem_Malloc(len);/***must use this,can't is stdc malloc***/
	if (data==NULL) User::Leave(KErrNoMemory);
        fread(data, 1, len, in);
        fclose(in);

        uint32_t compression = header[0x1C] | (header[0x1C + 1] << 8) | (header[0x1C + 2] << 16) | (header[0x1C + 3] << 24);
        if (compression != 0) {
                return Py_BuildValue("s","Input image not uncompressed!\n");
        }
        header[0x1C] = KUidCompressionDeflate&0xff;
        header[0x1C + 1] = (KUidCompressionDeflate >> 8)&0xff;
        header[0x1C + 2] = (KUidCompressionDeflate >> 16)&0xff;
        header[0x1C + 3] = (KUidCompressionDeflate >> 24)&0xff;
	if (headersize==0x9c)
	{
        header[0x14] = KImageCrcInit&0xff;
        header[0x14 + 1] = (KImageCrcInit >> 8)&0xff;
        header[0x14 + 2] = (KImageCrcInit >> 16)&0xff;
        header[0x14 + 3] = (KImageCrcInit >> 24)&0xff;

        TUint32 crc=0;
        HMem::Crc32(crc,header,HEADER_SIZE);
        header[0x14] = crc&0xff;
        header[0x14 + 1] = (crc >> 8)&0xff;
        header[0x14 + 2] = (crc >> 16)&0xff;
        header[0x14 + 3] = (crc >> 24)&0xff;
	}
	else
	{
        header[0x2f] = 1;
        header[0x7c] = len&0xff;
        header[0x7c + 1] = (len >> 8)&0xff;
        header[0x7c + 2] = (len >> 16)&0xff;
        header[0x7c + 3] = (len >> 24)&0xff;
        }

        FILE* out = fopen(ofilename, "wb");
        fwrite(header, 1, headersize, out);
        delete [] header;

	CProgressNotes* prog=new(ELeave) CProgressNotes();
	prog->ConstructL(TInt(len/6144));

	TUint8* op = new TUint8[0x1000];
	TBitOutput* output=new TBitOutput(op,out,prog);
	DeflateL(data, TInt(len), *output);
	output->FlushL();
	prog->Finishl();
        delete [] op;
	delete output;
        fclose(out);
	PyMem_Free(data);

        return Py_None;
}


static PyObject* e32decompress(PyObject* /*self*/, PyObject* args)
{
//   PyObject* pyfunc;
   char* ifilename;
   char* ofilename;

   if (!PyArg_ParseTuple(args, "ss", &ifilename,&ofilename))
   {
     return NULL;
     }

        FILE* in = fopen(ifilename, "rb");
        if (!in) {
                return Py_BuildValue("s", "Can't open file");
        }
        fseek(in, 0, SEEK_END);
        TUint32 len = ftell(in);
        fseek(in, 0, SEEK_SET);

	TUint32 headersize;
        TUint8* header = new(ELeave) TUint8[HEADER_SIZE];
        fread(header, 1, HEADER_SIZE, in);
	headersize = TUint32(header[0x64]);
	len -= headersize;
	if (headersize==0x7c) {len -= 4;fseek(in, 0x80, SEEK_SET);}
        TUint8* data = (TUint8*)PyMem_Malloc(len);/***must use this,can't is stdc malloc***/
	if (data==NULL) User::Leave(KErrNoMemory);
        fread(data, 1, len, in);
        fclose(in);

        TUint32 compression = header[0x1C] | (header[0x1C + 1] << 8) | (header[0x1C + 2] << 16) | (header[0x1C + 3] << 24);
        if (compression != KUidCompressionDeflate) {
                return Py_BuildValue("s", "Input image not compressed!");
        }
        header[0x1C] = 0;
        header[0x1C + 1] = 0;
        header[0x1C + 2] = 0;
        header[0x1C + 3] = 0;

	if (headersize==0x9c){
        header[0x14] = KImageCrcInit & 0xff;
        header[0x14 + 1] = (KImageCrcInit >> 8) & 0xff;
        header[0x14 + 2] = (KImageCrcInit >> 16) & 0xff;
        header[0x14 + 3] = (KImageCrcInit >> 24) & 0xff;

        TUint32 crc=0;
        HMem::Crc32(crc,header,HEADER_SIZE);
        header[0x14] = crc & 0xff;
        header[0x14 + 1] = (crc >> 8) & 0xff;
        header[0x14 + 2] = (crc >> 16) & 0xff;
        header[0x14 + 3] = (crc >> 24) & 0xff;
	}
        TBitInput bitInput(data, 8*len);
        CInflater* inflater = CInflater::NewLC(bitInput);

        FILE* out = fopen(ofilename, "wb");

        fwrite(header, 1, headersize, out);
        delete [] header;

	TInt ipos=0;
	TBuf<8> decompinfo;//_LIT(aText,"Decompress...");
	iconv(decompinfo,0);
	CProgressNotes* prog=new(ELeave) CProgressNotes();
	prog->ConstructL(TInt(len/2048));

	TUint8* outbuf = new(ELeave) TUint8[4096];
        while (true) {
                int n = inflater->ReadL(outbuf, 4096);
                if (n <= 0)
                        break;
                fwrite(outbuf, 1, n, out);
		ipos+=1;
		prog->UpdateProcessL( ipos, decompinfo);
        }
        fclose(out);

	PyMem_Free(data);
	delete outbuf;
        delete inflater;
	prog->Finishl();

        return Py_None;
}


  static const PyMethodDef SetFileSize_methods[] =
{
	{"setsize", (PyCFunction)SetFileSize, METH_VARARGS, "ZntxPDA\n setsize The file must be closed!"},
	{"setclipboard", (PyCFunction)SetClipboard, METH_VARARGS, "ZntxPDA"},
	{"getclipboard", (PyCFunction)GetClipboard, METH_VARARGS, "ZntxPDA"},
	{"openurl", (PyCFunction)Open_Url, METH_VARARGS, "ZntxPDA"},
        {"exelist", (PyCFunction)SearchVal, METH_VARARGS, "ZntxPDA\nexelist can search a list and save to the given filepath."},
        {"compress", e32compress, METH_VARARGS, "ZntxPDA\n Deflate compress"}, 
        {"uncompress", e32decompress, METH_VARARGS, "ZntxPDA\n Inflate decompress"},
	{NULL,NULL} 
};

DL_EXPORT( void ) init_zntxhanpyd( )
    {
   	Py_InitModule("zntxhanpyd", ( PyMethodDef *) SetFileSize_methods );
    }

#ifndef EKA2
GLDEF_C TInt E32Dll( TDllReason )
{
	return KErrNone;
}
#endif
