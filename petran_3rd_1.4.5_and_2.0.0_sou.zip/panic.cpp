// e32tools\petran\Szip\panic.cpp
//
// Copyright (c) 1998-2004 Symbian Software Ltd. All rights reserved.
//

#include "panic.h"
//#include "h_utl.h"
#include <stdlib.h>
#include <e32std.h>
/*
static const char* HuffmanError[]=	{
						"Huffman: Too many codes\n",
						"Huffman: Invalid coding\n",
						"Huffman: Buffer overflow\n",
						"Huffman: Out Of Memory\n",
						"Huffman: Corrupt File\n",
						};
*/
static const TInt KHuffmanErrorBase=700;

void Panic(TPanic aPanic)
	{
	User::Leave(KHuffmanErrorBase+TInt(aPanic));
	}
