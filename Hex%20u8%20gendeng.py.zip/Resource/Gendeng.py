#author: emjebe

def decompile(f):
 a=open(f).read()
 b=a.replace('+','')
 b=b.replace(';','')
 b=b.replace('"','')
 b=b.replace('\'','')
 b=b.replace(' ','')
 isi=b[b.find('execexec')+8:b.find('.')]
 isi=isi.decode('hex').decode('u8')
 open(f,'w').write(isi)

def compile(f,p):
 a=open(f).read().replace('\r\n','\n')
 isi=a.encode('hex').encode('u8')
 awal="exec'ex'+'ec\"'+'"
 ahir= "\"'+'.'+'dec'+'ode'+'(\"'+'h'+''+''+''+''+''+''+'e'+''+''+''+'x\"'+')'+'.'+'dec'+'ode'+'('+'\"u'+'8\"'+')'"
 n=20
 l=[]
 for i in range(0, len(isi),n):
   x= str(isi[i:n])
   l.append(x+"'+'")#open(p,'a').write(x+"'+'")
   n=n+20
 l= ''.join(l)
 ab= "'"+l+'0000'+"'"
 open(p,'w').write(ab+';'+awal+l+ahir+';'+ab)
 
#sampel
#compile('c:\\b.py', 'c:\\b.py')