#author: emjebe

import appuifw2 as a,e32,powlite_fm, os, gendeng
l=e32.Ao_lock()
a.app.title=u'Hex u8 D/E'
def exit():
 l.signal();a.app.set_exit()
p= powlite_fm.manager()

def tg():
 f=p.AskUser('', ext =['.py'])
 if  not f : return None
 py=os.path.splitext(f)[0]+'_new.py'
 gendeng.compile(f,py)
 a.note(u'Ok')

def gt():
 f=p.AskUser('', ext =['.py'])
 if  not f : return None
 gendeng.decompile(f)
 a.note(u'Ok')

a.app.exit_key_handler=exit
a.app.menu=[(u'py to hex/u8', tg),(u'hex/u8 to py', gt)]
l.wait()