import glprogress, e32

#вызовется при отмене
def cancel(): print "Cancel"

gp=glprogress.New(u"Progress",cancel)

#конечное значение update-101 

for i in range(0,102):
 gp.update(i)
 e32.ao_sleep(0.01)

print 'end'
del gp
