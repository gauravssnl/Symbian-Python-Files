#simple log data connection
#gulam gumal gamul
#http://gumalgamul.mywapblog.com
#debug ram

from appuifw import*;from graphics import*;from e32 import*;import conmonitor,fgimage,time,appswitch

fg=fgimage.FGImage()
def quit():
  global run,runn
  note(unicode('terima kasih'))
  run,runn=0,0
  #app.set_exit()

def fokus(on):
  global fg,run
  if not on:
    fg=fgimage.FGImage()
    run=2
  else:
    fg=0
    run=1

def menu_app():
  m=popup_menu(list(appswitch.application_list(0)),unicode('switch ke'))
  if m!=None:
    appswitch.switch_to_fg(appswitch.application_list(0)[m])
  pass

menu=[(unicode('keluar'),quit)]

app.screen='full'
app.exit_key_handler=menu_app
app.body=c=Canvas()
app.focus=fokus
app.menu=menu
im=Image.new((176,16))
img=Image.new((176,208))
run,runn=1,1
  
class monitor:
  def __init__(self):
    self.t=0
    self.data=[['not active','not active']]
  def draw(self):
    im.clear(0)
    im.text((1,10),u'ccd: '+str(ccd),0xda)
    fg.set(0,0,im._bitmapapi())

teks=['','simple log data','','by: gumalgamul','http://gumalgamul.mywapblog.com','',' thanks:','  agus ibrahim','  group fb: for pys60','  you','','','','minimize untuk melihat log data']

def tulis(lis):
  for i in range(len(lis)):
    img.text((3,10+(i*12)),unicode(''+lis[i]),0xfafafa,u'latinplain12')

rrr=0
a=[
  [0,1,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
  [1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
  [1,1,1,0,1,0,1,0,1,0,0,1,1,0,1,1,1,1,1,0],
  [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0],
  [0,1,1,0,0,1,1,0,1,0,0,1,1,0,1,0,1,0,1,0]]
x,y=10,60

cd=0
gulam=monitor()
t=0
ccd=[]
while runn:
  while run==1:
    img.clear(0)
    img.rectangle((124,190,166,202),0x00ff00,0xffffff)
    img.text((126,200),unicode('minimize'),0xff0000,u'latinplain12')
    if rrr<100: rrr+=10
    if rrr>100: rrr=100
    for yy in range(len(a)):
      Y=yy*8
      for xx in range(len(a[yy])):
        X=xx*8
        if a[yy][xx]:
          img.point((x+X,y+Y),(rrr,rrr,rrr),width=10)
        if a[yy][xx]==0:
          img.point((x+X,y+Y),(rrr,0,0),width=10)
    tulis(teks)
    c.blit(img)
    ao_sleep(0)
  while run==2:
    if t>0: t-=1
    if t<=0:
      cd=conmonitor.get()
      t=1
      ccd.append(cd)
    if len(ccd)>1:
      ccd.pop(0)
    gulam.draw()
    ao_sleep(0)
  ao_yield()