import txtfield,sys,e32,appuifw

sys.setdefaultencoding("utf-8")

canvas=appuifw.Canvas()
appuifw.app.screen="full"
appuifw.app.body=canvas


sz=((30,30,200,90),(5,5,150,80),(55,55,230,180))
color=[0x88bb33,0xeeea55,0x9922ee]
lsw=[txtfield.New(i,cornertype=txtfield.ECorner5) for i in sz]

for i in range(3):
 lsw[i].add(unicode("window %s"%(i+1)))
 lsw[i].bgcolor(color[i])
 lsw[i].shadow(i+1)


def start(x):
 for i in range(3): 
   lsw[i].z_index(i==x and 4 or i+1)


canvas.bind(49, lambda:start(0) )
canvas.bind(50, lambda:start(1) )
canvas.bind(51, lambda:start(2) )

app_lock = e32.Ao_lock() 
def exit(): app_lock.signal()
appuifw.app.exit_key_handler = exit
appuifw.note(u"Press 1,2,3","info")

app_lock.wait()

del lsw