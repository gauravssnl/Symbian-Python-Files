#include <coecntrl.h>
#include <ImageConversion.h>	
//#include <f32file.h>

#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* Get(PyObject* /*self*/,PyObject* args)
{
  
 PyObject* obj_img;
 PyObject* obj_img_mask;
 
 PyObject* obj_filename;
  
 if (!PyArg_ParseTuple(args, "UOO", &obj_filename, &obj_img, &obj_img_mask))
    return NULL;


 CFbsBitmap* img = (CFbsBitmap*)PyCObject_AsVoidPtr(
                    PyObject_CallObject(PyObject_GetAttrString(
                    obj_img,"_bitmapapi"),NULL)); 
 CFbsBitmap* img_mask = (CFbsBitmap*)PyCObject_AsVoidPtr(
                         PyObject_CallObject(PyObject_GetAttrString(
                         obj_img_mask,"_bitmapapi"),NULL));
  
 TPtrC filename((TUint16*) PyUnicode_AsUnicode(obj_filename),
                           PyUnicode_GetSize(obj_filename));
 

  
 CImageDecoder* decoder = CImageDecoder::FileNewL(CCoeEnv::Static()->FsSession(),
                        filename,CImageDecoder::EOptionAlwaysThread); 
 CleanupStack::PushL(decoder);
 
 img->Resize(decoder->FrameInfo().iOverallSizeInPixels);
 img_mask->Resize(decoder->FrameInfo().iOverallSizeInPixels);
 
 TRequestStatus stat = KRequestPending;
 decoder->Convert(&stat, *img, *img_mask);  
 User::WaitForRequest(stat);
   
 CleanupStack::PopAndDestroy(decoder);
     
 Py_INCREF(Py_None);
 return Py_None;
}
 
//--------------------------------------------------------------------------

static const PyMethodDef maskpng_met[] = {
    {"get", (PyCFunction)Get, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
    Py_InitModule("maskpng", maskpng_met);
}

//--------------------------------------------------------------------------
