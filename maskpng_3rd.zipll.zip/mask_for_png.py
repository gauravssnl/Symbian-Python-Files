import e32,appuifw, time
from graphics import *
import maskpng

canvas=appuifw.Canvas()
appuifw.app.screen="full"
appuifw.app.body=canvas

img=Image.new((0,0))
img_mask=Image.new((0,0),'L')
maskpng.get(u'e:\\1g.png',img,img_mask)

canvas.clear(0xffdd99)
canvas.line((30,0,0,30),0x00dd00,width=5)
canvas.line((0,0,30,30),0xdd0000,width=5)

canvas.blit(img,mask=img_mask)

app_lock = e32.Ao_lock() 
def exit():
  app_lock.signal()
appuifw.app.exit_key_handler = exit

app_lock.wait()