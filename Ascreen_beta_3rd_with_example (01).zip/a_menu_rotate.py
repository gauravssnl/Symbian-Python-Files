import ascreen,e32,appswitch,sys,appuifw
sys.setdefaultencoding("utf-8")

w,h=appuifw.Canvas().size
e32.ao_yield()

appswitch.switch_to_fg(unicode("Меню"))
e32.ao_sleep(0.01)

arr=ascreen.get([],(40,40,w-40,w-40) )


for i in range(30):
 #ascreen.rotate((40,40,w-40,w-40),i, 20,20)
 ascreen.rotate_array((40,40,w-40,w-40),arr,i, (20,20))
 ascreen.redraw()
 e32.ao_yield()
 