import math,time,e32,ascreen
import appuifw
from graphics import *

appuifw.app.screen='full'
canvas=appuifw.Canvas()
appuifw.app.body=canvas
we,he=canvas.size
img=Image.new((we,he))
img.clear(0xbabafa)
img.text((10,20),u"Python",font="title")
img.rectangle((50,50,140,150),0x22dd22,0x22dd22)

canvas.blit(img)
e32.ao_yield()
#e32.ao_sleep(2)

ascreen.line((50,60,200,90),0x88000000)

ascreen.pieslice((130,250,180,300),90,360,0x995511)

ascreen.arc((5,5,205,305),30,210,0x2222ff)

ascreen.line((15,30,240,230),0xaa2233dd)

ascreen.line((10,100,220,110),0xaa992233)

ascreen.line((1,30,240,20),0x9922aa22)

ascreen.ellipse((10,10,100,100),0xff225522)

ascreen.ellipse((150,10,200,300),0x11ddaa22)
ascreen.redraw()
e32.ao_sleep(5)

