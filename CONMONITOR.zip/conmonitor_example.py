import conmonitor
listm = conmonitor.get()
if listm: # if there are connections of
  for i in listm:
    print i[0] # connection IAP name
    print i[1] # connection IAP ID
    print i[2] # connection downlink data (in bytes)
    print i[3] # connection uplink data (in bytes)
    print i[4] # 1- if the connection is active, else- 0
else:
  print "No active connections"