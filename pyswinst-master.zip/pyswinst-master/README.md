This is `pyswinst`, a Python for S60 extension for
programmatic, non-interactive application installation.

http://new.contextlogger.org/pyswinst/
