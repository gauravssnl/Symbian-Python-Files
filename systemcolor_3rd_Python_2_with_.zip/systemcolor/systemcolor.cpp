#include <fbs.h> //CFbsBitmap
#include <aknsskininstance.h> //MAknsSkinInstance
#include <aknsutils.h> //AknsUtils

#include "Python.h"
#include "symbian_python_ext_util.h"

//--------------------------------------------------------------------------

static PyObject* GetTextColor(PyObject* /*self*/,PyObject* args)
{
  TUint index;
  if (!PyArg_ParseTuple(args, "i", &index))
    return NULL;

  TRgb color;
  
  MAknsSkinInstance* skin = AknsUtils::SkinInstance();
  AknsUtils::GetCachedColor(skin, color, KAknsIIDQsnTextColors, index);

  return Py_BuildValue("(iii)",color.Red(),color.Green(),color.Blue());
}
//--------------------------------------------------------------------------

static PyObject* GetBitmap(PyObject* /*self*/,PyObject* args)
{
  TUint index, x, y;
  if (!PyArg_ParseTuple(args, "(ii)i", &x, &y, &index))
    return NULL;

  TAknsItemID id = { EAknsMajorSkin, index };

  MAknsSkinInstance* skin = AknsUtils::SkinInstance();
  CFbsBitmap* bitmap(NULL);
  TRAPD(err,bitmap = AknsUtils::CreateBitmapL(skin, id));
  //CFbsBitmap* bitmap = AknsUtils::GetCachedBitmap( skin, id );
  //CApaMaskedBitmap* bitmap = AknsUtils::CreateMaskedBitmapL(skin, id);
  if(bitmap)
  {
    AknIconUtils::SetSize(bitmap, TSize(x,y),EAspectRatioPreservedAndUnusedSpaceRemoved);
    //AknIconUtils::SetSize(bitmap, bitmap->SizeInPixels());
    return Py_BuildValue("O",PyCObject_FromVoidPtr(bitmap, NULL));
  }

  Py_INCREF(Py_None);
  return Py_None;
}
//--------------------------------------------------------------------------

static const PyMethodDef systemcolor_met[] = {
    {"text", (PyCFunction)GetTextColor, METH_VARARGS},
    {"bitmap", (PyCFunction)GetBitmap, METH_VARARGS},
    {0, 0}
};

//--------------------------------------------------------------------------

DL_EXPORT(void) MODULE_INIT_FUNC()
{
   Py_InitModule("systemcolor", (PyMethodDef*)systemcolor_met);
}

//--------------------------------------------------------------------------
