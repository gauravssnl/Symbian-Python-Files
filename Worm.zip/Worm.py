# -*- coding: utf-8 -*-
# простой скрипт, разрушение уровня. Стрельба-кнопкой '5', управление-'2' и '8'

import appuifw,e32
from graphics import *

# создаем два буфера, один-для карты, второй для пушки и снаряда
img=Image.new((176,208))
map=Image.new((176,208))

appuifw.app.screen='full'
appuifw.app.body=k=appuifw.Canvas()

global x,y,x1,y1,fire
x,y=5,50 # координаты пушки
x1,y1=13,53 # координаты снаряда
fire=0 # флаг выстрела

map.clear((200,200,200))
map.rectangle((100,30,170,150),0x0000ff,0x0000ff)
# рисуем фон и мишень

def draw():
  global x,y,x1,y1,fire
  img.blit(map) # рисуем буфер фона с мишенью в буфер пушки и снаряда
  img.rectangle((x,y,x+10,y+10),0x000000,0x000000) # пушка
  img.point((x1,y1),0x000000,0x000000,width=5) # снаряд
  k.blit(img) # рисуем все в канвас

def pula_letit():
  global x,y,x1,y1,fire
  if fire==1: # если выстрел был
    x1+=1   # то продвигаем пулю
    if map.getpixel((x1,y1))[0]==(0,0,255): # проверяем цвет буфера карты под пулей
      map.point((x1,y1),(200,200,200),(200,200,200),width=20) # если там цвет мишени, то рисуем круг фонового цвета.
      fire=0 # опускаем флаг выстрела, если этой строки не будет, то пуля пройдет насквозь :) 
      x1,y1=x+3,y+3 # возвращаем пулю в ствол пушки
    if x1>176: # если пуля улетела за экран
      fire=0 # возвращаем все
      x1,y1=x+3,y+3

def down():
  global x,y,x1,y1,fire
  y+=3
  if fire==0:y1+=3 #если пуля не летит, то двигаем ее вместе с пушкой
def up():
  global x,y,x1,y1,fire
  y-=3
  if fire==0:y1-=3

def f(): # ф-ция выстрела
  global x,y,x1,y1,fire
  fire=1 # поднимаем флаг, пуля полетела
  while fire==1:
    draw()
    pula_letit()
    k.bind(50,up)
    k.bind(56,down)
    e32.ao_sleep(0.01)
    # пока пуля летит, прорисовываем, проверяем состояние пули и можем двигать пушку

while 1: # прорисовываем,  можем двигать пушку и стрелять
 draw()
 k.bind(50,up)
 k.bind(53,f)
 k.bind(56,down)
 pula_letit()
 e32.ao_sleep(0.01)

