import appuifw
appuifw.query(u'Do you want to continue?','query')
appuifw.note(u'I love python')